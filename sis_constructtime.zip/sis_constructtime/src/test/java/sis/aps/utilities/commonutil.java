package sis.aps.utilities;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;

public class commonutil {

	public static void selectDropDownValueBasedOnVisibleText(List<WebElement> elements, String id, String name) {

		for (WebElement w : elements) {

			if (w.getAttribute("innerHTML").contains(id) && w.getAttribute("innerHTML").contains(name)) {

				w.click();

				break;
			}

			else {

				System.out.println("Expected value not found in dropdown");
			}
		}
	}

	public static void fileupload(String filePath) {

		ProcessBuilder pb = new ProcessBuilder(System.getProperty("user.dir") + "\\excel\\upload.exe", filePath);
		try {
			pb.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

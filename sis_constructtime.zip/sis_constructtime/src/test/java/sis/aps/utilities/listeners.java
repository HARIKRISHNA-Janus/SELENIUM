package sis.aps.utilities;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class listeners extends TestListenerAdapter {
	
	public ExtentSparkReporter htmltemplate;
	public ExtentReports reportmsg;
	public ExtentTest status;
	
	@Override
	public void onStart(ITestContext tr)
	{
		String timestamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		//String repname="Test-Report-"+timestamp+".html";
		String repname="Test-Report.html";
		htmltemplate=new ExtentSparkReporter(System.getProperty("user.dir")+"/test-output/"+repname);
		try {
			htmltemplate.loadXMLConfig(System.getProperty("user.dir")+"/extent-config.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		reportmsg=new ExtentReports();
		reportmsg.attachReporter(htmltemplate);
		reportmsg.setSystemInfo("Environment", "QA Environement");
		reportmsg.setSystemInfo("Build Number", "1.1.1");
		reportmsg.setSystemInfo("Reporter Name", "Suresh");
		htmltemplate.config().setDocumentTitle("Automation Test Report");
		htmltemplate.config().setReportName("sis-aps automation test report");
		htmltemplate.config().setTheme(Theme.DARK);
	}
	@Override
	public void onTestSuccess(ITestResult tr)
	{
		status=reportmsg.createTest(tr.getName());
		status.log(Status.PASS, MarkupHelper.createLabel(tr.getName(), ExtentColor.GREEN));
	}
	@Override
	public void onTestFailure(ITestResult tr)
	{
		status=reportmsg.createTest(tr.getName());
		status.log(Status.PASS, MarkupHelper.createLabel(tr.getName(), ExtentColor.RED));
		String screenshotpath=System.getProperty("user.dir")+"/screenshots/"+tr.getName()+".png";
		status.fail("Screenshot for the error page is "+status.addScreenCaptureFromPath(screenshotpath));
	}
	@Override
	public void onTestSkipped(ITestResult tr)
	{
		status=reportmsg.createTest(tr.getName());
		status.log(Status.PASS, MarkupHelper.createLabel(tr.getName(), ExtentColor.ORANGE));
	}
	@Override
	public void onFinish(ITestContext tr)
	{
		reportmsg.flush();
	}
}

package sis.aps.testcases;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import sis.aps.utilities.XLUtils;
import sis.aps.utilities.readconfig;

public class baseclass {

	public WebDriver driver;
	public static Logger logger;

	readconfig rd = new readconfig();

	// public String baseurl=rd.getappurl();
	public String baseurl=rd.getxlurl();
	public String browser = rd.getbrowser();
	public String username = rd.getusername();
	public String password = rd.getpassword();
	public String excelpath="./excel/TestData.xlsx";
    public String sheet1="LoginDetails";
    public String sheet2="MyTimesheet";
    public String sheet3="CrewTemplate";
	public String sheet4="AllNewCrewTimesheet";
	public String sheet5="CrewTemplateTimesheets";
    public String sheet6="NewAllCrew";
	
    

	@BeforeClass
	public void setup() throws InterruptedException, IOException {
		logger = Logger.getLogger(getClass());
		PropertyConfigurator.configure("log4j.properties");
		System.setProperty("webdriver.chrome.driver", browser);
		/*
		 * ChromeOptions options=new ChromeOptions(); options.setHeadless(true);
		 * driver=new ChromeDriver(options);
		 */
	   
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// logger.info("Invoked Application URL");
		// Added by ram on 17th june to get URL from test data - excel
		//String baseurl = XLUtils.getCellData(System.getProperty("user.dir") + "\\excel\\TestData.xlsx","LoginDetails", 1, 0);
		
		
		//String baseurl=XLUtils.getCellData(excelpath, sheet1, 1, 0);
		Thread.sleep(1000);
		driver.get(baseurl);
		Thread.sleep(6000);
		driver.findElement(By.xpath("//button[@id='kt_login_signin_submit']")).click();
	}

	@AfterClass
	public void closebrowser() {
		//driver.close();
		logger.info("Browser Closed");
	}

	@AfterMethod
	public void capturescreenshots(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			File target = new File(System.getProperty("user.dir") + "/screenshots/" + result.getName() + ".png");
			FileUtils.copyFile(source, target);
		}
	}

}

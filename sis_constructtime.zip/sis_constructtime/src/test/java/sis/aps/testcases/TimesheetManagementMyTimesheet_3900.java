package sis.aps.testcases;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.TimeManagement_Timesheets_AllTimesheets_pom;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class TimesheetManagementMyTimesheet_3900 extends baseclass {

	@Test
	public void createMyTimesheet() throws InterruptedException, IOException {

		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom timesheet = new leftmenu_pom(driver);
		Thread.sleep(3000);
		login.setUserName(
				XLUtils.getCellData(System.getProperty("user.dir") + "\\excel\\TestData.xlsx", "LoginDetails", 1, 1));
		login.setPasword(
				XLUtils.getCellData(System.getProperty("user.dir") + "\\excel\\TestData.xlsx", "LoginDetails", 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(3000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		Thread.sleep(30000);

		leftmenuObj.clickorganizationsetuptab();
		Thread.sleep(2000);

		leftmenuObj.clkOrganizationtab();
		Thread.sleep(2000);

		leftmenuObj.clkCompaniestab();
		Thread.sleep(2000);

		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);

		leftmenuObj.clicktimesheetstab();
		Thread.sleep(2000);

		leftmenuObj.clkMytimesheetstab();
		Thread.sleep(2000);

		constructsmokeMyTimesheet_pom csmObj = new constructsmokeMyTimesheet_pom(driver);

		if (csmObj.checkProjectId_search_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Project ID Search field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Project ID Search field is not displayed");
		}

		if (csmObj.checkStatus_search_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Status Search field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Status Search field is not displayed");
		}

		Thread.sleep(2000);

		leftmenuObj.clickNewtimesheetsbtn();

		Thread.sleep(2000);

		if (csmObj.checkHeader_tab_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Header tab is displayed");
		}

		else {

			Assert.fail();
			logger.info("Header tab is not displayed");
		}

		if (csmObj.checkHours_tab_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Hours tab is displayed");
		}

		else {

			Assert.fail();
			logger.info("Hours tab is not displayed");
		}

		if (csmObj.checkFieldExpenses_tab_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Field Expenses tab is displayed");
		}

		else {

			Assert.fail();
			logger.info("Field Expenses tab is not displayed");
		}

		if (csmObj.checkEquipment_tab_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Equipment tab is displayed");
		}

		else {

			Assert.fail();
			logger.info("Equipment tab is not displayed");
		}

		if (csmObj.checkProduction_tab_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Production tab is displayed");
		}

		else {

			Assert.fail();
			logger.info("Production tab is not displayed");
		}

		if (csmObj.checkBack_button_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Back button is displayed");
		}

		else {

			Assert.fail();
			logger.info("Back button is not displayed");
		}

		if (csmObj.checkSave_button_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Save button is displayed");
		}

		else {

			Assert.fail();
			logger.info("Save button is not displayed");
		}

		if (csmObj.check_Date_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Date Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Date Field is not displayed");
		}

		if (csmObj.check_Worker_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Worker Field is not displayed");
		}

		if (csmObj.check_Description_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Description Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Description Field is not displayed");
		}

		if (csmObj.check_Project_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Project Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Project Field is not displayed");
		}

		if (csmObj.check_ProjectName_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Project Name Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Project Name Field is not displayed");
		}

		if (csmObj.check_Status_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Status Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Status Field is not displayed");
		}

		if (csmObj.check_Notes_Field_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Notes Field is displayed");
		}

		else {

			Assert.fail();
			logger.info("Notes Field is not displayed");
		}

		if (csmObj.checkWorkerField_isDisabled() == true) {
			Assert.assertTrue(true);
			logger.info("Worker Field is disabled");
		}

		else {

			Assert.fail();
			logger.info("Worker Field is not disabled");
		}

		Thread.sleep(2000);

		if (csmObj.checkDescriptionField_isDisabled() == true) {
			Assert.assertTrue(true);
			logger.info("Description Field is disabled");
		}

		else {

			Assert.fail();
			logger.info("Description Field is not disabled");
		}

		if (csmObj.checkStatusField_isDisabled() == true) {
			Assert.assertTrue(true);
			logger.info("Status Field is disabled");
		}

		else {

			Assert.fail();
			logger.info("Status Field is not disabled");
		}

		Thread.sleep(2000);

		csmObj.clickUserProfileIcon();

		Thread.sleep(2000);

		if (csmObj.checkLoginUserNameFromProfile().equals(csmObj.checkWorkerFieldValue().replaceAll("\\s+", ""))) {
			Assert.assertTrue(true);
			logger.info("Worker Name matches with Profile Name");
		}

		else {
			logger.info("Expected Worker Name:" + csmObj.checkLoginUserNameFromProfile());

			logger.info("Actual Worker Name:" + csmObj.checkWorkerFieldValue().replaceAll("\\s+", ""));

			logger.info("Worker Name does not matches with Profile Name");

			Assert.fail();

		}

		csmObj.clickUserProfileIcon();

		Thread.sleep(2000);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDateTime now = LocalDateTime.now();
		String TodayDate = dtf.format(now);

		String ExpectedDescription = TodayDate + " " + "Timesheet for" + " " + csmObj.checkWorkerFieldValue();

		String ActualDescription = csmObj.checkDescriptionFieldValue();

		logger.info("Actual Description:" + ActualDescription);

		logger.info("Expected Description:" + ExpectedDescription);

		if (ActualDescription.equals(ExpectedDescription)) {
			Assert.assertTrue(true);
			logger.info("Description value is displayed as expected");

		}

		else {

			logger.info("Description value is not displayed as expected");

			Assert.fail();

		}

		if (csmObj.checkStatusFieldValue().equals("Draft")) {
			Assert.assertTrue(true);
			logger.info("Status value is displayed as Draft expected");

		}

		else {

			logger.info("Status value is not displayed as Draft expected");

			Assert.fail();

		}

		/*
		 * String DateFieldValue = csmObj.checkDateValue();
		 * 
		 * DateFieldValue = dtf.format(now);
		 * 
		 * 
		 * 
		 * if (TodayDate.equals(csmObj.checkDateValue())) { Assert.assertTrue(true);
		 * logger.info("Date value is displayed as expected");
		 * 
		 * }
		 * 
		 * else {
		 * 
		 * 
		 * logger.info("Actual Date:" + csmObj.checkDateValue());
		 * 
		 * logger.info("Expected Date:" + TodayDate);
		 * 
		 * logger.info("Date value is not displayed as expected");
		 * 
		 * Assert.fail();
		 * 
		 * 
		 * }
		 */

		Thread.sleep(2000);

		String ProjectID = XLUtils.getCellData(System.getProperty("user.dir") + "\\excel\\TestData.xlsx", "MyTimeSheet",
				1, 1);

		String ProjectName = XLUtils.getCellData(System.getProperty("user.dir") + "\\excel\\TestData.xlsx",
				"MyTimeSheet", 1, 2);

		//csmObj.setProject(ProjectID, ProjectName);

		Thread.sleep(2000);

		csmObj.clickSaveBtn();

		Thread.sleep(2000);

		csmObj.clickAddButton();

		Thread.sleep(2000);

	}
}

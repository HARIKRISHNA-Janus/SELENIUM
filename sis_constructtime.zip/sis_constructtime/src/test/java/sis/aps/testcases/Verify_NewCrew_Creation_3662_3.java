package sis.aps.testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.TimeManagement_Crews_AllCrews;
import sis.ct.pageobjects.TimeManagement_Crews_MyCrews;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class Verify_NewCrew_Creation_3662_3 extends baseclass { 

	String crewId;

	String crewDescription;

	String crewForemanpersonnelNo;

	String crewForemanName;

	String ProjectID_1;

	String ProjectID_2;

	String ProjectID_3;

	String TaskDeleted;

	TimeManagement_Crews_MyCrews mcObj;

	TimeManagement_Crews_AllCrews acObj;

	leftmenu_pom leftmenuObj;

	common_pom cm;

	List<String> TaskListDashboard;

	List<String> TaskListSelected_Project1;

	List<String> TaskListSelected_Project2;

	List<String> ExpectedTaskList_Project1;

	List<String> ExpectedTaskList_Project2;

	List<String> ExpectedTaskList_Project3;

	List<String> TaskListEditForm;

	@Test(priority = 1)
	public void Verify_New_Crew_Creation_3662() throws InterruptedException, IOException, Exception { 

		loginpage_pom login = new loginpage_pom(driver);
		// leftmenu_pom timesheet = new leftmenu_pom(driver);
		Thread.sleep(3000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		//Thread.sleep(90000);
		Thread.sleep(10000);

		login.clkSignin();
		//Thread.sleep(5000);
		Thread.sleep(30000);


		leftmenuObj = new leftmenu_pom(driver);

		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);

		leftmenuObj.clickCrewstab();
		Thread.sleep(2000);

		leftmenuObj.clkMyCrewstab();
		Thread.sleep(2000);

		mcObj = new TimeManagement_Crews_MyCrews(driver);
		acObj = new TimeManagement_Crews_AllCrews(driver);

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}
		Thread.sleep(2000);

		if (mcObj.checksearchInput_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews search input field displayed");
		}

		else {

			logger.info("My crews search input field not displayed");
			Assert.fail();
		}

		if (mcObj.checkSourcedropdown_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews source dropdown field displayed");
		}

		else {

			logger.info("My crews source dropdown field not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewId_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew id column header displayed");
		}

		else {

			logger.info("My crews crew id column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew description column header displayed");
		}

		else {

			logger.info("My crews crew description column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanfirstname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman first name column header displayed");
		}

		else {

			logger.info("My crews crew foreman first name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanlastname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman last name column header displayed");
		}

		else {

			logger.info("My crews crew foreman last name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanpersonnelnumber_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman personnel number column header displayed");
		}

		else {

			logger.info("My crews crew foreman personnel number column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		mcObj.clickNewcrewbtn();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Back button displayed");
		}

		else {

			logger.info("My Crew details tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Resetbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Reset button displayed");
		}

		else {

			logger.info("My Crew details tab - Reset button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Savebtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Save button displayed");
		}

		else {

			logger.info("My Crew details tab - Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewdetails_Tabenabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Enabled");
		}

		else {

			logger.info("My Crew details tab - Disabled");
			Assert.fail();
		}

		if (mcObj.check_crewmembers_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Disabled");
		}

		else {

			logger.info("My Crew members tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewprojecttask_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew project task tab - Disabled");
		}

		else {

			logger.info("My Crew project task tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewId_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id field - Present");
		}

		else {

			logger.info("My Crew - Crew id field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew description field - Present");
		}

		else {

			logger.info("My Crew - Crew description field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanpersonnelnumber_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crewforeman personnel number field - Present");
		}

		else {

			Assert.fail();
			logger.info("My Crew - Crewforeman personnel number field - Not Present");
		}

		if (mcObj.check_crewFormanname_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew foreman name field - Present");
		}

		else {

			logger.info("My Crew - Crew foreman name field - Not Present");
			Assert.fail();

		}

		Thread.sleep(1000);
		mcObj.clickSavebtn();
		Thread.sleep(3000);

		if (mcObj.check_alertmessage_isdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew details tab alert message - displayed");
		}

		else {

			logger.info("My Crew - Crew details tab alert message - not displayed");
			Assert.fail();
		}

//		Thread.sleep(2000);

		if (mcObj.check_crewidinput_fielderrormessage_isdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id input field error message - displayed");
		}

		else {

			logger.info("My Crew - Crew id input field error message - not displayed");
			Assert.fail();

		}

		/* APPLICATION Error */

//		if (mcObj.check_crewpersonnelno_inputfielderrormessage_isdisplayed() == true) {
//			Assert.assertTrue(true);
//			logger.info("My Crew - Foreman personnel number input field error message - displayed");
//		}
//
//		else {
//			
//			logger.info("My Crew -  Foreman personnel number input field error message - not displayed");
//			Assert.fail();
//			
//		}

		crewId = XLUtils.getCellData(excelpath, sheet6, 2, 0);
		crewDescription = XLUtils.getCellData(excelpath, sheet6, 2, 1);

		acObj.setCrewid(crewId);
		Thread.sleep(2000);

		acObj.setCrewdescription(crewDescription);
		Thread.sleep(2000);

		crewForemanpersonnelNo = XLUtils.getCellData(excelpath, sheet6, 2, 2);

		acObj.setCrewformanpersonnelno(crewForemanpersonnelNo);
		Thread.sleep(2000);

		cm = new common_pom(driver);

		cm.selectDropDownValue(crewForemanpersonnelNo);
		Thread.sleep(2000);

		crewForemanName = XLUtils.getCellData(excelpath, sheet6, 2, 3);

		String foremanName = driver.findElement(By.xpath("//input[@data-placeholder='Foreman name']"))
				.getAttribute("value");
		System.out.println("Crew Foreman Name = " + foremanName);

		if (crewForemanName.equals(foremanName)) {

			Assert.assertTrue(true);
			logger.info("Crew foreman displayed and equal");
		}

		else {

			logger.info("Crew foreman not equal / not displayed");
			Assert.fail();
		}

		String defaultcrew = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");

		if (defaultcrew.equals("false")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - Unchecked");
		}

		else {

			logger.info("Default crew checkbox - checked");
			Assert.fail();
		}

		mcObj.clickResetbtn();
		Thread.sleep(1000);

		mcObj.clickBackbtn();
		Thread.sleep(2000);

//		if (acObj.checkcrew_created_msg_displayed() == true) 
//		{
//			Assert.assertTrue(true);
//			logger.info("Crew created message is displayed");
//		}
//
//		else 
//		{
//
//			Assert.fail();
//			logger.info("Crew created message is not displayed");
//		}
//		
//		logger.info("createMyNewcrew_Fillthedetails_2826 ==> Method Executed");

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}
		Thread.sleep(2000);

		if (mcObj.checksearchInput_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews search input field displayed");
		}

		else {

			logger.info("My crews search input field not displayed");
			Assert.fail();
		}

		if (mcObj.checkSourcedropdown_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews source dropdown field displayed");
		}

		else {

			logger.info("My crews source dropdown field not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewId_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew id column header displayed");
		}

		else {

			logger.info("My crews crew id column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew description column header displayed");
		}

		else {

			logger.info("My crews crew description column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanfirstname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman first name column header displayed");
		}

		else {

			logger.info("My crews crew foreman first name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanlastname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman last name column header displayed");
		}

		else {

			logger.info("My crews crew foreman last name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanpersonnelnumber_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman personnel number column header displayed");
		}

		else {

			logger.info("My crews crew foreman personnel number column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		mcObj.clickNewcrewbtn();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Back button displayed");
		}

		else {

			logger.info("My Crew details tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Resetbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Reset button displayed");
		}

		else {

			logger.info("My Crew details tab - Reset button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Savebtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Save button displayed");
		}

		else {

			logger.info("My Crew details tab - Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewdetails_Tabenabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Enabled");
		}

		else {

			logger.info("My Crew details tab - Disabled");
			Assert.fail();
		}

		if (mcObj.check_crewmembers_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Disabled");
		}

		else {

			logger.info("My Crew members tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewprojecttask_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew project task tab - Disabled");
		}

		else {

			logger.info("My Crew project task tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewId_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id field - Present");
		}

		else {

			logger.info("My Crew - Crew id field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew description field - Present");
		}

		else {

			logger.info("My Crew - Crew description field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanpersonnelnumber_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crewforeman personnel number field - Present");
		}

		else {

			logger.info("My Crew - Crewforeman personnel number field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanname_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew foreman name field - Present");
		}

		else {

			logger.info("My Crew - Crew foreman name field - Not Present");
			Assert.fail();
		}

		acObj.setCrewid(crewId);
		Thread.sleep(2000);

		acObj.setCrewdescription(crewDescription);
		Thread.sleep(2000);

		acObj.setCrewformanpersonnelno(crewForemanpersonnelNo);
		Thread.sleep(2000);

		cm.selectDropDownValue(crewForemanpersonnelNo);
		Thread.sleep(2000);

		String foremanName2 = driver.findElement(By.xpath("//input[@data-placeholder='Foreman name']"))
				.getAttribute("value");
		System.out.println("Crew Foreman Name = " + foremanName2);

		if (crewForemanName.equals(foremanName2)) {

			Assert.assertTrue(true);
			logger.info("Crew foreman displayed and equal");
		}

		else {

			logger.info("Crew foreman not equal / not displayed");
			Assert.fail();
		}

		String defaultcrew2 = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");
		System.out.println("Default crew checjbox = " + defaultcrew2);

		if (defaultcrew2.equals("false")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - Unchecked");
			mcObj.clickDefaultcrewcheckbox();
			logger.info("Default crew checkbox ==> checked");
		}

		else {

			logger.info("Default crew checkbox - checked");
			Assert.fail();
		}

		Thread.sleep(3000);
		mcObj.clickSavebtn();
		Thread.sleep(2000);

		if (mcObj.check_editcrew_headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - edit crew header - displayed");
		}

		else {

			logger.info("My Crew -  edit crew header - Not displayed");
			Assert.fail();
		}

		String defaultcrew3 = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");
		System.out.println("Default crew checjbox = " + defaultcrew3);

		if (defaultcrew3.equals("true")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - checked");

		}

		else {
			logger.info("Default crew checkbox - Unchecked");
			Assert.fail();
		}

		mcObj.clickBackbtn();
		Thread.sleep(2000);

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}

		acObj.searchCrew(XLUtils.getCellData(excelpath, sheet6, 2, 0));
		Thread.sleep(3000);

		String gCrewid = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[1]/a[1]")).getText();
		System.out.println("Crew id " + gCrewid);

		if (gCrewid.equals(XLUtils.getCellData(excelpath, sheet6, 2, 0))) {
			Assert.assertTrue(true);
			logger.info("Crew id - Equals");
		} else {
			logger.info("Crew id - Not Equals");
			Assert.fail();
		}

		String gCrewdecription = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[2]/a[1]")).getText();
		System.out.println("Crew description " + gCrewdecription);

		if (gCrewdecription.equals(XLUtils.getCellData(excelpath, sheet6, 2, 1))) {
			Assert.assertTrue(true);
			logger.info("Crew description - Equals");
		} else {
			logger.info("Crew description - Not Equals");
			Assert.fail();
		}

		String gCrewforeman1stname = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[3]")).getText();
		System.out.println("Crew foreman first name " + gCrewforeman1stname);

		if (gCrewforeman1stname.equals(XLUtils.getCellData(excelpath, sheet6, 2, 8))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman first name - Equals");
		} else {

			logger.info("Crew foreman first name - Not Equals");
			Assert.fail();
		}

		String gCrewforemanlaststname = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[4]")).getText();
		System.out.println("Crew foreman last name " + gCrewforemanlaststname);

		if (gCrewforemanlaststname.equals(XLUtils.getCellData(excelpath, sheet6, 2, 9))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman last name - Equals");
		} else {
			logger.info("Crew foreman last name - Not Equals");
			Assert.fail();
		}

		String gCrewforemanpersonnelNo = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[5]")).getText();
		System.out.println("Crew foreman personnel " + gCrewforemanpersonnelNo);

		if (gCrewforemanpersonnelNo.equals(XLUtils.getCellData(excelpath, sheet6, 2, 2))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman personnel number - Equals");
		} else {

			logger.info("Crew foreman personnel number - Not Equals");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_viewcrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews view button displayed");
		}

		else {

			logger.info("My crews view button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Editcrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Edit button displayed");
		}

		else {

			logger.info("My crews Edit button not displayed");
			Assert.fail();
		}

		if (mcObj.check_deletecrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews delete button displayed");
		}

		else {

			logger.info("My crews delete button not displayed");
			Assert.fail();
		}

	}

	@Test(priority = 2, dependsOnMethods = { "Verify_New_Crew_Creation_3662" })
	public void Verify_Add_Crew_Members_3667() throws InterruptedException, IOException, Exception {

		mcObj.click_Mycrew_Editbutton();
		Thread.sleep(2000);

		mcObj.clickcrewmembers_tab();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Back button displayed");
		}

		else {

			logger.info("My Crew members tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Add_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Add button displayed");
		}

		else {

			logger.info("Add button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Edit_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Edit button displayed");
		}

		else {

			logger.info("Edit button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Delete_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Delete button displayed");
		}

		else {

			logger.info("Delete button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Save_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Save button displayed");
		}

		else {

			logger.info("Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Cancel_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Cancel button displayed");
		}

		else {

			logger.info("Cancel button not displayed");
			Assert.fail();
		}

		if (mcObj.check_workerfieldheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field header displayed");
		}

		else {

			logger.info("Worker field header not displayed");
			Assert.fail();
		}

		if (mcObj.check_jobfieldheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field header displayed");
		}

		else {

			logger.info("Job field header not displayed");
			Assert.fail();
		}

		mcObj.click_Addbutton();
		Thread.sleep(3000);

		if (mcObj.check_Workerfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field displayed");
		}

		else {

			logger.info("Worker field not displayed");
			Assert.fail();
		}

		if (mcObj.check_Jobfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field displayed");
		}

		else {

			logger.info("Job field not displayed");
			Assert.fail();
		}

		mcObj.click_ToolbarSavebutton();
		Thread.sleep(2000);

		if (mcObj.check_Workerfield_errormsgdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field error displayed");
		}

		else {

			logger.info("Worker field error not displayed");
			Assert.fail();
		}

		mcObj.click_ToolbarCancelbutton();
		Thread.sleep(2000);

		mcObj.click_Addbutton();
		Thread.sleep(2000);

		if (mcObj.check_Workerfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field displayed");
		}

		else {

			logger.info("Worker field not displayed");
			Assert.fail();
		}

		if (mcObj.check_Jobfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field displayed");
		}

		else {

			logger.info("Job field not displayed");
			Assert.fail();
		}

		String workerName = XLUtils.getCellData(excelpath, sheet6, 2, 4);

		acObj.setWorker(workerName);
		Thread.sleep(2000);

		cm.selectDropDownValue(workerName);
		Thread.sleep(2000);

		String jobId = XLUtils.getCellData(excelpath, sheet6, 2, 5);

		acObj.setJobid(jobId);
		Thread.sleep(2000);

		cm.selectDropDownValue(jobId);
		Thread.sleep(2000);

		mcObj.click_ToolbarSavebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_created_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member created message is displayed");
		}

		else {

			logger.info("Crew member created message is not displayed");
			Assert.fail();
		}

		Thread.sleep(5000); 

		String gworker = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).getText();
		System.out.println("Worker Name = " + gworker);

		if (gworker.contains(workerName)) {
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Worker name equals");
		}

		else {

			logger.info("Crew Member Tab - Worker name not equals");
			Assert.fail();
		}

		String gJobid = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).getText();
		System.out.println("Job id = " + gJobid);

		if (gJobid.contains(jobId)) {
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Job id equals");
		}

		else {

			logger.info("Crew Member Tab - Job id not equals");
			Assert.fail();
		}

		driver.findElement(By.xpath("(//app-crew-member//table//tr[1])[3]")).click();
		Thread.sleep(2000);

		mcObj.click_ToolbarDeletebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_delete_popup_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup is displayed");
		}

		else {

			logger.info("Crew member delete popup is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupDeletebutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Delete button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Delete button is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupCancelbutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Cancel button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Cancel button is not displayed");
			Assert.fail();
		}

		mcObj.clickcrewmemberpopupCancelbtn();
		Thread.sleep(1000);

		mcObj.click_ToolbarDeletebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_delete_popup_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup is displayed");
		}

		else {

			logger.info("Crew member delete popup is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupDeletebutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Delete button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Delete button is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupCancelbutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Cancel button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Cancel button is not displayed");
			Assert.fail();
		}

		mcObj.clickcrewmemberpopupDeletebtn();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_deleted_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member deleted message is displayed");
		}

		else {

			logger.info("Crew member deleted message is not displayed");
			Assert.fail();
		}

		/*
		 * =============================================================================
		 * =========================================
		 */

		/*
		 * // Add Crew Member
		 * 
		 * mcObj.click_Addbutton(); Thread.sleep(2000);
		 * 
		 * if (mcObj.check_Workerfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Worker field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Worker field not displayed"); Assert.fail(); }
		 * 
		 * if (mcObj.check_Jobfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Job field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Job field not displayed"); Assert.fail(); }
		 * 
		 * String workerName2 = XLUtils.getCellData(excelpath, sheet6, 2, 6);
		 * 
		 * acObj.setWorker(workerName2); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName2); Thread.sleep(2000);
		 * 
		 * String jobId2 = XLUtils.getCellData(excelpath, sheet6, 2, 7);
		 * 
		 * acObj.setJobid(jobId2); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId2); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_created_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member created message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member created message is not displayed"); Assert.fail(); }
		 * 
		 * 
		 * String gworker2 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).
		 * getText(); System.out.println("Worker Name = "+gworker2);
		 * 
		 * 
		 * if(gworker2.contains(workerName2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid2 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).
		 * getText(); System.out.println("Job id = "+gJobid2);
		 * 
		 * if(gJobid2.contains(jobId2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 * 
		 * driver.findElement(By.xpath("//app-crew-member//table//tr[1]//td[text()='" +
		 * gworker2 + "']")).click(); Thread.sleep(2000);
		 * 
		 * Edit Crew Member - Scenario - L22
		 * 
		 * acObj.clickEditbtn(); Thread.sleep(2000);
		 * 
		 * String workerName3 = XLUtils.getCellData(excelpath, sheet6, 2, 10);
		 * 
		 * acObj.setWorker(workerName3); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName3); Thread.sleep(2000);
		 * 
		 * String jobId3 = XLUtils.getCellData(excelpath, sheet6, 2, 11);
		 * 
		 * acObj.setJobid(jobId3); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId3); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_updated_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member updated message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member updated message is not displayed"); Assert.fail(); }
		 * 
		 * String gworker3 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).
		 * getText(); System.out.println("Worker Name = "+gworker3);
		 * 
		 * 
		 * if(gworker3.contains(workerName3)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid3 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).
		 * getText(); System.out.println("Job id = "+gJobid3);
		 * 
		 * if(gJobid3.contains(jobId3)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 * 
		 * // Add Crew member
		 * 
		 * 
		 * mcObj.click_Addbutton(); Thread.sleep(2000);
		 * 
		 * if (mcObj.check_Workerfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Worker field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Worker field not displayed"); Assert.fail(); }
		 * 
		 * if (mcObj.check_Jobfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Job field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Job field not displayed"); Assert.fail(); }
		 * 
		 * String workerName4 = XLUtils.getCellData(excelpath, sheet6, 2, 12);
		 * 
		 * acObj.setWorker(workerName4); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName4); Thread.sleep(2000);
		 * 
		 * String jobId4 = XLUtils.getCellData(excelpath, sheet6, 2, 13);
		 * 
		 * acObj.setJobid(jobId4); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId4); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_created_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member created message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member created message is not displayed"); Assert.fail(); }
		 * 
		 * String gworker4 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[3]//td[1])[1]")).
		 * getText(); System.out.println("Worker Name = "+gworker4);
		 * 
		 * 
		 * if(gworker4.contains(workerName4)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid4 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[3]//td[2])[1]")).
		 * getText(); System.out.println("Job id = "+gJobid4);
		 * 
		 * if(gJobid2.contains(jobId2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 */

	}

	@Test(priority = 3, dependsOnMethods = { "Verify_Add_Crew_Members_3667" })
	public void verifyCrewProjectTask_3788() throws InterruptedException, IOException, Exception {

		ProjectID_1 = XLUtils.getCellData(excelpath, sheet5, 1, 0);

		ProjectID_2 = XLUtils.getCellData(excelpath, sheet5, 4, 0);

		ProjectID_3 = XLUtils.getCellData(excelpath, sheet5, 5, 0);

		cm = new common_pom(driver);

		ExpectedTaskList_Project1 = cm.getTaskListBasedOnProject(ProjectID_1);

		Thread.sleep(2000);

		ExpectedTaskList_Project2 = cm.getTaskListBasedOnProject(ProjectID_2);

		Thread.sleep(3000);

		ExpectedTaskList_Project3 = cm.getTaskListBasedOnProject(ProjectID_3);

		Thread.sleep(3000);

		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);

		leftmenuObj.clickCrewstab();
		Thread.sleep(2000);

		leftmenuObj.clkMyCrewstab();
		Thread.sleep(2000);

		Thread.sleep(2000);

		mcObj.searchCrew2(crewId);

		Thread.sleep(5000);

		mcObj.click_Mycrew_Editbutton(crewId); 

		Thread.sleep(3000);

		mcObj.clickDefaultcrewcheckbox();

		Thread.sleep(2000);

		mcObj.clickSavebtn();

		Thread.sleep(5000);

		mcObj.clickBackbtn();

		Thread.sleep(3000);

		mcObj.searchCrew2(crewId);

		Thread.sleep(5000);

		mcObj.click_Mycrew_Editbutton(crewId); 

		Thread.sleep(3000);

		if (mcObj.check_crewId_value().equals(crewId) && mcObj.check_crewDescription_value().equals(crewDescription)
				&& mcObj.check_crewFormanpersonnelnumber_value().equals(crewForemanpersonnelNo)
		// && mcObj.check_crewFormanname_value().equals(crewForemanname)
		) {

			logger.info("crew details are displayed as expected while edit");

			Assert.assertTrue(true);

		}

		else {

			logger.info("crew details are not displayed as expected while edit");

			logger.info("Crew Id Expected :" + crewId);
			logger.info("Crew Id Actual :" + mcObj.check_crewId_value());
			logger.info("Crew Description Expected :" + crewDescription);
			logger.info("Crew Description Actual :" + mcObj.check_crewDescription_value());
			logger.info("Crew ForemanPersonnelNumber Expected :" + crewForemanpersonnelNo);
			logger.info("Crew ForemanPersonnelNumber Actual :" + mcObj.check_crewFormanpersonnelnumber_value());
			logger.info("Crew ForemanName Expected :" + crewForemanName);
			logger.info("Crew ForemanName Actual :" + mcObj.check_crewFormanname_value());

			Assert.fail();
		}

		if (mcObj.checkDefaultCrew_isSelected() == false) {

			logger.info("Default crew is not selected as expected while edit");

			Assert.assertTrue(true);

		}

		else {

			logger.info("Default crew is selected which is not expected while edit");

			logger.info("Default crew checked: " + mcObj.checkDefaultCrew_isSelected());

			Assert.fail();
		}

		if (mcObj.check_crewdetails_Tabenabled() == true && mcObj.check_crewmembers_Tabdisabled() == true
				&& mcObj.check_crewprojecttask_Tabdisabled() == true) {

			logger.info("crew details, crew members and crew project task are displayed as expected");

			Assert.assertTrue(true);

		}

		else {

			logger.info("crew details, crew members and crew project task are not displayed as expected");

			logger.info("crew details tab displayed: " + mcObj.check_crewdetails_Tabenabled());

			logger.info("crew members tab displayed: " + mcObj.check_crewmembers_Tabdisabled());

			logger.info("crew project task tab displayed: " + mcObj.check_crewprojecttask_Tabdisabled());

			Assert.fail();
		}

		Thread.sleep(2000);

		mcObj.click_crewprojecttask_Tabdisabled();

		Thread.sleep(5000);

		if (mcObj.check_detailstab_Backbtn_displayed()) {
			logger.info("back button displayed as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info("back button is not displayed as expected in the crew project task tab");

			logger.info("back button display in crew project task tab : " + mcObj.check_detailstab_Backbtn_displayed());

			Assert.fail();

		}

		if (acObj.clickAddbtn_isDisplayed() == true && acObj.clickEditbtn_isDisplayed() == true
				&& acObj.clickDeletebtn_isDisplayed() == true && acObj.clickSavebtn_isDisplayed() == true
				&& acObj.clickCancelbtn_isDisplayed() == true) {
			logger.info("Add, edit, delete,save and cancel buttons displayed as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {

			logger.info(
					"Add, edit, delete,save and cancel buttons are not displayed as expected in the crew project task tab");

			logger.info("add button display in crew project task tab : " + acObj.clickAddbtn_isDisplayed());

			logger.info("edit button display in crew project task tab : " + acObj.clickEditbtn_isDisplayed());

			logger.info("delete button display in crew project task tab : " + acObj.clickDeletebtn_isDisplayed());

			logger.info("save button display in crew project task tab : " + acObj.clickSavebtn_isDisplayed());

			logger.info("cancel button display in crew project task tab : " + acObj.clickCancelbtn_isDisplayed());

			Assert.fail();

		}

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnDisabled() == true
				&& mcObj.checkDeletebtnDisabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add is disabled and edit, delete , save , cancel buttons are enabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info("Add , edit, delete , save , cancel buttons are not as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button disabled in crew project task tab : " + mcObj.checkEditbtnDisabled());

			logger.info("delete button disabled in crew project task tab : " + mcObj.checkDeletebtnDisabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnDisabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnDisabled());

			Assert.fail();

		}

		acObj.clickAddbtn();

		Thread.sleep(2000);

		if (mcObj.checkAddCrewProjectTaskForm_isDisplayed() == true) {
			logger.info("Add crew project task form displayed as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info("Add crew project task form is not displayed as expected in the crew project task tab");

			Assert.fail();
		}

		if (mcObj.checkkProjectID_isDisplayed() == true && mcObj.checkSelectAllProjectTask_isChecked() == false) {

			logger.info(
					"'Projecy ID' and 'select all project task' check box displayed as expected in the 'Add crew project task form'");

			Assert.assertTrue(true);

		}

		else {

			logger.info(
					"'Projecy ID' and 'select all project task' check box displayed as expected in the 'Add crew project task form'");

			logger.info("Project ID displayed : " + mcObj.checkkProjectID_isDisplayed());

			logger.info("'Select All Project Task' is selected by default  : "
					+ mcObj.checkSelectAllProjectTask_isChecked());
			Assert.fail();

		}

		if (mcObj.checkSavebtn_AddCrewProjectTaskForm_isDisplayed() == true
				&& mcObj.checkCancelbtn_AddCrewProjectTaskForm_isDisplayed() == true) {

			logger.info("save and cancel buttons displayed as expected in the 'Add crew project task form'");

			Assert.assertTrue(true);

		}

		else {

			logger.info("save and cancel buttons are not displayed as expected in the 'Add crew project task form'");

			logger.info("save button display in crew project task tab : "
					+ mcObj.checkSavebtn_AddCrewProjectTaskForm_isDisplayed());

			logger.info("cancel button display in crew project task tab : "
					+ mcObj.checkCancelbtn_AddCrewProjectTaskForm_isDisplayed());

			Assert.fail();

		}

		mcObj.clickProjectID();

		Thread.sleep(2000);

		cm.selectDropDownValue(ProjectID_1);

		Thread.sleep(2000);

		mcObj.clickSelectAllProjectTask();

		Thread.sleep(2000);

		List<String> ActualtaskList = mcObj.getTaskListCrewProjectTask();

		Collections.sort(ActualtaskList);

		Collections.sort(ExpectedTaskList_Project1);

		Thread.sleep(2000);

		if (ActualtaskList.equals(ExpectedTaskList_Project1)) {

			logger.info("Task list displayed as expected in the add crew project task");

			logger.info("ActualtaskList :" + ActualtaskList.toString());

			logger.info("ExpectedTaskList :" + ExpectedTaskList_Project1.toString());

			Assert.assertTrue(true);
		}

		else {

			logger.info("Task list not displayed as expected in the add crew project task");

			logger.info("ActualtaskList :" + ActualtaskList.toString());

			logger.info("ExpectedTaskList :" + ExpectedTaskList_Project1.toString());

			Assert.fail();

		}

		if (mcObj.checkAllTaskCodes_CheckBox_CrewProjectTask_isSelected() == true) {

			logger.info("All the task codes selected as expected in the add crew project task");
			Assert.assertTrue(true);

		}

		else {

			logger.info("All the task codes not selected as expected in the add crew project task");

			logger.info("cm.checkAllTaskCodes_CheckBox_CrewProjectTask_isSelected :"
					+ mcObj.checkAllTaskCodes_CheckBox_CrewProjectTask_isSelected());

			Assert.fail();

		}

		Thread.sleep(2000);

		TaskListSelected_Project1 = mcObj.getTaskListCrewProjectTask();

		mcObj.clickSavebtn_AddCrewProjectTaskForm();

		Thread.sleep(2000);

		TaskListDashboard = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		Collections.sort(TaskListDashboard);

		Collections.sort(TaskListSelected_Project1);

		if (TaskListDashboard.equals(TaskListSelected_Project1)) {

			logger.info("All the selected task codes are displayed as expected in the add crew project task dashboard");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListDashboard.toString());

			Assert.assertTrue(true);

		}

		else {

			logger.info(
					"All the selected task codes are not displayed as expected in the add crew project task dashboard");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListDashboard.toString());

			Assert.fail();

		}

		Thread.sleep(2000);

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}

	}

	@Test(priority = 4)
	public void verifyCrewProjectTask_Modify_TaskCode_3789() throws InterruptedException, IOException, Exception {

		Thread.sleep(2000);

		acObj.clickEditbtn();

		Thread.sleep(3000);

		TaskListEditForm = mcObj.getTaskListCrewProjectTask();

		Collections.sort(TaskListEditForm);

		if (TaskListSelected_Project1.equals(TaskListEditForm)) {

			logger.info("Task list displayed as expected while editing crew project task");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListEditForm.toString());

			Assert.assertTrue(true);

		}

		else {

			logger.info("Task list not displayed as expected while editing crew project task");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListEditForm.toString());
			Assert.fail();

		}
		
		Thread.sleep(2000);

		mcObj.clickTask_CheckBox_CrewProjectTask();

		Thread.sleep(3000);

		TaskListSelected_Project1 = mcObj.getSelectedTaskListCrewProjectTask();

		Thread.sleep(3000);

		mcObj.clickSavebtn_AddCrewProjectTaskForm();

		Thread.sleep(5000);

		TaskListDashboard = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		Collections.sort(TaskListSelected_Project1);

		Collections.sort(TaskListDashboard);

		if (TaskListSelected_Project1.equals(TaskListDashboard)) {

			logger.info(
					"All the selected task codes are displayed as expected in the add crew project task dashboard after edit");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListDashboard.toString());

			Assert.assertTrue(true);

		} 

		else {

			logger.info(
					"All the selected task codes are not displayed as expected in the add crew project task dashboard after edit");

			logger.info("TaskListExpected :" + TaskListSelected_Project1.toString());

			logger.info("TaskListActual :" + TaskListDashboard.toString());

			Assert.fail();

		}

		Thread.sleep(2000);

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}

	}

	@Test(priority = 5)
	public void verifyCrewProjectTask_Delete_TaskCode_3793() throws InterruptedException, IOException, Exception {

		Thread.sleep(2000);

		List<String> TaskListDashboardBeforeDelete = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		Collections.sort(TaskListDashboard);

		cm.clickkDashboardRecord();

		Thread.sleep(2000);

		mcObj.clickDeleteofSelectedProjectTask();

		Thread.sleep(2000);

		acObj.clickcrewmemberpopupCancelbtn();

		Thread.sleep(2000);

		cm.clickkDashboardRecord();

		Thread.sleep(2000);

		if (cm.checkDashboardRecordSelected() == true) {
			logger.info("Dashboard record has been selected as expected when clicked");

			Assert.assertTrue(true);

		}

		else {
			logger.info("Dashboard record has not been selected as expected when clicked");
			Assert.fail();

		}

		String TaskToBeDeleted = mcObj.getProjectTaskOfSelectedRecordFromDashboard();

		List<String> TaskListDashboardAfterDeleteExpected = new ArrayList<String>();

		for (int i = 0; i < TaskListDashboardBeforeDelete.size(); i++) {

			if (!TaskListDashboardBeforeDelete.get(i).equals(TaskToBeDeleted)) {

				TaskListDashboardAfterDeleteExpected.add(TaskListDashboardBeforeDelete.get(i));

			}
		}

		mcObj.clickDeleteofSelectedProjectTask();

		Thread.sleep(2000);

		acObj.clickcrewmemberpopupCancelbtn();

		Thread.sleep(2000);

		mcObj.clickDeleteofSelectedProjectTask();

		Thread.sleep(2000);

		acObj.clickcrewmemberpopupDeletebtn();

		Thread.sleep(3000);

		TaskDeleted = TaskToBeDeleted;

		List<String> TaskListDashboardAfterDeleteActual = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		Collections.sort(TaskListDashboardAfterDeleteExpected);

		Collections.sort(TaskListDashboardAfterDeleteActual);

		TaskListSelected_Project1 = TaskListDashboardAfterDeleteExpected;

		if (TaskListDashboardAfterDeleteExpected.equals(TaskListDashboardAfterDeleteActual)) {

			logger.info("Deleted record has been removed from the dashboard as expected");

			logger.info("Task List afer delete expected :" + TaskListDashboardAfterDeleteExpected.toString());

			logger.info("Task List afer delete actual :" + TaskListDashboardAfterDeleteActual.toString());

			Assert.assertTrue(true);

		}

		else {
			logger.info("Deleted record has not been removed from the dashboard as expected");

			logger.info("Task List afer delete expected :" + TaskListDashboardAfterDeleteExpected.toString());

			logger.info("Task List afer delete actual :" + TaskListDashboardAfterDeleteActual.toString());

			Assert.fail();

		}

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}
	}

	@Test(priority = 6)
	public void verifyCrewProjectTask_3798() throws InterruptedException, IOException, Exception {

		cm = new common_pom(driver);

		Thread.sleep(2000);

		TaskListDashboard = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		Thread.sleep(2000);

		acObj.clickAddbtn();

		Thread.sleep(2000);

		if (mcObj.checkAddCrewProjectTaskForm_isDisplayed() == true) {
			logger.info("Add crew project task form displayed as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info("Add crew project task form is not displayed as expected in the crew project task tab");

			Assert.fail();
		}

		Thread.sleep(3000);
		
		if (mcObj.checkkProjectID_isDisplayed() == true && mcObj.checkSelectAllProjectTask_isChecked() == false) {

			logger.info(
					"'Projecy ID' and 'select all project task' check box displayed as expected in the 'Add crew project task form'");

			Assert.assertTrue(true);

		}

		else {

			logger.info(
					"'Projecy ID' and 'select all project task' check box is not displayed as expected in the 'Add crew project task form'");

			logger.info("Project ID displayed : " + mcObj.checkkProjectID_isDisplayed());

			logger.info("'Select All Project Task' is selected by default  : "
					+ mcObj.checkSelectAllProjectTask_isChecked());
			Assert.fail();

		}

		if (mcObj.checkSavebtn_AddCrewProjectTaskForm_isDisplayed() == true
				&& mcObj.checkCancelbtn_AddCrewProjectTaskForm_isDisplayed() == true) {

			logger.info("save and cancel buttons displayed as expected in the 'Add crew project task form'");

			Assert.assertTrue(true);

		}

		else {

			logger.info("save and cancel buttons are not displayed as expected in the 'Add crew project task form'");

			logger.info("save button display in crew project task tab : "
					+ mcObj.checkSavebtn_AddCrewProjectTaskForm_isDisplayed());

			logger.info("cancel button display in crew project task tab : "
					+ mcObj.checkCancelbtn_AddCrewProjectTaskForm_isDisplayed());

			Assert.fail();

		}

		mcObj.clickProjectID();

		Thread.sleep(2000);

		cm.selectDropDownValue(ProjectID_2);

		Thread.sleep(2000);

		List<String> ActualtaskList = mcObj.getTaskListCrewProjectTask();

		Collections.sort(ActualtaskList);

		Collections.sort(ExpectedTaskList_Project2);

		Thread.sleep(2000);

		if (ActualtaskList.equals(ExpectedTaskList_Project2)) {
 
			logger.info("Task list displayed as expected in the add crew project task");

			logger.info("ActualtaskList :" + ActualtaskList.toString());

			logger.info("ExpectedTaskList :" + ExpectedTaskList_Project2.toString());

			Assert.assertTrue(true);
		}

		else {

			logger.info("Task list not displayed as expected in the add crew project task");

			logger.info("ActualtaskList :" + ActualtaskList.toString());

			logger.info("ExpectedTaskList :" + ExpectedTaskList_Project2.toString());

			Assert.fail();
		}

		mcObj.clickTask_CheckBox_CrewProjectTask();

		Thread.sleep(2000);

		TaskListSelected_Project2 = mcObj.getSelectedTaskListCrewProjectTask();

		Thread.sleep(2000);

		mcObj.clickSavebtn_AddCrewProjectTaskForm();

		Thread.sleep(3000);

		List<String> TaskListDashboardExpected = new ArrayList<String>();

		TaskListDashboardExpected.addAll(TaskListDashboard);
		TaskListDashboardExpected.addAll(TaskListSelected_Project2);

		List<String> TaskListDashboardActual = new ArrayList<String>();

		TaskListDashboardActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1));
		TaskListDashboardActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_2));

		Collections.sort(TaskListDashboardExpected);

		Collections.sort(TaskListDashboardActual);

		if (TaskListDashboardExpected.equals(TaskListDashboardActual)) {

			logger.info(
					"All the selected task codes for the new project has been displayed as expected in the crew project task dashboard after new project task addition");

			logger.info("TaskListExpected :" + TaskListDashboardExpected.toString());

			logger.info("TaskListActual :" + TaskListDashboardActual.toString());

			Assert.assertTrue(true);

		}

		else {

			logger.info(
					"All the selected task codes for the new project has not been displayed as expected in the crew project task dashboard after new project task addition");

			logger.info("TaskListExpected :" + TaskListDashboardExpected.toString());

			logger.info("TaskListActual :" + TaskListDashboardActual.toString());

			Assert.fail();

		}

		Thread.sleep(2000);

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}

	}

	@Test(priority = 7)
	public void verifyCrewProjectTask_Modify_Project_3800() throws InterruptedException, IOException, Exception {

		Thread.sleep(2000);

		List<String> TaskListDashboardBeforeModify = new ArrayList<String>();

		TaskListDashboardBeforeModify.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1));
		TaskListDashboardBeforeModify.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_2));

		Collections.sort(TaskListDashboardBeforeModify);

		cm.clickkDashboardRecordBasedOnProject(ProjectID_2);

		Thread.sleep(2000);

		String RecordToBeModified = mcObj.getProjectTaskOfSelectedRecordFromDashboard();

		logger.info("RecordToBeModified: " + RecordToBeModified);

		List<String> TaskListDashboardAfterModifyExpected = new ArrayList<String>();

		for (int i = 0; i < TaskListDashboardBeforeModify.size(); i++) {

			if (!TaskListDashboardBeforeModify.get(i).equals(RecordToBeModified)) {

				TaskListDashboardAfterModifyExpected.add(TaskListDashboardBeforeModify.get(i));

			}
		}

		String Project3_Task = ExpectedTaskList_Project3.get(0);

		TaskListDashboardAfterModifyExpected.add(Project3_Task);

		Collections.sort(TaskListDashboardAfterModifyExpected);

		cm.doubleClickkDashboardRecordBasedOnProject(ProjectID_2);

		Thread.sleep(2000);

		cm.setProjectInline(ProjectID_3);

		Thread.sleep(2000);

		cm.setTaskInline(Project3_Task);

		Thread.sleep(3000);

		mcObj.clickSaveIconInline();

		Thread.sleep(2000);

		List<String> TaskListDashboardAfterModifyActual = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		TaskListDashboardAfterModifyActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_2));

		TaskListDashboardAfterModifyActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_3));

		Collections.sort(TaskListDashboardAfterModifyActual);

		if (TaskListDashboardAfterModifyExpected.equals(TaskListDashboardAfterModifyActual)) {

			logger.info("Project tasks has been modified as expected");

			logger.info("Task List afer modification expected :" + TaskListDashboardAfterModifyExpected.toString());

			logger.info("Task List afer modification actual :" + TaskListDashboardAfterModifyActual.toString());

			Assert.assertTrue(true);

		}

		else {
			logger.info("Project tasks has not been modified as expected");

			logger.info("Task List afer modification expected :" + TaskListDashboardAfterModifyExpected.toString());

			logger.info("Task List afer modification actual :" + TaskListDashboardAfterModifyActual.toString());

			Assert.fail();

		}

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}
	}

	@Test(priority = 8)
	public void verifyCrewProjectTask_Remove_Project_3802() throws InterruptedException, IOException, Exception {

		Thread.sleep(2000);

		List<String> TaskListDashboardBeforeDelete = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		TaskListDashboardBeforeDelete.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_2));

		TaskListDashboardBeforeDelete.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_3));

		Collections.sort(TaskListDashboardBeforeDelete);

		cm.clickkDashboardRecordBasedOnProject(ProjectID_3);

		Thread.sleep(2000);

		String TaskToBeDeleted = mcObj.getProjectTaskOfSelectedRecordFromDashboard();

		List<String> TaskListDashboardAfterDeleteExpected = new ArrayList<String>();

		for (int i = 0; i < TaskListDashboardBeforeDelete.size(); i++) {

			if (!TaskListDashboardBeforeDelete.get(i).equals(TaskToBeDeleted)) {

				TaskListDashboardAfterDeleteExpected.add(TaskListDashboardBeforeDelete.get(i));

			}
		}

		acObj.clickDeletebtn();

		Thread.sleep(2000);

		acObj.clickcrewmemberpopupDeletebtn();

		Thread.sleep(3000);

		TaskDeleted = TaskToBeDeleted;

		List<String> TaskListDashboardAfterDeleteActual = mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_1);

		TaskListDashboardAfterDeleteActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_2));

		TaskListDashboardAfterDeleteActual.addAll(mcObj.getTaskListCrewProjectTask_Dashboard(ProjectID_3));

		Collections.sort(TaskListDashboardAfterDeleteExpected);

		Collections.sort(TaskListDashboardAfterDeleteActual);

		if (TaskListDashboardAfterDeleteExpected.equals(TaskListDashboardAfterDeleteActual)) {

			logger.info("Deleted record has been removed from the dashboard as expected");

			logger.info("Task List afer delete expected :" + TaskListDashboardAfterDeleteExpected.toString());

			logger.info("Task List afer delete actual :" + TaskListDashboardAfterDeleteActual.toString());

			Assert.assertTrue(true);

		}

		else {
			logger.info("Deleted record has not been removed from the dashboard as expected");

			logger.info("Task List afer delete expected :" + TaskListDashboardAfterDeleteExpected.toString());

			logger.info("Task List afer delete actual :" + TaskListDashboardAfterDeleteActual.toString());

			Assert.fail();

		}

		if (mcObj.checkAddbtnEnabled() == true && mcObj.checkEditbtnEnabled() == true
				&& mcObj.checkDeletebtnEnabled() == true && mcObj.checkSavebtnDisabled() == true
				&& mcObj.checkCancelbtnDisabled() == true) {

			logger.info(
					"Add , edit, delete  are enabled and save , cancel buttons are disabled  are  as expected in the crew project task tab");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Add , edit, delete  are not enabled and save , cancel buttons are not disabled  are  as expected in the crew project task tab");

			logger.info("add button enabled in crew project task tab : " + mcObj.checkAddbtnEnabled());

			logger.info("edit button enabled in crew project task tab : " + mcObj.checkEditbtnEnabled());

			logger.info("delete button enabled in crew project task tab : " + mcObj.checkDeletebtnEnabled());

			logger.info("save button disabled in crew project task tab : " + mcObj.checkSavebtnEnabled());

			logger.info("cancel button disabled in crew project task tab : " + mcObj.checkCancelbtnEnabled());

			Assert.fail();
		}

		if (mcObj.CheckEditIconCrewProjectTask_Dashboard() && mcObj.CheckDeleteIconCrewProjectTask_Dashboard()) {
			logger.info(
					"Edit and delete buttons are displayed as expected for every record in the crew project task tab dashboard");

			Assert.assertTrue(true);

		}

		else {
			logger.info(
					"Edit and delete buttons are not displayed as expected for every record in the crew project task tab dashboard");

			Assert.fail();

		}
	}

	@Test(priority = 9)
	public void verifyCrew_Delete() throws InterruptedException, IOException, Exception {

		Thread.sleep(2000);

		leftmenuObj.clkMyCrewstab();

		Thread.sleep(2000);

		mcObj.searchCrew2(crewId);

		Thread.sleep(3000);

		mcObj.clickkDeleteCrew(crewId);

		Thread.sleep(3000);
		
		mcObj.clickCrewDeleteConfirm();

		Thread.sleep(5000);

		mcObj.searchCrew2(crewId);

		Thread.sleep(5000);

		if (mcObj.checkNoRecordsFoundMessage() == true) {

			logger.info("No Records Found message displayed as expected");

			Assert.assertTrue(true);

		}

		else {
			logger.info("No Records Found message is not displayed as expected");

			Assert.fail();

		}

	}
}

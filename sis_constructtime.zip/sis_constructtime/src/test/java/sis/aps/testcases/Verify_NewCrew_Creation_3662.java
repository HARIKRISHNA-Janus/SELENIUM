package sis.aps.testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.TimeManagement_Crews_AllCrews;
import sis.ct.pageobjects.TimeManagement_Crews_MyCrews;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class Verify_NewCrew_Creation_3662 extends baseclass {

	@Test(priority = 1)
	public void Verify_New_Crew_Creation_3662() throws InterruptedException, IOException, Exception {

		loginpage_pom login = new loginpage_pom(driver);
		// leftmenu_pom timesheet = new leftmenu_pom(driver);
		Thread.sleep(3000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(3000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		Thread.sleep(3000);

		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);

		leftmenuObj.clickCrewstab();
		Thread.sleep(2000);

		leftmenuObj.clkMyCrewstab();
		Thread.sleep(2000);

		TimeManagement_Crews_MyCrews mcObj = new TimeManagement_Crews_MyCrews(driver);
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}
		Thread.sleep(2000);

		if (mcObj.checksearchInput_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews search input field displayed");
		}

		else {

			logger.info("My crews search input field not displayed");
			Assert.fail();
		}

		if (mcObj.checkSourcedropdown_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews source dropdown field displayed");
		}

		else {

			logger.info("My crews source dropdown field not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewId_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew id column header displayed");
		}

		else {

			logger.info("My crews crew id column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew description column header displayed");
		}

		else {

			logger.info("My crews crew description column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanfirstname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman first name column header displayed");
		}

		else {

			logger.info("My crews crew foreman first name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanlastname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman last name column header displayed");
		}

		else {

			logger.info("My crews crew foreman last name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanpersonnelnumber_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman personnel number column header displayed");
		}

		else {

			logger.info("My crews crew foreman personnel number column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		mcObj.clickNewcrewbtn();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Back button displayed");
		}

		else {

			logger.info("My Crew details tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Resetbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Reset button displayed");
		}

		else {

			logger.info("My Crew details tab - Reset button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Savebtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Save button displayed");
		}

		else {

			logger.info("My Crew details tab - Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewdetails_Tabenabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Enabled");
		}

		else {

			logger.info("My Crew details tab - Disabled");
			Assert.fail();
		}

		if (mcObj.check_crewmembers_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Disabled");
		}

		else {

			logger.info("My Crew members tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewprojecttask_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew project task tab - Disabled");
		}

		else {

			logger.info("My Crew project task tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewId_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id field - Present");
		}

		else {

			logger.info("My Crew - Crew id field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew description field - Present");
		}

		else {

			logger.info("My Crew - Crew description field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanpersonnelnumber_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crewforeman personnel number field - Present");
		}

		else {

			Assert.fail();
			logger.info("My Crew - Crewforeman personnel number field - Not Present");
		}

		if (mcObj.check_crewFormanname_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew foreman name field - Present");
		}

		else {

			logger.info("My Crew - Crew foreman name field - Not Present");
			Assert.fail();

		}

		Thread.sleep(1000);
		mcObj.clickSavebtn();
		Thread.sleep(3000);

		if (mcObj.check_alertmessage_isdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew details tab alert message - displayed");
		}

		else {

			logger.info("My Crew - Crew details tab alert message - not displayed");
			Assert.fail();
		}

//		Thread.sleep(2000);

		if (mcObj.check_crewidinput_fielderrormessage_isdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id input field error message - displayed");
		}

		else {

			logger.info("My Crew - Crew id input field error message - not displayed");
			Assert.fail();

		}

		/* APPLICATION Error */

//		if (mcObj.check_crewpersonnelno_inputfielderrormessage_isdisplayed() == true) {
//			Assert.assertTrue(true);
//			logger.info("My Crew - Foreman personnel number input field error message - displayed");
//		}
//
//		else {
//			
//			logger.info("My Crew -  Foreman personnel number input field error message - not displayed");
//			Assert.fail();
//			
//		}

		String crewId = XLUtils.getCellData(excelpath, sheet6, 2, 0);
		String crewDescription = XLUtils.getCellData(excelpath, sheet6, 2, 1);

		acObj.setCrewid(crewId);
		Thread.sleep(2000);

		acObj.setCrewdescription(crewDescription);
		Thread.sleep(2000);

		String crewForemanpersonnelNo = XLUtils.getCellData(excelpath, sheet6, 2, 2);

		acObj.setCrewformanpersonnelno(crewForemanpersonnelNo);
		Thread.sleep(2000);

		common_pom cm = new common_pom(driver);

		cm.selectDropDownValue(crewForemanpersonnelNo);
		Thread.sleep(2000);

		String crewForemanName = XLUtils.getCellData(excelpath, sheet6, 2, 3);

		String foremanName = driver.findElement(By.xpath("//input[@data-placeholder='Foreman name']"))
				.getAttribute("value");
		System.out.println("Crew Foreman Name = " + foremanName);

		if (crewForemanName.equals(foremanName)) {

			Assert.assertTrue(true);
			logger.info("Crew foreman displayed and equal");
		}

		else {

			logger.info("Crew foreman not equal / not displayed");
			Assert.fail();
		}

		String defaultcrew = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");

		if (defaultcrew.equals("false")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - Unchecked");
		}

		else {

			logger.info("Default crew checkbox - checked");
			Assert.fail();
		}

		mcObj.clickResetbtn();
		Thread.sleep(1000);

		mcObj.clickBackbtn();
		Thread.sleep(2000);

//		if (acObj.checkcrew_created_msg_displayed() == true) 
//		{
//			Assert.assertTrue(true);
//			logger.info("Crew created message is displayed");
//		}
//
//		else 
//		{
//
//			Assert.fail();
//			logger.info("Crew created message is not displayed");
//		}
//		
//		logger.info("createMyNewcrew_Fillthedetails_2826 ==> Method Executed");

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}
		Thread.sleep(2000);

		if (mcObj.checksearchInput_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews search input field displayed");
		}

		else {

			logger.info("My crews search input field not displayed");
			Assert.fail();
		}

		if (mcObj.checkSourcedropdown_fieldisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews source dropdown field displayed");
		}

		else {

			logger.info("My crews source dropdown field not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewId_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew id column header displayed");
		}

		else {

			logger.info("My crews crew id column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew description column header displayed");
		}

		else {

			logger.info("My crews crew description column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanfirstname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman first name column header displayed");
		}

		else {

			logger.info("My crews crew foreman first name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanlastname_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman last name column header displayed");
		}

		else {

			logger.info("My crews crew foreman last name column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewforemanpersonnelnumber_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew foreman personnel number column header displayed");
		}

		else {

			logger.info("My crews crew foreman personnel number column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		mcObj.clickNewcrewbtn();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Back button displayed");
		}

		else {

			logger.info("My Crew details tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Resetbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Reset button displayed");
		}

		else {

			logger.info("My Crew details tab - Reset button not displayed");
			Assert.fail();
		}

		if (mcObj.check_detailstab_Savebtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Save button displayed");
		}

		else {

			logger.info("My Crew details tab - Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewdetails_Tabenabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew details tab - Enabled");
		}

		else {

			logger.info("My Crew details tab - Disabled");
			Assert.fail();
		}

		if (mcObj.check_crewmembers_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Disabled");
		}

		else {

			logger.info("My Crew members tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewprojecttask_Tabdisabled() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew project task tab - Disabled");
		}

		else {

			logger.info("My Crew project task tab - Enabled");
			Assert.fail();
		}

		if (mcObj.check_crewId_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew id field - Present");
		}

		else {

			logger.info("My Crew - Crew id field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewDescription_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew description field - Present");
		}

		else {

			logger.info("My Crew - Crew description field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanpersonnelnumber_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crewforeman personnel number field - Present");
		}

		else {

			logger.info("My Crew - Crewforeman personnel number field - Not Present");
			Assert.fail();
		}

		if (mcObj.check_crewFormanname_fielddisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - Crew foreman name field - Present");
		}

		else {

			logger.info("My Crew - Crew foreman name field - Not Present");
			Assert.fail();
		}

		acObj.setCrewid(crewId);
		Thread.sleep(2000);

		acObj.setCrewdescription(crewDescription);
		Thread.sleep(2000);

		acObj.setCrewformanpersonnelno(crewForemanpersonnelNo);
		Thread.sleep(2000);

		cm.selectDropDownValue(crewForemanpersonnelNo);
		Thread.sleep(2000);

		String foremanName2 = driver.findElement(By.xpath("//input[@data-placeholder='Foreman name']"))
				.getAttribute("value");
		System.out.println("Crew Foreman Name = " + foremanName2);

		if (crewForemanName.equals(foremanName2)) {

			Assert.assertTrue(true);
			logger.info("Crew foreman displayed and equal");
		}

		else {

			logger.info("Crew foreman not equal / not displayed");
			Assert.fail();
		}

		String defaultcrew2 = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");
		System.out.println("Default crew checjbox = " + defaultcrew2);

		if (defaultcrew2.equals("false")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - Unchecked");
			mcObj.clickDefaultcrewcheckbox();
			logger.info("Default crew checkbox ==> checked");
		}

		else {

			logger.info("Default crew checkbox - checked");
			Assert.fail();
		}

		Thread.sleep(3000);
		mcObj.clickSavebtn();
		Thread.sleep(2000);

		if (mcObj.check_editcrew_headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew - edit crew header - displayed");
		}

		else {

			logger.info("My Crew -  edit crew header - Not displayed");
			Assert.fail();
		}

		String defaultcrew3 = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");
		System.out.println("Default crew checjbox = " + defaultcrew3);

		if (defaultcrew3.equals("true")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - checked");

		}

		else {
			logger.info("Default crew checkbox - Unchecked");
			Assert.fail();
		}

		mcObj.clickBackbtn();
		Thread.sleep(2000);

		if (mcObj.checkMycrews_Headerdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else {

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}

		acObj.searchCrew(XLUtils.getCellData(excelpath, sheet6, 2, 0));
		Thread.sleep(3000);

		String gCrewid = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[1]/a[1]")).getText();
		System.out.println("Crew id " + gCrewid);

		if (gCrewid.equals(XLUtils.getCellData(excelpath, sheet6, 2, 0))) {
			Assert.assertTrue(true);
			logger.info("Crew id - Equals");
		} else {
			logger.info("Crew id - Not Equals");
			Assert.fail();
		}

		String gCrewdecription = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[2]/a[1]")).getText();
		System.out.println("Crew description " + gCrewdecription);

		if (gCrewdecription.equals(XLUtils.getCellData(excelpath, sheet6, 2, 1))) {
			Assert.assertTrue(true);
			logger.info("Crew description - Equals");
		} else {
			logger.info("Crew description - Not Equals");
			Assert.fail();
		}

		String gCrewforeman1stname = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[3]")).getText();
		System.out.println("Crew foreman first name " + gCrewforeman1stname);

		if (gCrewforeman1stname.equals(XLUtils.getCellData(excelpath, sheet6, 2, 8))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman first name - Equals");
		} else {

			logger.info("Crew foreman first name - Not Equals");
			Assert.fail();
		}

		String gCrewforemanlaststname = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[4]")).getText();
		System.out.println("Crew foreman last name " + gCrewforemanlaststname);

		if (gCrewforemanlaststname.equals(XLUtils.getCellData(excelpath, sheet6, 2, 9))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman last name - Equals");
		} else {
			logger.info("Crew foreman last name - Not Equals");
			Assert.fail();
		}

		String gCrewforemanpersonnelNo = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[5]")).getText();
		System.out.println("Crew foreman personnel " + gCrewforemanpersonnelNo);

		if (gCrewforemanpersonnelNo.equals(XLUtils.getCellData(excelpath, sheet6, 2, 2))) {
			Assert.assertTrue(true);
			logger.info("Crew foreman personnel number - Equals");
		} else {

			logger.info("Crew foreman personnel number - Not Equals");
			Assert.fail();
		}

		if (mcObj.check_crewActions_columnheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else {

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_viewcrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews view button displayed");
		}

		else {

			logger.info("My crews view button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Editcrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews Edit button displayed");
		}

		else {

			logger.info("My crews Edit button not displayed");
			Assert.fail();
		}

		if (mcObj.check_deletecrew_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("My crews delete button displayed");
		}

		else {

			logger.info("My crews delete button not displayed");
			Assert.fail();
		}

	}

	@Test(priority = 2, dependsOnMethods = { "Verify_New_Crew_Creation_3662" })
	public void Verify_Add_Crew_Members_3667() throws InterruptedException, IOException, Exception {
		TimeManagement_Crews_MyCrews mcObj = new TimeManagement_Crews_MyCrews(driver);
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		// leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		common_pom cm = new common_pom(driver);

		mcObj.click_Mycrew_Editbutton();
		Thread.sleep(2000);

		mcObj.clickcrewmembers_tab();
		Thread.sleep(2000);

		if (mcObj.check_detailstab_Backbtn_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("My Crew members tab - Back button displayed");
		}

		else {

			logger.info("My Crew members tab - Back button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Add_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Add button displayed");
		}

		else {

			logger.info("Add button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Edit_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Edit button displayed");
		}

		else {

			logger.info("Edit button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Delete_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Delete button displayed");
		}

		else {

			logger.info("Delete button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Save_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Save button displayed");
		}

		else {

			logger.info("Save button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Cancel_buttondisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Cancel button displayed");
		}

		else {

			logger.info("Cancel button not displayed");
			Assert.fail();
		}

		if (mcObj.check_workerfieldheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field header displayed");
		}

		else {

			logger.info("Worker field header not displayed");
			Assert.fail();
		}

		if (mcObj.check_jobfieldheader_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field header displayed");
		}

		else {

			logger.info("Job field header not displayed");
			Assert.fail();
		}

		mcObj.click_Addbutton();
		Thread.sleep(2000);

		if (mcObj.check_Workerfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field displayed");
		}

		else {

			logger.info("Worker field not displayed");
			Assert.fail();
		}

		if (mcObj.check_Jobfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field displayed");
		}

		else {

			logger.info("Job field not displayed");
			Assert.fail();
		}

		mcObj.click_ToolbarSavebutton();
		Thread.sleep(2000);

		if (mcObj.check_Workerfield_errormsgdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field error displayed");
		}

		else {

			logger.info("Worker field error not displayed");
			Assert.fail();
		}

		mcObj.click_ToolbarCancelbutton();
		Thread.sleep(2000);

		mcObj.click_Addbutton();
		Thread.sleep(2000);

		if (mcObj.check_Workerfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Worker field displayed");
		}

		else {

			logger.info("Worker field not displayed");
			Assert.fail();
		}

		if (mcObj.check_Jobfield_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Job field displayed");
		}

		else {

			logger.info("Job field not displayed");
			Assert.fail();
		}

		String workerName = XLUtils.getCellData(excelpath, sheet6, 2, 4);

		acObj.setWorker(workerName);
		Thread.sleep(2000);

		cm.selectDropDownValue(workerName);
		Thread.sleep(2000);

		String jobId = XLUtils.getCellData(excelpath, sheet6, 2, 5);

		acObj.setJobid(jobId);
		Thread.sleep(2000);

		cm.selectDropDownValue(jobId);
		Thread.sleep(2000);

		mcObj.click_ToolbarSavebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_created_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member created message is displayed");
		}

		else {

			logger.info("Crew member created message is not displayed");
			Assert.fail();
		}

		String gworker = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).getText();
		System.out.println("Worker Name = " + gworker);

		if (gworker.contains(workerName)) {
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Worker name equals");
		}

		else {

			logger.info("Crew Member Tab - Worker name not equals");
			Assert.fail();
		}

		String gJobid = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).getText();
		System.out.println("Job id = " + gJobid);

		if (gJobid.contains(jobId)) {
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Job id equals");
		}

		else {

			logger.info("Crew Member Tab - Job id not equals");
			Assert.fail();
		}

		driver.findElement(By.xpath("(//app-crew-member//table//tr[1])[3]")).click();
		Thread.sleep(2000);

		mcObj.click_ToolbarDeletebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_delete_popup_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup is displayed");
		}

		else {

			logger.info("Crew member delete popup is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupDeletebutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Delete button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Delete button is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupCancelbutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Cancel button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Cancel button is not displayed");
			Assert.fail();
		}

		mcObj.clickcrewmemberpopupCancelbtn();
		Thread.sleep(1000);

		mcObj.click_ToolbarDeletebutton();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_delete_popup_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup is displayed");
		}

		else {

			logger.info("Crew member delete popup is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupDeletebutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Delete button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Delete button is not displayed");
			Assert.fail();
		}

		if (mcObj.check_crewmember_popupCancelbutton_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member delete popup - Cancel button is displayed");
		}

		else {

			logger.info("Crew member delete popup - Cancel button is not displayed");
			Assert.fail();
		}

		mcObj.clickcrewmemberpopupDeletebtn();
		Thread.sleep(2000);

		if (acObj.checkcrew_member_deleted_msg_displayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew member deleted message is displayed");
		}

		else {

			logger.info("Crew member deleted message is not displayed");
			Assert.fail();
		}

		/*
		 * =============================================================================
		 * =========================================
		 */

		/*
		 * // Add Crew Member
		 * 
		 * mcObj.click_Addbutton(); Thread.sleep(2000);
		 * 
		 * if (mcObj.check_Workerfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Worker field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Worker field not displayed"); Assert.fail(); }
		 * 
		 * if (mcObj.check_Jobfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Job field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Job field not displayed"); Assert.fail(); }
		 * 
		 * String workerName2 = XLUtils.getCellData(excelpath, sheet6, 2, 6);
		 * 
		 * acObj.setWorker(workerName2); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName2); Thread.sleep(2000);
		 * 
		 * String jobId2 = XLUtils.getCellData(excelpath, sheet6, 2, 7);
		 * 
		 * acObj.setJobid(jobId2); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId2); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_created_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member created message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member created message is not displayed"); Assert.fail(); }
		 * 
		 * 
		 * String gworker2 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).
		 * getText(); System.out.println("Worker Name = "+gworker2);
		 * 
		 * 
		 * if(gworker2.contains(workerName2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid2 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).
		 * getText(); System.out.println("Job id = "+gJobid2);
		 * 
		 * if(gJobid2.contains(jobId2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 * 
		 * driver.findElement(By.xpath("//app-crew-member//table//tr[1]//td[text()='" +
		 * gworker2 + "']")).click(); Thread.sleep(2000);
		 * 
		 * Edit Crew Member - Scenario - L22
		 * 
		 * acObj.clickEditbtn(); Thread.sleep(2000);
		 * 
		 * String workerName3 = XLUtils.getCellData(excelpath, sheet6, 2, 10);
		 * 
		 * acObj.setWorker(workerName3); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName3); Thread.sleep(2000);
		 * 
		 * String jobId3 = XLUtils.getCellData(excelpath, sheet6, 2, 11);
		 * 
		 * acObj.setJobid(jobId3); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId3); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_updated_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member updated message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member updated message is not displayed"); Assert.fail(); }
		 * 
		 * String gworker3 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).
		 * getText(); System.out.println("Worker Name = "+gworker3);
		 * 
		 * 
		 * if(gworker3.contains(workerName3)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid3 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).
		 * getText(); System.out.println("Job id = "+gJobid3);
		 * 
		 * if(gJobid3.contains(jobId3)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 * 
		 * // Add Crew member
		 * 
		 * 
		 * mcObj.click_Addbutton(); Thread.sleep(2000);
		 * 
		 * if (mcObj.check_Workerfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Worker field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Worker field not displayed"); Assert.fail(); }
		 * 
		 * if (mcObj.check_Jobfield_displayed() == true) { Assert.assertTrue(true);
		 * logger.info("Job field displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Job field not displayed"); Assert.fail(); }
		 * 
		 * String workerName4 = XLUtils.getCellData(excelpath, sheet6, 2, 12);
		 * 
		 * acObj.setWorker(workerName4); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(workerName4); Thread.sleep(2000);
		 * 
		 * String jobId4 = XLUtils.getCellData(excelpath, sheet6, 2, 13);
		 * 
		 * acObj.setJobid(jobId4); Thread.sleep(2000);
		 * 
		 * cm.selectDropDownValue(jobId4); Thread.sleep(2000);
		 * 
		 * mcObj.click_ToolbarSavebutton(); Thread.sleep(2000);
		 * 
		 * if (acObj.checkcrew_member_created_msg_displayed() == true) {
		 * Assert.assertTrue(true);
		 * logger.info("Crew member created message is displayed"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew member created message is not displayed"); Assert.fail(); }
		 * 
		 * String gworker4 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[3]//td[1])[1]")).
		 * getText(); System.out.println("Worker Name = "+gworker4);
		 * 
		 * 
		 * if(gworker4.contains(workerName4)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Worker name equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Worker name not equals"); Assert.fail(); }
		 * 
		 * String gJobid4 =
		 * driver.findElement(By.xpath("(//app-crew-member//table//tr[3]//td[2])[1]")).
		 * getText(); System.out.println("Job id = "+gJobid4);
		 * 
		 * if(gJobid2.contains(jobId2)) { Assert.assertTrue(true);
		 * logger.info("Crew Member Tab - Job id equals"); }
		 * 
		 * else {
		 * 
		 * logger.info("Crew Member Tab - Job id not equals"); Assert.fail(); }
		 */	 
		
	}
	
	@Test(priority = 3, dependsOnMethods = { "Verify_Add_Crew_Members_3667" })
	public void VerifyofnewCrew_modify_CrewDetails_3873() throws InterruptedException, IOException, Exception {

		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		Thread.sleep(3000);

		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);

		leftmenuObj.clickCrewstab();
		Thread.sleep(2000);

		leftmenuObj.clkMyCrewstab();
		Thread.sleep(2000);

		TimeManagement_Crews_MyCrews mcObj = new TimeManagement_Crews_MyCrews(driver);
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);

		if (mcObj.checkMycrews_Headerdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews Header is displayed");
		}

		else 
		{

			logger.info("My crews Header is not displayed");
			Assert.fail();
		}
		Thread.sleep(2000);

		if (mcObj.checksearchInput_fieldisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews search input field displayed");
		}

		else 
		{

			logger.info("My crews search input field not displayed");
			Assert.fail();
		}

		if (mcObj.checkSourcedropdown_fieldisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews source dropdown field displayed");
		}

		else 
		{

			logger.info("My crews source dropdown field not displayed");
			Assert.fail();
		}		
		
		acObj.searchCrew(XLUtils.getCellData(excelpath, sheet6, 2, 0));
		Thread.sleep(3000);

		String gCrewid = driver.findElement(By.xpath("//mat-table//mat-row[1]//mat-cell[1]/a[1]")).getText();
		System.out.println("Crew id " + gCrewid);

		if (gCrewid.equals(XLUtils.getCellData(excelpath, sheet6, 2, 0))) 
		{
			Assert.assertTrue(true);
			logger.info("Crew id - Equals");
		} 
		else 
		{
			logger.info("Crew id - Not Equals");
			Assert.fail();
		}
		
		if (mcObj.check_crewActions_columnheader_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews crew actions column header displayed");
		}

		else 
		{

			logger.info("My crews crew actions column header not displayed");
			Assert.fail();
		}

		if (mcObj.check_viewcrew_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews view button displayed");
		}

		else 
		{

			logger.info("My crews view button not displayed");
			Assert.fail();
		}

		if (mcObj.check_Editcrew_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews Edit button displayed");
		}

		else 
		{

			logger.info("My crews Edit button not displayed");
			Assert.fail();
		}

		if (mcObj.check_deletecrew_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("My crews delete button displayed");
		}

		else
		{

			logger.info("My crews delete button not displayed");
			Assert.fail();
		}	
		
		mcObj.click_Mycrew_Editbutton();
		Thread.sleep(2000);
		
		String defaultcrew2 = driver.findElement(By.xpath("//mat-checkbox//input")).getAttribute("aria-checked");
		System.out.println("Default crew checjbox = " + defaultcrew2);

		if (defaultcrew2.equals("true")) {
			Assert.assertTrue(true);
			logger.info("Default crew checkbox - checked");
			mcObj.clickDefaultcrewcheckbox();
			logger.info("crew checkbox ==> Unchecked");
		}

		else 
		{

			logger.info("Default crew checkbox - Unchecked");
			Assert.fail();
		}

		Thread.sleep(3000);
		mcObj.clickSavebtn();
		Thread.sleep(2000);		
		
		if (acObj.checkcrew_Updated_msg_displayed() == true) 
		{
				Assert.assertTrue(true);
				logger.info("Crew Updated message is displayed");
		}

		else 
		{
			Assert.fail();
			logger.info("Crew updated message is not displayed");
		}		
		
	}
}
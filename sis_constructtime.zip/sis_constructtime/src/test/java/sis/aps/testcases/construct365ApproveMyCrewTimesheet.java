package sis.aps.testcases;
import java.io.IOException;

import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;


public class construct365ApproveMyCrewTimesheet extends baseclass{
	
	//String projectid = "000191";

	@Test(priority=1)
	public void Construct365_MyCrewTimesheet_3281_header_Approve() throws InterruptedException, IOException, Exception
	{
		loginpage_pom login=new loginpage_pom(driver);
		leftmenu_pom timesheet=new leftmenu_pom(driver);
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		Thread.sleep(30000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(15000);
		timesheet.clicktimemanagementtab();
		Thread.sleep(1000);
		timesheet.clicktimesheetstab();
		Thread.sleep(1000);
		//timesheet.clickkAlltimesheetstab();
		timesheet.clkCrewtimesheetstab();
		Thread.sleep(1000);
		MyTime.clickNewCrewtimesheetsbtn();
		Thread.sleep(1000);
		MyTime.checkdatevalue();
		Thread.sleep(1000);
		MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
		Thread.sleep(1000);
		MyTime.checkCrewDescriptionField();
		Thread.sleep(1000);
		//MyTime.checkProjectID();
		MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
		Thread.sleep(1000);
		MyTime.clickStatusField();
		Thread.sleep(1000);
		MyTime.clickkNotestab();
		Thread.sleep(3000);
		MyTime.clickSaveBtn();
		Thread.sleep(3000);
		System.out.println("NewCrewtimesheet_Header method executed");	
		logger.info("My Crew Timesheet-Header tab data has been saved successfully");
	}
	@Test(priority=2,dependsOnMethods= {"Construct365_MyCrewTimesheet_3281_header_Approve"})
	public void Construct365_MyCrewTimesheet_3282_hours_Approve() throws InterruptedException, IOException, Exception
	{
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		//common_pom common=new common_pom(driver);
		Thread.sleep(3000);
		MyTime.clickAddButton();
		Thread.sleep(3000);
		MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
		Thread.sleep(1000);
		if(XLUtils.getCellData(excelpath, sheet3, 1, 6).equals(""))
		{
			Thread.sleep(1000);
			MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7), XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
			Thread.sleep(1000);
			MyTime.clickSaveBtn1();
			Thread.sleep(1000);
			logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
			System.out.println("New Crew timesheet_hours method executed");
		}
		else
		{
		MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
		Thread.sleep(1000);
		//common.clickkfirstvalue();
		Thread.sleep(1000);
		MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7), XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
		Thread.sleep(1000);
		MyTime.clickSaveBtn1();
		Thread.sleep(1000);
		logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
		System.out.println("New Crew timesheet_hours method executed");
		}
	 }
	
	@Test(priority=3,dependsOnMethods= {"Construct365_MyCrewTimesheet_3282_hours_Approve"})
	public void Construct365_MyCrewTimesheet_3283_FieldExpenses_Approve() throws InterruptedException, IOException, Exception
	{	
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		MyTime.clickFieldExpensesTab();
		Thread.sleep(1000);
		MyTime.clickAddButton();
		Thread.sleep(1000);
		MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
		Thread.sleep(1000);
		MyTime.clickExpenseCategory(XLUtils.getCellData(excelpath, sheet3, 1, 3));
		Thread.sleep(1000);
		MyTime.enterQuantity(XLUtils.getCellData(excelpath, sheet3, 1, 10));
		Thread.sleep(1000);
		MyTime.clickSaveBtn1();
		Thread.sleep(1000);
		System.out.println("newtimesheet_fieldexpense method executed");
		logger.info("My Crew Timesheet-Field Expenses tab data has been saved successfully");
		
	}
	@Test(priority=4,dependsOnMethods= {"Construct365_MyCrewTimesheet_3283_FieldExpenses_Approve"})
	public void Construct365_MyCrewTimesheet_3284_Equipment_Approve() throws InterruptedException, IOException, Exception
	{	
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		MyTime.clickEquipmentTab();
		Thread.sleep(1000);
		MyTime.clickAddButton();
		Thread.sleep(1000);
		MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
		Thread.sleep(1000);
		MyTime.clickEquipmentID(XLUtils.getCellData(excelpath, sheet3, 1, 4));
		Thread.sleep(1000);
		MyTime.enterQuantity(XLUtils.getCellData(excelpath, sheet3, 1, 11));
		Thread.sleep(1000);
		MyTime.clickSaveBtn1();
		Thread.sleep(1000);
		System.out.println("New Crewtimesheet_fieldexpense method executed");
		logger.info("My Crew Timesheet-Equipment tab data has been saved successfully");
	}
	@Test(priority=5,dependsOnMethods= {"Construct365_MyCrewTimesheet_3284_Equipment_Approve"})
	public void Construct365_MyCrewTimesheet_3285_Production_Approve() throws InterruptedException, IOException, Exception
	{	
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		MyTime.clickProductionTab();
		Thread.sleep(1000);
		MyTime.clickAddButton();
		Thread.sleep(1000);
		MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
		Thread.sleep(1000);
		MyTime.clickQuantityProductionTab(XLUtils.getCellData(excelpath, sheet3, 1, 12));
		Thread.sleep(1000);
		MyTime.clickSaveBtn1();
		System.out.println("New Crewtimesheet_Production method executed");
		logger.info("My Crew Timesheet-Production tab data has been saved successfully");
	}
	@Test(priority=6,dependsOnMethods= {"Construct365_MyCrewTimesheet_3285_Production_Approve"})
	public void Construct365_MyCrewTimesheet_3285_Submit_Approve() throws InterruptedException, IOException, Exception
	{	
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		MyTime.clickSubmitBtn();
		Thread.sleep(1000);
		System.out.println("My Crewtimesheet has been submitted");
		logger.info("My Crewtimesheet has been submitted successfully");
	}
	@Test(priority=7,dependsOnMethods= {"Construct365_MyCrewTimesheet_3285_Submit_Approve"})
	public void Construct365_MyCrewTimesheet_3287_Approve() throws InterruptedException, IOException, Exception
	{	
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		common_pom common=new common_pom(driver);
		//Search Project
		MyTime.clicksearchinprojid(XLUtils.getCellData(excelpath, sheet3, 1, 0));
		Thread.sleep(3000);
		common.clickstatusdropdown();
		Thread.sleep(1000);
		MyTime.selectDropDownValue("Submitted");
		Thread.sleep(3000);
		common.clickfirstcheckbox();
		Thread.sleep(2000);
		common.clickworkflow();
		Thread.sleep(2000);
		MyTime.clickApproveBtn();
		Thread.sleep(2000);
		MyTime.clickInlineApproveBtn();
		Thread.sleep(5000);
		System.out.println("My Crew Timesheet has been Approved");
		logger.info("My New Crew Timesheet has been Approved successfully");
	}
	
}

package sis.aps.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.ct.pageobjects.TimeManagement_Timesheets_CrewTemplateTimesheets;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class CrewTemplateTimesheet extends baseclass {

	String crewId = "CREWQA";
	String notes = "This is a test by Automation team";
	String crewM1= "Abel Johny";
	String crewM2= "Siva S";
	String regularHrs = "8";
	String ot1Hrs = "3";
	String ot2Hrs = "2";
	String expenseQty ="5";
	String equipmentQty ="5";
	String productionQty ="5";
	
	@Test(priority = 1)
	public void Construct365_smokesuite_CrewTemplateTimesheet_Header() throws InterruptedException, IOException, Exception {
		
		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);
		
		
		Thread.sleep(120000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(12000);
		logger.info("User logged in successfully");
		

		
		Thread.sleep(2000);
		menu.clicktimemanagementtab();
		Thread.sleep(1000);
		menu.clicktimesheetstab();
		Thread.sleep(1000);
		menu.clickcrewtemplateTimesheetstab();
		Thread.sleep(1000);
		crewtt.isCrewtemplateTMSHeaderDisplayed();
		Thread.sleep(1000);
		crewtt.clickBtnCrewtemplateTMS();
		Thread.sleep(2000);
		crewtt.isNewCrewtemplateTMSHeaderDisplayed();
		crewtt.setcrew(crewId);	
		Thread.sleep(3000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.setNotes(notes);
		Thread.sleep(1000);
		crewtt.ClickSaveBtn();
		Thread.sleep(3000);
		System.out.println("NewCrewtemplatetimesheet_Header > executed");	
		logger.info("My Crew Template Timesheet-Header tab data has been saved successfully");
	}
		

	@Test(priority = 2,dependsOnMethods= {"Construct365_smokesuite_CrewTemplateTimesheet_Header"})
	public void Construct365_smokesuite_CrewTemplateTimesheet_Hours() throws InterruptedException, IOException, Exception 
	{
		
		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);
		//Hours Tab - Activities
		
		crewtt.isHoursTabselected();
		Thread.sleep(2000);
		
		//click crew Member 1 Edit button
		driver.findElement(By.xpath("((//app-multi-worker-timesheet-hours//table)[2]//tr//td[text()='" +crewM1+ "']//parent::tr//td//button[@title='Edit'])[1]")).click();
		
		Thread.sleep(3000);
		crewtt.ClickJobclassification();
		Thread.sleep(3000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickSpecialPay();
		Thread.sleep(3000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickShiftId();
		Thread.sleep(3000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.SetRegularHrs(regularHrs);
		crewtt.SetOT1Hrs(ot1Hrs);
		crewtt.SetOT2Hrs(ot2Hrs);
		Thread.sleep(1000);
		crewtt.Clickpopup_SaveBtn();
		Thread.sleep(3000);
		logger.info("My Crew Template Timesheet-Hours tab > crew Member 1 has been updated successfully");
		System.out.println("New Crew template timesheet_hours tab editcrew Member > executed");
		
		//click crew Member 2 Edit button
		driver.findElement(By.xpath("((//app-multi-worker-timesheet-hours//table)[2]//tr//td[text()='" +crewM2+ "']//parent::tr//td//button[@title='Edit'])[1]")).click();
				
		Thread.sleep(3000);
		crewtt.ClickJobclassification();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickSpecialPay();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickShiftId();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.SetRegularHrs(regularHrs);
		crewtt.SetOT1Hrs(ot1Hrs);
		crewtt.SetOT2Hrs(ot2Hrs);
		Thread.sleep(1000);
		crewtt.Clickpopup_SaveBtn();
		Thread.sleep(3000);
		logger.info("My Crew Template Timesheet-Hours tab > crew member 2 has been updated successfully");
		System.out.println("New Crew template timesheet_hours tab edit crew Member > executed");
		
	}
	

	@Test(priority = 3,dependsOnMethods= {"Construct365_smokesuite_CrewTemplateTimesheet_Hours"})
	public void Construct365_smokesuite_CrewTemplateTimesheet_FieldExpense() throws InterruptedException, IOException, Exception 
	{

		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);
		// Field Expense Tab - Activities
		
		crewtt.clickfieldexpensestab();
		Thread.sleep(2000);
		crewtt.clickAddBtn();
		Thread.sleep(2000);
		crewtt.ClickprojectId();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClicktaskCode();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickexpenseCategory();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.setQuantity_Expense(expenseQty);
		Thread.sleep(1000);
		crewtt.ClickSaveBtn_expensepopup();
		Thread.sleep(3000);
		System.out.println("newcrewtemplatetimesheet_fieldexpense > executed");
		logger.info("New Crew Template Timesheet-Field Expenses tab data has been saved successfully");
	}
		

	@Test(priority = 4,dependsOnMethods= {"Construct365_smokesuite_CrewTemplateTimesheet_FieldExpense"})
	public void Construct365_smokesuite_CrewTemplateTimesheet_Equipment() throws InterruptedException, IOException, Exception 
	{
		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);

		// Equipment Tab - Activities
		crewtt.clickEquipmenttab();
		Thread.sleep(2000);
		crewtt.clickAddBtn();
		Thread.sleep(2000);
		crewtt.ClickprojectId_equipment();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.Clicktaskcode_equipment();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.ClickequipmentId_equipment();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.setQuantity_Equipment(equipmentQty);
		Thread.sleep(1000);
		crewtt.ClickSaveBtn_equipmentpopup();
		Thread.sleep(3000);
		System.out.println("newcrewtemplatetimesheet_equipment > executed");
		logger.info("New Crew Template Timesheet-Equipment tab data has been saved successfully");
	}
	

	@Test(priority = 5,dependsOnMethods= {"Construct365_smokesuite_CrewTemplateTimesheet_Equipment"})
	public void Construct365_smokesuite_CrewTemplateTimesheet_Production() throws InterruptedException, IOException, Exception 
	{
		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);

		// Production Tab - Activities
		crewtt.clickProductiontab();
		Thread.sleep(2000);
		crewtt.clickAddBtn();
		Thread.sleep(2000);
		crewtt.ClickprojectId_production();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.Clicktaskcode_production();
		Thread.sleep(2000);
		crewtt.clickmatoption();
		Thread.sleep(1000);
		crewtt.setQuantity_production(productionQty);
		Thread.sleep(1000);
		crewtt.ClickSaveBtn_productionpopup();
		Thread.sleep(3000);
		System.out.println("newcrewtemplatetimesheet_production > executed");
		logger.info("New Crew Template Timesheet- production tab data has been saved successfully");
		
		Thread.sleep(2000);
		mytimesheet.clickSubmitBtn();
		Thread.sleep(5000);
		logger.info("crew Template Timesheet ==> Submitted");
	}
		

	@Test(priority = 6,dependsOnMethods= {"Construct365_smokesuite_CrewTemplateTimesheet_Production"})
	public void Construct365_smokesuite_CrewTemplateTimesheet_ApproveandDelete() throws InterruptedException, IOException, Exception 
	{
		loginpage_pom login = new loginpage_pom(driver);
		leftmenu_pom menu = new leftmenu_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);
		
		// select crew Id
		driver.findElement(By.xpath("//app-timesheet-list//mat-select[@placeholder = 'Search field']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//mat-option//span[contains(text(),'Crew id')]")).click();
		Thread.sleep(1000);
		
		// search by crew id
		driver.findElement(By.xpath("//app-timesheet-list//input[@formcontrolname='searchInput']")).sendKeys(crewId);
		Thread.sleep(3000);
		
		/* Checkbox - Submitted Timesheet */
		
			
		String Tms_status = driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell[normalize-space(text())='" +crewId+ "']//parent::mat-row//mat-cell[6])[1]")).getText();
		System.out.println(Tms_status);
		
		if(Tms_status.equals("Submitted"))
		{
		logger.info("Timeheet status : " + Tms_status);	
		System.out.println("Timesheet status equals");
		Assert.assertTrue(true);
		}
		else
		{
		logger.info("Timeheet status : " + Tms_status);	
		System.out.println("Timesheet status not equals");	
		Assert.fail();
		}
		
		//
		
		// click checkbox 
		
		driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell[normalize-space(text())='" +crewId+ "']//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[1]")).click();
		Thread.sleep(2000);
		mytimesheet.clickApproveBtn();
		Thread.sleep(2000);
		mytimesheet.clickInlineApproveBtn();
		Thread.sleep(5000);
		logger.info("crew Template Timesheet ==> Approved");
		
		String Tms_status2 = driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell[normalize-space(text())='" +crewId+ "']//parent::mat-row//mat-cell[6])[1]")).getText();
		System.out.println(Tms_status2);
		
		if(Tms_status2.equals("Approved"))
		{
		logger.info("Timeheet status : " + Tms_status2);	
		System.out.println("Timesheet status equals");
		Assert.assertTrue(true);
		}
		else
		{
		logger.info("Timeheet status : " + Tms_status2);	
		System.out.println("Timesheet status not equals");	
		Assert.fail();
		}
		
		// Delete timesheet
		driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell[normalize-space(text())='CREWQA']//parent::mat-row//span[contains(text(),'Approved')]//parent::mat-cell//following-sibling::mat-cell//button[@mattooltip='Delete timesheet'])[1]")).click();
		Thread.sleep(2000);
		crewtt.ClickDeleteBtn_popup();
		Thread.sleep(3000);
		
		crewtt.isCrewtemplateTMSHeaderDisplayed();
		Thread.sleep(1000);
		logger.info("crew Template Approved Timesheet ==> Deleted");
	}
		
	}

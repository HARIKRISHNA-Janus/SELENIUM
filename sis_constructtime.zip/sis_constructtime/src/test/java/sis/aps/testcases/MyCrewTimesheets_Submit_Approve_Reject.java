package sis.aps.testcases;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;


public class MyCrewTimesheets_Submit_Approve_Reject extends baseclass{
	

	@Test(priority=1)
	public void MyCrewTimesheet_header() throws InterruptedException, IOException, Exception
	{
		loginpage_pom login=new loginpage_pom(driver);
		leftmenu_pom timesheet=new leftmenu_pom(driver);
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		
		Thread.sleep(30000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(15000);
		
		timesheet.clicktimemanagementtab();
		Thread.sleep(1000);
		timesheet.clicktimesheetstab();
		Thread.sleep(1000);
		timesheet.clkCrewtimesheetstab();
		Thread.sleep(1000);
		MyTime.clickNewCrewtimesheetsbtn();
		Thread.sleep(1000);
		MyTime.checkdatevalue();
		Thread.sleep(1000);
		MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
		Thread.sleep(1000);
		MyTime.checkCrewDescriptionField();
		Thread.sleep(1000);
		//MyTime.checkProjectID();
		MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
		Thread.sleep(1000);
		MyTime.clickStatusField();
		Thread.sleep(1000);
		MyTime.clickkNotestab();
		Thread.sleep(3000);
		MyTime.clickSaveBtn();
		Thread.sleep(3000);
		System.out.println("NewCrewtimesheet_Header method executed");	
		logger.info("My Crew Timesheet-Header tab data has been saved successfully");
	}
	

	@Test(priority=2,dependsOnMethods= {"MyCrewTimesheet_header"})
	public void MyCrewTimesheet_hours() throws InterruptedException, IOException, Exception
	{
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		//common_pom common=new common_pom(driver);
		Thread.sleep(3000);
		MyTime.clickAddButton();
		Thread.sleep(3000);
		MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
		Thread.sleep(1000);
		if(XLUtils.getCellData(excelpath, sheet3, 1, 6).equals(""))
		{
			Thread.sleep(1000);
			MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7), XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
			Thread.sleep(1000);
			MyTime.clickSaveBtn1();
			Thread.sleep(1000);
			logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
			System.out.println("New Crew timesheet_hours method executed");
		}
		else
		{
		MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
		Thread.sleep(1000);
		//common.clickkfirstvalue();
		Thread.sleep(1000);
		MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7), XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
		Thread.sleep(1000);
		MyTime.clickSaveBtn1();
		Thread.sleep(1000);
		logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
		System.out.println("New Crew timesheet_hours method executed");
		}
	 }
	
		@Test(priority = 3, dependsOnMethods = { "MyCrewTimesheet_hours" })
		public void MyCrewTimesheet_2819_Submit() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowSubmitBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetSubmitconformbox_displayed() == true) {
				Assert.assertTrue(true);
				logger.info("Timesheet submit conform box displayed");
			}

			else {

				Assert.fail();
				logger.info("Timesheet submit conform box not displayed");
			}
			Thread.sleep(1000);
			MyTime.clickConfirmboxSubmitbtn();
			Thread.sleep(2000);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}

			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);

			String tm_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm_status);

			if (tm_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();

			}

			System.out.println("My Crewtimesheet has been submitted");
			logger.info("My Crewtimesheet has been submitted successfully");
		}

		@Test(priority = 4, dependsOnMethods = { "MyCrewTimesheet_2819_Submit" })
		public void MyCrewTimesheet_header2() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 5, dependsOnMethods = { "MyCrewTimesheet_header2" })
		public void MyCrewTimesheet_hours2() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else 
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 6, dependsOnMethods = { "MyCrewTimesheet_hours2" })
		public void MyCrewTimesheet_2818_Submit() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			MyTime.clickSubmitBtn();
			Thread.sleep(2000);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}

			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);

			String tm_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm_status);

			if (tm_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();

			}

			System.out.println("My Crewtimesheet has been submitted");
			logger.info("My Crewtimesheet has been submitted successfully");
		}
		

		@Test(priority = 7, dependsOnMethods = { "MyCrewTimesheet_2818_Submit" })
		public void MyCrewTimesheet_header3() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 8, dependsOnMethods = { "MyCrewTimesheet_header3" })
		public void MyCrewTimesheet_hours3() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			leftmenu_pom timesheet=new leftmenu_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(2000);
				timesheet.clkCrewtimesheetstab();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 9, dependsOnMethods = { "MyCrewTimesheet_hours3" })
		public void MyCrewTimesheet_header4() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 10, dependsOnMethods = { "MyCrewTimesheet_header4" })
		public void MyCrewTimesheet_hours4() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			leftmenu_pom timesheet=new leftmenu_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else 
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(2000);
				timesheet.clkCrewtimesheetstab();
				Thread.sleep(2000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 11, dependsOnMethods = { "MyCrewTimesheet_hours4" })
		public void MyCrewTimesheet_2817_SubmitMultiple() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}
			
			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectDraftStatusoption();
			Thread.sleep(3000);

			// Get 1st timesheet status
			String tm1_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm1_status);

			if (tm1_status.equals("Draft")) 
			{

				logger.info("My crew Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			// Get 2nd timesheet status
			String tm2_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm2_status);

			if (tm2_status.equals("Draft")) 
			{

				logger.info("My crew Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
		

			// click Draft Timesheets -  checkbox and Submit

			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Draft')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[1]"))
					.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Draft')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[2]"))
					.click();
			Thread.sleep(1000);
			
			
			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowSubmitBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetSubmitconformbox_displayed() == true) {
				Assert.assertTrue(true);
				logger.info("Timesheet submit conform box displayed");
			}

			else {

				Assert.fail();
				logger.info("Timesheet submit conform box not displayed");
			}
			Thread.sleep(1000);
			MyTime.clickConfirmboxSubmitbtn();
			Thread.sleep(2000);
			
			MyTime.selectSubmittedStatusoption();
			Thread.sleep(2000);
			
			// Get 1st timesheet status - After submitted
			String tm3_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm3_status);

			if (tm3_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm3_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm3_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			Thread.sleep(1000);
			
			// Get 2nd timesheet status - After submitted
			String tm4_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm4_status);

			if (tm4_status.equals("Submitted")) {

				logger.info("My crew Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else {

				logger.info("Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
	

			System.out.println("Multiple My Crewtimesheet has been submitted");
			logger.info("Multiple My Crewtimesheet has been submitted successfully");
			}
		
		

		@Test(priority = 12, dependsOnMethods = { "MyCrewTimesheet_2817_SubmitMultiple" })
		public void MyCrewTimesheet_2396_Approve() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(2000);
			driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell//button[@mattooltip='View timesheet'])[1]")).click();

			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowApproveBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetApproveconformbox_displayed() == true) {
				Assert.assertTrue(true);
				logger.info("Timesheet Approve conform box displayed");
			}

			else {

				Assert.fail();
				logger.info("Timesheet Approve conform box not displayed");
			}
			
			Thread.sleep(1000);
			MyTime.clickConfirmboxApprovebtn();
			Thread.sleep(2000);
			
			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}
			
			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectApprovedStatusoption();
			Thread.sleep(3000);

			// Get 1st timesheet status
			String tm1_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm1_status);

			if (tm1_status.equals("Approved")) 
			{

				logger.info("My crew Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			System.out.println("My Crewtimesheet has been Approved");
			logger.info("My Crewtimesheet has been Approved successfully");
				
		}
		

		@Test(priority = 13, dependsOnMethods = { "MyCrewTimesheet_2396_Approve" })
		public void MyCrewTimesheet_2939_ApproveMultiple() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
//			Thread.sleep(1000);
//			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);
			
			// Get 1st timesheet status
			String tm1_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm1_status);

			if (tm1_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} 
			else 
			{

				logger.info("Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
						
			// Get 2nd timesheet status
			String tm2_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm2_status);

			if (tm2_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} 
			else 
			{

				logger.info("Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			// Get 3rd timesheet status
			String tm3_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm3_status);

			if (tm3_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm3_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm3_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}

			// click Submitted Timesheets - checkbox and Approve

			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[1]"))
					.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[2]"))
					.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[3]"))
					.click();
			Thread.sleep(1000);

			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowApproveBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetApproveconformbox_displayed() == true) 
			{
				Assert.assertTrue(true);
				logger.info("Timesheet Approve conform box displayed");
			}

			else 
			{

				Assert.fail();
				logger.info("Timesheet Approve conform box not displayed");
			}

			Thread.sleep(1000);
			MyTime.clickConfirmboxApprovebtn();
			Thread.sleep(2000);	
						
//			MyTime.selectcrewIdoption();
//			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectApprovedStatusoption();
			Thread.sleep(3000);

			// Get 1st timesheet status
			String tm4_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm4_status);

			if (tm4_status.equals("Approved")) 
			{

				logger.info("My crew Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			// Get 2nd timesheet status
			String tm5_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm5_status);

			if (tm5_status.equals("Approved")) 
			{

				logger.info("My crew Timeheet status : " + tm5_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			}
			else 
			{

				logger.info("Timeheet status : " + tm5_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			// Get 3rd timesheet status
			String tm6_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[3]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm6_status);

			if (tm6_status.equals("Approved")) {

				logger.info("My crew Timeheet status : " + tm6_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else {

				logger.info("Timeheet status : " + tm6_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}	
			
			System.out.println("Multiple My Crewtimesheet has been Approved");
			logger.info("Multiple My Crewtimesheet has been Approved successfully");
			
		}
		

		@Test(priority = 14, dependsOnMethods = { "MyCrewTimesheet_2939_ApproveMultiple" })
		public void MyCrewTimesheet_header5() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 15, dependsOnMethods = { "MyCrewTimesheet_header5" })
		public void MyCrewTimesheet_hours5() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else 
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 16, dependsOnMethods = { "MyCrewTimesheet_hours5" })
		public void MyCrewTimesheet_Submit1() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			MyTime.clickSubmitBtn();
			Thread.sleep(2000);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}

			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);

			String tm_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm_status);

			if (tm_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();

			}

			System.out.println("My Crewtimesheet has been submitted");
			logger.info("My Crewtimesheet has been submitted successfully");
		}
		


		@Test(priority = 17, dependsOnMethods = { "MyCrewTimesheet_Submit1" })
		public void MyCrewTimesheet_header6() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 18, dependsOnMethods = { "MyCrewTimesheet_header6" })
		public void MyCrewTimesheet_hours6() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else 
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 19, dependsOnMethods = { "MyCrewTimesheet_hours6" })
		public void MyCrewTimesheet_Submit2() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			MyTime.clickSubmitBtn();
			Thread.sleep(2000);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}

			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);

			String tm_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm_status);

			if (tm_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();

			}

			System.out.println("My Crewtimesheet has been submitted");
			logger.info("My Crewtimesheet has been submitted successfully");
		}
		


		@Test(priority = 20, dependsOnMethods = { "MyCrewTimesheet_Submit2" })
		public void MyCrewTimesheet_header7() throws InterruptedException, IOException, Exception {
			
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
			Thread.sleep(1000);
			MyTime.clickNewCrewtimesheetsbtn();
			Thread.sleep(1000);
			MyTime.checkdatevalue();
			Thread.sleep(1000);
			MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(1000);
			MyTime.checkCrewDescriptionField();
			Thread.sleep(1000);
			//MyTime.checkProjectID();
			MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet3, 1, 0));
			Thread.sleep(1000);
			MyTime.clickStatusField();
			Thread.sleep(1000);
			MyTime.clickkNotestab();
			Thread.sleep(3000);
			MyTime.clickSaveBtn();
			Thread.sleep(3000);
			System.out.println("NewCrewtimesheet_Header method executed");	
			logger.info("My Crew Timesheet-Header tab data has been saved successfully");
		}

		@Test(priority = 21, dependsOnMethods = { "MyCrewTimesheet_header7" })
		public void MyCrewTimesheet_hours7() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			// common_pom common=new common_pom(driver);
			Thread.sleep(3000);
			MyTime.clickAddButton();
			Thread.sleep(3000);
			MyTime.clickTaskCodeHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 2));
			Thread.sleep(1000);
			if (XLUtils.getCellData(excelpath, sheet3, 1, 6).equals("")) 
			{
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			} 
			else 
			{
				MyTime.clickshiftid(XLUtils.getCellData(excelpath, sheet3, 1, 6));
				Thread.sleep(1000);
				// common.clickkfirstvalue();
				Thread.sleep(1000);
				MyTime.enterRegularHoursTab(XLUtils.getCellData(excelpath, sheet3, 1, 7),
						XLUtils.getCellData(excelpath, sheet3, 1, 8), XLUtils.getCellData(excelpath, sheet3, 1, 9));
				Thread.sleep(1000);
				MyTime.clickSaveBtn1();
				Thread.sleep(1000);
				logger.info("My Crew Timesheet-Hours tab data has been saved successfully");
				System.out.println("New Crew timesheet_hours method executed");
			}
		}
			

		@Test(priority = 22, dependsOnMethods = { "MyCrewTimesheet_hours7" })
		public void MyCrewTimesheet_Submit3() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);

			MyTime.clickSubmitBtn();
			Thread.sleep(2000);

			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}

			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);

			String tm_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm_status);

			if (tm_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();

			}

			System.out.println("My Crewtimesheet has been submitted");
			logger.info("My Crewtimesheet has been submitted successfully");
		}
		

		@Test(priority = 23, dependsOnMethods = { "MyCrewTimesheet_Submit3" })
		public void MyCrewTimesheet_Reject_2941() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			

			Thread.sleep(2000);
			driver.findElement(By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell//button[@mattooltip='View timesheet'])[1]")).click();

			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowRejectBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetRejectconformbox_displayed() == true) {
				Assert.assertTrue(true);
				logger.info("Timesheet Reject conform box displayed");
			}

			else {

				Assert.fail();
				logger.info("Timesheet Reject conform box not displayed");
			}
			
			Thread.sleep(1000);
			MyTime.clickConfirmboxRejectbtn();
			Thread.sleep(2000);
			
			if (MyTime.chk_Mycrewtimesheets_Headerdisplayed() == true) {
				Assert.assertTrue(true);
				logger.info("My crew timesheets header displayed");
			}

			else {

				Assert.fail();
				logger.info("My crew timesheets header displayed");
			}
			
			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectRejectedStatusoption();
			Thread.sleep(3000);

			// Get 1st timesheet status
			String tm1_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm1_status);

			if (tm1_status.equals("Rejected")) 
			{

				logger.info("My crew Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			System.out.println("My Crewtimesheet has been Rejected");
			logger.info("My Crewtimesheet has been Rejected successfully");

		}
		

		@Test(priority = 24, dependsOnMethods = { "MyCrewTimesheet_Reject_2941" })
		public void MyCrewTimesheet_2940_RejectMultiple() throws InterruptedException, IOException, Exception {
			constructsmokeMyTimesheet_pom MyTime = new constructsmokeMyTimesheet_pom(driver);
			
//			Thread.sleep(1000);
//			MyTime.selectcrewIdoption();
			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectSubmittedStatusoption();
			Thread.sleep(3000);
			
			// Get 1st timesheet status
			String tm1_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm1_status);

			if (tm1_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} 
			else 
			{

				logger.info("Timeheet status : " + tm1_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
						
			// Get 2nd timesheet status
			String tm2_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm2_status);

			if (tm2_status.equals("Submitted")) 
			{

				logger.info("My crew Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} 
			else 
			{

				logger.info("Timeheet status : " + tm2_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
		

			// click Submitted Timesheets - checkbox and Reject

			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[1]"))
					.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath(
					"(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//span[contains(text(),'Submitted')]//ancestor::mat-row//mat-checkbox[contains(@id,'checkbox')])[2]"))
					.click();
			Thread.sleep(1000);

			MyTime.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			MyTime.clickGroupworkflowRejectBtn();
			Thread.sleep(1000);

			if (MyTime.chk_TimesheetRejectconformbox_displayed() == true) 
			{
				Assert.assertTrue(true);
				logger.info("Timesheet Reject conform box displayed");
			}

			else 
			{

				Assert.fail();
				logger.info("Timesheet Reject conform box not displayed");
			}

			Thread.sleep(1000);
			MyTime.clickConfirmboxRejectbtn();
			Thread.sleep(2000);	
						
//			MyTime.selectcrewIdoption();
//			Thread.sleep(1000);

			MyTime.searchCrew(XLUtils.getCellData(excelpath, sheet3, 1, 5));
			Thread.sleep(2000);

			MyTime.selectRejectedStatusoption();
			Thread.sleep(3000);

			// Get 1st timesheet status
			String tm4_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[1]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm4_status);

			if (tm4_status.equals("Rejected")) 
			{

				logger.info("My crew Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			} else 
			{

				logger.info("Timeheet status : " + tm4_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			// Get 2nd timesheet status
			String tm5_status = driver
					.findElement(
							By.xpath("(//app-timesheet-list//mat-table//mat-cell//parent::mat-row//mat-cell[6])[2]"))
					.getText();
			System.out.println("Timesheet 1row status " + tm5_status);

			if (tm5_status.equals("Rejected")) 
			{

				logger.info("My crew Timeheet status : " + tm5_status);
				System.out.println("My crew Timesheet status equals");
				Assert.assertTrue(true);

			}
			else 
			{

				logger.info("Timeheet status : " + tm5_status);
				System.out.println("My crew Timesheet status not equals");
				Assert.fail();
			}
			
			
			System.out.println("Multiple My Crewtimesheet has been Rejected");
			logger.info("Multiple My Crewtimesheet has been Rejected successfully");
			
		}


		
		
}

package sis.aps.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.aps.utilities.commonutil;
import sis.ct.pageobjects.TimeManagement_Timesheets_CrewTemplateTimesheets;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class Verify_CrewTemplateTimesheet_Header_Hours_tab_3728 extends baseclass {


	@Test(priority = 1)
	public void Construct365_Regressionsuite_CrewTemplateTimesheet_HeaderandHours() throws InterruptedException, IOException, Exception {
		
		loginpage_pom login = new loginpage_pom(driver);
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		constructsmokeMyTimesheet_pom mytimesheet = new constructsmokeMyTimesheet_pom(driver);
		
		Thread.sleep(3000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(3000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		Thread.sleep(3000);
		
		Thread.sleep(2000);
		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(1000);
		
		leftmenuObj.clicktimesheetstab();
		Thread.sleep(1000);
		
		leftmenuObj.clickcrewtemplateTimesheetstab();
		Thread.sleep(1000);
		
		crewtt.isCrewtemplateTMSHeaderDisplayed();
		Thread.sleep(1000);
		
		crewtt.clickBtnCrewtemplateTMS();
		Thread.sleep(2000);
		
		crewtt.isNewCrewtemplateTMSHeaderDisplayed();
		Thread.sleep(1000);
		
		if (crewtt.check_Header_Tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Header tab - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Header tab - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Hours_Tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours tab - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours tab - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Fieldexpenses_Tabdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field expenses tab - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Field expenses tab - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Equipment_Tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment tab - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Equipment tab - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Production_Tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production tab - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Production tab - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Save_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Save button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Save button - Not Displayed");
			Assert.fail();
		}
		
		Thread.sleep(1000);
		crewtt.checkdatevalue();
		
		if (crewtt.check_crewfield_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Crew field - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_crewforemanfield_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew foreman field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Crew foreman field - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_crewdescriptionfield_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew description field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Crew description field - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_crewstatusfield_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew status field - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Crew status field - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_crewNotesfield_displayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew notes field - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Crew notes field - Not Displayed");
			Assert.fail();
		}
		
		
		String gStatus = driver.findElement(By.xpath("//app-timesheet-add-edit//input[@data-placeholder='Status']")).getAttribute("value");
		System.out.println("Status = " + gStatus);
		
		if (gStatus.equals("Draft")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Status equals");
		}

		else
		{

			logger.info("Crew Template Timesheet - Status not equals");
			Assert.fail();
		}
		
		
		crewtt.clickSavebutton_toobar();
		Thread.sleep(2000);
		
		if (crewtt.check_alertmessage_header_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Header tab alert message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Header tab alert message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_crewinput_fielderrormessage_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew input field error message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Crew input field error message - Not Displayed");
			Assert.fail();
		}
		
		
		
		/*
		 * // Set Date driver.findElement(By.
		 * xpath("(//mat-datepicker-toggle//button[@aria-label='Open calendar'])[1]")).
		 * click();
		 * driver.findElement(By.xpath("//div[@class='mat-calendar-arrow']")).click();
		 * driver.findElement(By.xpath("//div[normalize-space()='2021']")).click();
		 * driver.findElement(By.xpath("//div[normalize-space()='JUN']")).click();
		 * driver.findElement(By.xpath("//td//div[normalize-space()='30']")).click();
		 */
		
		String Crew = XLUtils.getCellData(excelpath, sheet5, 3, 0);
		
		crewtt.setCrew(Crew);
		Thread.sleep(2000);
		
		common_pom cm = new common_pom(driver);
		

		cm.selectDropDownValue(Crew);
		Thread.sleep(2000);
		
		String gForemanName = driver.findElement(By.xpath("//app-timesheet-add-edit//input[@data-placeholder='Crew foreman']")).getAttribute("value");
		System.out.println("Crew Foreman Name = " + gForemanName);
		
		String crewForemanName = XLUtils.getCellData(excelpath, sheet5, 3, 1);
		
		if (crewForemanName.equals(gForemanName))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Crew foreman name equals");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Crew foreman name not equals");
			Assert.fail();
		}
		
		crewtt.clickSavebutton_toobar();
		Thread.sleep(2000);
		
		String gHCrewid = driver.findElement(By.xpath("//input[@id='crewId']")).getAttribute("value");
		System.out.println("Crew Foreman Name = " + gHCrewid);
		
		if (Crew.equals(gHCrewid)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew equals");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Hours Tab - Crew not equals");
			Assert.fail();
		}
		
		String gHcrewforemanname = driver.findElement(By.xpath("//input[@formcontrolname='crewForeman']")).getAttribute("value");
		System.out.println("Crew Foreman Name = " + gHcrewforemanname);
		
		if (crewForemanName.equals(gHcrewforemanname)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew foreman name equals");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Hours Tab - Crew foreman name not equals");
			Assert.fail();
		}
		
		Thread.sleep(1000);
		crewtt.checkdatevalueHourstab();
		
		if (crewtt.check_crewmemberfilter_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours tab Crew member filter - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -Hours tab Crew member filter - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_projectfilter_isdisplayed() == true) {
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours tab Project filter - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -Hours tab Project filter - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_projectTaskfilter_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours tab Project Task filter - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -Hours tab Project Task filter - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Submit_btndisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Submit button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Submit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Addworker_buttondisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Add worker button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Add worker button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Addtaskcode_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Add Task code button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Add Task code button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Edit_buttondisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Edit button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Edit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Delete_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Delete button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Delete button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Save_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Save button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Save button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Cancel_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Cancel button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab - Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Crewmember_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - CrewMember column Header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab -  CrewMember column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Project_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Project column Header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab -  Project column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Task_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Task column Header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab -  Task column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Regularhours_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Regularhours column Header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab -  Regularhours column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_OT1hours_columnheaderisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - OT1Hours column Header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab -  OT1Hours column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_OT2hours_columnheaderisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - OT2Hours column Header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab -  OT2Hours column Header - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Total_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Total column Header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab -  Total column Header - Not Displayed");
			Assert.fail();
		}
		
		/* Crew Member 1 - Verification */ 
		
		String crewmember1 = XLUtils.getCellData(excelpath, sheet5, 3, 2);
		System.out.println("Crew member 1 = " + crewmember1);
		
		String gCm1Project = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[1]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " Project = " +gCm1Project );
		
		String crewmember1project = XLUtils.getCellData(excelpath, sheet5, 3, 3);		
		
		if(gCm1Project.contains(crewmember1project))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Project - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Project - Not Equals");
			Assert.fail();	
		}
		
		String gCm1Task = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[2]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " Task = " +gCm1Task );
		
		String crewmember1Task = XLUtils.getCellData(excelpath, sheet5, 3, 4);		
		
		if(gCm1Task.contains(crewmember1Task))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Task - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Task - Not Equals");
			Assert.fail();	
		}
		
		String gCm1RegularHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[3]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " Regular Hours = " +gCm1RegularHrs );
		
		if(gCm1RegularHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Regular Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Regular Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm1OT1Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[4]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " OT1 Hours = " +gCm1OT1Hrs );
		
		if(gCm1OT1Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 OT1 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 OT1 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm1OT2Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[5]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " OT2 Hours = " +gCm1OT2Hrs );
		
		if(gCm1OT2Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 OT2 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 OT2 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm1TotalHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']/following::td[6]")).getText();
		System.out.println("Crew Member 1 " +crewmember1+ " Total Hours = " +gCm1TotalHrs );
		
		if(gCm1TotalHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Total Hours - Not Equals");
			Assert.fail();	
		}
		
		/* Crew Member 2 - Verification */
		
		String crewmember2 = XLUtils.getCellData(excelpath, sheet5, 3, 9);
		System.out.println("Crew member 2 = " + crewmember2);
		
		String gCm2Project = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[1]")).getText();
		System.out.println("Crew Member 2 " +crewmember1+ " Project = " +gCm2Project );
		
		String crewmember2project = XLUtils.getCellData(excelpath, sheet5, 3, 10);		
		
		if(gCm2Project.contains(crewmember2project))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Project - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Project - Not Equals");
			Assert.fail();	
		}
		
		String gCm2Task = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[2]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " Task = " +gCm2Task );
		
		String crewmember2Task = XLUtils.getCellData(excelpath, sheet5, 3, 11);		
		
		if(gCm2Task.contains(crewmember2Task))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Task - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Task - Not Equals");
			Assert.fail();	
		}
		
		String gCm2RegularHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[3]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " Regular Hours = " +gCm2RegularHrs );
		
		if(gCm2RegularHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Regular Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Regular Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm2OT1Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[4]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " OT1 Hours = " +gCm2OT1Hrs );
		
		if(gCm2OT1Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT1 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT1 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm2OT2Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[5]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " OT2 Hours = " +gCm2OT2Hrs );
		
		if(gCm2OT2Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT2 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT2 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm2TotalHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[6]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " Total Hours = " +gCm2TotalHrs );
		
		if(gCm2TotalHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Total Hours - Not Equals");
			Assert.fail();	
		}
		
		/* Crew Member 3 - Verification */
		
		String crewmember3 = XLUtils.getCellData(excelpath, sheet5, 3, 16);
		System.out.println("Crew member 3 = " + crewmember3);
		
		String gCm3Project = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[1]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " Project = " +gCm3Project );
		
		String crewmember3project = XLUtils.getCellData(excelpath, sheet5, 3, 17);		
		
		if(gCm3Project.contains(crewmember3project))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Project - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Project - Not Equals");
			Assert.fail();	
		}
		
		String gCm3Task = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[2]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " Task = " +gCm3Task );
		
		String crewmember3Task = XLUtils.getCellData(excelpath, sheet5, 3, 18);		
		
		if(gCm3Task.contains(crewmember3Task))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Task - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Task - Not Equals");
			Assert.fail();	
		}
		
		String gCm3RegularHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[3]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " Regular Hours = " +gCm3RegularHrs );
		
		if(gCm3RegularHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Regular Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Regular Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm3OT1Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[4]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " OT1 Hours = " +gCm3OT1Hrs );
		
		if(gCm3OT1Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 OT1 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 OT1 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm3OT2Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[5]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " OT2 Hours = " +gCm3OT2Hrs );
		
		if(gCm3OT2Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 OT2 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 OT2 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm3TotalHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']/following::td[6]")).getText();
		System.out.println("Crew Member 3 " +crewmember3+ " Total Hours = " +gCm3TotalHrs );
		
		if(gCm3TotalHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 3 Total Hours - Not Equals");
			Assert.fail();	
		}
		
		/* Crew Member 4 - Verification */
		
		String crewmember4 = XLUtils.getCellData(excelpath, sheet5, 3, 23);
		System.out.println("Crew member 4 = " + crewmember4);
		
		String gCm4Project = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[1]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " Project = " +gCm4Project );
		
		String crewmember4project = XLUtils.getCellData(excelpath, sheet5, 3, 24);		
		
		if(gCm4Project.contains(crewmember4project))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Project - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Project - Not Equals");
			Assert.fail();	
		}
		
		String gCm4Task = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[2]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " Task = " +gCm4Task );
		 
		
		String crewmember4Task = XLUtils.getCellData(excelpath, sheet5, 3, 25);		
		
		if(gCm4Task.contains(crewmember4Task))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Task - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Task - Not Equals");
			Assert.fail();	
		}
		
		String gCm4RegularHrs = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[3]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " Regular Hours = " +gCm4RegularHrs );
		
		if(gCm4RegularHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Regular Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Regular Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm4OT1Hrs = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[4]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " OT1 Hours = " +gCm4OT1Hrs );
		
		if(gCm4OT1Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 OT1 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 OT1 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm4OT2Hrs = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[5]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " OT2 Hours = " +gCm4OT2Hrs );
		
		if(gCm4OT2Hrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 OT2 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 OT2 Hours - Not Equals");
			Assert.fail();	
		}
		
		String gCm4TotalHrs = driver.findElement(By.xpath("//table//tr//td[normalize-space(text())= '" + crewmember4 + "']/following::td[6]")).getText();
		System.out.println("Crew Member 4 " +crewmember4+ " Total Hours = " +gCm4TotalHrs );
		
		if(gCm4TotalHrs.equals("0.00"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 4 Total Hours - Not Equals");
			Assert.fail();	
		}
		
		/* Set Hours - Crew Member 1 - Inline Edit */
		Thread.sleep(1000);
		Actions a = new Actions(driver);
		
		a.moveToElement(driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember1 + "']"))).
		doubleClick().build().perform();
		Thread.sleep(1000);
		
		String crewmember1RegularHrs = XLUtils.getCellData(excelpath, sheet5, 3, 5);	
		
		crewtt.SetRegularHrs_Inline(crewmember1RegularHrs);
		Thread.sleep(1000);
		
		String crewmember1OT1Hrs = XLUtils.getCellData(excelpath, sheet5, 3, 6);
		
		crewtt.SetOT1Hrs_Inline(crewmember1OT1Hrs);
		Thread.sleep(1000);
		
		String gInlineCm1TotalHrs = driver.findElement(By.xpath("//table//tr//td/following::td[6]//input[@id='totalTimeHours']")).getAttribute("value");
		System.out.println("Crew Member 1 " +crewmember1+ " Total Hours = " +gInlineCm1TotalHrs );
		
		double crewmember1TotalHrsint = XLUtils.getFormulavalue(excelpath, sheet5, 3, 8);
		System.out.println("Excel value  "+crewmember1TotalHrsint);
		
		
		String crewmember1TotalHrs=Double.toString(crewmember1TotalHrsint);  
		System.out.println("Excel value  conversion "+crewmember1TotalHrs);
		
		if(gInlineCm1TotalHrs.contains(crewmember1TotalHrs))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 inline Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 1 Inline Total Hours - Not Equals");
			Assert.fail();	
		}
		
		crewtt.Savebutton_Inline();
		Thread.sleep(2000);
		
		/* Crew Member 2 - Edit */
		
		driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']")).click();
		
		crewtt.click_ToolbarEditbutton();
		Thread.sleep(3000);
		
		
		String worker = driver.findElement(By.xpath("//input[@formcontrolname='worker']")).getAttribute("value");
		System.out.println("Worker ==> " +worker);
		
		if(worker.equals(crewmember2))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Edit Crew Member 2 - Worker Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Edit Crew Member 2 - Worker Not Equals");
			Assert.fail();	
		}
		
		// Edit Project Id
		
		String editproject = XLUtils.getCellData(excelpath, sheet5, 3, 30);
		System.out.println("Edit Project Id " + editproject +" ==> " +worker);
		
		crewtt.setprojectId(editproject);
		Thread.sleep(2000);

		cm.selectDropDownValue(editproject);
		Thread.sleep(2000);
		
		// Edit Task code

		String editTask = XLUtils.getCellData(excelpath, sheet5, 3, 31);
		System.out.println("Edit Task code " + editTask + " ==> " + worker);

		crewtt.setTaskcode(editTask);
		Thread.sleep(2000);

		cm.selectDropDownValue(editTask);
		Thread.sleep(2000);
		
		
		
		// Set Job Classication - Crew member 2
		String crewmember2JBClassification = XLUtils.getCellData(excelpath, sheet5, 3, 32);
		System.out.println("Crew Member " +crewmember2 +"Job Classification ==> "+ crewmember2JBClassification);
		
		crewtt.setJobclassification(crewmember2JBClassification);
		Thread.sleep(2000);

		cm.selectDropDownValue(crewmember2JBClassification);
		
		// Set Special Pay - Crew member 2
		String crewmember2Specialpay = XLUtils.getCellData(excelpath, sheet5, 3, 33);
		System.out.println("Crew Member " +crewmember2 +"Special Pay ==> "+ crewmember2Specialpay);
		
		crewtt.setSpecialPayn(crewmember2Specialpay);
		Thread.sleep(2000);

		cm.selectDropDownValue(crewmember2Specialpay);
		
		// Set Shift Id - Crew member 2
		String crewmember2Shiftid = XLUtils.getCellData(excelpath, sheet5, 3, 34);
		System.out.println("Crew Member " + crewmember2 + "Special Pay ==> " + crewmember2Shiftid);

		crewtt.setShiftId(crewmember2Shiftid);
		Thread.sleep(2000);

		cm.selectDropDownValue(crewmember2Shiftid);
			
		// Set OT2 Hours - Crew member 2
		String crewmember2OT2Hrs = XLUtils.getCellData(excelpath, sheet5, 3, 14);
		System.out.println("Crew member " + crewmember2 + " OT2 Hours ==>  " + crewmember2OT2Hrs);
		
		Thread.sleep(1000);
		crewtt.SetOT2Hrs_Editpopup(crewmember2OT2Hrs);
		Thread.sleep(1000);
		
		// Verify Total hours - Crew member 2
		double crewmember2TotalHrsint = XLUtils.getFormulavalue(excelpath, sheet5, 3, 15);
		System.out.println("Crew member " + crewmember2 + " Total Hours ==>  " + crewmember2TotalHrsint);
		
		String crewmember2TotalHrs=Double.toString(crewmember2TotalHrsint);  
		System.out.println("Excel value  conversion "+crewmember2TotalHrs);
		
		String gCM2Totalhrsep = driver.findElement(By.xpath("//input[@formcontrolname='totalTimeHours']")).getAttribute("value");
		System.out.println("Crew member " + crewmember2 + " Edit popup Total Hours ==>  " + gCM2Totalhrsep);
		
		
		if(gCM2Totalhrsep.contains(crewmember2TotalHrs))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Edit popup Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Edit popup Total Hours - Not Equals");
			Assert.fail();	
		}
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		String g2ndCm2OT2Hrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[5]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " OT2 Hours = " +g2ndCm2OT2Hrs );
		
		if(g2ndCm2OT2Hrs.contains(crewmember2OT2Hrs))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT2 Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 OT2 Hours - Not Equals");
			Assert.fail();	
		}
		
		String g2ndCm2TotalHrs = driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']/following::td[6]")).getText();
		System.out.println("Crew Member 2 " +crewmember2+ " Total Hours ==> " +g2ndCm2TotalHrs );
		
		if(g2ndCm2TotalHrs.contains(crewmember2TotalHrs))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Crew Member 2 Total Hours - Not Equals");
			Assert.fail();	
		}
		
		//Weekly Total Hours
		double WeeklyTotalHoursint = XLUtils.getFormulavalue(excelpath, sheet5, 3, 35);
		System.out.println("Excel ==> Weekly Total Hours ==> " + WeeklyTotalHoursint);
		
		String WeeklyTotalHours=Double.toString(WeeklyTotalHoursint);  
		System.out.println("Excel value  conversion "+WeeklyTotalHours);
		
		
		String gWeeklyTotalHours = driver.findElement(By.xpath("//td[text()='Total']/following::td[4]")).getText();
		System.out.println("Weekly Total Hours ==> " +gWeeklyTotalHours );
		
		if(gWeeklyTotalHours.contains(WeeklyTotalHours))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Weekly Total Hours - Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Weekly Total Hours - Not Equals");
			Assert.fail();	
		}
		Thread.sleep(2000);
		
		/* Crew Member 2 - Edit */
		
		driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']")).click();
		
		crewtt.click_ToolbarEditbutton();
		Thread.sleep(2000);
		
		crewtt.click_CancelBtn_Editpopup();
		Thread.sleep(2000);
		
		/* Crew Member 3 - Delete */
		
		driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember3 + "']")).click();
		
		crewtt.click_ToolbarDeletebutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Deleteconfirmbox_Messagedisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Delete confirm Box Message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Delete confirm Box Message - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_Deletepopup_Cancelbutton();
		Thread.sleep(2000);
		
		crewtt.click_ToolbarDeletebutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Deleteconfirmbox_Messagedisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Delete confirm Box Message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Delete confirm Box Message - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_Deletepopup_Deletebutton();
		Thread.sleep(2000);
		
		if (crewtt.checkTimesheet_hours_deleted_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Timesheet hours deleted message is displayed");
		}

		else 
		{

			logger.info("Timesheet hours deleted message is not displayed");
			Assert.fail();
		}
		
//		/* Uncomment the beloq steps to add worker */
//		
//		// Add Worker
//		crewtt.click_Addworkerbutton();
//		Thread.sleep(2000);
//		
//		if (crewtt.check_worker_fielddisplayed() == true) {
//			Assert.assertTrue(true);
//			logger.info("Worker field is displayed");
//		}
//
//		else {
//
//			logger.info("Worker field is not displayed");
//			Assert.fail();
//		}
//		
//		
//		//Set worker
//		crewtt.SetWorker_Addworkerform(crewmember3);
//		Thread.sleep(2000);
//
//		cm.selectDropDownValue(crewmember3);
//		
//		crewtt.click_Savebtn_Editpopup();
//		Thread.sleep(2000);
		
		/* Step 24 - 40 needs to be covered  */	
		
		
	}
	

	@Test(priority = 2, dependsOnMethods = { "Construct365_Regressionsuite_CrewTemplateTimesheet_HeaderandHours" })
	public void Construct365_Regressionsuite_CrewTemplateTimesheet_FieldExpenses() throws InterruptedException, IOException, Exception {
		
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		
		
		//Click field expenses - Tab
		Thread.sleep(2000);
		crewtt.clickfieldexpensestab();
		Thread.sleep(2000);
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Submit_btndisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Submit button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Submit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Add_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Add button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab - Add button - Not Displayed");
			Assert.fail();
		}
		
		
		
		if (crewtt.check_Edit_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Edit button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Edit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Delete_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Delete button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Hours Tab - Delete button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Save_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Save button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Save button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Cancel_buttondisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Cancel button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet - Hours Tab - Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Date_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Date column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Date column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Crewmember_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Crew Member column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Crew member column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Project_columnheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Project column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Project column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Task_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Task column header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Task column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Expensecategory_columnheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Expense Category column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Expense Category column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantity_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Quantity column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Quantity column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unit_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Unit column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Unit column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitprice_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Unit price column header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Unit price column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Totalamount_columnheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Tab - Total amount column header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Tab - Total amount column header- Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Fieldexpense_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form header- Not Displayed");
			Assert.fail();
		}
		
		
		String crewmember1 = XLUtils.getCellData(excelpath, sheet5, 3, 2);
		System.out.println("Crew member 1 = " + crewmember1);
		
		// crew member 1 - checkbox is cheked/unchecked
		String crewmember1checked = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember1 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember1checked.contains("checked"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember1+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber"+crewmember1+" Unchecked");
			Assert.fail();
		}
		
		String crewmember2 = XLUtils.getCellData(excelpath, sheet5, 3, 9);
		System.out.println("Crew member 2 = " + crewmember2);
		
		// crew member 2 - checkbox is cheked/unchecked
		String crewmember2checked = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember2 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember2checked.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember2+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember2+ "Unchecked");
			Assert.fail();
		}
		
		String crewmember4 = XLUtils.getCellData(excelpath, sheet5, 3, 23);
		System.out.println("Crew member 4 = " + crewmember4);
		
		// crew member 4 - checkbox is cheked/unchecked
		String crewmember4checked = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember4checked.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember4+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember4+ "Unchecked");
			Assert.fail();
		}
		
		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();
		
		
		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Project field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Task code field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Task code field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Expensecategoryfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Expense category field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Expense category field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Quantity field - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitpricefield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit price - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit price - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Totalamountfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Total amount - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Total amount - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Cancel button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Save button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Save button - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(2000);
		
		if (crewtt.check_Projectfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form project field error message - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form project field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Task code field error message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Task code field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Expensecategoryfield_errormsg_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Expense category field error message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Expense category field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantityfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Quantity field error message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Quantity field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitpricefield_errormsg_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit price field error message - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit price field error message - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_CancelBtn_Editpopup();
		Thread.sleep(2000);

		// Add Field expense
		
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Fieldexpense_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form header- Not Displayed");
			Assert.fail();
		}
		
		
		// crew member 1 - checkbox is cheked/unchecked
		String crewmember1checked2 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember1 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember1checked2.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember1+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber"+crewmember1+" Unchecked");
			Assert.fail();
		}
		
		
		// crew member 2 - checkbox is cheked/unchecked
		String crewmember2checked2 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember2 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember2checked2.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember2+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember2+ "Unchecked");
			Assert.fail();
		}
		
		
		// crew member 4 - checkbox is cheked/unchecked
		String crewmember4checked2 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember4checked2.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember4+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember4+ "Unchecked");
			Assert.fail();
		}
		
		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();
		
		
		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Project field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Task code field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Task code field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Expensecategoryfield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Expense category field - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Expense category field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Quantity field - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitfield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitpricefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit price - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit price - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Totalamountfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Total amount - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Total amount - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Cancel button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Save button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Save button - Not Displayed");
			Assert.fail();
		}
		
			
		// uncheck crew member 2
		driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember2 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).click();

		// crew member 2 - checkbox is cheked/unchecked
		String crewmember2unchecked = driver
				.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='"
						+ crewmember2 + "']//ancestor::mat-list-option//mat-pseudo-checkbox"))
				.getAttribute("class");

		if (crewmember2unchecked.equals("mat-pseudo-checkbox ng-star-inserted")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" + crewmember2 + "unchecked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" + crewmember2 + "checked");
			Assert.fail();
		}

		
		// uncheck crew member 4
		driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).click();

		// crew member 4 - checkbox is cheked/unchecked
		String crewmember4unchecked = driver
				.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='"
						+ crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox"))
				.getAttribute("class");

		if (crewmember4unchecked.equals("mat-pseudo-checkbox ng-star-inserted")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" + crewmember4 + "unchecked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" + crewmember4 + "checked");
			Assert.fail();
		}
		
		common_pom cm = new common_pom(driver);
		
		String projectId = XLUtils.getCellData(excelpath, sheet5, 3, 36);
		System.out.println("Project Id " +projectId);
		
		crewtt.setprojectId(projectId);
		Thread.sleep(2000);

		cm.selectDropDownValue(projectId);
		Thread.sleep(2000);
		
		String taskCode = XLUtils.getCellData(excelpath, sheet5, 3, 37);
		System.out.println("Task code " +taskCode);
		
		crewtt.setTaskcode(taskCode);
		Thread.sleep(2000);

		cm.selectDropDownValue(taskCode);
		Thread.sleep(2000);
		
		String expenseCategory = XLUtils.getCellData(excelpath, sheet5, 3, 38);
		System.out.println("Expense category " +expenseCategory);
		
		crewtt.setExpenseCategory(expenseCategory);
		Thread.sleep(2000);

		cm.selectDropDownValue(expenseCategory);
		Thread.sleep(2000);
		
		String quantity = XLUtils.getCellData(excelpath, sheet5, 3, 39);
		System.out.println("Quantity " +quantity);
		
		crewtt.setQuantity(quantity);
		Thread.sleep(1000);
		
		String gUnit = driver.findElement(By.xpath("//input[@formcontrolname='unit']")).getAttribute("value");
		System.out.println("Unit value ==> " + gUnit );
		
		String unit = XLUtils.getCellData(excelpath, sheet5, 3, 40);
		System.out.println("Excel Unit value ==> " + unit );
		
		if(gUnit.equals(unit)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Unit value equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Unit value not equals");
			Assert.fail();
		}
		
		String gUnitprice = driver.findElement(By.xpath("//input[@formcontrolname='unitPrice']")).getAttribute("value");
		System.out.println("Unit price value ==> " + gUnitprice );
		
		String unitprice = XLUtils.getCellData(excelpath, sheet5, 3, 41);
		System.out.println("Excel Unit price value ==> " + unitprice );
		
		if(gUnitprice.equals(unitprice)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Unit price value equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Unit price not equals");
			Assert.fail();
		}
		
		String gTotalamount = driver.findElement(By.xpath("//input[@formcontrolname='totalAmount']")).getAttribute("value");
		System.out.println("Total amount value ==> " + gTotalamount );
		
		double totalAmountint = XLUtils.getFormulavalue(excelpath, sheet5, 3, 42);
		System.out.println("Excel Total amount value  "+totalAmountint);
		
		int totalAmountint1 = (int)Math.round(totalAmountint);
		System.out.println(totalAmountint1);
		
		String totalAmount = Integer.toString(totalAmountint1);  
		System.out.println("Excel value  conversion "+totalAmount);
		
		if(gTotalamount.equals(totalAmount))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Total amount value equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Total amount not equals");
			Assert.fail();
		}
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		String gGCrewmember = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[2]")).getText();
		System.out.println(gGCrewmember);
		
		if(gGCrewmember.equals(crewmember1)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Crew member equals");
		}
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Crew member not equals");
			Assert.fail();
		}
		
		String gGProjectId = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[3]")).getText();
		System.out.println(gGProjectId);
		
		if(gGProjectId.equals(projectId)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Project equals");
		}
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Project not equals");
			Assert.fail();
		}
		
		String gGTask = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[4]")).getText();
		System.out.println(gGTask);
		
		if(gGTask.equals(taskCode)) {
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Task equals");
		}
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Task not equals");
			Assert.fail();
		}
		
		String gGExpensecategory = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[5]")).getText();
		System.out.println(gGExpensecategory);
		
		if(gGExpensecategory.equals(expenseCategory))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Expense category equals");
		}
		
		else 
			
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Expense category not equals");
			Assert.fail();
		}
		
		String gGQuantity = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[6]")).getText();
		System.out.println(gGQuantity);
		
		if(gGQuantity.contains(quantity)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String gGUnit = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[7]")).getText();
		System.out.println(gGUnit);
		
		if(gGUnit.equals(unit)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit not equals");
			Assert.fail();
		}
		
		String gGUnitprice = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[8]")).getText();
		System.out.println(gGUnitprice);
		
		if(gGUnitprice.equals(unitprice)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit price equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit price not equals");
			Assert.fail();
		}
		
		String gGTotalamount = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[9]")).getText();
		System.out.println(gGTotalamount);
		
		if(gGTotalamount.contains(totalAmount)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
		
		// click Attachement upload
		driver.findElement(By.xpath("(//table)[2]//tr[1]//td[10]//button[@mattooltip='Attachment upload']")).click();
		Thread.sleep(2000);
		
		if (crewtt.check_Attachmentupload_Headerisdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Attachment upload Header - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense Attachment upload Header - Not Displayed");
			Assert.fail();
		}
		
		/*
		 * //click browse crewtt.clickBrowse(); Thread.sleep(3000);
		 * 
		 * String Dir = System.getProperty("user.dir"); String Path = Dir +
		 * "\\excel\\Test_Fileupload.xlsx";
		 * 
		 * commonutil.fileupload(Path);
		 * 
		 * Thread.sleep(3000); String filestatus =
		 * driver.findElement(By.xpath("//span[@class='e-file-status']")).getText();
		 * 
		 * if (filestatus.equals("Ready to upload")) { Assert.assertTrue(true);
		 * crewtt.ClickUploadBTN(); Thread.sleep(2000); }
		 */
		
		
		crewtt.click_Xbutton_attachmentuploadform();
		Thread.sleep(1000);
		
		/* 12 - 23 Step needs to be covered ---- Functionality issue*/
		
		Thread.sleep(1000);
		Actions a = new Actions(driver);
		
		a.moveToElement(driver.findElement(By.xpath("(//table)[2]//tr//td[text()='"+crewmember1+"']"))).
		doubleClick().build().perform();
		Thread.sleep(1000);
		
		String editQuantity = XLUtils.getCellData(excelpath, sheet5, 3, 43);
		System.out.println("Edit Quantity value ==> " +editQuantity);
		
		crewtt.setQuantity(editQuantity);
		Thread.sleep(1000);
		
		crewtt.clickToolbarSavebutton();
		Thread.sleep(3000);
		
		String g2GCrewmember = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[2]")).getText();
		System.out.println(g2GCrewmember);
		
		if(g2GCrewmember.equals(crewmember1)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Crew member equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Crew member not equals");
			Assert.fail();
		}
		
		String g2GProjectId = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[3]")).getText();
		System.out.println(g2GProjectId);
		
		if(g2GProjectId.equals(projectId)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Project equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Project not equals");
			Assert.fail();
		}
		
		String g2GTask = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[4]")).getText();
		System.out.println(g2GTask);
		
		if(g2GTask.equals(taskCode)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Task equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Task not equals");
			Assert.fail();
		}
		
		String g2GExpensecategory = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[5]")).getText();
		System.out.println(g2GExpensecategory);
		
		if(g2GExpensecategory.equals(expenseCategory)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Expense category equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Expense category not equals");
			Assert.fail();
		}
		
		String g2GQuantity = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[6]")).getText();
		System.out.println(g2GQuantity);
		
		if(g2GQuantity.contains(editQuantity)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String g2GUnit = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[7]")).getText();
		System.out.println(g2GUnit);
		
		if(g2GUnit.equals(unit)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit not equals");
			Assert.fail();
		}
		
		String g2GUnitprice = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[8]")).getText();
		System.out.println(g2GUnitprice);
		
		if(g2GUnitprice.equals(unitprice)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit price equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit price not equals");
			Assert.fail();
		}
		
		String g2GTotalamount = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[9]")).getText();
		System.out.println(g2GTotalamount);
		
		double totalAmount2int = XLUtils.getFormulavalue(excelpath, sheet5, 3, 44);
		System.out.println("Excel Total amount value  "+totalAmount2int);
		
		int totalAmount2int1 = (int)Math.round(totalAmount2int);
		System.out.println(totalAmount2int1);
		
		String totalAmount2 = Integer.toString(totalAmount2int1);  
		System.out.println("Excel value  conversion "+totalAmount2);
		
		if(g2GTotalamount.contains(totalAmount2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
		
		//Add Field Expense 2
		
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Fieldexpense_formheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form header - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form header- Not Displayed");
			Assert.fail();
		}
		
		
		// crew member 1 - checkbox is cheked/unchecked
		String crewmember1checked3 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember1 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember1checked3.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember1+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber"+crewmember1+" Unchecked");
			Assert.fail();
		}
		
		
		// crew member 2 - checkbox is cheked/unchecked
		String crewmember2checked3 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember2 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember2checked3.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember2+ "checked");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember2+ "Unchecked");
			Assert.fail();
		}
		
		
		// crew member 4 - checkbox is cheked/unchecked
		String crewmember4checked3 = driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).getAttribute("class");
		
		if (crewmember4checked3.contains("checked")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" +crewmember4+ "checked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" +crewmember4+ "Unchecked");
			Assert.fail();
		}
		
		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();
		
		
		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Project field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Task code field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Task code field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Expensecategoryfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Expense category field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Expense category field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Quantity field - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitfield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitpricefield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Unit price - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Unit price - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Totalamountfield_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Total amount - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Total amount - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Cancel button - Displayed");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form Save button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet -  Field Expense form Save button - Not Displayed");
			Assert.fail();
		}
		
			
		// uncheck crew member 1
		driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember1 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).click();

		// crew member 1 - checkbox is cheked/unchecked
		String crewmember1unchecked = driver
				.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='"
						+ crewmember1 + "']//ancestor::mat-list-option//mat-pseudo-checkbox"))
				.getAttribute("class");

		if (crewmember1unchecked.equals("mat-pseudo-checkbox ng-star-inserted")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" + crewmember1 + "unchecked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" + crewmember1 + "checked");
			Assert.fail();
		}

		
		// uncheck crew member 4
		driver.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='" + crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox")).click();

		// crew member 4 - checkbox is cheked/unchecked
		String crewmember4unchecked2 = driver
				.findElement(By.xpath("//mat-selection-list//mat-list-option//div[normalize-space(text())='"
						+ crewmember4 + "']//ancestor::mat-list-option//mat-pseudo-checkbox"))
				.getAttribute("class");

		if (crewmember4unchecked2.equals("mat-pseudo-checkbox ng-star-inserted")) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Crew memeber" + crewmember4 + "unchecked");
		}

		else 
		{

			logger.info("Crew Template Timesheet -  Field Expense form form - Crew memeber" + crewmember4 + "checked");
			Assert.fail();
		}
		
		
		String projectId2 = XLUtils.getCellData(excelpath, sheet5, 3, 45);
		System.out.println("Project Id " +projectId2);
		
		crewtt.setprojectId(projectId2);
		Thread.sleep(2000);

		cm.selectDropDownValue(projectId2);
		Thread.sleep(2000);
		
		String taskCode2 = XLUtils.getCellData(excelpath, sheet5, 3, 46);
		System.out.println("Task code " +taskCode2);
		
		crewtt.setTaskcode(taskCode2);
		Thread.sleep(2000);

		cm.selectDropDownValue(taskCode2);
		Thread.sleep(2000);
		
		String expenseCategory2 = XLUtils.getCellData(excelpath, sheet5, 3, 47);
		System.out.println("Expense category " +expenseCategory2);
		
		crewtt.setExpenseCategory(expenseCategory2);
		Thread.sleep(2000);

		cm.selectDropDownValue(expenseCategory2);
		Thread.sleep(2000);
		
		String quantity2 = XLUtils.getCellData(excelpath, sheet5, 3, 48);
		System.out.println("Quantity " +quantity2);
		
		crewtt.setQuantity(quantity2);
		Thread.sleep(1000);
		
		String gUnit2 = driver.findElement(By.xpath("//input[@formcontrolname='unit']")).getAttribute("value");
		System.out.println("Unit value ==> " + gUnit2 );
		
		String unit2 = XLUtils.getCellData(excelpath, sheet5, 3, 49);
		System.out.println("Excel Unit value ==> " + unit2 );
		
		if(gUnit2.equals(unit2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Unit value equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Unit value not equals");
			Assert.fail();
		}
		
		String gUnitprice2 = driver.findElement(By.xpath("//input[@formcontrolname='unitPrice']")).getAttribute("value");
		System.out.println("Unit price value ==> " + gUnitprice2 );
		
		String unitprice2 = XLUtils.getCellData(excelpath, sheet5, 3, 50);
		System.out.println("Excel Unit price value ==> " + unitprice2 );
		
		if(gUnitprice2.equals(unitprice2))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Unit price value equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Unit price not equals");
			Assert.fail();
		}
		
		String gTotalamount2 = driver.findElement(By.xpath("//input[@formcontrolname='totalAmount']")).getAttribute("value");
		System.out.println("Total amount value ==> " + gTotalamount2 );
		
		double totalAmountint2 = XLUtils.getFormulavalue(excelpath, sheet5, 3, 51);
		System.out.println("Excel Total amount value  "+totalAmountint2);
		
		int totalAmountintF2 = (int)Math.round(totalAmountint2);
		System.out.println(totalAmountintF2);
		
		String totalAmount_2 = Integer.toString(totalAmountintF2);  
		System.out.println("Excel value  conversion "+totalAmount_2);
		
		if(gTotalamount2.equals(totalAmount_2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense form - Total amount value equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense form - Total amount not equals");
			Assert.fail();
		}
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		
		String gGCrewmember2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[2]")).getText();
		System.out.println(gGCrewmember2);
		
		if(gGCrewmember2.equals(crewmember2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Crew member equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Crew member not equals");
			Assert.fail();
		}
		
		String gGProjectId2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[3]")).getText();
		System.out.println(gGProjectId2);
		
		if(gGProjectId2.equals(projectId2))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Project equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Project not equals");
			Assert.fail();
		}
		
		String gGTask2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[4]")).getText();
		System.out.println(gGTask2);
		
		if(gGTask2.equals(taskCode2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Task equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Task not equals");
			Assert.fail();
		}
		
		String gGExpensecategory2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[5]")).getText();
		System.out.println(gGExpensecategory2);
		
		if(gGExpensecategory2.equals(expenseCategory2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Expense category equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Expense category not equals");
			Assert.fail();
		}
		
		String gGQuantity2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[6]")).getText();
		System.out.println(gGQuantity2);
		
		if(gGQuantity2.contains(quantity2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String gGUnit2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[7]")).getText();
		System.out.println(gGUnit2);
		
		if(gGUnit2.equals(unit2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit not equals");
			Assert.fail();
		}
		
		String gGUnitprice2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[8]")).getText();
		System.out.println(gGUnitprice2);
		
		if(gGUnitprice2.equals(unitprice2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit price equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit price not equals");
			Assert.fail();
		}
		
		String gGTotalamount2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[9]")).getText();
		System.out.println(gGTotalamount2);
		
		if(gGTotalamount2.contains(totalAmount_2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
		
		
		// click line - crew member 2
		driver.findElement(By.xpath("//table//tr//td[text()= '" + crewmember2 + "']")).click();
		
		crewtt.click_ToolbarEditbutton();
		Thread.sleep(3000);
		
		
		String worker = driver.findElement(By.xpath("//input[@formcontrolname='personnelNumber']")).getAttribute("value");
		System.out.println("Worker ==> " +worker);
		
		if(worker.equals(crewmember2))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Hours Tab - Edit Crew Member 2 - Worker Equals");
		}
		else
		{
			logger.info("Crew Template Timesheet - Hours Tab - Edit Crew Member 2 - Worker Not Equals");
			Assert.fail();	
		}
		
		String editQuantity2 = XLUtils.getCellData(excelpath, sheet5, 3, 52);
		System.out.println("Edit Quantity value ==> " +editQuantity2);
		
		crewtt.setQuantity(editQuantity2);
		Thread.sleep(1000);
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		String g2GQuantity2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[6]")).getText();
		System.out.println(g2GQuantity2);
		
		if(g2GQuantity2.contains(editQuantity2))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String g2GTotalamount2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[9]")).getText();
		System.out.println(g2GTotalamount2);
		
		double totalAmount2int2 = XLUtils.getFormulavalue(excelpath, sheet5, 3, 53);
		System.out.println("Excel Total amount value  "+totalAmount2int2);
		
		int totalAmount2int_2 = (int)Math.round(totalAmount2int2);
		System.out.println(totalAmount2int_2);
		
		String totaleditAmount2 = Integer.toString(totalAmount2int_2);  
		System.out.println("Excel value  conversion "+totaleditAmount2);
		
		if(g2GTotalamount2.contains(totaleditAmount2))
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
		
		//Verify crew member 1 - Expense  record values
		
		String gcm1 = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[2]")).getText();
		System.out.println(gcm1);
		
		if(gcm1.equals(crewmember1)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Crew member equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Crew member not equals");
			Assert.fail();
		}
		
		String gpi = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[3]")).getText();
		System.out.println(gpi);
		
		if(gpi.equals(projectId)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Project equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Project not equals");
			Assert.fail();
		}
		
		String gtc = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[4]")).getText();
		System.out.println(gtc);
		
		if(gtc.equals(taskCode)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Task equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Task not equals");
			Assert.fail();
		}
		
		String gec = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[5]")).getText();
		System.out.println(gec);
		
		if(gec.equals(expenseCategory)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Expense category equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Expense category not equals");
			Assert.fail();
		}
		
		String gq = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[6]")).getText();
		System.out.println(gq);
		
		if(gq.contains(editQuantity)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String gu = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[7]")).getText();
		System.out.println(gu);
		
		if(gu.equals(unit)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit not equals");
			Assert.fail();
		}
		
		String gup = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[8]")).getText();
		System.out.println(gup);
		
		if(gup.equals(unitprice)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Unit price equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Unit price not equals");
			Assert.fail();
		}
		
		String gtm = driver.findElement(By.xpath("(//table)[2]//tr[1]//td[9]")).getText();
		System.out.println(g2GTotalamount);
		
		double tm2 = XLUtils.getFormulavalue(excelpath, sheet5, 3, 44);
		System.out.println("Excel Total amount value  "+tm2);
		
		int tm1 = (int)Math.round(tm2);
		System.out.println(tm1);
		
		String tm = Integer.toString(tm1);  
		System.out.println("Excel value  conversion "+tm);
		
		if(gtm.contains(tm)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
		//Verify crew member 2 - Expense  record values
		
		String gcm2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[2]")).getText();
		System.out.println(gcm2);
		
		if(gcm2.equals(crewmember2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Crew member equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Crew member not equals");
			Assert.fail();
		}
		
		String gpi2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[3]")).getText();
		System.out.println(gpi2);
		
		if(gpi2.equals(projectId2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Project equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Project not equals");
			Assert.fail();
		}
		
		String gtc2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[4]")).getText();
		System.out.println(gtc2);
		
		if(gtc2.equals(taskCode2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Task equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Task not equals");
			Assert.fail();
		}
		
		String gec2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[5]")).getText();
		System.out.println(gec2);
		
		if(gec2.equals(expenseCategory2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Expense category equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Expense category not equals");
			Assert.fail();
		}
		
		String gq2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[6]")).getText();
		System.out.println(gq2);
		
		if(gq2.contains(editQuantity2)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Quantity equals");
		}
		
		else
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Quantity not equals");
			Assert.fail();
		}
		
		String gtm2 = driver.findElement(By.xpath("(//table)[2]//tr[2]//td[9]")).getText();
		System.out.println(gtm2);
		
		double tm2_2 = XLUtils.getFormulavalue(excelpath, sheet5, 3, 53);
		System.out.println("Excel Total amount value  "+tm2_2);
		
		int tm2_1 = (int)Math.round(tm2_2);
		System.out.println(tm2_1);
		
		String tm2_0 = Integer.toString(tm2_1);  
		System.out.println("Excel value  conversion "+tm2_0);
		
		if(gtm2.contains(tm2_0)) 
		{
			
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Field Expense Grid - Total amount equals");
		}
		
		else 
		{
			
			logger.info("Crew Template Timesheet - Field Expense  Grid - Total amount not equals");
			Assert.fail();
		}
		
	}
	

	@Test(priority = 3, dependsOnMethods = { "Construct365_Regressionsuite_CrewTemplateTimesheet_FieldExpenses" })
	public void Construct365_Regressionsuite_CrewTemplateTimesheet_Equipment() throws InterruptedException, IOException, Exception {
		
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		
		// Click Equipment - Tab
		
		Thread.sleep(2000);
		crewtt.clickfieldexpensestab();
		crewtt.clickEquipmenttab();
		Thread.sleep(2000);
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Submit_btndisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Submit button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Submit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Add_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Add button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Add button - Not Displayed");
			Assert.fail();
		}
				
		
		if (crewtt.check_Edit_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Edit button - Displayed");
		}

		else 
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Edit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Delete_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Delete button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Delete button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Save_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Save button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Save button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Cancel_buttondisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Cancel button - Not Displayed");
			Assert.fail();
		}
		
		// Grid column Headers - Verify
		
		if (crewtt.check_Date_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Date column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet -  Equipment Tab - Date column header- Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_Project_columnheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Project column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet -  Equipment Tab - Project column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Task_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment - Task column header - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Equipment - Task column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Equipment_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment - Equipment column header - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Equipment - Equipment column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantity_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Quantity column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Quantity column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unit_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment Tab - Unit column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment Tab - Unit column header- Not Displayed");
			Assert.fail();
		}
		
		// click Add button - Equipment Tab
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Equipment_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form header- Not Displayed");
			Assert.fail();
		}
		
		
		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();
		
		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Project field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Task code field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Task code field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Equipmentfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Equipment field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Equipment field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unitfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet -Equipment form Unit - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Quantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Quantity field - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Equipment form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Save button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Equipment form Save button - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(2000);
		
		if (crewtt.check_Projectfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form project field error message - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Equipment form project field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Task code field error message - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Task code field error message - Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_Quantityfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Quantity field error message - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Quantity field error message - Not Displayed");
			Assert.fail();
		}
		
		crewtt.click_CancelBtn_Editpopup();
		Thread.sleep(2000);
		
		// click Add button - Equipment Tab
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
				
		if (crewtt.check_Equipment_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form header- Not Displayed");
			Assert.fail();
		}
			
				
				
		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();
				
		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Project field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form project field- Not Displayed");
			Assert.fail();
		}
				
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Task code field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Task code field- Not Displayed");
			Assert.fail();
		}
			
		if (crewtt.check_Equipmentfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Equipment field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Equipment field- Not Displayed");
			Assert.fail();
		}
				
		if (crewtt.check_Unitfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet -Equipment form Unit - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Unit - Not Displayed");
			Assert.fail();
		}
				
		if (crewtt.check_Quantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet -Equipment form Quantity field - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Equipment form Quantity field- Not Displayed");
			Assert.fail();
		}
				
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form Cancel button - Not Displayed");
			Assert.fail();
		}
				
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form Save button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Equipment form Save button - Not Displayed");
			Assert.fail();
		}
		
		common_pom cm = new common_pom(driver);
		
		String eProjectId = XLUtils.getCellData(excelpath, sheet5, 3, 54);
		System.out.println("Project Id " +eProjectId);
		
		crewtt.setprojectId(eProjectId);
		Thread.sleep(2000);

		cm.selectDropDownValue(eProjectId);
		Thread.sleep(2000);
		
		String eTaskCode = XLUtils.getCellData(excelpath, sheet5, 3, 55);
		System.out.println("Task code " +eTaskCode);
		
		crewtt.setTaskcode(eTaskCode);
		Thread.sleep(2000);

		cm.selectDropDownValue(eTaskCode);
		Thread.sleep(2000);
		
		String eEuipmentId = XLUtils.getCellData(excelpath, sheet5, 3, 56);
		System.out.println("Equipment Id " +eEuipmentId);
		
		crewtt.setEquipmentId(eEuipmentId);
		Thread.sleep(2000);

		cm.selectDropDownValue(eEuipmentId);
		Thread.sleep(2000);
		
		String gEUnit = driver.findElement(By.xpath("//input[@formcontrolname='unit']")).getAttribute("value");
		System.out.println("Unit value ==> " + gEUnit );
		
		String eunit = XLUtils.getCellData(excelpath, sheet5, 3, 57);
		System.out.println("Excel Unit value ==> " + eunit );
		
		if(gEUnit.equals(eunit)) 
		{	
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form - Unit value equals");
		}		
		else
		{		
			logger.info("Crew Template Timesheet - Equipment form - Unit value not equals");
			Assert.fail();
		}
		
		
		String eQuantity = XLUtils.getCellData(excelpath, sheet5, 3, 58);
		System.out.println("Quantity " +eQuantity);
		
		crewtt.setQuantity(eQuantity);
		Thread.sleep(1000);
		
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		
		/* Set Qty - Sepcified Project - Inline Edit */
		Thread.sleep(1000);
		Actions a = new Actions(driver);
		
		a.moveToElement(driver.findElement(By.xpath("//table//tr//td[contains(text(),'"+eProjectId+"')]"))).
		doubleClick().build().perform();
		Thread.sleep(1000);
		
		String eEditQuantity = XLUtils.getCellData(excelpath, sheet5, 3, 59);
		System.out.println("Edit Quantity " +eEditQuantity);
		
		crewtt.setQuantity(eEditQuantity);
		Thread.sleep(1000);
		
		crewtt.clickToolbarSavebutton();
		Thread.sleep(3000);
		
		// click Add button - Equipment Tab
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
						
		if (crewtt.check_Equipment_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Equipment form header- Not Displayed");
			Assert.fail();
		}
		
		String eProjectId2 = XLUtils.getCellData(excelpath, sheet5, 3, 60);
		System.out.println("Project Id " +eProjectId2);
		
		crewtt.setprojectId(eProjectId2);
		Thread.sleep(2000);

		cm.selectDropDownValue(eProjectId2);
		Thread.sleep(2000);
		
		String eTaskCode2 = XLUtils.getCellData(excelpath, sheet5, 3, 61);
		System.out.println("Task code " +eTaskCode2);
		
		crewtt.setTaskcode(eTaskCode2);
		Thread.sleep(2000);

		cm.selectDropDownValue(eTaskCode2);
		Thread.sleep(2000);
		
		String eEuipmentId2 = XLUtils.getCellData(excelpath, sheet5, 3, 62);
		System.out.println("Equipment Id " +eEuipmentId2);
		
		crewtt.setEquipmentId(eEuipmentId2);
		Thread.sleep(2000);

		cm.selectDropDownValue(eEuipmentId2);
		Thread.sleep(2000);
		
		String gEUnit2 = driver.findElement(By.xpath("//input[@formcontrolname='unit']")).getAttribute("value");
		System.out.println("Unit value ==> " + gEUnit2 );
		
		String eunit2 = XLUtils.getCellData(excelpath, sheet5, 3, 63);
		System.out.println("Excel Unit value ==> " + eunit2 );
		
		if(gEUnit2.equals(eunit2)) 
		{	
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Equipment form - Unit value equals");
		}		
		else
		{		
			logger.info("Crew Template Timesheet - Equipment form - Unit value not equals");
			Assert.fail();
		}
		
		
		String eQuantity2 = XLUtils.getCellData(excelpath, sheet5, 3, 64);
		System.out.println("Quantity " +eQuantity2);
		
		crewtt.setQuantity(eQuantity2);
		Thread.sleep(1000);
		
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		
		//click row 2 
		
		driver.findElement(By.xpath("//table//tr//td[contains(text(),'"+eProjectId2+"')]")).click();
		Thread.sleep(1000);
		
		crewtt.click_ToolbarEditbutton();
		Thread.sleep(2000);	
		
		String eEditQuantity2 = XLUtils.getCellData(excelpath, sheet5, 3, 65);
		System.out.println("Quantity " +eEditQuantity2);
		
		crewtt.setQuantity(eEditQuantity2);
		Thread.sleep(1000);
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		
	}
	

	@Test(priority = 4, dependsOnMethods = { "Construct365_Regressionsuite_CrewTemplateTimesheet_Equipment" })
	public void Construct365_Regressionsuite_CrewTemplateTimesheet_Production() throws InterruptedException, IOException, Exception {
		
		TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
		
		// Click Production - Tab
		
		Thread.sleep(2000);
		crewtt.clickProductiontab();
		Thread.sleep(2000);
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Submit_btndisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Submit button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Submit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Add_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Add button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Production Tab - Add button - Not Displayed");
			Assert.fail();
		}
				
		
		if (crewtt.check_Edit_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Edit button - Displayed");
		}

		else 
		{
			logger.info("Crew Template Timesheet - Production Tab - Edit button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Delete_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Delete button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Production Tab - Delete button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Save_buttondisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Save button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production Tab - Save button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Cancel_buttondisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production Tab - Cancel button - Not Displayed");
			Assert.fail();
		}
		
		
		// Grid column Headers - Verify
		if (crewtt.check_Date_columnheaderisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Date column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet -  Production Tab - Date column header- Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_Project_columnheaderdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Project column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet -  Production Tab - Project column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Task_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production - Task column header - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Production - Task column header- Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_Quantity_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Quantity column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production Tab - Quantity column header- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Unit_columnheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production Tab - Unit column header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production Tab - Unit column header- Not Displayed");
			Assert.fail();
		}
		
		// click Add button - Production  Tab
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);

		if (crewtt.check_Production_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form header- Not Displayed");
			Assert.fail();
		}

		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();		

		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Project field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Task code field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Task code field- Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_prodUnitfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Unit - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_ProdQuantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Quantity field - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Production form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Save button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Production form Save button - Not Displayed");
			Assert.fail();
		}

		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(2000);
		
		if (crewtt.check_Projectfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - production form project field error message - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - production form project field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - production form Task code field error message - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - production form Task code field error message - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Prod_Quantityfield_errormsg_isdisplayed() == true)
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Quantity field error message - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Quantity field error message - Not Displayed");
			Assert.fail();
		}
	
		crewtt.click_CancelBtn_Editpopup();
		Thread.sleep(2000);
		
		// click Add button - Production Tab
		crewtt.click_ToolbarAddbutton();
		Thread.sleep(2000);
		
		if (crewtt.check_Production_formheaderdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form header - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form header- Not Displayed");
			Assert.fail();
		}

		Thread.sleep(1000);
		crewtt.checkdatevalueFieldExpensetab();		

		if (crewtt.check_Projectfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Project field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form project field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_Taskcodefield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Task code field - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Task code field- Not Displayed");
			Assert.fail();
		}
		
		
		if (crewtt.check_prodUnitfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Unit - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Unit - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_ProdQuantityfield_isdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Quantity field - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet -  Production form Quantity field- Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_cancelbtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Cancel button - Displayed");
		}
		else 
		{
			logger.info("Crew Template Timesheet - Production form Cancel button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_savebtn_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form Save button - Displayed");
		}
		else
		{
			logger.info("Crew Template Timesheet - Production form Save button - Not Displayed");
			Assert.fail();
		}

		common_pom cm = new common_pom(driver);
		
		String prod_ProjectId = XLUtils.getCellData(excelpath, sheet5, 3, 66);
		System.out.println("Project Id " +prod_ProjectId);
		
		crewtt.setprojectId(prod_ProjectId);
		Thread.sleep(2000);

		cm.selectDropDownValue(prod_ProjectId);
		Thread.sleep(2000);	
		
		String prod_TaskCode = XLUtils.getCellData(excelpath, sheet5, 3, 67);
		System.out.println("Task code " +prod_TaskCode);
		
		crewtt.setTaskcode(prod_TaskCode);
		Thread.sleep(2000);

		cm.selectDropDownValue(prod_TaskCode);
		Thread.sleep(2000);
		
		String gPUnit = driver.findElement(By.xpath("//input[@formcontrolname='prodUnit']")).getAttribute("value");
		System.out.println("Unit value ==> " + gPUnit );
		
		String Produnit = XLUtils.getCellData(excelpath, sheet5, 3, 68);
		System.out.println("Excel Unit value ==> " + Produnit );
		
		if(gPUnit.equals(Produnit)) 
		{	
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Production form - Unit value equals");
		}		
		else
		{		
			logger.info("Crew Template Timesheet - Production form - Unit value not equals");
			Assert.fail();
		}
		
		String pQuantity = XLUtils.getCellData(excelpath, sheet5, 3, 69);
		System.out.println("Quantity " +pQuantity);
		
		crewtt.setQuantity(pQuantity);
		Thread.sleep(1000);
		
		
		crewtt.click_Savebtn_Editpopup();
		Thread.sleep(3000);
		
		
		
		
		

	}

}
		
		
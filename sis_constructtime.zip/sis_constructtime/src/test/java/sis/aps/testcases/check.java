package sis.aps.testcases;

import java.io.IOException;
import java.text.DecimalFormat;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.TimeManagement_Timesheets_CrewTemplateTimesheets;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class check extends baseclass {
	
	@Test
	public void newTest() throws InterruptedException, IOException, Exception
	{
		
		

		@Test(priority = 5, dependsOnMethods = { "Construct365_Regressionsuite_CrewTemplateTimesheet_Equipment" })
		public void Construct365_Regressionsuite_CrewTemplateTimesheet_Submit() throws InterruptedException, IOException, Exception {
			
			TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);

		
		// Submit Timesheet
		
		if (crewtt.check_Back_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Back button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Back button - Not Displayed");
			Assert.fail();
		}
		
		if (crewtt.check_CTTMS_Submit_btndisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Submit button - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Submit button - Not Displayed");
			Assert.fail();
		}
		
		crewtt.clickCTTMS_Submit_button();
		Thread.sleep(2000);
		
		if (crewtt.checkTimesheet_Statusupdated_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Status updated message - Displayed");
		}

		else
		{

			logger.info("Crew Template Timesheet - Status updated message - Not Displayed");
			Assert.fail();
		}
		
		Thread.sleep(2000);
		
		// Filter by Submitted
		
		driver.findElement(By.xpath("//mat-select[@placeholder='Status']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//mat-option//span[normalize-space()='Submitted']")).click();
		Thread.sleep(2000);
		
		String crewId = XLUtils.getCellData(excelpath, sheet5, 3, 0);
		
		String status = driver.findElement(By.xpath("(//mat-row//mat-cell[normalize-space()='"+crewId+"']//following-sibling::mat-cell[3])[1]")).getText();
		System.out.println("Timesheet Status " + status);
		
		if (status.equals("Submitted"))
		{
			Assert.assertTrue(true);
			logger.info("Crew Template Timesheet - Status - Equals");
		}
		else
		{

			logger.info("Crew Template Timesheet - Status - Not Equals");
			Assert.fail();
		}
		
		
		
		}
		

		@Test(priority = 6, dependsOnMethods = { "Construct365_Regressionsuite_CrewTemplateTimesheet_Submit" })
		public void Construct365_Regressionsuite_CrewTemplateTimesheet_Approve() throws InterruptedException, IOException, Exception {
			
			TimeManagement_Timesheets_CrewTemplateTimesheets crewtt = new TimeManagement_Timesheets_CrewTemplateTimesheets(driver);
			
			String crewId = XLUtils.getCellData(excelpath, sheet5, 3, 0);
			
			//Search by crew Id
			driver.findElement(By.xpath("//mat-select[@placeholder='Search field']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//mat-option//span[normalize-space()='Crew id']")).click();
			Thread.sleep(3000);
			
			//Filter by crew Id
			driver.findElement(By.xpath("//input[@name='searchInput']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@name='searchInput']")).clear();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@name='searchInput']")).sendKeys(crewId);
			Thread.sleep(2000);
		
			// Filter by Submitted
			driver.findElement(By.xpath("//mat-select[@placeholder='Status']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//mat-option//span[normalize-space()='Submitted']")).click();
			Thread.sleep(3000);
			
			//Verify record status
			String status = driver.findElement(By.xpath("(//mat-row//mat-cell[normalize-space()='"+crewId+"']//following-sibling::mat-cell[3])[1]")).getText();
			System.out.println("Timesheet Status " + status);
			
			if (status.equals("Submitted"))
			{
				Assert.assertTrue(true);
				logger.info("Crew Template Timesheet - Status - Equals");
			}
			else
			{

				logger.info("Crew Template Timesheet - Status - Not Equals");
				Assert.fail();
			}
			
			// click view - filtered record in grid
			driver.findElement(By.xpath("(//mat-row//mat-cell[normalize-space()='"+crewId+"']//following-sibling::mat-cell[normalize-space()='Submitted']//following-sibling::mat-cell//button[@mattooltip='View timesheet'])[1]")).click();
			Thread.sleep(2000);
			
			// click Hours Tab
			crewtt.clickHourstab();
			Thread.sleep(1000);
			
			crewtt.click_crewmemberfilter();
			Thread.sleep(1000);
			
			crewtt.click_crewprojectfilter();
			Thread.sleep(1000);
			
			
			// Click cancel in conform Approval
			crewtt.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			crewtt.clickGroupworkflowApproveBtn();
			Thread.sleep(1000);
			
			if (crewtt.chk_TimesheetApproveconformbox_displayed() == true)
			{
				Assert.assertTrue(true);
				logger.info("Timesheet Approve conform box displayed");
			}
			else 
			{

				Assert.fail();
				logger.info("Timesheet Approve conform box not displayed");
			}
			Thread.sleep(1000);
			
			crewtt.clickConfirmboxApprove_Cancelbtn();
			Thread.sleep(1000);
			
			// Click Approve in confirm approval
			crewtt.clkGroupWorkflowbtn();
			Thread.sleep(1000);
			crewtt.clickGroupworkflowApproveBtn();
			Thread.sleep(1000);
			
			if (crewtt.chk_TimesheetApproveconformbox_displayed() == true)
			{
				Assert.assertTrue(true);
				logger.info("Timesheet Approve conform box displayed");
			}
			else 
			{

				Assert.fail();
				logger.info("Timesheet Approve conform box not displayed");
			}
			Thread.sleep(1000);
			
			crewtt.clickConfirmboxApprovebtn();
			Thread.sleep(3000);
			
			// Verify Approved record in grid
			
			//Search by crew Id
			driver.findElement(By.xpath("//mat-select[@placeholder='Search field']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//mat-option//span[normalize-space()='Crew id']")).click();
			Thread.sleep(3000);
			
			//Filter by Crew Id
			driver.findElement(By.xpath("//input[@name='searchInput']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@name='searchInput']")).clear();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//input[@name='searchInput']")).sendKeys(crewId);
			Thread.sleep(2000);
			
			// Filter by Submitted
			driver.findElement(By.xpath("//mat-select[@placeholder='Status']")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//mat-option//span[normalize-space()='Approved']")).click();
			Thread.sleep(3000);
					
			//Verify record status
			String status1 = driver.findElement(By.xpath("(//mat-row//mat-cell[normalize-space()='"+crewId+"']//following-sibling::mat-cell[3])[1]")).getText();
			System.out.println("Timesheet Status " + status1);
					
			if (status1.equals("Approved"))
			{
				Assert.assertTrue(true);
				logger.info("Crew Template Timesheet - Status - Equals");
			}
			else
			{

				logger.info("Crew Template Timesheet - Status - Not Equals");
				Assert.fail();
			}		
			
			
		}	
		
		
		
		

	        
	}

}

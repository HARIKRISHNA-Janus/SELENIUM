package sis.aps.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.loginpage_pom;

public class loginandlogout extends baseclass {
	
	@Test
	public void logintest() throws InterruptedException, IOException, Exception
	{
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		
	    login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
	    login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));

//		login.setUserName(username);
//		login.setPasword(password);
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(12000);
		if(driver.getTitle().equals("Construct Time Dev - Dashboard"))
		{
			Assert.assertTrue(true);
			logger.info("Logged in Successfully");
		}
		else
		{
			Assert.fail();
			logger.info("Login failed");
		}
		Thread.sleep(10000);
		login.clkicon();
		login.clkSignout();
		logger.info("Logout Successfully");
	}

}

package sis.aps.testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.utilities.XLUtils;
import sis.ct.pageobjects.TimeManagement_Crews_AllCrews;
import sis.ct.pageobjects.common_pom;
import sis.ct.pageobjects.constructsmokeMyTimesheet_pom;
import sis.ct.pageobjects.leftmenu_pom;
import sis.ct.pageobjects.loginpage_pom;

public class Create_AllNew_Crew_2825 extends baseclass {

	@Test(priority=1)
	public void createNewcrew_Fillthedetails_2825() throws InterruptedException, IOException, Exception
	{

		loginpage_pom login = new loginpage_pom(driver);
		//leftmenu_pom timesheet = new leftmenu_pom(driver);
		Thread.sleep(3000);
		login.setUserName(XLUtils.getCellData(excelpath, sheet1, 1, 1));
		login.setPasword(XLUtils.getCellData(excelpath, sheet1, 1, 2));
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(110000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
		Thread.sleep(3000);
		
		leftmenuObj.clicktimemanagementtab();
		Thread.sleep(2000);
		
		leftmenuObj.clickCrewstab();
		Thread.sleep(2000);
		
		leftmenuObj.clkAllCrewstab();
		Thread.sleep(2000);
		
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		
		if (acObj.checkAllcrews_Headerdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("All crews Header is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("All crews Header is not displayed");
		}
		Thread.sleep(2000);
		
		acObj.clickNewcrewbtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrews_details_tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crews details tab is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crews details tab is not displayed");
		}
		Thread.sleep(2000);
		
		String crewId = XLUtils.getCellData(excelpath, sheet6, 1, 0);
		String crewDescription = XLUtils.getCellData(excelpath, sheet6, 1, 1);
		
		acObj.setCrewid(crewId);
		Thread.sleep(2000);
		
		acObj.setCrewdescription(crewDescription);
		Thread.sleep(2000);
		
		String crewForemanpersonnelNo = XLUtils.getCellData(excelpath, sheet6, 1, 2);
				
		
		acObj.setCrewformanpersonnelno(crewForemanpersonnelNo);
		Thread.sleep(2000);
		
		common_pom cm = new common_pom(driver);
		

		cm.selectDropDownValue(crewForemanpersonnelNo);
		Thread.sleep(2000);
		
		String crewForemanName = XLUtils.getCellData(excelpath, sheet6, 1, 3);
				
		
		String foremanName = driver.findElement(By.xpath("//input[@data-placeholder='Foreman name']")).getAttribute("value");
		System.out.println("Crew Foreman Name = " + foremanName);
		
		
		if(crewForemanName.equals(foremanName)) {
			
			Assert.assertTrue(true);
			logger.info("Crew foreman displayed and equal");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew foreman not equal / not displayed");
		}
		
		acObj.clickSavebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_created_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew created message is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew created message is not displayed");
		}
		
		logger.info("createNewcrew_Fillthedetails_2825 ==> Method Executed");
		
			
	}
	
	
	@Test(priority=2,dependsOnMethods= {"createNewcrew_Fillthedetails_2825"})
	public void Addcrewmemberstothecrew_2827() throws InterruptedException, IOException, Exception
	{
		
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		
		if (acObj.checkcrews_members_tabdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crews members tab is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crews members tab is not displayed");
		}
		Thread.sleep(2000);
		
		acObj.clickCrewmemberstab();
		Thread.sleep(2000);
		
		acObj.clickAddbtn();
		Thread.sleep(2000);
		
		common_pom cm = new common_pom(driver);
		
		String workerName = XLUtils.getCellData(excelpath, sheet6, 1, 4);
				
			
		acObj.setWorker(workerName);
		Thread.sleep(2000);
	
		cm.selectDropDownValue(workerName);
		Thread.sleep(2000);
		
		String jobId = XLUtils.getCellData(excelpath, sheet6, 1, 5);
				
		
		acObj.setJobid(jobId);
		Thread.sleep(2000);
		
		cm.selectDropDownValue(jobId);
		Thread.sleep(2000);
		
		acObj.clickSavebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_member_created_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew member created message is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew member created message is not displayed");
		}
		
		String gworker = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).getText();
		System.out.println("Worker Name = "+gworker);
		
		
		if(gworker.contains(workerName)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Worker name equals");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew Member Tab - Worker name not equals");
		}
		
		String gJobid = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).getText();
		System.out.println("Job id = "+gJobid);
		
		if(gJobid.contains(jobId)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Job id equals");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew Member Tab - Job id not equals");
		}
		
		logger.info("Addcrewmemberstothecrew_2827 ==> Method Executed");
		
	}
	

	@Test(priority=3,dependsOnMethods= {"Addcrewmemberstothecrew_2827"})
	public void Editacrewmemberlineatthecrew_2830() throws InterruptedException, IOException, Exception
	{
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		
		driver.findElement(By.xpath("(//app-crew-member//table//tr[1])[3]")).click();
		Thread.sleep(2000);
		
		acObj.clickEditbtn();
		Thread.sleep(2000);
		
		common_pom cm = new common_pom(driver);
		
		String workerName2 = XLUtils.getCellData(excelpath, sheet6, 1, 6);
				
			
		acObj.setWorker(workerName2);
		Thread.sleep(2000);
	
		cm.selectDropDownValue(workerName2);
		Thread.sleep(2000);
		
		String jobId2 = XLUtils.getCellData(excelpath, sheet6, 1, 7);
		
		acObj.setJobid(jobId2);
		Thread.sleep(2000);
		
		cm.selectDropDownValue(jobId2);
		Thread.sleep(2000);
		
		acObj.clickSavebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_member_updated_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew member updated message is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew member updated message is not displayed");
		}
		
		String gworker = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[1])[2]")).getText();
		System.out.println("Worker Name = "+gworker);
		
		
		if(gworker.contains(workerName2)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Worker name equals");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew Member Tab - Worker name not equals");
		}
		
		String gJobid = driver.findElement(By.xpath("(//app-crew-member//table//tr[1]//td[2])[2]")).getText();
		System.out.println("Job id = "+gJobid);
		
		if(gJobid.contains(jobId2)) 
		{
			Assert.assertTrue(true);
			logger.info("Crew Member Tab - Job id equals");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew Member Tab - Job id not equals");
		}
		
		logger.info("Editacrewmemberlineatthecrew_2830 ==> Method Executed");
		
	}
	

	@Test(priority=4,dependsOnMethods= {"Editacrewmemberlineatthecrew_2830"})
	public void Deleteacrewmemberfromthecrew_2832() throws InterruptedException, IOException, Exception
	{
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		
		driver.findElement(By.xpath("(//app-crew-member//table//tr[1])[3]")).click();
		Thread.sleep(2000);
		
		acObj.clickDeletebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_member_delete_popup_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew member delete popup is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew member delete popup is not displayed");
		}
		
		Thread.sleep(2000);
		
		acObj.clickcrewmemberpopupDeletebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_member_deleted_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew member deleted message is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew member deleted message is not displayed");
		}
		
		Thread.sleep(2000);	
		
		logger.info("Deleteacrewmemberfromthecrew_2832 ==> Method Executed");
	}
	
	

	@Test(priority=5,dependsOnMethods= {"Deleteacrewmemberfromthecrew_2832"})
	public void DeleteaCrew_2834() throws InterruptedException, IOException, Exception
	{
		
		leftmenu_pom timesheet=new leftmenu_pom(driver);
		constructsmokeMyTimesheet_pom MyTime= new  constructsmokeMyTimesheet_pom(driver);
		
//		timesheet.clicktimemanagementtab();
//		Thread.sleep(1000);
//		timesheet.clicktimesheetstab();
//		Thread.sleep(1000);
//		timesheet.clickkAlltimesheetstab();
//		Thread.sleep(1000);
//		MyTime.clickNewCrewtimesheetsbtn();
//		Thread.sleep(1000);
//		MyTime.checkdatevalue();
//		Thread.sleep(1000);
//		MyTime.clickCrewdropdown(XLUtils.getCellData(excelpath, sheet3, 1, 0));
//		Thread.sleep(1000);
//		MyTime.checkCrewDescriptionField();
//		Thread.sleep(1000);
//		MyTime.checkProjectID_Crew(XLUtils.getCellData(excelpath, sheet4, 1, 0));
//		Thread.sleep(1000);
//		MyTime.clickStatusField();
//		Thread.sleep(1000);
//		MyTime.clickkNotestab();
//		Thread.sleep(3000);
//		MyTime.clickSaveBtn();
//		Thread.sleep(3000);
//		logger.info("All New Crew Timesheet-Header tab data has been saved successfully");
//		
//		leftmenu_pom leftmenuObj = new leftmenu_pom(driver);
//		Thread.sleep(3000);
//		
//		leftmenuObj.clicktimemanagementtab();
//		Thread.sleep(2000);
//		
//		leftmenuObj.clickCrewstab();
//		Thread.sleep(2000);
//		
//		leftmenuObj.clkAllCrewstab();
//		Thread.sleep(2000);
//		
//		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
//		
//		if (acObj.checkAllcrews_Headerdisplayed() == true) 
//		{
//			Assert.assertTrue(true);
//			logger.info("All crews Header is displayed");
//		}
//
//		else 
//		{
//
//			Assert.fail();
//			logger.info("All crews Header is not displayed");
//		}
//		Thread.sleep(2000);
		
		
		TimeManagement_Crews_AllCrews acObj = new TimeManagement_Crews_AllCrews(driver);
		
		acObj.clickBackbtn();
		Thread.sleep(2000);
		
		
		if (acObj.checkAllcrews_Headerdisplayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("All crews Header is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("All crews Header is not displayed");
		}
		Thread.sleep(2000);
		
		acObj.searchCrew(XLUtils.getCellData(excelpath, sheet6, 1, 0));
		Thread.sleep(5000);
		
		// Btn Delete crew [1]
		driver.findElement(By.xpath("//app-crew-list//mat-table//mat-row[1]//mat-cell//button[@mattooltip='Delete crew']")).click();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_delete_popup_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew delete popup is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew delete popup is not displayed");
		}
		
		Thread.sleep(2000);
		
		acObj.clickcrewpopupDeletebtn();
		Thread.sleep(2000);
		
		if (acObj.checkcrew_deleted_msg_displayed() == true) 
		{
			Assert.assertTrue(true);
			logger.info("Crew deleted message is displayed");
		}

		else 
		{

			Assert.fail();
			logger.info("Crew deleted message is not displayed");
		}
		
		Thread.sleep(2000);	
	}
		

	
}
package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import sis.aps.utilities.commonutil;

public class TimeManagement_Crews_MyCrews {

	public WebDriver ldriver;

	public TimeManagement_Crews_MyCrews(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// My crews header
	@FindBy(xpath = "//div[normalize-space()='My crews']")
	WebElement myCrews_Header;

	public boolean checkMycrews_Headerdisplayed() {

		return myCrews_Header.isDisplayed();
	}

	// Search input field
	@FindBy(xpath = "//input[@formcontrolname='searchInput']")
	WebElement searchInputfield;

	public boolean checksearchInput_fieldisplayed() {

		return searchInputfield.isDisplayed();
	}

	// source dropdown field
	@FindBy(xpath = "//mat-select[@placeholder='Source']")
	WebElement sourceDropdownfield;

	public boolean checkSourcedropdown_fieldisplayed() {

		return sourceDropdownfield.isDisplayed();
	}

	// Crew id column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell//div[text()='Crew id']")
	WebElement crewId_clm_header;

	public boolean check_crewId_columnheader_displayed() {

		return crewId_clm_header.isDisplayed();
	}

	// Crew description column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell[text()='Crew description']")
	WebElement crewDescription_clm_header;

	public boolean check_crewDescription_columnheader_displayed() {

		return crewDescription_clm_header.isDisplayed();
	}

	// Crew forman first name column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell[text()='Foreman first name']")
	WebElement crewformanfirstname_clm_header;

	public boolean check_crewforemanfirstname_columnheader_displayed() {

		return crewformanfirstname_clm_header.isDisplayed();
	}

	// Crew forman last name column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell[text()='Foreman last name']")
	WebElement crewformanlastname_clm_header;

	public boolean check_crewforemanlastname_columnheader_displayed() {

		return crewformanlastname_clm_header.isDisplayed();
	}

	// Crew forman personnel number column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell[text()='Foreman personnel number']")
	WebElement crewformanpersoneelnumber_clm_header;

	public boolean check_crewforemanpersonnelnumber_columnheader_displayed() {

		return crewformanpersoneelnumber_clm_header.isDisplayed();
	}

	// Crew actions column header
	@FindBy(xpath = "//mat-header-row//mat-header-cell[text()='Actions']")
	WebElement crewActions_clm_header;

	public boolean check_crewActions_columnheader_displayed() {

		return crewActions_clm_header.isDisplayed();
	}

	// New Crew button
	@FindBy(xpath = "//span[text()='New crew']")
	WebElement clkNewcrewbtn;

	public void clickNewcrewbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNewcrewbtn);

	}

	// Crew details - Back button
	@FindBy(xpath = "//app-crew-details//button//span[text()='Back']")
	WebElement detailstab_Backbtn;

	public boolean check_detailstab_Backbtn_displayed() {

		return detailstab_Backbtn.isDisplayed();
	}

	public void clickBackbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", detailstab_Backbtn);

	}

	// Crew details - Reset button
	@FindBy(xpath = "//app-crew-details//button//span[text()='Reset']")
	WebElement detailstab_Resetbtn;

	public boolean check_detailstab_Resetbtn_displayed() {

		return detailstab_Resetbtn.isDisplayed();
	}

	public void clickResetbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", detailstab_Resetbtn);

	}

	// Crew details - Save button
	@FindBy(xpath = "//app-crew-details//button//span[text()='Save']")
	WebElement detailstab_Savebtn;

	public boolean check_detailstab_Savebtn_displayed() {

		return detailstab_Savebtn.isDisplayed();
	}

	public void clickSavebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", detailstab_Savebtn);

	}

	// Crew details - Tab - enabled
	@FindBy(xpath = "(//div[@aria-selected='true']//div[normalize-space()='Crew details'])[1]")
	WebElement tab_crewdetails;

	public boolean check_crewdetails_Tabenabled() {

		return tab_crewdetails.isDisplayed();
	}

	// Crew members - Tab - disabled
	@FindBy(xpath = "(//div[@aria-selected='false']//div[normalize-space()='Crew members'])[1]")
	WebElement tab_crewmembers;

	public boolean check_crewmembers_Tabdisabled() {

		return tab_crewmembers.isDisplayed();
	}

	public void clickcrewmembers_tab() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", tab_crewmembers);
	}

	// Crew project task - Tab - disabled
	@FindBy(xpath = "(//div[@aria-selected='false']//div[normalize-space()='Crew project task'])[1]")
	WebElement tab_crewprojecttask;

	public boolean check_crewprojecttask_Tabdisabled() {

		return tab_crewprojecttask.isDisplayed();
	}

	// crew id field
	@FindBy(xpath = "//input[@data-placeholder='Crew id']")
	WebElement crewid_inputfield;

	public boolean check_crewId_fielddisplayed() {

		return crewid_inputfield.isDisplayed();
	}

	// crew description field
	@FindBy(xpath = "//input[@data-placeholder='Crew description']")
	WebElement crewdescription_inputfield;

	public boolean check_crewDescription_fielddisplayed() {

		return crewdescription_inputfield.isDisplayed();
	}

	// Foreman personnel number field
	@FindBy(xpath = "//input[@data-placeholder='Foreman personnel number']")
	WebElement crewforemenpersonnelno_inputfield;

	public boolean check_crewFormanpersonnelnumber_fielddisplayed() {

		return crewforemenpersonnelno_inputfield.isDisplayed();
	}

	// Foreman name field
	@FindBy(xpath = "//input[@data-placeholder='Foreman personnel number']")
	WebElement crewforemanName_inputfield;

	public boolean check_crewFormanname_fielddisplayed() {

		return crewforemanName_inputfield.isDisplayed();
	}

	// Default crew checkbox
	@FindBy(xpath = "//mat-checkbox[@formcontrolname='defaultCrew']")
	WebElement defaultcrew_checkbox;

	public boolean check_Defaultcrew_checkboxdisplayed() {

		return defaultcrew_checkbox.isDisplayed();
	}

	// Default crew checkbox 2
	@FindBy(xpath = "//mat-checkbox[@formcontrolname='defaultCrew']//input")
	WebElement clk_defaultcrew_checkbox;

	public void clickDefaultcrewcheckbox() {
//		JavascriptExecutor js = (JavascriptExecutor) ldriver;
//		js.executeScript("arguments[0].click()", defaultcrew_checkbox);
		defaultcrew_checkbox.click();

	}

	// Crew Details tab - alert message
	@FindBy(xpath = "//kt-alert//div[normalize-space()='Please correct below errors']")
	WebElement crewdetails_alertmsg;

	public boolean check_alertmessage_isdisplayed() {

		return crewdetails_alertmsg.isDisplayed();
	}

	// Crew Details tab - crew id field error message
	@FindBy(xpath = "(//mat-error//strong[text()='required'])[1]")
	WebElement crewid_inputfield_alertmsg;

	public boolean check_crewidinput_fielderrormessage_isdisplayed() {

		return crewid_inputfield_alertmsg.isDisplayed();
	}

	// Crew Details tab - personnel number field error message
	@FindBy(xpath = "//mat-error//strong[text()='invalid']")
	WebElement personnelno_inputfield_alertmsg;

	public boolean check_crewpersonnelno_inputfielderrormessage_isdisplayed() {

		return personnelno_inputfield_alertmsg.isDisplayed();
	}

	// Crew Details tab - Edit crew header
	@FindBy(xpath = "//app-crew-details//span[contains(text(),'Edit crew')]")
	WebElement editcrew_header;

	public boolean check_editcrew_headerdisplayed() {

		return editcrew_header.isDisplayed();
	}

	// My Crews search
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement clk_searchcrew;
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement etr_crew;

	public void searchCrew(String crewid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_searchcrew);
		Thread.sleep(1000);
		clk_searchcrew.clear();
		etr_crew.sendKeys(crewid);
	}

	// My Crews - View crew button
	@FindBy(xpath = "//app-crew-list//mat-table//mat-row[1]//button[@mattooltip='View crew']")
	WebElement viewCrew_btn;

	public boolean check_viewcrew_buttondisplayed() {

		return viewCrew_btn.isDisplayed();
	}

	// My Crews - Edit crew button
	@FindBy(xpath = "//app-crew-list//mat-table//mat-row[1]//button[@mattooltip='Edit crew']")
	WebElement EditCrew_btn;

	public boolean check_Editcrew_buttondisplayed() {

		return EditCrew_btn.isDisplayed();
	}

	public void click_Mycrew_Editbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", EditCrew_btn);
	}

	// My Crews - Delete crew button
	@FindBy(xpath = "//app-crew-list//mat-table//mat-row[1]//button[@mattooltip='Delete crew']")
	WebElement deleteCrew_btn;

	public boolean check_deletecrew_buttondisplayed() {

		return deleteCrew_btn.isDisplayed();
	}

	// Tool bar - Add button
	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement add_btn;

	public boolean check_Add_buttondisplayed() {

		return add_btn.isDisplayed();
	}

	public void click_Addbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", add_btn);
	}

	// Tool bar - Edit button
	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement edit_btn;

	public boolean check_Edit_buttondisplayed() {

		return edit_btn.isDisplayed();
	}

	// Tool bar - Delete button
	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement delete_btn;

	public boolean check_Delete_buttondisplayed() {

		return delete_btn.isDisplayed();
	}

	public void click_ToolbarDeletebutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", delete_btn);
	}

	// Tool bar - Save button
	@FindBy(xpath = "//button[@aria-label='Save']")
	WebElement save_btn;

	public boolean check_Save_buttondisplayed() {

		return save_btn.isDisplayed();
	}

	public void click_ToolbarSavebutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", save_btn);
	}

	// Tool bar - Cancel button
	@FindBy(xpath = "//button[@aria-label='Cancel']")
	WebElement cancel_btn;

	public boolean check_Cancel_buttondisplayed() {

		return cancel_btn.isDisplayed();
	}

	public void click_ToolbarCancelbutton() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", cancel_btn);
	}

	// Field header - Worker
	@FindBy(xpath = "//app-crew-member//table//th//span[text()='Worker']")
	WebElement worker_fieldheader;

	public boolean check_workerfieldheader_displayed() {

		return worker_fieldheader.isDisplayed();
	}

	// Field header - Job
	@FindBy(xpath = "//app-crew-member//table//th//span[text()='Job']")
	WebElement job_fieldheader;

	public boolean check_jobfieldheader_displayed() {

		return job_fieldheader.isDisplayed();
	}

	// crew member Tab - Worker field
	@FindBy(xpath = "//input[@id='worker']")
	WebElement worker_inputfield;

	public boolean check_Workerfield_displayed() {

		return worker_inputfield.isDisplayed();
	}

	// crew member Tab - job field
	@FindBy(xpath = "//input[@id='jobId']")
	WebElement job_inputfield;

	public boolean check_Jobfield_displayed() {

		return job_inputfield.isDisplayed();
	}

	// crew member Tab - worker field - error message
	@FindBy(xpath = "//input[@name='worker']//parent::div//ancestor::form//div//label[text()='This field is required.']")
	WebElement worker_inputfield_validation;

	public boolean check_Workerfield_errormsgdisplayed() {

		return worker_inputfield_validation.isDisplayed();
	}

	// Delete button = Crew member delete popup
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Delete']")
	WebElement clk_crewmember_popupDeletebtn;

	public boolean check_crewmember_popupDeletebutton_displayed() {

		return clk_crewmember_popupDeletebtn.isDisplayed();
	}

	public void clickcrewmemberpopupDeletebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewmember_popupDeletebtn);
	}

	// Cancel button = Crew member delete popup
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Cancel']")
	WebElement clk_crewmember_popupcancelbtn;

	public boolean check_crewmember_popupCancelbutton_displayed() {

		return clk_crewmember_popupcancelbtn.isDisplayed();
	}

	public void clickcrewmemberpopupCancelbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewmember_popupcancelbtn);
	}

	// Ram
	public void clickEditCrewbtn() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", EditCrew_btn);
	}

	public String check_crewId_value() {

		return crewid_inputfield.getAttribute("value");
	}

	public String check_crewDescription_value() {

		return crewdescription_inputfield.getAttribute("value");
	}

	public String check_crewFormanpersonnelnumber_value() {

		return crewforemenpersonnelno_inputfield.getAttribute("value");
	}

	public String check_crewFormanname_value() {

		return crewforemanName_inputfield.getAttribute("value");
	}

	@FindBy(xpath = "//input[@type='checkbox']")
	WebElement chkDefaultCrew_isSelected;

	public boolean checkDefaultCrew_isSelected() {

		return chkDefaultCrew_isSelected.getAttribute("aria-checked").contains("true");
	}

	public void click_crewprojecttask_Tabdisabled() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", tab_crewprojecttask);
	}

	@FindBy(xpath = "//span[text()='Add']//parent::button//parent::div")
	WebElement chkAddbtnEnabled;

	public boolean checkAddbtnEnabled() {
		return chkAddbtnEnabled.getAttribute("aria-disabled").contains("false");
	}

	@FindBy(xpath = "//span[text()='Edit']//parent::button//parent::div")
	WebElement chkEdittnEnabled;

	public boolean checkEditbtnDisabled() {
		return chkEdittnEnabled.getAttribute("aria-disabled").contains("true");

	}

	@FindBy(xpath = "//span[text()='Delete']//parent::button//parent::div")
	WebElement chkDeletetnEnabled;

	public boolean checkDeletebtnDisabled() {
		return chkDeletetnEnabled.getAttribute("aria-disabled").contains("true");

	}

	@FindBy(xpath = "//span[text()='Save']//parent::button//parent::div")
	WebElement chkSavebtnDisabled;

	public boolean checkSavebtnDisabled() {
		return chkSavebtnDisabled.getAttribute("aria-disabled").contains("true");

	}

	@FindBy(xpath = "//span[text()='Cancel']//parent::button//parent::div")
	WebElement chkCancelbtnDisabled;

	public boolean checkCancelbtnDisabled() {
		return chkCancelbtnDisabled.getAttribute("aria-disabled").contains("true");

	}

	@FindBy(xpath = "//div[@class='cdk-overlay-pane']")
	WebElement clkAddCrewProjectTaskForm;

	public boolean checkAddCrewProjectTaskForm_isDisplayed() {

		return clkAddCrewProjectTaskForm.isDisplayed();
	}

	@FindBy(xpath = "//input[@formcontrolname='projId']")
	WebElement clkProjectID;

	public boolean checkkProjectID_isDisplayed() {
		return clkProjectID.isDisplayed();
	}

	@FindBy(xpath = "//input[@type='checkbox']")
	WebElement clkSelectAllProjectTask;

	public boolean checkSelectAllProjectTask_isChecked() {
		return clkSelectAllProjectTask.isSelected();
	}

	@FindBy(xpath = "(//button//span[normalize-space()='Save'])[2]")
	WebElement clkSavebtn_AddCrewProjectTaskForm;

	public boolean checkSavebtn_AddCrewProjectTaskForm_isDisplayed() {
		return clkSavebtn_AddCrewProjectTaskForm.isDisplayed();
	}

	@FindBy(xpath = "(//span[normalize-space()='Cancel'])[2]")
	WebElement clkCancelbtn_AddCrewProjectTaskForm;

	public boolean checkCancelbtn_AddCrewProjectTaskForm_isDisplayed() {
		return clkCancelbtn_AddCrewProjectTaskForm.isDisplayed();
	}

	public void clickProjectID() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkProjectID);
	}

	public void clickSelectAllProjectTask() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSelectAllProjectTask);
	}

	@FindBy(xpath = "//div[@class='mat-list-text']//span//b")
	List<WebElement> checkTaskCodes_CrewProjectTask;

	public List<String> getTaskListCrewProjectTask() throws InterruptedException {

		Thread.sleep(2000);

		List<String> TaskIDList = new ArrayList<>();

		for (WebElement taskcode : checkTaskCodes_CrewProjectTask) {

			TaskIDList.add(taskcode.getText());
		}

		return TaskIDList;

	}

	@FindBy(xpath = "//mat-pseudo-checkbox")
	List<WebElement> checkTaskCodes_CheckBox_CrewProjectTask;

	public boolean checkAllTaskCodes_CheckBox_CrewProjectTask_isSelected() {

		for (WebElement checkbox : checkTaskCodes_CheckBox_CrewProjectTask) {

			if (!checkbox.getAttribute("class").contains("mat-pseudo-checkbox-checked")) {

				return false;

			}

		}
		return true;
	}

	public void clickSavebtn_AddCrewProjectTaskForm() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSavebtn_AddCrewProjectTaskForm);
	}

	public List<String> getTaskListCrewProjectTask_Dashboard(String ProjectID) throws InterruptedException {

		Thread.sleep(2000);

		List<String> TaskIDList = new ArrayList<>();

		List<WebElement> checkTaskCodes_CrewProjectTask_Dashboard = ldriver
				.findElements(By.xpath("//tr[@role='row']/td[@aria-colindex='0' and contains(@aria-label,'" + ProjectID
						+ "')]//following-sibling::td[1]"));

		for (WebElement taskcode : checkTaskCodes_CrewProjectTask_Dashboard) {

			TaskIDList.add(taskcode.getText());
		}

		return TaskIDList;

	}

	public boolean checkEditbtnEnabled() {
		return chkEdittnEnabled.getAttribute("aria-disabled").contains("false");

	}

	public boolean checkDeletebtnEnabled() {
		return chkDeletetnEnabled.getAttribute("aria-disabled").contains("false");

	}

	public boolean checkSavebtnEnabled() {
		return chkSavebtnDisabled.getAttribute("aria-disabled").contains("false");

	}

	public boolean checkCancelbtnEnabled() {
		return chkCancelbtnDisabled.getAttribute("aria-disabled").contains("false");

	}

	@FindBy(xpath = "//td[contains(@class,'e-rowcell e-ellipsistooltip') and @aria-colindex='1']")
	List<WebElement> checkTaskCodes_CrewProjectTask_Dashboard;

	@FindBy(xpath = "//td[contains(@class,'e-rowcell e-ellipsistooltip') and @aria-colindex='1']//following-sibling::td//div//button[@title='Edit']")
	List<WebElement> clkEditiconCrewProjectTask_Dashboard;

	@FindBy(xpath = "//td[contains(@class,'e-rowcell e-ellipsistooltip') and @aria-colindex='1']//following-sibling::td//div//button[@title='Delete']")
	List<WebElement> clkDeleteiconCrewProjectTask_Dashboard;

	public boolean CheckEditIconCrewProjectTask_Dashboard() throws InterruptedException {

		Thread.sleep(2000);

		if (checkTaskCodes_CrewProjectTask_Dashboard.size() == clkEditiconCrewProjectTask_Dashboard.size()) {
			return true;
		}

		else {
			return false;
		}
	}

	public boolean CheckDeleteIconCrewProjectTask_Dashboard() throws InterruptedException {

		Thread.sleep(2000);

		if (checkTaskCodes_CrewProjectTask_Dashboard.size() == clkDeleteiconCrewProjectTask_Dashboard.size()) {
			return true;
		}

		else {
			return false;
		}
	}

	public void clickTask_CheckBox_CrewProjectTask() {
		checkTaskCodes_CheckBox_CrewProjectTask.get(1).click();

	}

	@FindBy(xpath = "//mat-pseudo-checkbox[contains(@class,'mat-pseudo-checkbox-checked')]//following-sibling::div[@class='mat-list-text']//span//b")
	List<WebElement> check_Selected_TaskCodes_CrewProjectTask;

	public List<String> getSelectedTaskListCrewProjectTask() throws InterruptedException {

		Thread.sleep(2000);

		List<String> TaskIDList = new ArrayList<>();

		for (WebElement taskcode : check_Selected_TaskCodes_CrewProjectTask) {

			TaskIDList.add(taskcode.getText());
		}

		return TaskIDList;

	}

	@FindBy(xpath = "//tr[@role='row' and @aria-selected='true']//td[2]//following-sibling::td//button[@title='Delete']")
	WebElement clkDeleteofSelectedProjectTask;

	public void clickDeleteofSelectedProjectTask() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkDeleteofSelectedProjectTask);
	}

	@FindBy(xpath = "//tr[@role='row' and @aria-selected='true']//td[2]")
	WebElement chkTaskCodeOfSelectRecord;

	public String getProjectTaskOfSelectedRecordFromDashboard() {

		return chkTaskCodeOfSelectRecord.getText();

	}

	@FindBy(xpath = "//button[@title='Save']")
	WebElement chkSaveIconInline;

	public void clickSaveIconInline() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", chkSaveIconInline);
	}

	public void clickkDeleteCrew(String CrewID) {

		WebElement clkDeleteCrew = ldriver.findElement(By.xpath("//a[normalize-space()='" + CrewID
				+ "']//parent::mat-cell//following-sibling::mat-cell//button[@mattooltip=\"Delete crew\"]//span//mat-icon"));

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkDeleteCrew);
	}

	@FindBy(xpath = "//button//span[normalize-space()='Delete']")
	WebElement clkCrewDeleteConfirm;

	public void clickCrewDeleteConfirm() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCrewDeleteConfirm);
	}

	public void searchCrew2(String crewid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_searchcrew);
		Thread.sleep(1000);
		clk_searchcrew.clear();
		etr_crew.sendKeys(crewid);
		etr_crew.sendKeys(" ");
		Thread.sleep(3000);

	}

	public void click_Mycrew_Editbutton(String CrewID) throws InterruptedException {
		WebElement EditCrew = ldriver.findElement(By.xpath("//mat-row//mat-cell//a[text()='" + CrewID + "']"));

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", EditCrew);
	}

	@FindBy(xpath = "//div[@class='mat-table-message ng-star-inserted' and normalize-space()='No records found']")
	WebElement chkNoRecordsFoundMessage;

	public boolean checkNoRecordsFoundMessage() {

		try {

			chkNoRecordsFoundMessage.isDisplayed();

			return true;
		}

		catch (Exception e) {

			return false;

		}
	}

}
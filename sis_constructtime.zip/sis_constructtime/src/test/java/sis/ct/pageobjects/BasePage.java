package sis.ct.pageobjects;

public class BasePage {

}

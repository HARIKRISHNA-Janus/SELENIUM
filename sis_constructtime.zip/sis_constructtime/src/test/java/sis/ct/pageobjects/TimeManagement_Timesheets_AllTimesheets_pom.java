package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.Date;
import org.testng.Assert;

public class TimeManagement_Timesheets_AllTimesheets_pom {

	public WebDriver ldriver;

	public TimeManagement_Timesheets_AllTimesheets_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	/*
	 * ------------------------------------------------- HARI
	 * -----------------------------------------------------------------------------
	 * ---------
	 */

	// Dashboard
	@FindBy(xpath = "//span[contains(text(),'Dashboard')]")
	WebElement dashboardtab;

	public void isdashboardtabDisplayed() {
		boolean dashboard = dashboardtab.isDisplayed();
		System.out.println(dashboard);
	}

	// Click Toogle
	@FindBy(xpath = "//button[@id='toggle']")
	WebElement clktoglebtn;

	public void clkTooglebtn() {
		clktoglebtn.click();
	}

	// check toogle Timesheet
	@FindBy(xpath = "//h5[normalize-space(text()='Timesheets')]")
	WebElement timesheetstgl;

	public void istimesheettglDisplayed() {
		boolean tglTM = timesheetstgl.isDisplayed();
		System.out.println(tglTM);
	}

	// Click Timesheet Toogle
	public void clicktimesheettgl() {
		timesheetstgl.click();
	}

	// check toogle workflow
	@FindBy(xpath = "//button//span[text()='Workflow']")
	WebElement workflowtgl;

	public void isworkflowtglDisplayed() {
		boolean tglwf = workflowtgl.isDisplayed();
		System.out.println(tglwf);
	}

	// Date label- Defaulted to current date
	@FindBy(xpath = "//a[@id='kt_dashboard_daterangepicker']//span[2]")
	WebElement chkdateValue;

	public void checkdatevalue()

	{
		String datevalue = chkdateValue.getAttribute("value");
		System.out.println(datevalue);
		String datetamp = new SimpleDateFormat("M/d/YYYY").format(new Date());
		System.out.println(datetamp);
		if (datevalue.equals(datetamp)) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}
	}

	// Check All Timesheet Header
	@FindBy(xpath = "//kt-portlet-header//span[text()='All timesheets']")
	WebElement chkAllTimesheetHd;

	public void isalltimesheet_hdDisplayed() {
		boolean hdallTM = chkAllTimesheetHd.isDisplayed();
		System.out.println(hdallTM);
	}

	// check New Timesheet Button
	@FindBy(xpath = "//kt-portlet-header//button//span[text()='New timesheet']")
	WebElement chkNewTimesheetbtn;

	public void isNewtimesheet_btnDisplayed() {
		boolean btnntm = chkNewTimesheetbtn.isDisplayed();
		System.out.println(btnntm);
	}

	// check New Crew Timesheet Button
	@FindBy(xpath = "//kt-portlet-header//button//span[text()='New crew timesheet']")
	WebElement chkNewCrewTimesheetbtn;

	public void isNewCrewtimesheet_btnDisplayed() {
		boolean btnnctm = chkNewCrewTimesheetbtn.isDisplayed();
		System.out.println(btnnctm);
	}

}

package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import sis.aps.utilities.commonutil;

public class TimeManagement_Crews_AllCrews {

	public WebDriver ldriver;

	public TimeManagement_Crews_AllCrews(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// All crews header
	@FindBy(xpath = "//div[normalize-space()='All crews']")
	WebElement allCrews_Header;

	public boolean checkAllcrews_Headerdisplayed() {

		return allCrews_Header.isDisplayed();
	}

	// New Crew button
	@FindBy(xpath = "//span[text()='New crew']")
	WebElement clkNewcrewbtn;

	public void clickNewcrewbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNewcrewbtn);

	}

	// Crew details tab
	@FindBy(xpath = "(//div[normalize-space()='Crew details'])[1]")
	WebElement crew_details_tab;

	public boolean checkcrews_details_tabdisplayed() {

		return crew_details_tab.isDisplayed();
	}

	// crew id field
	@FindBy(xpath = "//input[@data-placeholder='Crew id']")
	WebElement clk_crewid;
	@FindBy(xpath = "//input[@data-placeholder='Crew id']")
	WebElement etr_crewid;

	public void setCrewid(String crewId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewid);
		Thread.sleep(1000);
		etr_crewid.sendKeys(crewId);
	}

	// crew description field
	@FindBy(xpath = "//input[@data-placeholder='Crew description']")
	WebElement clk_crewdecription;
	@FindBy(xpath = "//input[@data-placeholder='Crew description']")
	WebElement etr_crewdescription;

	public void setCrewdescription(String crewDescription) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewdecription);
		Thread.sleep(1000);
		etr_crewdescription.sendKeys(crewDescription);
	}

	// crew foreman personnel number field
	@FindBy(xpath = "//input[@data-placeholder='Foreman personnel number']")
	WebElement clk_crewformanpersonnelno;

	public void setCrewformanpersonnelno(String foremanPersonnelNo) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewformanpersonnelno);
		Thread.sleep(1000);
		clk_crewformanpersonnelno.sendKeys(foremanPersonnelNo);

	}

	// Save button
	@FindBy(xpath = "//button//span[text()='Save']")
	WebElement clk_savebtn;

	public void clickSavebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_savebtn);
	}

	// Crew members tab
	@FindBy(xpath = "(//div[normalize-space()='Crew members'])[1]")
	WebElement crew_members_tab;

	public boolean checkcrews_members_tabdisplayed() {

		return crew_members_tab.isDisplayed();
	}

	public void clickCrewmemberstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", crew_members_tab);
	}

	// Add button
	@FindBy(xpath = "//span[text()='Add']")
	WebElement clkAddBtn;

	public void clickAddbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAddBtn);
	}

	// crew member Tab - Worker field
	@FindBy(xpath = "//input[@id='worker']")
	WebElement clk_worker;
	@FindBy(xpath = "//input[@id='worker']")
	WebElement etr_worker;

	public void setWorker(String workername) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_worker);
		Thread.sleep(1000);
		clk_worker.clear();
		etr_worker.sendKeys(workername);
	}

	// crew member Tab - Job field
	@FindBy(xpath = "//input[@id='jobId']")
	WebElement clk_Jobid;
	@FindBy(xpath = "//input[@id='jobId']")
	WebElement etr_Jobid;

	public void setJobid(String jobId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Jobid);
		Thread.sleep(1000);
		clk_Jobid.clear();
		etr_Jobid.sendKeys(jobId);

	}

	// Edit button
	@FindBy(xpath = "//button//span[text()='Edit']")
	WebElement clk_Editbtn;

	public void clickEditbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Editbtn);
	}

	// Delete button
	@FindBy(xpath = "//button//span[text()='Delete']")
	WebElement clk_Deletebtn;

	public void clickDeletebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Deletebtn);
	}

	// Crew member delete - popup message
	@FindBy(xpath = "(//kt-delete-entity-dialog//div[normalize-space()='Are you sure to delete this crew member?'])[3]")
	WebElement crew_member_delete_popup;

	public boolean checkcrew_member_delete_popup_msg_displayed() {

		return crew_member_delete_popup.isDisplayed();
	}

	// Delete button = Crew member delete popup
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Delete']")
	WebElement clk_crewmember_popupDeletebtn;

	public void clickcrewmemberpopupDeletebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewmember_popupDeletebtn);
	}

	// Crew member deleted message
	@FindBy(xpath = "//div[normalize-space()='Crew member has been deleted']")
	WebElement crew_member_deletedmsg;

	public boolean checkcrew_member_deleted_msg_displayed() {

		return crew_member_deletedmsg.isDisplayed();
	}

	// Crew member updated message
	@FindBy(xpath = "//div[normalize-space()='Crew member has been updated']")
	WebElement crew_member_updatedmsg;

	public boolean checkcrew_member_updated_msg_displayed() {

		return crew_member_updatedmsg.isDisplayed();
	}

	// Crew member created message
	@FindBy(xpath = "//div[normalize-space()='Crew member has been created']")
	WebElement crew_member_createdmsg;

	public boolean checkcrew_member_created_msg_displayed() {

		return crew_member_createdmsg.isDisplayed();
	}

	// Crew created message
	@FindBy(xpath = "//div[normalize-space()='Crew has been created']")
	WebElement crew_createdmsg;

	public boolean checkcrew_created_msg_displayed() {

		return crew_createdmsg.isDisplayed();
	}

	// All Crews search
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement clk_searchcrew;
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement etr_crew;

	public void searchCrew(String crewid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_searchcrew);
		Thread.sleep(1000);
		clk_searchcrew.clear();
		etr_crew.sendKeys(crewid);

	}

	// Back button
	@FindBy(xpath = "//button//span[text()='Back']")
	WebElement clk_Backbtn;

	public void clickBackbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Backbtn);
	}

	// Crew delete - popup message
	@FindBy(xpath = "(//kt-delete-entity-dialog//div[normalize-space()='Are you sure to delete this crew?'])[3]")
	WebElement crew_delete_popup;

	public boolean checkcrew_delete_popup_msg_displayed() {

		return crew_delete_popup.isDisplayed();
	}

	// Delete button = Crew delete popup
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Delete']")
	WebElement clk_crew_popupDeletebtn;

	public void clickcrewpopupDeletebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crew_popupDeletebtn);
	}

	// Crew deleted message
	@FindBy(xpath = "//div[normalize-space()='Crew has been deleted']")
	WebElement crew_deletedmsg;

	public boolean checkcrew_deleted_msg_displayed() {

		return crew_deletedmsg.isDisplayed();
	}

	// Crew Updated message
	@FindBy(xpath = "//div[normalize-space()='Crew has been updated']")
	WebElement crew_updatedmsg;

	public boolean checkcrew_Updated_msg_displayed() {

		return crew_updatedmsg.isDisplayed();
	}

	public boolean clickAddbtn_isDisplayed() {
		return clkAddBtn.isDisplayed();
	}

	public boolean clickDeletebtn_isDisplayed() {
		return clk_Deletebtn.isDisplayed();
	}

	public boolean clickEditbtn_isDisplayed() {
		return clk_Editbtn.isDisplayed();
	}

	public boolean clickSavebtn_isDisplayed() {
		return clk_savebtn.isDisplayed();
	}

	@FindBy(xpath = "//span[text()='Cancel']")
	WebElement clkCancelBtn;

	public boolean clickCancelbtn_isDisplayed() {
		return clkCancelBtn.isDisplayed();
	}

	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Cancel']")
	WebElement clk_crewmember_popupCancelbtn;

	public void clickcrewmemberpopupCancelbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewmember_popupCancelbtn);
	}

}
package sis.ct.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginpage_pom {
	
	public WebDriver ldriver;
	
	public loginpage_pom(WebDriver rdriver) //constructor concept
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//input[@id='email']") WebElement txtUserName;
	public void setUserName(String uname)
	{
		txtUserName.sendKeys(uname);
	}
	@FindBy(xpath="//input[@id='password']") WebElement txtPassword;
	public void setPasword(String pwd)
	{
		txtPassword.sendKeys(pwd);
	}
	@FindBy(xpath="//button[@id='next']") WebElement clkSubmit;
	public void clkSignin()
	{
		//js.executeScript("arguments[0].click()",clkSubmit);
		clkSubmit.click();
	}
	@FindBy(xpath="//*[@id='kt_quick_user_toggle']/span[1]") WebElement clkLogouticon;
	public void clkicon()
	{		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkLogouticon);
		//clkLogouticon.click();
	}
	@FindBy(xpath="//*[@id='kt_quick_user']/div[2]/div[1]/div[2]/a[2]") WebElement clkSignout;
	public void clkSignout()
	{
		clkSignout.click();
	}
}

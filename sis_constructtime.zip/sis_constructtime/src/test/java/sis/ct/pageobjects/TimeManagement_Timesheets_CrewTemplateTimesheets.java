package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.Date;
import org.testng.Assert;

public class TimeManagement_Timesheets_CrewTemplateTimesheets {

	public WebDriver ldriver;

	public TimeManagement_Timesheets_CrewTemplateTimesheets(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	/*
	 * ------------------------------------------------- HARI
	 * -----------------------------------------------------------------------------
	 * ---------
	 */

	// Header Crew Template Timesheet
	@FindBy(xpath = "//app-timesheet-list//kt-portlet-header//span[text()='Crew template timesheets']")
	WebElement CrewtemplateTMSHeader;

	public void isCrewtemplateTMSHeaderDisplayed() {
		boolean Header = CrewtemplateTMSHeader.isDisplayed();
		System.out.println(Header);
	}

	// Button New Crew Template Timesheet
	@FindBy(xpath = "//app-timesheet-list//button//span[text()='New crew template timesheet']")
	WebElement BtnCrewtemplateTMS;

	public void clickBtnCrewtemplateTMS() {
		BtnCrewtemplateTMS.click();
	}

	// Header New Crew Template Timesheet
	@FindBy(xpath = "//app-timesheet-add-edit//kt-portlet-header//span[text()='New crew template timesheet']")
	WebElement NewCrewtemplateTMSHeader;

	public void isNewCrewtemplateTMSHeaderDisplayed() {
		boolean Header = NewCrewtemplateTMSHeader.isDisplayed();
		System.out.println(Header);
	}

	// input crew
	@FindBy(xpath = "//app-timesheet-add-edit//input[@data-placeholder='Crew']")
	WebElement inputcrew;

	public void setcrew(String crewName) {
		inputcrew.sendKeys(crewName);
	}

	// mat-Option
	@FindBy(xpath = "(//mat-option)[1]")
	WebElement clkoption;

	public void clickmatoption() {
		clkoption.click();
	}

	// input notes
	@FindBy(xpath = "//app-timesheet-add-edit//textarea[@data-placeholder='Notes']")
	WebElement inputNotes;

	public void setNotes(String notes) {
		inputNotes.sendKeys(notes);
	}

	// Button Save
	@FindBy(xpath = "//app-timesheet-add-edit//a//span[text()='Save']")
	WebElement clksaveBtn;

	public void ClickSaveBtn() {
		clksaveBtn.click();
	}

	// Header New Crew Template Timesheet
	@FindBy(xpath = "//app-timesheet-add-edit//div[contains(text(),'Hours')]//parent::div[@aria-selected='true']")
	WebElement isHoursTabselected;

	public void isHoursTabselected() {
		boolean Tab = isHoursTabselected.isDisplayed();
		System.out.println(Tab);
	}

	// Cancel button > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//button//span[normalize-space(text())='Cancel']")
	WebElement clkCancelBtn;

	public void ClickCancelBtn() {
		clkCancelBtn.click();
	}

	// Save button > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//button//span[normalize-space(text())='Save']")
	WebElement clkSaveBtn;

	public void Clickpopup_SaveBtn() {
		clkSaveBtn.click();
	}

	// input Job Classification > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='Job classification']")
	WebElement clkjobclassification;

	public void ClickJobclassification() {
		clkjobclassification.click();
	}

	// input Special pay > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='Special pay']")
	WebElement clkSpecialPay;

	public void ClickSpecialPay() {
		clkSpecialPay.click();
	}

	// input Shift Id > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='Shift id']")
	WebElement clkShiftId;

	public void ClickShiftId() {
		clkShiftId.click();
	}

	// input Regular Hours > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='Regular hours']")
	WebElement inputRegularHrs;

	public void SetRegularHrs(String RegularHrs) {
		inputRegularHrs.click();
		inputRegularHrs.clear();
		inputRegularHrs.sendKeys(RegularHrs);
	}

	// input OT1 Hours > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='OT1 hours']")
	WebElement inputOT1Hrs;

	public void SetOT1Hrs(String OT1Hrs) {
		inputOT1Hrs.click();
		inputOT1Hrs.clear();
		inputOT1Hrs.sendKeys(OT1Hrs);

	}

	// input OT2 Hours > Edit Timesheet pop-up
	@FindBy(xpath = "//app-multi-worker-timesheet-edit//input[@data-placeholder='OT2 hours']")
	WebElement inputOT2Hrs;

	public void SetOT2Hrs(String OT2Hrs) {
		inputOT2Hrs.click();
		inputOT2Hrs.clear();
		inputOT2Hrs.sendKeys(OT2Hrs);

	}

	// Tab Field Expenses
	@FindBy(xpath = "//app-timesheet-add-edit//div[contains(text(),'Field expenses')]")
	WebElement clkfieldexpensestab;

	public void clickfieldexpensestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkfieldexpensestab);
		// clkdashboardtab.click();
	}

	// Button Add
	@FindBy(xpath = "//button[@id='Add']")
	WebElement clkAddbtn;

	public void clickAddBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAddbtn);
		// clkdashboardtab.click();
	}

	// input Project Id > Edit Expense pop-up
	@FindBy(xpath = "//app-timesheet-expense-edit//input[@data-placeholder='Project id']")
	WebElement clkProjectId;

	public void ClickprojectId() {
		clkProjectId.click();
	}

	// input Task code > Edit Expense pop-up
	@FindBy(xpath = "//app-timesheet-expense-edit//input[@data-placeholder='Task code']")
	WebElement clktaskcode;

	public void ClicktaskCode() {
		clktaskcode.click();
	}

	// input Expense category > Edit Expense pop-up
	@FindBy(xpath = "//app-timesheet-expense-edit//input[@data-placeholder='Expense category']")
	WebElement clkexpenseCategory;

	public void ClickexpenseCategory() {
		clkexpenseCategory.click();
	}

	// input Qunatity > Edit Expense pop-up
	@FindBy(xpath = "//app-timesheet-expense-edit//input[@data-placeholder='Quantity']")
	WebElement setquantity_expense;

	public void setQuantity_Expense(String expenseQty) {
		setquantity_expense.click();
		setquantity_expense.clear();
		setquantity_expense.sendKeys(expenseQty);
	}

	// Save button > Edit Expense pop-up
	@FindBy(xpath = "//app-timesheet-expense-edit//button//span[normalize-space(text())='Save']")
	WebElement clkSaveBtn_expensepopup;

	public void ClickSaveBtn_expensepopup() {
		clkSaveBtn_expensepopup.click();
	}

	// Tab Equipment
	@FindBy(xpath = "//app-timesheet-add-edit//div[contains(text(),'Equipment')]")
	WebElement clkEquipmenttab;

	public void clickEquipmenttab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEquipmenttab);
		// clkdashboardtab.click();
	}

	// input Project Id > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-equipment-edit//input[@data-placeholder='Project id']")
	WebElement clkProjectId_equipment;

	public void ClickprojectId_equipment() {
		clkProjectId_equipment.click();
	}

	// input Task code > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-equipment-edit//input[@data-placeholder='Task code']")
	WebElement clktaskcode_equipment;

	public void Clicktaskcode_equipment() {
		clktaskcode_equipment.click();
	}

	// input Equipment Id > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-equipment-edit//input[@data-placeholder='Equipment id']")
	WebElement clkEquipmentId_equipment;

	public void ClickequipmentId_equipment() {
		clkEquipmentId_equipment.click();
	}

	// input Qunatity > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-equipment-edit//input[@data-placeholder='Quantity']")
	WebElement setquantity_equipment;

	public void setQuantity_Equipment(String equipmentQty) {
		setquantity_equipment.click();
		setquantity_equipment.clear();
		setquantity_equipment.sendKeys(equipmentQty);
	}

	// Save button > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-equipment-edit//button//span[normalize-space(text())='Save']")
	WebElement clkSaveBtn_equipmentpopup;

	public void ClickSaveBtn_equipmentpopup() {
		clkSaveBtn_equipmentpopup.click();
	}

	// Tab Production
	@FindBy(xpath = "//app-timesheet-add-edit//div[contains(text(),'Production')]")
	WebElement clkProductiontab;

	public void clickProductiontab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkProductiontab);
		// clkdashboardtab.click();
	}

	// input Project Id > Edit Production pop-up
	@FindBy(xpath = "//app-timesheet-production-edit//input[@data-placeholder='Project id']")
	WebElement clkProjectId_production;

	public void ClickprojectId_production() {
		clkProjectId_production.click();
	}

	// input Task code > Edit production pop-up
	@FindBy(xpath = "//app-timesheet-production-edit//input[@data-placeholder='Task code']")
	WebElement clktaskcode_production;

	public void Clicktaskcode_production() {
		clktaskcode_production.click();
	}

	// input Qunatity > Edit Equipment pop-up
	@FindBy(xpath = "//app-timesheet-production-edit//input[@data-placeholder='Quantity']")
	WebElement setquantity_production;

	public void setQuantity_production(String productionQty) {
		setquantity_production.click();
		setquantity_production.clear();
		setquantity_production.sendKeys(productionQty);
	}

	// Save button > Edit Production pop-up
	@FindBy(xpath = "//app-timesheet-production-edit//button//span[normalize-space(text())='Save']")
	WebElement clkSaveBtn_productionpopup;

	public void ClickSaveBtn_productionpopup() {
		clkSaveBtn_productionpopup.click();
	}

	// Delete button > pop-up
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Delete']")
	WebElement clkDeletebtn_popup;

	public void ClickDeleteBtn_popup() {
		clkDeletebtn_popup.click();
	}

	// Hari - 6/29/2021

	// Crew Template Timesheet - Tab - Header
	@FindBy(xpath = "(//div[normalize-space()='Header'])[1]")
	WebElement tab_header;

	public boolean check_Header_Tabdisplayed() {

		return tab_header.isDisplayed();
	}

	// Crew Template Timesheet - Tab - Hours
	@FindBy(xpath = "(//div[contains(text(),'Hours')])[1]")
	WebElement tab_hours;

	public boolean check_Hours_Tabdisplayed() {

		return tab_hours.isDisplayed();
	}

	// Crew Template Timesheet - Tab - Field Expenses
	@FindBy(xpath = "(//div[contains(text(),'Field expenses')])[1]")
	WebElement tab_fieldExpenses;

	public boolean check_Fieldexpenses_Tabdisplayed() {

		return tab_fieldExpenses.isDisplayed();
	}

	// Crew Template Timesheet - Tab - Equipment
	@FindBy(xpath = "(//div[contains(text(),'Equipment')])[1]")
	WebElement tab_equipment;

	public boolean check_Equipment_Tabdisplayed() {

		return tab_equipment.isDisplayed();
	}

	// Crew Template Timesheet - Tab - production
	@FindBy(xpath = "(//div[contains(text(),'Production')])[1]")
	WebElement tab_production;

	public boolean check_Production_Tabdisplayed() {

		return tab_production.isDisplayed();
	}

	// Crew Template Timesheet - Back button
	@FindBy(xpath = "//kt-portlet-header//span[text()='Back']")
	WebElement back_btn;

	public boolean check_Back_btndisplayed() {

		return back_btn.isDisplayed();
	}

	// Crew Template Timesheet - Save button
	@FindBy(xpath = "//kt-portlet-header//span[text()='Save']")
	WebElement save_btn;

	public boolean check_Save_btndisplayed() {

		return save_btn.isDisplayed();
	}

	public void clickSavebutton_toobar() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", save_btn);
		// clkdashboardtab.click();
	}

	// Date field- Defaulted to current date in MM/DD/YYY format with Calendar icon
	// and editable.
	@FindBy(xpath = "//input[@formcontrolname='timesheetDate']")
	WebElement chkdateValue;
	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement chkopencalendar;

	public void checkdatevalue() {
		String datevalue = chkdateValue.getAttribute("value");
		System.out.println("App date value is: " + datevalue);
		String timestamp = new SimpleDateFormat("M/d/YYYY").format(new Date());
		System.out.println("System timestamp is: " + timestamp);
		if (datevalue.equals(timestamp)) {
			Assert.assertTrue(true);
		} else {
			System.out.println("Date field doesn't equal to timestamp");
			Assert.fail();
		}
		boolean dateeditable = chkdateValue.isEnabled();
		chkopencalendar.isDisplayed();
		chkopencalendar.isEnabled();

	}

	// crew Template timesheet - crew field
	public boolean check_crewfield_displayed() {

		return inputcrew.isDisplayed();
	}

	// Crew foreman field
	@FindBy(xpath = "//app-timesheet-add-edit//input[@data-placeholder='Crew foreman']")
	WebElement crewforman_inputfield;

	public boolean check_crewforemanfield_displayed() {

		return crewforman_inputfield.isDisplayed();
	}

	// Crew Description field
	@FindBy(xpath = "//app-timesheet-add-edit//input[@data-placeholder='Description']")
	WebElement crewdescription_inputfield;

	public boolean check_crewdescriptionfield_displayed() {

		return crewdescription_inputfield.isDisplayed();
	}

	// Crew Status field
	@FindBy(xpath = "//app-timesheet-add-edit//input[@data-placeholder='Status']")
	WebElement crewstatus_inputfield;

	public boolean check_crewstatusfield_displayed() {

		return crewstatus_inputfield.isDisplayed();
	}

	// Crew Status field

	public boolean check_crewNotesfield_displayed() {

		return inputNotes.isDisplayed();
	}

	// Header Alret message
	@FindBy(xpath = "(//kt-alert//div[normalize-space(text()='Please correct below errors')])[3]")
	WebElement alertmsg_header;

	public boolean check_alertmessage_header_displayed() {

		return alertmsg_header.isDisplayed();
	}

	// Header tab - crew field error message
	@FindBy(xpath = "(//mat-error//strong[text()='required'])[1]")
	WebElement crew_inputfield_alertmsg;

	public boolean check_crewinput_fielderrormessage_isdisplayed() {

		return crew_inputfield_alertmsg.isDisplayed();
	}

	public void setCrew(String crew) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputcrew);
		Thread.sleep(1000);
		inputcrew.sendKeys(crew);

	}

	// Date field- Defaulted to current date in MM/DD/YYY format - Hours Tab
	@FindBy(xpath = "//input[@formcontrolname='dateFilter']")
	WebElement chkdateValue_Htab;

	public void checkdatevalueHourstab() {
		String datevalue = chkdateValue_Htab.getAttribute("value");
		System.out.println("App date value is: " + datevalue);
		String timestamp = new SimpleDateFormat("MM/dd/YYYY").format(new Date());
		System.out.println("System timestamp is: " + timestamp);
		if (datevalue.equals(timestamp)) {
			Assert.assertTrue(true);
		} else {
			System.out.println("Date field doesn't equal to timestamp");
			Assert.fail();
		}

	}

	// Hours tab - crew member filter
	@FindBy(xpath = "//input[@formcontrolname='crewMember']")
	WebElement crewmember_filterfield;

	public boolean check_crewmemberfilter_isdisplayed() {

		return crewmember_filterfield.isDisplayed();
	}

	// Hours tab - Project filter
	@FindBy(xpath = "//input[@formcontrolname='projectFilter']")
	WebElement project_filterfield;

	public boolean check_projectfilter_isdisplayed() {

		return project_filterfield.isDisplayed();
	}

	// Hours tab - Project Task filter
	@FindBy(xpath = "//input[@formcontrolname='projectTaskFilter']")
	WebElement projectTask_filterfield;

	public boolean check_projectTaskfilter_isdisplayed() {

		return projectTask_filterfield.isDisplayed();
	}

	// Crew Template Timesheet - Hours Tab - Submit button
	@FindBy(xpath = "//kt-portlet-header//span[text()='Submit']")
	WebElement submit_btn;

	public boolean check_Submit_btndisplayed() {

		return submit_btn.isDisplayed();
	}

	// Hours Tab - Tool bar - Add worker button
	@FindBy(xpath = "//button[@aria-label='Add worker']")
	WebElement addWorker_btn;

	public boolean check_Addworker_buttondisplayed() {

		return addWorker_btn.isDisplayed();
	}

	public void click_Addworkerbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", addWorker_btn);
	}

	// Hours Tab - Tool bar - Add Task code button
	@FindBy(xpath = "//button[@aria-label='Add task code']")
	WebElement addTaskcode_btn;

	public boolean check_Addtaskcode_buttondisplayed() {

		return addTaskcode_btn.isDisplayed();
	}

	// Hours Tab - Tool bar - Add button
	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement Add_btn;

	public boolean check_Add_buttondisplayed() {

		return Add_btn.isDisplayed();
	}

	public void click_ToolbarAddbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", Add_btn);
	}

	// Hours Tab - Tool bar - Edit button
	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement Edit_btn;

	public boolean check_Edit_buttondisplayed() {

		return Edit_btn.isDisplayed();
	}

	public void click_ToolbarEditbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", Edit_btn);
	}

	// Hours Tab - Tool bar - Delete button
	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement Delete_btn;

	public boolean check_Delete_buttondisplayed() {

		return Delete_btn.isDisplayed();
	}

	public void click_ToolbarDeletebutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", Delete_btn);
	}

	// Hours Tab - Tool bar - Delete confirm box
	@FindBy(xpath = "(//kt-delete-entity-dialog//div[contains(@class,'form') and normalize-space(text()='Are you sure to delete this timesheet hours?')])[2]")
	WebElement Delete_confirmbox_msg;

	public boolean check_Deleteconfirmbox_Messagedisplayed() {

		return Delete_confirmbox_msg.isDisplayed();
	}

	// Hours Tab - Delete popup - Cancel button
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Cancel']")
	WebElement deletepopup_Cancel_btn;

	public void click_Deletepopup_Cancelbutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", deletepopup_Cancel_btn);
	}

	// Hours Tab - Delete popup - Delete button
	@FindBy(xpath = "//kt-delete-entity-dialog//button//span[text()='Delete']")
	WebElement deletepopup_Delete_btn;

	public void click_Deletepopup_Deletebutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", deletepopup_Delete_btn);
	}

	// Timesheet Hours deleted message
	@FindBy(xpath = "//div[normalize-space()='Timesheet hours has been deleted']")
	WebElement timesheet_Hours_deletedmsg;

	public boolean checkTimesheet_hours_deleted_msg_displayed() {

		return timesheet_Hours_deletedmsg.isDisplayed();
	}

	// Hours Tab - Tool bar - Save button
	@FindBy(xpath = "//button[@aria-label='Save']")
	WebElement Save_btn;

	public boolean check_Save_buttondisplayed() {

		return Save_btn.isDisplayed();
	}

	public void clickToolbarSavebutton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", Save_btn);

	}

	// Hours Tab - Tool bar - Cancel button
	@FindBy(xpath = "//button[@aria-label='Cancel']")
	WebElement Cancel_btn;

	public boolean check_Cancel_buttondisplayed() {

		return Cancel_btn.isDisplayed();
	}

	// Hours Tab - column header - Crew member
	@FindBy(xpath = "//table//th//span[text()='Crew Member']")
	WebElement Cremember_clmnHeader;

	public boolean check_Crewmember_columnheaderisplayed() {

		return Cremember_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - Project
	@FindBy(xpath = "//table//th//span[text()='Project']")
	WebElement Project_clmnHeader;

	public boolean check_Project_columnheaderisplayed() {

		return Project_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - Task
	@FindBy(xpath = "//table//th//span[text()='Task']")
	WebElement Task_clmnHeader;

	public boolean check_Task_columnheaderisplayed() {

		return Task_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - Regular Hours
	@FindBy(xpath = "//table//th//span[text()='Regular hours']")
	WebElement regularHours_clmnHeader;

	public boolean check_Regularhours_columnheaderisplayed() {

		return regularHours_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - OT1 Hours
	@FindBy(xpath = "//table//th//span[text()='OT1 hours']")
	WebElement oT1Hours_clmnHeader;

	public boolean check_OT1hours_columnheaderisplayed() {

		return oT1Hours_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - OT2 Hours
	@FindBy(xpath = "//table//th//span[text()='OT2 hours']")
	WebElement oT2Hours_clmnHeader;

	public boolean check_OT2hours_columnheaderisplayed() {

		return oT2Hours_clmnHeader.isDisplayed();
	}

	// Hours Tab - column header - Total
	@FindBy(xpath = "//table//th//span[text()='Total']")
	WebElement total_clmnHeader;

	public boolean check_Total_columnheaderisplayed() {

		return total_clmnHeader.isDisplayed();
	}

	// Hours Tab - Regular Hours - Inline
	@FindBy(xpath = "//input[@id='regularHours']")
	WebElement inline_RegularHrs;

	public void SetRegularHrs_Inline(String RegularHrs) {
		inline_RegularHrs.click();
		inline_RegularHrs.clear();
		inline_RegularHrs.sendKeys(RegularHrs);
	}

	// Hours Tab - OT1 Hours - Inline
	@FindBy(xpath = "//input[@id='overTimeHours']")
	WebElement inline_OT1Hrs;

	public void SetOT1Hrs_Inline(String OT1Hrs) {
		inline_OT1Hrs.click();
		inline_OT1Hrs.clear();
		inline_OT1Hrs.sendKeys(OT1Hrs);
	}

	// Hours Tab - Inline - Save Button
	@FindBy(xpath = "//button[@title='Save']")
	WebElement inline_Savebtn;

	public void Savebutton_Inline() {
		inline_Savebtn.click();
	}

	// Hours Tab - Edit popup - project id field
	@FindBy(xpath = "//input[@formcontrolname='projId']")
	WebElement inputProjectId_Editpopup;

	public void setprojectId(String projectId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputProjectId_Editpopup);
		Thread.sleep(1000);
		inputProjectId_Editpopup.clear();
		inputProjectId_Editpopup.sendKeys(projectId);
	}

	// Hours Tab - Edit popup - Task code field
	@FindBy(xpath = "//input[@formcontrolname='taskCode']")
	WebElement inputTaskcode_Editpopup;

	public void setTaskcode(String Taskcode) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputTaskcode_Editpopup);
		Thread.sleep(1000);
		inputTaskcode_Editpopup.clear();
		inputTaskcode_Editpopup.sendKeys(Taskcode);
	}

	// Hours Tab - Edit popup - Job Classification field
	@FindBy(xpath = "//input[@formcontrolname='jobId']")
	WebElement inputJbClassification_Editpopup;

	public void setJobclassification(String jbClassification) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputJbClassification_Editpopup);
		Thread.sleep(1000);
		inputJbClassification_Editpopup.sendKeys(jbClassification);
	}

	// Hours Tab - Edit popup - Special Pay field
	@FindBy(xpath = "//input[@formcontrolname='specialPay']")
	WebElement inputSpecialPay_Editpopup;

	public void setSpecialPayn(String specialPay) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputSpecialPay_Editpopup);
		Thread.sleep(1000);
		inputSpecialPay_Editpopup.sendKeys(specialPay);
	}

	// Hours Tab - Edit popup - Shift Id field
	@FindBy(xpath = "//input[@formcontrolname='shiftId']")
	WebElement inputShiftId_Editpopup;

	public void setShiftId(String shiftId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputShiftId_Editpopup);
		Thread.sleep(1000);
		inputShiftId_Editpopup.sendKeys(shiftId);
	}

	// Hours Tab - OT2 Hours - Edit popup
	@FindBy(xpath = "//input[@formcontrolname='doubleTimeHours']")
	WebElement editpopup_OT2Hrs;

	public void SetOT2Hrs_Editpopup(String OT2Hrs) {
		editpopup_OT2Hrs.click();
		editpopup_OT2Hrs.clear();
		editpopup_OT2Hrs.sendKeys(OT2Hrs);
	}

	// Hours Tab - Save button - Edit popup
	@FindBy(xpath = "(//button//span[normalize-space(text())='Save'])[2]")
	WebElement editpopup_SaveBtn;

	public void click_Savebtn_Editpopup() {
		editpopup_SaveBtn.click();
	}

	public boolean check_savebtn_displayed() {

		return editpopup_SaveBtn.isDisplayed();
	}

	// Hours Tab - Cancel button - Edit popup
	@FindBy(xpath = "(//button//span[normalize-space(text())='Cancel'])[2]")
	WebElement editpopup_CancelBtn;

	public void click_CancelBtn_Editpopup() {
		editpopup_CancelBtn.click();
	}

	public boolean check_cancelbtn_displayed() {

		return editpopup_CancelBtn.isDisplayed();
	}

	// Add worker - form - worker field
	@FindBy(xpath = "//input[@formcontrolname='worker']")
	WebElement addWorker_input;

	public boolean check_worker_fielddisplayed() {

		return addWorker_input.isDisplayed();
	}

	public void SetWorker_Addworkerform(String Worker) {
		addWorker_input.click();
		addWorker_input.clear();
		addWorker_input.sendKeys(Worker);
	}

	// Field Expense Tab - column header - Date
	@FindBy(xpath = "//table//th//span[text()='Date']")
	WebElement date_clmnHeader;

	public boolean check_Date_columnheaderisplayed() {

		return date_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Crew member
	@FindBy(xpath = "//table//th//span[text()='Crew member']")
	WebElement crewMember_clmnHeader;

	public boolean check_Crewmember_columnheaderdisplayed() {

		return crewMember_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Project
	@FindBy(xpath = "//table//th//span[text()='Project']")
	WebElement project_clmnHeader;

	public boolean check_Project_columnheaderdisplayed() {

		return project_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Task
	@FindBy(xpath = "//table//th//span[text()='Task']")
	WebElement task_clmnHeader;

	public boolean check_Task_columnheaderdisplayed() {

		return task_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Expense Category
	@FindBy(xpath = "//table//th//span[text()='Expense category']")
	WebElement expenseCategory_clmnHeader;

	public boolean check_Expensecategory_columnheaderdisplayed() {

		return expenseCategory_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Quantity
	@FindBy(xpath = "//table//th//span[text()='Quantity']")
	WebElement quantity_clmnHeader;

	public boolean check_Quantity_columnheaderdisplayed() {

		return quantity_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Unit
	@FindBy(xpath = "//table//th//span[text()='Unit']")
	WebElement unit_clmnHeader;

	public boolean check_Unit_columnheaderdisplayed() {

		return unit_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Unit price
	@FindBy(xpath = "//table//th//span[text()='Unit price']")
	WebElement unitPrice_clmnHeader;

	public boolean check_Unitprice_columnheaderdisplayed() {

		return unitPrice_clmnHeader.isDisplayed();
	}

	// Field Expense Tab - column header - Total Amount
	@FindBy(xpath = "//table//th//span[text()='Total amount']")
	WebElement totalAmount_clmnHeader;

	public boolean check_Totalamount_columnheaderdisplayed() {

		return totalAmount_clmnHeader.isDisplayed();
	}

	// Field Expense form header
	@FindBy(xpath = "//h3[text()='Add field expense']")
	WebElement fieldExpense_formHeader;

	public boolean check_Fieldexpense_formheaderdisplayed() {

		return fieldExpense_formHeader.isDisplayed();
	}

	// Date field- Defaulted to current date in MM/DD/YYY format - Field expense Tab
	@FindBy(xpath = "//input[@formcontrolname='date']")
	WebElement chkdateValue_FEtab;

	public void checkdatevalueFieldExpensetab() {
		String datevalue = chkdateValue_FEtab.getAttribute("value");
		System.out.println("App date value is: " + datevalue);
		String timestamp = new SimpleDateFormat("M/d/YYYY").format(new Date());
		System.out.println("System timestamp is: " + timestamp);
		if (datevalue.equals(timestamp)) {
			Assert.assertTrue(true);
		} else {
			System.out.println("Date field doesn't equal to timestamp");
			Assert.fail();
		}

	}

	// Field expense form - project field
	@FindBy(xpath = "//input[@formcontrolname='projId']")
	WebElement Projectfield_FE;

	public boolean check_Projectfield_isdisplayed() {

		return Projectfield_FE.isDisplayed();
	}

	// Field expense form - Task code field
	@FindBy(xpath = "//input[@formcontrolname='taskCode']")
	WebElement Taskcodefield_FE;

	public boolean check_Taskcodefield_isdisplayed() {

		return Taskcodefield_FE.isDisplayed();
	}

	// Field expense form - Expense category field
	@FindBy(xpath = "//input[@formcontrolname='expenseCategory']")
	WebElement Expensecategoryfield_FE;

	public boolean check_Expensecategoryfield_isdisplayed() {

		return Expensecategoryfield_FE.isDisplayed();
	}

	// Field expense form - Quantity field
	@FindBy(xpath = "//input[@formcontrolname='qty']")
	WebElement Qty_field_FE;

	public boolean check_Quantityfield_isdisplayed() {

		return Qty_field_FE.isDisplayed();
	}

	public void setQuantity(String qty) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", Qty_field_FE);
		Thread.sleep(1000);
		Qty_field_FE.clear();
		Qty_field_FE.sendKeys(qty);
	}

	// Field expense form - Unit field
	@FindBy(xpath = "//input[@formcontrolname='unit']")
	WebElement Unit_field_FE;

	public boolean check_Unitfield_isdisplayed() {

		return Unit_field_FE.isDisplayed();
	}

	// Field expense form - Unit price field
	@FindBy(xpath = "//input[@formcontrolname='unitPrice']")
	WebElement Unitprice_field_FE;

	public boolean check_Unitpricefield_isdisplayed() {

		return Unitprice_field_FE.isDisplayed();
	}

	// Field expense form - Total Amount field
	@FindBy(xpath = "//input[@formcontrolname='totalAmount']")
	WebElement Totalamount_field_FE;

	public boolean check_Totalamountfield_isdisplayed() {

		return Totalamount_field_FE.isDisplayed();
	}

	// Field expense form - project field error message
	@FindBy(xpath = "//input[@formcontrolname='projId']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement project_field_FE_erMsg;

	public boolean check_Projectfield_errormsg_isdisplayed() {

		return project_field_FE_erMsg.isDisplayed();
	}

	// Field expense form - Task field error message
	@FindBy(xpath = "//input[@formcontrolname='taskCode']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement taskcode_field_FE_erMsg;

	public boolean check_Taskcodefield_errormsg_isdisplayed() {

		return taskcode_field_FE_erMsg.isDisplayed();
	}

	// Field expense form - Expense category field error message
	@FindBy(xpath = "//input[@formcontrolname='expenseCategory']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement expenseCategory_field_FE_erMsg;

	public boolean check_Expensecategoryfield_errormsg_isdisplayed() {

		return expenseCategory_field_FE_erMsg.isDisplayed();
	}

	// Field expense form - Quantity field error message
	@FindBy(xpath = "//input[@formcontrolname='qty']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement quantity_field_FE_erMsg;

	public boolean check_Quantityfield_errormsg_isdisplayed() {

		return quantity_field_FE_erMsg.isDisplayed();
	}

	// Field expense form - Unit price field error message
	@FindBy(xpath = "//input[@formcontrolname='unitPrice']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement unitPrice_field_FE_erMsg;

	public boolean check_Unitpricefield_errormsg_isdisplayed() {

		return unitPrice_field_FE_erMsg.isDisplayed();
	}

	// Field expense form - Expense category field
	@FindBy(xpath = "//input[@formcontrolname='expenseCategory']")
	WebElement inputExpenseCategory;

	public void setExpenseCategory(String expenseCategory) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputExpenseCategory);
		Thread.sleep(1000);
		inputExpenseCategory.clear();
		inputExpenseCategory.sendKeys(expenseCategory);
	}

	// Field expense Attachedment upload header
	@FindBy(xpath = "//app-attachment-upload//div//span[contains(text(),'Crew timesheet expense attachment')]")
	WebElement attachmentUpload_header;

	public boolean check_Attachmentupload_Headerisdisplayed() {

		return attachmentUpload_header.isDisplayed();
	}

	@FindBy(xpath = "//a[@id='browse']")
	WebElement LinkBrowse;

	public void clickBrowse() {
		LinkBrowse.click();
	}

	@FindBy(xpath = "//button//span[text()='Upload']")
	WebElement BTNUpload;

	public void ClickUploadBTN() {
		BTNUpload.click();
	}

	// Click x button - Attachment upload
	@FindBy(xpath = "//button//mat-icon[text()='clear']")
	WebElement clk_Xbtn;

	public void click_Xbutton_attachmentuploadform() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Xbtn);
	}

	// Equipment Tab - column header - Equipment
	@FindBy(xpath = "//table//th//span[text()='Equipment']")
	WebElement equipment_clmnHeader;

	public boolean check_Equipment_columnheaderdisplayed() {

		return equipment_clmnHeader.isDisplayed();
	}

	// Equipment form - Task code field
	@FindBy(xpath = "//input[@formcontrolname='equipmentId']")
	WebElement Equipmentfield_Eq;

	public boolean check_Equipmentfield_isdisplayed() {

		return Equipmentfield_Eq.isDisplayed();
	}

	// Equipment form header
	@FindBy(xpath = "//h3[text()='Add equipment']")
	WebElement equipment_formHeader;

	public boolean check_Equipment_formheaderdisplayed() {

		return equipment_formHeader.isDisplayed();
	}

	// Equipment form - Equipment field
	@FindBy(xpath = "//input[@formcontrolname='equipmentId']")
	WebElement inputEquipmentid;

	public void setEquipmentId(String equipmentId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", inputEquipmentid);
		Thread.sleep(1000);
		inputEquipmentid.clear();
		inputEquipmentid.sendKeys(equipmentId);
	}

	// Crew Template Timesheet - Submit button
	@FindBy(xpath = "//kt-portlet-header//span[text()='Submit']")
	WebElement submit_btn_cttms;

	public boolean check_CTTMS_Submit_btndisplayed() {

		return submit_btn_cttms.isDisplayed();
	}

	public void clickCTTMS_Submit_button() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", submit_btn_cttms);

	}

	// Timesheet status - Updated toast message

	@FindBy(xpath = "//div[normalize-space()='Timesheet status has been updated']")
	WebElement timesheet_Status_updatedmsg;

	public boolean checkTimesheet_Statusupdated_msg_displayed() {

		return timesheet_Status_updatedmsg.isDisplayed();
	}

	// Tab Hours
	@FindBy(xpath = "(//app-timesheet-add-edit//div[contains(text(),'Hours')])[1]")
	WebElement clkHourstab;

	public void clickHourstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkHourstab);
		// clkdashboardtab.click();
	}

	// click crew member - Hours tab
	public void click_crewmemberfilter() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", crewmember_filterfield);
		// clkdashboardtab.click();
	}

	// click crew project - Hours Tab
	public void click_crewprojectfilter() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", project_filterfield);
		// clkdashboardtab.click();
	}

	// Workflow button
	@FindBy(xpath = "//button//span[text()='Workflow']")
	WebElement clkgroupWorkflowbtn;

	public void clkGroupWorkflowbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkgroupWorkflowbtn);
	}

	// Approve Button
	@FindBy(xpath = "//div[contains(@class,'dropdown-menu')]//a[normalize-space()='Approve']")
	WebElement clkGroupworkflowApproveBtn;

	public void clickGroupworkflowApproveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkGroupworkflowApproveBtn);
	}

	// Approve Confirm box
	@FindBy(xpath = "//h3[text()='Approve timesheet']")
	WebElement tmApproveconfirmbox;

	public boolean chk_TimesheetApproveconformbox_displayed() {

		return tmApproveconfirmbox.isDisplayed();
	}

	// confirm box Approve Button
	@FindBy(xpath = "//button//span[text()='Approve']")
	WebElement clkConfirmboxApproveBtn;

	public void clickConfirmboxApprovebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkConfirmboxApproveBtn);
	}

	// confirm box Approve - Cancel Button
	@FindBy(xpath = "//button//span[text()='Cancel']")
	WebElement clkConfirmboxApprove_cancelBtn;

	public void clickConfirmboxApprove_Cancelbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkConfirmboxApprove_cancelBtn);
	}

	// Production form header
	@FindBy(xpath = "//h3[text()='Add production']")
	WebElement production_formHeader;

	public boolean check_Production_formheaderdisplayed() {

		return production_formHeader.isDisplayed();
	}

	// Production form - Unit field
	@FindBy(xpath = "//input[@formcontrolname='prodUnit']")
	WebElement Unit_field_prod;

	public boolean check_prodUnitfield_isdisplayed() {

		return Unit_field_prod.isDisplayed();
	}

	// Production form - Quantity field
	@FindBy(xpath = "//input[@formcontrolname='completedQty']")
	WebElement Qty_field_prod;

	public boolean check_ProdQuantityfield_isdisplayed() {

		return Qty_field_prod.isDisplayed();
	}

	// Production form - Quantity field error message
	@FindBy(xpath = "//input[@formcontrolname='completedQty']//parent::div//following::div[3]//mat-error//strong[text()='required']")
	WebElement quantity_field_Prod_erMsg;

	public boolean check_Prod_Quantityfield_errormsg_isdisplayed() {

		return quantity_field_Prod_erMsg.isDisplayed();
	}

}
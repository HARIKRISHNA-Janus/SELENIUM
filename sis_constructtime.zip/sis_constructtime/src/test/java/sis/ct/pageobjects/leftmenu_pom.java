package sis.ct.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class leftmenu_pom {

	public WebDriver ldriver;

	public leftmenu_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// Dashboard
	@FindBy(xpath = "//span[contains(text(),'Dashboard')]")
	WebElement clkdashboardtab;

	public void clickdashboardtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdashboardtab);
		// clkdashboardtab.click();
	}

	// Administration
	@FindBy(xpath = "//span[contains(text(),'Administration')]")
	WebElement clkadministrationtab;

	public void clickadministrationtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkadministrationtab);
		// clkadministrationtab.click();
	}

	// Administration SubTabs
	// Organization setup
	@FindBy(xpath = "//span[contains(text(),'Organization setup')]")
	WebElement clkorganizationsetuptab;

	public void clickorganizationsetuptab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkorganizationsetuptab);
		// clkorganizationsetuptab.click();
	}

	// Security
	@FindBy(xpath = "//span[contains(text(),'Security')]")
	WebElement clksecuritytab;

	public void clksecuritytab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clksecuritytab);
		// clksecuritytab.click();
	}

	// Security SubTabs
	// Users
	@FindBy(xpath = "//span[contains(text(),'Users')]")
	WebElement clkUserstab;

	public void clkUserstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkUserstab);
		// clkUserstab.click();
	}

	// Data Management
	@FindBy(xpath = "//span[contains(text(),'Data management')]")
	WebElement clkdatamanagementtab;

	public void clkdatamanagementtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdatamanagementtab);
		// clkdatamanagementtab.click();
	}

	// Data Management Sub task
	// Excel Import
	@FindBy(xpath = "//span[contains(text(),'Excel import')]")
	WebElement clkExcelImporttab;

	public void clkExcelImporttab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkExcelImporttab);
		// clkExcelImporttab.click();
	}

	// Organization Setup
	@FindBy(xpath = "//span[contains(text(),'Organization setup')]")
	WebElement clkOrganizationsetuptab;

	public void clkOrganizationsetuptab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkOrganizationsetuptab);
		// clkOrganizationsetuptab.click();
	}

	// Organization Setup SubTabs
	// Organization tab
	@FindBy(xpath = "//span[text()='Organization']")
	WebElement clkOrganizationtab;

	public void clkOrganizationtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkOrganizationtab);
		// clkOrganizationsetuptab.click();
	}

	// Companies tab
	@FindBy(xpath = "//span[text()='Companies']")
	WebElement clkCompaniestab;

	public void clkCompaniestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCompaniestab);
		// clkCompaniestab.click();
	}

	// Operating Units tab
	@FindBy(xpath = "//span[text()='Operating units']")
	WebElement clkOperatingunitstab;

	public void clkOperatingunitstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkOperatingunitstab);
		// clkOperatingunitstab.click();
	}

	// Project management
	@FindBy(xpath = "//span[contains(text(),'Project management')]")
	WebElement clkprojectmanagementtab;

	public void clickprojectmanagementtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprojectmanagementtab);
		// clkprojectmanagementtab.click();
	}

	// Project Management sub tabs
	// Projects
	@FindBy(xpath = "(//span[text()='Projects'])[1]")
	WebElement clkprojectstab;

	public void clkprojectstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprojectstab);
		// clkprojectstab.click();
	}

	// Projects sub task
	@FindBy(xpath = "(//span[text()='Projects'])[2]")
	WebElement clkprojectssubtab;

	public void clkprojectssubtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprojectssubtab);
		// clkprojectssubtab.click();
	}

	// SetUp
	@FindBy(xpath = "(//span[text()='Setup'])[1]")
	WebElement clkSetuptab;

	public void clkSetuptab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSetuptab);
		// clkSetuptab.click();
	}

	// Task codes
	@FindBy(xpath = "//span[text()='Task codes']")
	WebElement clkTaskCodestab;

	public void clkTaskCodestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSetuptab);
		// clkSetuptab.click();
	}

	// Expense Categories
	@FindBy(xpath = "//span[text()='Expense categories']")
	WebElement clkExpenseCategoriestab;

	public void clkExpenseCategoriestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkExpenseCategoriestab);
		// clkExpenseCategoriestab.click();
	}

	// Equipment
	@FindBy(xpath = "//span[text()='Equipment']")
	WebElement clkEquipmenttab;

	public void clkEquipmenttab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEquipmenttab);
		// clkEquipmenttab.click();
	}

	// HR management
	@FindBy(xpath = "//span[contains(text(),'HR management')]")
	WebElement clkhrmanagementtab;

	public void clickhrmanagementtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkhrmanagementtab);
		// clkhrmanagementtab.click();
	}

	// HR management Sub task
	// Employees
	@FindBy(xpath = "//span[contains(text(),'Employees')]")
	WebElement clkEmployeestab;

	public void clkEmployeestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEmployeestab);
		// clkEmployeestab.click();
	}

	// Employees
	@FindBy(xpath = "//span[text()='All workers']")
	WebElement clkAllWorkerstab;

	public void clkAllWorkerstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAllWorkerstab);
		// clkAllWorkerstab.click();
	}

	// Setup HR Management
	@FindBy(xpath = "(//span[text()='Setup'])[2]")
	WebElement clkSetupHRmgmttab;

	public void clkSetupHRmgmttab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSetupHRmgmttab);
		// clkSetupHRmgmttab.click();
	}

	// Job
	@FindBy(xpath = "//span[text()='Job']")
	WebElement clkJobtab;

	public void clkJobtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkJobtab);
		// clkJobtab.click();
	}

	// Crafts
	@FindBy(xpath = "//span[text()='Crafts']")
	WebElement clkCraftstab;

	public void clkCraftstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCraftstab);
		// clkCraftstab.click();
	}

	// Special Pay
	@FindBy(xpath = "//span[text()='Special pay']")
	WebElement clkSpecialtab;

	public void clkSpecialtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSpecialtab);
		// clkSpecialtab.click();
	}

	// Time management
	@FindBy(xpath = "//span[contains(text(),'Time management')]")
	WebElement clktimemanagementtab;

	public void clicktimemanagementtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimemanagementtab);
		// clktimemanagementtab.click();
	}

	// TimeSheets Sub tab
	// Time sheets
	@FindBy(xpath = "//span[contains(text(),'Timesheets')]")
	WebElement clktimesheetstab;

	public void clicktimesheetstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheetstab);
		// clktimesheetstab.click();
	}

	// All Time sheets
	@FindBy(xpath = "//span[contains(text(),'All timesheets')]")
	WebElement clkAlltimesheetstab;

	public void clickkAlltimesheetstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAlltimesheetstab);
		// clkAlltimesheetstab.click();
	}

	// All Time sheets page elements
	@FindBy(xpath = "//span[text()='New timesheet']")
	WebElement clkNewtimesheetsbtn;

	public void clickNewtimesheetsbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNewtimesheetsbtn);
		// clkNewtimesheetsbtn.click();
	}

	// Timesheet date
	@FindBy(xpath = "//input[@formcontrolname='timesheetDate']")
	WebElement clkDatefield;

	public void clickDateField() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		if (clkDatefield.isEnabled()) {
			System.out.println("Date field is enabled");
			js.executeScript("arguments[0].click()", clkDatefield);
		} else {
			System.out.println("Date field is disabled");
		}
		// clkDatefield.click();
	}

	// My Time sheets
	@FindBy(xpath = "//span[contains(text(),'My timesheets')]")
	WebElement clkMytimesheetstab;

	public void clkMytimesheetstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkMytimesheetstab);
		// clkMytimesheetstab.click();
	}

	// My Crew Time sheets
	@FindBy(xpath = "//span[contains(text(),'My crew timesheets')]")
	WebElement clkCrewtimesheetstab;

	public void clkCrewtimesheetstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCrewtimesheetstab);
		// clkCrewtimesheetstab.click();
	}

	// Crews
	@FindBy(xpath = "//span[contains(text(),'Crews')]")
	WebElement clkCrewstab;

	public void clkCrewstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCrewstab);
		// clkCrewstab.click();
	}

	// AllCrews
	@FindBy(xpath = "//span[contains(text(),'All crews')]")
	WebElement clkAllCrewstab;

	public void clkAllCrewstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAllCrewstab);
		// clkAllCrewstab.click();
	}

	// MyCrews
	@FindBy(xpath = "//span[contains(text(),'My crews')]")
	WebElement clkMyCrewstab;

	public void clkMyCrewstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkMyCrewstab);
		// clkMyCrewstab.click();
	}

	// Time Management Setup
	@FindBy(xpath = "//span[contains(text(),'Setup')]")
	WebElement clkSetupTimeManagementtab;

	public void clkSetupTimeManagementtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSetupTimeManagementtab);
		// clkSetupTimeManagementtab.click();
	}

	// Shift Setup
	@FindBy(xpath = "//span[contains(text(),'Shift')]")
	WebElement clkShiftSetuptab;

	public void clkShiftSetuptab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkShiftSetuptab);
		// clkSetupTimeManagementtab.click();
	}

	// Report Setup
	@FindBy(xpath = "//span[contains(text(),'Reports')]")
	WebElement clkReportstab;

	public void clkReportstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkReportstab);
		// clkReportstab.click();
	}

	// Export Timesheet
	@FindBy(xpath = "//span[contains(text(),'Export timesheets')]")
	WebElement clkExportTimesheettab;

	public void clkExportTimesheettab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkExportTimesheettab);
		// clkExportTimesheettab.click();
	}

	// Hari 5/28/2021

	// TimeSheets Sub tab
	// Crew Template Timesheet
	@FindBy(xpath = "//span[contains(text(),'Crew template timesheets')]")
	WebElement clkcrewtemplateTimesheetstab;

	public void clickcrewtemplateTimesheetstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkcrewtemplateTimesheetstab);
		// clktimesheetstab.click();
	}

	// HARI 6/21/2021
	// Crews
	@FindBy(xpath = "//span[contains(text(),'Crews')]")
	WebElement clkcrewstab;

	public void clickCrewstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkcrewstab);

	}

	// Crews
	@FindBy(xpath = "//span[contains(text(),'All crews')]")
	WebElement clkAllcrewstab;

	public void clickAllcrewstab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAllcrewstab);

	}

}

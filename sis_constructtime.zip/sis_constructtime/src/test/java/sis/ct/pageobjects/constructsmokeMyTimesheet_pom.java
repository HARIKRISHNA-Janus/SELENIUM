package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import sis.aps.utilities.commonutil;

public class constructsmokeMyTimesheet_pom {

	public WebDriver ldriver;

	public constructsmokeMyTimesheet_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// Dashboard
	@FindBy(xpath = "//span[contains(text(),'Dashboard')]")
	WebElement clkdashboardtab;

	public void clickdashboardtab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdashboardtab);
		// clkdashboardtab.click();
	}

	// Date field- Defaulted to current date in MM/DD/YYY format with Calendar icon
	// and editable.
	@FindBy(xpath = "//input[@formcontrolname='timesheetDate']")
	WebElement chkdateValue;
	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement chkopencalendar;

	public void checkdatevalue() {
		String datevalue = chkdateValue.getAttribute("value");
		System.out.println("App date value is: " + datevalue);
		String timestamp = new SimpleDateFormat("M/d/YYYY").format(new Date());
		System.out.println("System timestamp is: " + timestamp);
		if (datevalue.equals(timestamp)) {
			Assert.assertTrue(true);
		} else {
			System.out.println("Date field doesn't equal to timestamp");
			Assert.fail();
		}
		boolean dateeditable = chkdateValue.isEnabled();
		chkopencalendar.isDisplayed();
		chkopencalendar.isEnabled();

	}

	// Worker field- Worker name should be displayed and non editable
	@FindBy(xpath = "//input[@formcontrolname='worker']")
	WebElement chkworkerfield;

	public void checkWorkerField() {
		String workername = chkworkerfield.getAttribute("value");
		System.out.println("App worker name displayed is: " + workername);
		boolean workernamereadonly = chkworkerfield.getAttribute("readonly").contains("true");
	}

	// Description - Default date followed by "Timesheet for Worker name" should be
	// displayed and non editable
	@FindBy(xpath = "//input[@data-placeholder='Description']")
	WebElement chkDescriptionfield;

	public void checkDescriptionField() {
		String descriptionreadonly = chkDescriptionfield.getAttribute("readonly");
		Assert.assertNull(descriptionreadonly);
		String descriptionvaluetext = chkDescriptionfield.getAttribute("value");
		System.out.println(descriptionvaluetext);
		String timestamp1 = new SimpleDateFormat("MM/dd/YYYY").format(new Date());
		// System.out.println(timestamp1);
		String workername = chkworkerfield.getAttribute("value");
		String descriptionvalue = timestamp1.concat(" Timesheet for " + workername);
		System.out.println(descriptionvalue);
		if (descriptionvaluetext.equals(descriptionvalue)) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}
	}

	// Project ID field should be dropdown field with the list of Projects available
	@FindBy(xpath = "//input[@formcontrolname='project']")
	WebElement clkProjectIDList;
	// @FindBy(xpath = "//div[@role='listbox']//following::mat-option")
	@FindBy(xpath = "//div[@role='listbox']")
	WebElement chkProjectIDList;
	@FindBy(xpath = "//input[@data-placeholder='Project']")
	WebElement entProjectID;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement clkProjectName;
	@FindBy(xpath = "//input[@data-placeholder='Project name']")
	WebElement entProjectName;

	// update by Hari 6/3/2021
	public void checkProjectID(String projectId) throws InterruptedException {
		clkProjectIDList.click();
		boolean projectidlist = chkProjectIDList.isDisplayed();
		System.out.println(projectidlist);
		// Project Name is displayed by default and the field is non editable
		entProjectID.sendKeys(projectId);
		Thread.sleep(2000);
		clkProjectName.click();
		String projectname = entProjectName.getAttribute("readonly");
		Assert.assertNull(projectname);
	}

	// Status field
	@FindBy(xpath = "//input[@formcontrolname='status']")
	WebElement clkStatusfield;

	public void clickStatusField() {
		boolean checkStatusIsEnabled = clkStatusfield.isEnabled();
		if (checkStatusIsEnabled == false) {
			String statustxt = clkStatusfield.getAttribute("value");
			if (statustxt.equals("Draft")) {
				System.out.println("Draft is displayed");
			} else {
				System.out.println("Draft is not displayed");
			}
		} else {
			System.out.println("Status field is enabled");
		}
	}

	// Notes Field
	@FindBy(xpath = "//textarea[@formcontrolname='notes']")
	WebElement clkNotestab;

	public void clickkNotestab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNotestab);
		clkNotestab.sendKeys(
				"The purpose of this document is to provide detailed specifications and layout for the standard Certified Payroll Report (CPR) to be included in the SIS Advanced Labor application");
		// clkMytimesheetstab.click();
	}

	// Save Button
	@FindBy(xpath = "//span[contains(text(),'Save')]")
	WebElement clkSaveBtn;

	public void clickSaveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSaveBtn);
		// clkMytimesheetstab.click();
	}

	// Savetabs Button
	@FindBy(xpath = "//span[@class='mat-button-wrapper' and contains(text(),'Save')]")
	WebElement clkSaveBtn1;

	public void clickSaveBtn1() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSaveBtn1);
		// clkMytimesheetstab.click();
	}

	// Cancel Inline tab
	@FindBy(xpath = "(//span[contains(text(),'Cancel')])[2]")
	WebElement clkCancelHoursInlineBtn;

	public void clickCancelHoursInlineBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCancelHoursInlineBtn);
		// clkCancelHoursInlineBtn.click();
	}

	// HOURS TAB
	// Add Button
	@FindBy(xpath = "//span[text()='Add']")
	WebElement clkAddBtn;

	public void clickAddButton() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAddBtn);
		// clkAddBtn.click();
	}

	// Task Code
	// @FindBy(xpath="//span[@class='mat-select-placeholder ng-tns-c33-44
	// ng-star-inserted']") WebElement clkTaskCodeHoursTab;
	@FindBy(xpath = "//input[@formcontrolname='taskCode']")
	WebElement clkTaskCodeHoursTab;
	@FindBy(xpath = "//input[@formcontrolname='taskCode']")
	WebElement etrTaskCodeHoursTab;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement sltTaskCodeHoursTab;

	public void clickTaskCodeHoursTab(String taskcode) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTaskCodeHoursTab);
		Thread.sleep(1000);
		etrTaskCodeHoursTab.sendKeys(taskcode);
		Thread.sleep(1000);
		sltTaskCodeHoursTab.click();
		// clkTaskCode.click();
	}

	// Task Code Production tab
	@FindBy(xpath = "(//span[text()='Task code'])[2]")
	WebElement clkTaskCodeProductionTab;
	@FindBy(xpath = "(//span[@class='mat-option-text'])[1]")
	WebElement sltTaskCodeProductionTab;

	public void clickTaskCodeProductionTab() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTaskCodeProductionTab);
		// clkTaskCodeProductionTab.click();
		Thread.sleep(2000);
		js.executeScript("arguments[0].click()", sltTaskCodeProductionTab);
		// clkTaskCode.click();
	}

	// Regular Hours
	@FindBy(xpath = "//input[@formcontrolname='regularHours']")
	WebElement entRegularHoursTab;
	@FindBy(xpath = "//input[@formcontrolname='overTimeHours']")
	WebElement entOT1HoursTab;
	@FindBy(xpath = "//input[@formcontrolname='doubleTimeHours']")
	WebElement entOT2HoursTab;

	public void enterRegularHoursTab(String regularhours, String OT1, String OT2) throws InterruptedException {
		// JavascriptExecutor js = (JavascriptExecutor) ldriver;
		// js.executeScript("arguments[0].click()", entRegularHoursTab);
		// entRegularHoursTab.sendKeys("2");
		// entOT1HoursTab.sendKeys("2");
		// entOT2HoursTab.sendKeys("2");
		entRegularHoursTab.sendKeys(regularhours);
		Thread.sleep(100);
		entOT1HoursTab.sendKeys(OT1);
		Thread.sleep(100);
		entOT2HoursTab.sendKeys(OT2);
		Thread.sleep(100);
	}

	// Hours save button
	@FindBy(xpath = "//span[text()=' Save ']")
	WebElement clkHoursSaveBtn;

	public void clickHoursSaveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkHoursSaveBtn);
	}

	// FieldExpenses tab
	// Field expenses header
	@FindBy(xpath = "//div[contains(text(),'Field expenses')]")
	WebElement clkFieldExpensesTab;

	public void clickFieldExpensesTab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkFieldExpensesTab);
	}

	// Expense Category
	@FindBy(xpath = "//input[@formcontrolname='expenseCategory']")
	WebElement clkExpenseCategory;
	@FindBy(xpath = "//input[@formcontrolname='expenseCategory']")
	WebElement etrExpenseCategory;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement sltExpenseCategory;

	public void clickExpenseCategory(String expensecategory) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkExpenseCategory);
		Thread.sleep(1000);
		etrExpenseCategory.sendKeys(expensecategory);
		Thread.sleep(1000);
		sltExpenseCategory.click();
	}

	// Quantity
	@FindBy(xpath = "//input[@formcontrolname='qty']")
	WebElement entQuantity;

	public void enterQuantity(String quantity) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", entQuantity);
		Thread.sleep(1000);
		entQuantity.sendKeys(quantity);
	}

	// Equipment Tab
	@FindBy(xpath = "//div[contains(text(),'Equipment')]")
	WebElement clkEquipmentTab;

	public void clickEquipmentTab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEquipmentTab);
	}

	// Equipment ID
	@FindBy(xpath = "//input[@formcontrolname='equipmentId']")
	WebElement clkEquipmentID;
	@FindBy(xpath = "//input[@formcontrolname='equipmentId']")
	WebElement etrEquipmentID;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement entEquipmentID;

	public void clickEquipmentID(String equipmentid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEquipmentID);
		Thread.sleep(1000);
		etrEquipmentID.sendKeys(equipmentid);
		Thread.sleep(1000);
		entEquipmentID.click();
	}

	// Production Tab
	@FindBy(xpath = "//div[contains(text(),'Production')]")
	WebElement clkProductionTab;

	public void clickProductionTab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkProductionTab);
	}

	// Quantity Production tab
	@FindBy(xpath = "//input[@formcontrolname='completedQty']")
	WebElement clkQuantityProductionTab;

	public void clickQuantityProductionTab(String prodquantity) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkQuantityProductionTab);
		Thread.sleep(1000);
		clkQuantityProductionTab.sendKeys(prodquantity);
	}

	// MY CREW TIMESHEET
	// New Crew Timesheet button
	@FindBy(xpath = "//span[text()='New crew timesheet']")
	WebElement clkNewCrewtimesheetsbtn;

	public void clickNewCrewtimesheetsbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNewCrewtimesheetsbtn);
		// clkNewCrewtimesheetsbtn.click();
	}

	// Header Tab Crew dropdown
	@FindBy(xpath = "//input[@formcontrolname='crew']")
	WebElement clkCrewdropdown;
	@FindBy(xpath = "//input[@formcontrolname='crew']")
	WebElement etrCrewdropdowntext;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement sltCrewdropdown;

	public void clickCrewdropdown(String crew) throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		// js.executeScript("arguments[0].click()", clkCrewdropdown);
		etrCrewdropdowntext.sendKeys(crew);
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", sltCrewdropdown);
		// clkNewCrewtimesheetsbtn.click();
	}

	// Crew Description
	@FindBy(xpath = "//input[@placeholder='Description']")
	WebElement chkCrewDescriptionfield;

	public void checkCrewDescriptionField() {
		String descriptionreadonly = chkDescriptionfield.getAttribute("readonly");
		Assert.assertNull(descriptionreadonly);
		String descriptionvaluetext = chkDescriptionfield.getAttribute("value");
		System.out.println(descriptionvaluetext);
		String timestamp1 = new SimpleDateFormat("MM/dd/YYYY").format(new Date());
		System.out.println(timestamp1);
	}

	// Submit Button
	@FindBy(xpath = "//span[normalize-space()='Submit']")
	WebElement clkSubmitBtn;

	public void clickSubmitBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkSubmitBtn);
	}

	// First Grid selection
	@FindBy(xpath = "(//mat-row[@role='row'][1]//input[1]")
	WebElement clkFirstGrid;

	public void clickFirstGrid() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkFirstGrid);
	}

	// Approve Button
	@FindBy(xpath = "//a[normalize-space()='Approve']")
	WebElement clkApproveBtn;

	public void clickApproveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkApproveBtn);
	}

	// reject Button
	@FindBy(xpath = "//a[normalize-space()='Reject']")
	WebElement clkRejectBtn;

	public void clickRejectBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkRejectBtn);
	}

	// Inline Approve Button
	@FindBy(xpath = "//span[text()='Approve']")
	WebElement clkInlineApproveBtn;

	public void clickInlineApproveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkInlineApproveBtn);
	}

	// Inline Reject Button
	@FindBy(xpath = "//span[text()='Reject']")
	WebElement clkInlineRejectBtn;

	public void clickInlineRejectBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkInlineRejectBtn);
	}

	// Hari 6/1/2021

	// Project ID field should be dropdown field with the list of Projects available

	@FindBy(xpath = "//input[@data-placeholder='Project id']")
	WebElement entProjectID1;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement clkProjectName1;
	@FindBy(xpath = "//input[@data-placeholder='Project name']")
	WebElement entProjectName1;

	public void setProjectID() throws InterruptedException {

		entProjectID1.click();
		Thread.sleep(1000);
		entProjectID1.sendKeys("AA_");
		Thread.sleep(2000);
		clkProjectName1.click();
		String projectname = entProjectName1.getAttribute("readonly");
		Assert.assertNull(projectname);
	}

	// Hari 6/3/2021

	public void checkProjectID_Crew(String crewprojectId) throws InterruptedException {
		clkProjectIDList.click();
		boolean projectidlist = chkProjectIDList.isDisplayed();
		System.out.println(projectidlist);
		// Project Name is displayed by default and the field is non editable
		entProjectID.sendKeys(crewprojectId);
		Thread.sleep(2000);
		clkProjectName.click();
		String projectname = entProjectName.getAttribute("readonly");
		Assert.assertNull(projectname);
	}

	// Added by Ram on 17th June 2021 - Start

	@FindBy(xpath = "//span[normalize-space()='Project id']")
	WebElement clkProjectId_search;

	public boolean checkProjectId_search_displayed() {

		return clkProjectId_search.isDisplayed();
	}

	@FindBy(xpath = "//span[normalize-space()='All']")
	WebElement clkStatus_search;

	public boolean checkStatus_search_displayed() {

		return clkStatus_search.isDisplayed();
	}

	@FindBy(xpath = "//div[normalize-space()='Header']")
	WebElement clkNewTimesheet_Header_tab;

	public boolean checkHeader_tab_displayed() {

		return clkNewTimesheet_Header_tab.isDisplayed();
	}

	@FindBy(xpath = "//div[normalize-space()='Hours (0)']")
	WebElement clkNewTimesheet_Hours_tab;

	public boolean checkHours_tab_displayed() {

		return clkNewTimesheet_Hours_tab.isDisplayed();
	}

	@FindBy(xpath = "//div[normalize-space()='Field expenses (0)']")
	WebElement clkNewTimesheet_FieldExpenses_tab;

	public boolean checkFieldExpenses_tab_displayed() {

		return clkNewTimesheet_FieldExpenses_tab.isDisplayed();
	}

	@FindBy(xpath = "//div[normalize-space()='Equipment (0)']")
	WebElement clkNewTimesheet_Equipment_tab;

	public boolean checkEquipment_tab_displayed() {

		return clkNewTimesheet_Equipment_tab.isDisplayed();
	}

	@FindBy(xpath = "//div[normalize-space()='Production (0)']")
	WebElement clkNewTimesheet_Production_tab;

	public boolean checkProduction_tab_displayed() {

		return clkNewTimesheet_Production_tab.isDisplayed();
	}

	public boolean checkSave_button_displayed() {

		return clkSaveBtn.isDisplayed();
	}

	@FindBy(xpath = "//span[contains(text(),'Back')]")
	WebElement clkNewTimesheet_Back_button;

	public boolean checkBack_button_displayed() {

		return clkNewTimesheet_Back_button.isDisplayed();
	}

	public boolean check_Date_Field_displayed() {

		return chkdateValue.isDisplayed();
	}

	public boolean check_Worker_Field_displayed() {

		return chkworkerfield.isDisplayed();
	}

	public boolean check_Description_Field_displayed() {

		return chkDescriptionfield.isDisplayed();
	}

	public boolean check_Project_Field_displayed() {

		return clkProjectIDList.isDisplayed();
	}

	public boolean check_ProjectName_Field_displayed() {

		return entProjectName.isDisplayed();
	}

	public boolean check_Status_Field_displayed() {

		return clkStatusfield.isDisplayed();
	}

	public String checkStatusFieldValue() {

		return clkStatusfield.getAttribute("value");
	}

	public boolean check_Notes_Field_displayed() {

		return clkNotestab.isDisplayed();
	}

	public boolean checkWorkerField_isDisabled() {
		return chkworkerfield.getAttribute("readonly").contains("true");
	}

	public boolean checkDescriptionField_isDisabled() {
		try {
			chkDescriptionfield.sendKeys("Modify");
			return false;
		} catch (ElementNotInteractableException e) {
			return true;
		}
	}

	public String checkDescriptionFieldValue() {
		return chkDescriptionfield.getAttribute("value");
	}

	public boolean checkStatusField_isDisabled() {
		return clkStatusfield.getAttribute("readonly").contains("true");
	}

	public String checkWorkerFieldValue() {

		return chkworkerfield.getAttribute("value");
	}

	@FindBy(xpath = "//div[@ngbtooltip='User profile']")
	WebElement clkUserProfileIcon;

	public void clickUserProfileIcon() {
		clkUserProfileIcon.click();
	}

	@FindBy(xpath = "//div[@id='kt_quick_user']/descendant::a[@href='#'][2]")
	WebElement LoginUserName;

	public String checkLoginUserNameFromProfile() {
		return LoginUserName.getText();
	}

	public String checkDateValue() {

		return chkdateValue.getAttribute("value");
	}

	public void clkProject_Timesheet() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkProjectIDList);
	}

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> clkProject;

	public void setProject(String ProjectId, String ProjectName) {

		commonutil.selectDropDownValueBasedOnVisibleText(clkProject, ProjectId, ProjectId);
	}
	// Updated WebElement Name and removed second parameter of the method - by Ram
	// on 18th June 2021

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> getdropdownvalues;

	public void selectDropDownValue(String Code) {

		for (WebElement w : getdropdownvalues) {

			if (w.getAttribute("innerHTML").contains(Code)) {

				w.click();

				break;
			} else {

				System.out.println("Expected value not found in dropdown");
			}
		}
	}

	// Suresh 18th June : Mytimesheet search in project id text field
	@FindBy(xpath = "//app-timesheet-list//input[@formcontrolname='searchInput']")
	WebElement clksearchinprojid;
	@FindBy(xpath = "//app-timesheet-list//input[@formcontrolname='searchInput']")
	WebElement etrsearchinprojid;

	public void clicksearchinprojid(String projectid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clksearchinprojid);
		// clksearchinprojid.click();
		Thread.sleep(1000);
		etrsearchinprojid.sendKeys(projectid);
	}

	// Suresh 21st June : Added with Shift elements
	@FindBy(xpath = "//input[@formcontrolname='shiftId']")
	WebElement clkshiftid;
	@FindBy(xpath = "//input[@formcontrolname='shiftId']")
	WebElement etrshiftid;
	@FindBy(xpath = "//span[@class='mat-option-text']")
	WebElement sltshiftid;

	public void clickshiftid(String shiftid) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkshiftid);
		// clkshiftid.click();
		Thread.sleep(1000);
		etrshiftid.sendKeys(shiftid);
		Thread.sleep(1000);
		js.executeScript("arguments[0].click()", sltshiftid);
	}

	// HARI - 6/24/21
	@FindBy(xpath = "//button//span[text()='Workflow']")
	WebElement clkgroupWorkflowbtn;

	public void clkGroupWorkflowbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkgroupWorkflowbtn);
	}

	// Submit Button
	@FindBy(xpath = "//div[contains(@class,'dropdown-menu')]//a[normalize-space()='Submit']")
	WebElement clkGroupworkflowSubmitBtn;

	public void clickGroupworkflowSubmitBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkGroupworkflowSubmitBtn);
	}

	// Submit Confirm box
	@FindBy(xpath = "//h3[text()='Submit timesheet']")
	WebElement tmsubmitconfirmbox;

	public boolean chk_TimesheetSubmitconformbox_displayed() {

		return tmsubmitconfirmbox.isDisplayed();
	}

	// confirm box Submit Button
	@FindBy(xpath = "//button//span[text()='Submit']")
	WebElement clkConfirmboxSubmitBtn;

	public void clickConfirmboxSubmitbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkConfirmboxSubmitBtn);
	}

	// Approve Button
	@FindBy(xpath = "//div[contains(@class,'dropdown-menu')]//a[normalize-space()='Approve']")
	WebElement clkGroupworkflowApproveBtn;

	public void clickGroupworkflowApproveBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkGroupworkflowApproveBtn);
	}

	// Approve Confirm box
	@FindBy(xpath = "//h3[text()='Approve timesheet']")
	WebElement tmApproveconfirmbox;

	public boolean chk_TimesheetApproveconformbox_displayed() {

		return tmApproveconfirmbox.isDisplayed();
	}

	// confirm box Approve Button
	@FindBy(xpath = "//button//span[text()='Approve']")
	WebElement clkConfirmboxApproveBtn;

	public void clickConfirmboxApprovebtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkConfirmboxApproveBtn);
	}

	// Reject Button
	@FindBy(xpath = "//div[contains(@class,'dropdown-menu')]//a[normalize-space()='Reject']")
	WebElement clkGroupworkflowRejectBtn;

	public void clickGroupworkflowRejectBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkGroupworkflowRejectBtn);
	}

	// Reject Confirm box
	@FindBy(xpath = "//h3[text()='Reject timesheet']")
	WebElement tmRejectconfirmbox;

	public boolean chk_TimesheetRejectconformbox_displayed() {

		return tmRejectconfirmbox.isDisplayed();
	}

	// confirm box Reject Button
	@FindBy(xpath = "//button//span[text()='Reject']")
	WebElement clkConfirmboxRejectBtn;

	public void clickConfirmboxRejectbtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkConfirmboxRejectBtn);
	}

	// My crew timesheets Header
	@FindBy(xpath = "//kt-portlet-header//span[text()='My crew timesheets']")
	WebElement myCrewtimesheetsHeader;

	public boolean chk_Mycrewtimesheets_Headerdisplayed() {

		return myCrewtimesheetsHeader.isDisplayed();
	}

	// My crew Timesheets - Search Input field
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement clk_search;
	@FindBy(xpath = "//input[@name='searchInput']")
	WebElement etr_search;

	public void searchCrew(String crewId) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_search);
		Thread.sleep(1000);
		clk_search.clear();
		etr_search.sendKeys(crewId);
	}

	// My crew Timesheet - select search by crew id option
	@FindBy(xpath = "//mat-select[@placeholder='Search field']")
	WebElement clk_searchbydropdown;
	@FindBy(xpath = "//span[normalize-space()='Crew id']")
	WebElement clk_crewId;

	public void selectcrewIdoption() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_searchbydropdown);
		Thread.sleep(1000);
		JavascriptExecutor j = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_crewId);
	}

	// My crew Timesheet - select search by status option - Submitted
	@FindBy(xpath = "//mat-select[@placeholder='Status']")
	WebElement clk_statusdropdown;
	@FindBy(xpath = "//mat-option//span[normalize-space()='Submitted']")
	WebElement clk_Submitted_opt;

	public void selectSubmittedStatusoption() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_statusdropdown);
		Thread.sleep(1000);
		JavascriptExecutor j = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Submitted_opt);

	}

	// My crew Timesheet - select search by status option - Draft
	@FindBy(xpath = "//mat-option//span[normalize-space()='Draft']")
	WebElement clk_Draft_opt;

	public void selectDraftStatusoption() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_statusdropdown);
		Thread.sleep(1000);
		JavascriptExecutor j = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Draft_opt);
	}

	// My crew Timesheet - select search by status option - Approved
	@FindBy(xpath = "//mat-option//span[normalize-space()='Approved']")
	WebElement clk_Approved_opt;

	public void selectApprovedStatusoption() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_statusdropdown);
		Thread.sleep(1000);
		JavascriptExecutor j = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Approved_opt);
	}

	// My crew Timesheet - select search by status option - Rejected
	@FindBy(xpath = "//mat-option//span[normalize-space()='Rejected']")
	WebElement clk_Rejected_opt;

	public void selectRejectedStatusoption() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_statusdropdown);
		Thread.sleep(1000);
		JavascriptExecutor j = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clk_Rejected_opt);
	}

}
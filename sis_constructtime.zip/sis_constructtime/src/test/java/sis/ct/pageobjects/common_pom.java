package sis.ct.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class common_pom {

	public WebDriver ldriver;

	public common_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// Status dropdown click event
	@FindBy(xpath = "//mat-select[@placeholder='Status']")
	WebElement clkstatusdropdown;

	public void clickstatusdropdown() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkstatusdropdown);
		// clkstatusdropdown.click();
	}

	// first checkbox select
	@FindBy(xpath = "//mat-row[@role='row'][1]//mat-checkbox[contains(@id,'checkbox')]")
	WebElement clkfirstcheckbox;

	public void clickfirstcheckbox() {
		// JavascriptExecutor js = (JavascriptExecutor) ldriver;
		// js.executeScript("arguments[0].click()", clkfirstcheckbox);
		clkfirstcheckbox.click();
	}

	// click workflow on top page
	@FindBy(xpath = "//span[normalize-space()='Workflow']")
	WebElement clkworkflow;

	public void clickworkflow() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkflow);
		// clkworkflow.click();
	}

	@FindBy(xpath = "//input[@formcontrolname='searchInput']")
	WebElement clkSearchField;

	public String getProjectNameBasedOnProjectID(String ProjectID) throws InterruptedException {

		Thread.sleep(3000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(ldriver);

		leftmenuObj.clickprojectmanagementtab();

		Thread.sleep(3000);

		leftmenuObj.clkprojectstab();

		Thread.sleep(2000);

		leftmenuObj.clkprojectssubtab();

		Thread.sleep(2000);

		clkSearchField.sendKeys(ProjectID);

		clkSearchField.sendKeys(" ");

		Thread.sleep(5000);

		String ProjectName = ldriver.findElement(By.xpath(
				"//mat-row//mat-cell/a[text()='" + ProjectID + "']/parent::mat-cell/following-sibling::mat-cell/a"))
				.getText();

		return ProjectName;

	}

	@FindBy(xpath = "//tr//td[@class='e-rowcell e-ellipsistooltip' and @aria-colindex='0']")
	List<WebElement> checkTaskCodes;

	public List<String> getTaskListBasedOnProject(String ProjectID) throws InterruptedException {

		Thread.sleep(2000);

		leftmenu_pom leftmenuObj = new leftmenu_pom(ldriver);

		leftmenuObj.clickprojectmanagementtab();

		Thread.sleep(2000);

		leftmenuObj.clkprojectstab();

		Thread.sleep(2000);

		leftmenuObj.clkprojectssubtab();

		Thread.sleep(2000);

		clkSearchField.sendKeys(ProjectID);

		clkSearchField.sendKeys(" ");

		Thread.sleep(5000);

		WebElement ProjectIDLink = ldriver.findElement(By.xpath("//mat-row//mat-cell/a[text()='" + ProjectID + "']"));

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", ProjectIDLink);

		Thread.sleep(3000);

		ProjectManagement_projects_Projects projmgmtObj = new ProjectManagement_projects_Projects(ldriver);

		projmgmtObj.ClickprojectTasktab();

		Thread.sleep(3000);

		List<String> TaskIDList = new ArrayList<>();

		for (WebElement taskcode : checkTaskCodes) {

			TaskIDList.add(taskcode.getText());
		}

		return TaskIDList;

	}

	@FindBy(xpath = "//tr[@role='row']")
	WebElement clkDashboardRecord;

	public void clickkDashboardRecord() {

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkDashboardRecord);
	}

	public boolean checkDashboardRecordSelected() throws InterruptedException {

		try {
			clkDashboardRecord.getAttribute("aria-selected").contains("true");

			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void doubleClickkDashboardRecordBasedOnProject(String ProjectID) {

		WebElement clkDashboardRecordBasedOnProject = ldriver
				.findElement(By.xpath("//td[contains(@aria-label,'" + ProjectID + "')]//parent::tr"));

		Actions act = new Actions(ldriver);

		act.moveToElement(clkDashboardRecordBasedOnProject).doubleClick().build().perform();
	}

	public void clickkDashboardRecordBasedOnProject(String ProjectID) {

		WebElement clkDashboardRecordBasedOnProject = ldriver
				.findElement(By.xpath("//td[contains(@aria-label,'" + ProjectID + "')]//parent::tr"));

		clkDashboardRecordBasedOnProject.click();

	}

	@FindBy(xpath = "//input[@name='fieldProjectId']")
	WebElement projectUpdateInline;

	@FindBy(xpath = "//input[@name='fieldTaskCodeId']")
	WebElement taskUpdateInline;

	public void setProjectInline(String ProjectID) {

		projectUpdateInline.clear();

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", projectUpdateInline);

		selectDropDownValue(ProjectID);

	}

	public void setTaskInline(String Task) throws InterruptedException {

		taskUpdateInline.clear();

		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", taskUpdateInline);

		Thread.sleep(2000);

		String TaskDetails[] = Task.split(" ");

		String TaskID = TaskDetails[0];

		selectDropDownValue(TaskID);

	}

	@FindBy(xpath = "//span[@class='mat-option-text']")
	List<WebElement> getdropdownvalues;

	public void selectDropDownValue(String Code) {

		for (WebElement w : getdropdownvalues) {

			if (w.getAttribute("innerHTML").contains(Code)) {

				w.click();

				break;
			} else {

				System.out.println("Expected value not found in dropdown");
			}
		}
	}
}

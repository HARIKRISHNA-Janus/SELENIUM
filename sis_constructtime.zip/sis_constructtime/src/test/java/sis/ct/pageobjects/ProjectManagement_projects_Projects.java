package sis.ct.pageobjects;

import java.text.SimpleDateFormat;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.Date;
import org.testng.Assert;

public class ProjectManagement_projects_Projects {

	public WebDriver ldriver;

	public ProjectManagement_projects_Projects(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	/*
	 * ------------------------------------------------- HARI
	 * -----------------------------------------------------------------------------
	 * ---------
	 */

	// Header All Projects
	@FindBy(xpath = "//kt-project-list//kt-portlet-header//span[text()='All projects']")
	WebElement allprojectHeader;

	public void isallprojectHeaderDisplayed() {

		boolean Header = allprojectHeader.isDisplayed();
		System.out.println(Header);
	}

	// Button New project
	@FindBy(xpath = "//kt-project-list//button//span[text()='New project']")
	WebElement Btnnewproject;

	public void clickBtnnewproject() {
		Btnnewproject.click();
	}

	// Header New project
	@FindBy(xpath = "//kt-project-details//kt-portlet-header//span[text()='New project']")
	WebElement NewprojectHeader;

	public void isNewprojectHeaderDisplayed() {
		boolean Header = NewprojectHeader.isDisplayed();
		System.out.println(Header);
	}

	// input project ID
	@FindBy(xpath = "//app-project-edit//input[@data-placeholder='Project id']")
	WebElement inputprojectid;

	public void setprojectid(String projectid) {
		inputprojectid.sendKeys(projectid);
	}

	// input project Name
	@FindBy(xpath = "//app-project-edit//input[@data-placeholder='Project name']")
	WebElement inputprojectname;

	public void setprojectname(String projectname) {
		inputprojectname.sendKeys(projectname);
	}

	// input project Customer Name
	@FindBy(xpath = "//app-project-edit//input[@data-placeholder='Customer name']")
	WebElement inputprojectcustomername;

	public void setcustomername(String customername) {
		inputprojectcustomername.sendKeys(customername);
	}

	// Button Save
	@FindBy(xpath = "//kt-project-details//button//span[text()='Save']")
	WebElement clksaveBtn;

	public void ClickSaveBtn() {
		clksaveBtn.click();
	}

	// Tab - Project Task > New Project
	@FindBy(xpath = "//kt-project-details//div[contains(text(),'Project task')]")
	WebElement TabProjecttask;

	public void ClickprojectTasktab() {
		TabProjecttask.click();
	}

	// Button Add
	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement clkAddbtn;

	public void clickAddBtn() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAddbtn);
		// clkdashboardtab.click();
	}

	// input Task code > Project Task Tab
	@FindBy(xpath = "//kt-project-details//input[@id='taskCode']")
	WebElement inputtaskCode;

	public void setTaskcode(String taskCode) {
		inputtaskCode.click();
		inputtaskCode.clear();
		inputtaskCode.sendKeys(taskCode);
	}

	// mat-Option
	@FindBy(xpath = "(//mat-option)[1]")
	WebElement clkoption;

	public void clickmatoption() {
		clkoption.click();
	}

	// input Details > Project Task Tab
	@FindBy(xpath = "//kt-project-details//input[@id='description']")
	WebElement inputdetails;

	public void setdetails(String Taskdetails) {
		inputdetails.click();
		inputdetails.clear();
		inputdetails.sendKeys(Taskdetails);
	}

	// Button Save > Project Task Tab
	@FindBy(xpath = "//kt-project-details//button[@aria-label='Save']")
	WebElement BtnSave_ProjectTaskTab;

	public void clickSave_projectTaskTab() {
		BtnSave_ProjectTaskTab.click();
	}

	// Button Edit > Project Task Tab
	@FindBy(xpath = "//kt-project-details//button[@aria-label='Edit']")
	WebElement BtnEdit_ProjectTaskTab;

	public void clickEdit_projectTaskTab() {
		BtnEdit_ProjectTaskTab.click();
	}

	// Button Delete > Project Task Tab
	@FindBy(xpath = "//kt-project-details//button[@aria-label='Delete']")
	WebElement BtnDelete_ProjectTaskTab;

	public void clickDelete_projectTaskTab() {
		BtnDelete_ProjectTaskTab.click();
	}

	// Tab - Project production Budget > New Project
	@FindBy(xpath = "//kt-project-details//div[contains(text(),'Project production budget')]")
	WebElement TabProjectproductionBudget;

	public void ClickprojectProductionBudgettab() {
		TabProjectproductionBudget.click();
	}

	// input Prod unit > Project Production Budget Tab
	@FindBy(xpath = "//kt-project-details//input[@id='prodUnit']")
	WebElement inputprodunit;

	public void setProdUnit(String Unit) {
		inputprodunit.click();
		inputprodunit.clear();
		inputprodunit.sendKeys(Unit);
	}

	// input prior complete Qty > Project Production Budget Tab
	@FindBy(xpath = "//kt-project-details//input[@id='priorCompletedQty']")
	WebElement inputPCQunatity;

	public void setpcQunatity(String pcQunatity) {
		inputPCQunatity.click();
		inputPCQunatity.clear();
		inputPCQunatity.sendKeys(pcQunatity);
	}

	// input field complete Qty > Project Production Budget Tab
	@FindBy(xpath = "//kt-project-details//input[@id='fieldCompletedQty']")
	WebElement inputfcQunatity;

	public void setfcQunatity(String fcQunatity) {
		inputfcQunatity.click();
		inputfcQunatity.clear();
		inputfcQunatity.sendKeys(fcQunatity);
	}

	// input field budget Qty > Project Production Budget Tab
	@FindBy(xpath = "//kt-project-details//input[@id='budgetQty']")
	WebElement inputbudgetQunatity;

	public void setbudgetQunatity(String bdgQunatity) {
		inputbudgetQunatity.click();
		inputbudgetQunatity.clear();
		inputbudgetQunatity.sendKeys(bdgQunatity);
	}

	// Tab - Project address > New Project
	@FindBy(xpath = "//kt-project-details//div[contains(text(),'Project address')]")
	WebElement TabProjectaddress;

	public void Clickprojectaddresstab() {
		TabProjectaddress.click();
	}

	// input field name > Project Address Tab
	@FindBy(xpath = "//input[@id='name']")
	WebElement InputName;

	public void SetName(String Name) {
		InputName.click();
		InputName.clear();
		InputName.sendKeys(Name);
	}

	// input field street > Project Address Tab
	@FindBy(xpath = "//input[@id='street']")
	WebElement InputStreet;

	public void Setstreet(String street) {
		InputStreet.click();
		InputStreet.sendKeys(street);
	}

	// input field city > Project Address Tab
	@FindBy(xpath = "//input[@id='city']")
	WebElement Inputcity;

	public void Setcity(String city) {
		Inputcity.click();
		Inputcity.sendKeys(city);
	}

	// input field zip code > Project Address Tab
	@FindBy(xpath = "//input[@id='zipCode']")
	WebElement InputZipcode;

	public void SetZipCode(String ZipCode) {
		InputZipcode.click();
		InputZipcode.sendKeys(ZipCode);
	}

}

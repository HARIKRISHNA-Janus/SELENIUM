package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_UnionReciprocities_pom {

	public WebDriver ldriver;

	public unions_UnionReciprocities_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Unions'])[1]")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		clkUnionsTab.click();
	}

	@FindBy(xpath = "(//a//span[text()='Union reciprocities'])[1]")
	WebElement UReciprocitiesTab;

	public void clickUnionReciprocitiesTab() {
		UReciprocitiesTab.click();
	}

	@FindBy(xpath = "//button[text()='New union reciprocity']")
	WebElement NewUReciprocityButton;

	public void clickNewUnionReciprocityButton() {
		NewUReciprocityButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Reciprocity id']")
	WebElement txtReciprocityId;

	public void SetReciprocityIdId(String ReciprocityId) {
		txtReciprocityId.sendKeys(ReciprocityId + randomInt);
	}

	public void editReciprocityId() {
		txtReciprocityId.clear();
		txtReciprocityId.sendKeys("AARPI" + randomInt);
	}

	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement btnDatePicker;

	public void clickDatepickerButton() {
		btnDatePicker.click();
	}

	@FindBy(xpath = "//tbody[@class='mat-calendar-body']//div[contains(@class,'today')]")
	WebElement currentDate;

	public void clickCurrentDate() {
		currentDate.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Home union']")
	WebElement inputHomeUnion;

	public void ClickHomeUnion() {
		inputHomeUnion.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Work union']")
	WebElement inputWorkUnion;

	public void clickWorkUnion() {
		inputWorkUnion.click();
	}

	@FindBy(xpath = "//mat-select[@placeholder='Reciprocity source']")
	WebElement dropdownReciprocitySource;

	public void clickReciprocitiesSourceDropdown() {
		dropdownReciprocitySource.click();
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//span[text()='Union reciprocity has been updated']")
	WebElement UReciprocityUpdateMsg;

	public String IsUReciprocityUpdated() {
		return UReciprocityUpdateMsg.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option//span//b[text()='UnionA']")
	WebElement ValUnionA;

	public void ClickUnionAValue() {
		ValUnionA.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][1]")
	WebElement Index1Val;

	public void ClickIndex1Val() {
		Index1Val.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option//span//b[text()='UnionB']")
	WebElement ValUnionB;

	public void ClickUnionBValue() {
		ValUnionB.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][2]")
	WebElement Index2Val;

	public void ClickIndex2Val() {
		Index2Val.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[last()]")
	WebElement OptionLast;

	public void ClickLastOption() {
		OptionLast.click();
	}

	@FindBy(xpath = "//app-union-reciprocity-edit//a[contains(text(),'Union reciprocity fringe')]")
	WebElement U_reciprocityFringeTab;

	public String is_UnionReciprocityFringeTabDisplayed() {
		return U_reciprocityFringeTab.getText();
	}

	@FindBy(xpath = "//button//span[text()='Add']")
	WebElement btnAdd;

	public void clickAddButton() {
		btnAdd.click();
	}

	@FindBy(xpath = "//input[@id='unionFringe___union___code']")
	WebElement inputUFringeUCode;

	public void clickUnionFringeCodeField() {
		inputUFringeUCode.click();
	}

	@FindBy(xpath = "//input[@id='unionFringe___fringe___code']")
	WebElement inputUFringeFCode;

	public void clickUnionFringeFCodeField() {
		inputUFringeFCode.click();
	}

	@FindBy(xpath = "//table//tr//td[@tabindex='0']")
	WebElement tableRow1;

	public boolean isRow1Displayed() {
		return tableRow1.isDisplayed();
	}

	@FindBy(xpath = "//button//span[text()='Update']")
	WebElement btnUpdate;

	public void clickUpdateButton() {
		btnUpdate.click();
	}

	@FindBy(xpath = "//app-union-reciprocity-list//h3[text()='All union reciprocities']")
	WebElement AllUnionReciprocityHd;

	public String isAllUnionReciprocityHeaderDisplayed() {
		return AllUnionReciprocityHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in reciprocity id']")
	WebElement txtsearch;

	public void searchReciprocity() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-union-reciprocity-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

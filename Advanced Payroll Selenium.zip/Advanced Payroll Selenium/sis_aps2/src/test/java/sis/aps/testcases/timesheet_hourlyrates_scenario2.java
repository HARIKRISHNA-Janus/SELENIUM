package sis.aps.testcases;

import java.text.DecimalFormat;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_Shits_pom;
import sis.aps.pageobjects.employees_positions_pom;
import sis.aps.pageobjects.employees_workers_pom;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.pay_earningcodes_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.pageobjects.unions_Unions_pom;
import sis.aps.utilities.XLUtils;

public class timesheet_hourlyrates_scenario2 extends baseclass {
	
	@Test
	public void timesheet_non_union_employee_certified_payroll() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(30000);
		login.setUserName(username);
		//logger.info("User entered the Username");
		login.setPasword(password);
		//logger.info("User entered the Password");
		Thread.sleep(3000);
		login.clkSignin();
		//logger.info("User Clicked on Signin button");
		Thread.sleep(10000);
		logger.info("Logged in Successfull");
		
		//earning code rates
		pay_earningcodes_pom earningcode=new pay_earningcodes_pom(driver);
		//earningcode.payTab();
		earningcode.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		earningcode.clickpayrollsetuptab();
		Thread.sleep(1000);
		//logger.info("Navigated to Payroll Mgmt ADP tab");
		earningcode.earningcodesscreen();
		logger.info("Navigated to Earning codes screen");
		earningcode.searchtxtbox();
		Thread.sleep(1000);
		earningcode.searchregular();
		Thread.sleep(3000);
		earningcode.selectedit();
		Thread.sleep(2000);
		String RegularAmtRate=earningcode.selectamtratevalue();
		//logger.info("Regular Amt Rate is: " +RegularAmtRate);
		double RegularAmtRatevalue=Double.parseDouble(RegularAmtRate);
		System.out.println("Regular Amt Rate is: " +RegularAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		Thread.sleep(1000);
		earningcode.selectclose();
		Thread.sleep(1000);
		earningcode.searchrovertime();
		Thread.sleep(3000);
		earningcode.selectsecondedit();
		Thread.sleep(2000);
		String OvertimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Overtime Amt Rate is: " +OvertimeAmtRate);
		double OvertimeAmtRatevalue=Double.parseDouble(OvertimeAmtRate);
		System.out.println("Overtime Amt Rate is: " +OvertimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		Thread.sleep(1000);
		earningcode.selectclose();
		Thread.sleep(1000);
		earningcode.searchdot();
		Thread.sleep(3000);
		earningcode.selectedit();
		Thread.sleep(2000);
		String DoubletimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Doubleovertime Amt Rate is: " +DoubletimeAmtRate);
		double DoubletimeAmtRatevalue=Double.parseDouble(DoubletimeAmtRate);
		System.out.println("DoubleOvertime Amt Rate is: " +DoubletimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		Thread.sleep(1000);
		earningcode.selectclose();
		Thread.sleep(1000);
		earningcode.searchtripleovertime();
		Thread.sleep(3000);
		earningcode.selectedit();
		Thread.sleep(2000);
		String TripletimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Tripleovertime Amt Rate is: " +TripletimeAmtRate);
		double TripletimeAmtRatevalue=Double.parseDouble(TripletimeAmtRate);
		System.out.println("Triple Overtime Amt Rate is: " +TripletimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		Thread.sleep(1000);
		earningcode.selectclose();
		Thread.sleep(3000);
		earningcode.clickpayrollsetuptab();
		Thread.sleep(1000);
		earningcode.clickpayrollmgmtadptab();
		//Shift rates
		advancepayroll_Shits_pom shiftsrate=new advancepayroll_Shits_pom(driver);
		//shiftsrate.clickAdvancepayrollTab();
		shiftsrate.clickoperationsmgmttab();
		Thread.sleep(1000);
		shiftsrate.clickoperationssetuptab();
		Thread.sleep(1000);
		shiftsrate.clickShiftTab();
		Thread.sleep(2000);
		shiftsrate.clkdroplist();
		Thread.sleep(1000);
		shiftsrate.clkdroplist100();
		Thread.sleep(3000);
		//day rate
		String dayratetxt=shiftsrate.getdayrate();
		int dayratelen=dayratetxt.length();
		String dayratefinalstring=dayratetxt.substring(1,dayratelen);
		double dayratevalue=Double.parseDouble(dayratefinalstring);
		System.out.println("Day rate is: " +dayratevalue);
		//night percentage
		String nightpercenttxt=shiftsrate.getnightpercentage();
		//System.out.println("Night percent txt is: " +nightpercenttxt);
		int nightpercentratelen=(nightpercenttxt.length()-1);
		String nightpercentfinalstring=nightpercenttxt.substring(0,nightpercentratelen);
		double nightpercent=Double.parseDouble(nightpercentfinalstring);
		double nightpercentvalue=nightpercent/100;
		System.out.println("Night percentage is: " +nightpercentvalue);
		//swing rate
		String swingratetxt=shiftsrate.getswingrate();
		int swingratelen=swingratetxt.length();
		String swingratefinalstring=swingratetxt.substring(1,swingratelen);
		double swingratevalue=Double.parseDouble(swingratefinalstring);
		System.out.println("Swing rate is: " +swingratevalue);
		//AT_Shift1 rate
		String atshift1ratetxt=shiftsrate.getautomationshift1();
		int atshift1ratelen=atshift1ratetxt.length();
		String atshift1ratefinalstring=atshift1ratetxt.substring(1,atshift1ratelen);
		double atshift1ratevalue=Double.parseDouble(atshift1ratefinalstring);
		System.out.println("AT_Shift1 rate is: " +atshift1ratevalue);
		//AT_shift2 rate
		String atshift2ratetxt=shiftsrate.getautomationshift2();
		int atshift2ratelen=atshift2ratetxt.length();
		String atshift2ratefinalstring=atshift2ratetxt.substring(1,atshift2ratelen);
		double atshift2ratevalue=Double.parseDouble(atshift2ratefinalstring);
		System.out.println("AT_shift2 rate is: " +atshift2ratevalue);
		//AT_shift4 rate
		String atshift4ratetxt=shiftsrate.getautomationshift4();
		int atshift4ratelen=atshift4ratetxt.length();
		String atshift4ratefinalstring=atshift4ratetxt.substring(1,atshift4ratelen);
		double atshift4ratevalue=Double.parseDouble(atshift4ratefinalstring);
		System.out.println("AT_shift4 rate is: " +atshift4ratevalue);
		//AT_shift3 percentage
		String atshift3percenttxt=shiftsrate.getautomationshift3();
		int atshift3percentratelen=(atshift3percenttxt.length()-1);
		String atshift3percentfinalstring=atshift3percenttxt.substring(0,atshift3percentratelen);
		System.out.println("AT_shift3 len is: " +atshift3percentfinalstring);
		double atshift3percent=Double.parseDouble(atshift3percentfinalstring);
		double atshift3percentvalue=atshift3percent/100;
		System.out.println("AT_shift3 percentage is: " +atshift3percentvalue);
		//AT_shift5 percentage
		String atshift5percenttxt=shiftsrate.getautomationshift5();
		int atshift5percentratelen=(atshift3percenttxt.length()-1);
		String atshift5percentfinalstring=atshift5percenttxt.substring(0,atshift5percentratelen);
		System.out.println("AT_shift3 len is: " +atshift5percentfinalstring);
		double atshift5percent=Double.parseDouble(atshift5percentfinalstring);
		double atshift5percentvalue=atshift5percent/100;
		System.out.println("AT_shift5 percentage is: " +atshift5percentvalue);
		//union rates
		String path="./excel/Scenarios.xlsx";
		String sheetname="scenario2";
		XLUtils.setExcelFile(path, sheetname);
		int xlrowcount=XLUtils.getRowCount(path, sheetname);
		int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
		System.out.println("Excel Row Count: " +xlrowcount);
		System.out.println("Excel Column Count: " +xlcellcount);
		for(int i=1;i<=xlrowcount;i++)
		{

			String workername=XLUtils.getCellData(path, sheetname, i, 0);
			String project=XLUtils.getCellData(path, sheetname, i, 1);
			String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
			String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
			
			String editdate=XLUtils.getCellData(path, sheetname, i, 4);
			String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
			String edittaskcode=XLUtils.getCellData(path, sheetname, i, 6);
			String editjobid=XLUtils.getCellData(path, sheetname, i, 7);
			String editearningcode=XLUtils.getCellData(path, sheetname, i, 8);
			String editshiftid=XLUtils.getCellData(path, sheetname, i, 9);
			String editspecialpayid=XLUtils.getCellData(path, sheetname, i, 10);
			String editregularhours=XLUtils.getCellData(path, sheetname, i, 11);
			String editovertimehours=XLUtils.getCellData(path, sheetname, i, 12);
			String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 13);
			String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 14);

			String editrow2date=XLUtils.getCellData(path, sheetname, i, 15);
			String editrow2projectcode=XLUtils.getCellData(path, sheetname, i, 16);
			String editrow2taskcode=XLUtils.getCellData(path, sheetname, i, 17);
			String editrow2jobid=XLUtils.getCellData(path, sheetname, i, 18);
			String editrow2earningcode=XLUtils.getCellData(path, sheetname, i, 19);
			String editrow2shiftid=XLUtils.getCellData(path, sheetname, i, 20);
			String editrow2specialpayid=XLUtils.getCellData(path, sheetname, i, 21);
			String editrow2regularhours=XLUtils.getCellData(path, sheetname, i, 22);
			String editrow2overtimehours=XLUtils.getCellData(path, sheetname, i, 23);
			String editrow2doubletimehours=XLUtils.getCellData(path, sheetname, i, 24);
			String editrow2tripletimehours=XLUtils.getCellData(path, sheetname, i, 25);
			
			String editrow3date=XLUtils.getCellData(path, sheetname, i, 26);
			String editrow3projectcode=XLUtils.getCellData(path, sheetname, i, 27);
			String editrow3taskcode=XLUtils.getCellData(path, sheetname, i, 28);
			String editrow3jobid=XLUtils.getCellData(path, sheetname, i, 29);
			String editrow3earningcode=XLUtils.getCellData(path, sheetname, i, 30);
			String editrow3shiftid=XLUtils.getCellData(path, sheetname, i, 31);
			String editrow3specialpayid=XLUtils.getCellData(path, sheetname, i, 32);
			String editrow3regularhours=XLUtils.getCellData(path, sheetname, i, 33);
			String editrow3overtimehours=XLUtils.getCellData(path, sheetname, i, 34);
			String editrow3doubletimehours=XLUtils.getCellData(path, sheetname, i, 35);
			String editrow3tripletimehours=XLUtils.getCellData(path, sheetname, i, 36);
			
			String editrow4date=XLUtils.getCellData(path, sheetname, i, 37);
			String editrow4projectcode=XLUtils.getCellData(path, sheetname, i, 38);
			String editrow4taskcode=XLUtils.getCellData(path, sheetname, i, 39);
			String editrow4jobid=XLUtils.getCellData(path, sheetname, i, 40);
			String editrow4earningcode=XLUtils.getCellData(path, sheetname, i, 41);
			String editrow4shiftid=XLUtils.getCellData(path, sheetname, i, 42);
			String editrow4specialpayid=XLUtils.getCellData(path, sheetname, i, 43);
			String editrow4regularhours=XLUtils.getCellData(path, sheetname, i, 44);
			String editrow4overtimehours=XLUtils.getCellData(path, sheetname, i, 45);
			String editrow4doubletimehours=XLUtils.getCellData(path, sheetname, i, 46);
			String editrow4tripletimehours=XLUtils.getCellData(path, sheetname, i, 47);
			
			String editrow5date=XLUtils.getCellData(path, sheetname, i, 48);
			String editrow5projectcode=XLUtils.getCellData(path, sheetname, i, 49);
			String editrow5taskcode=XLUtils.getCellData(path, sheetname, i, 50);
			String editrow5jobid=XLUtils.getCellData(path, sheetname, i, 51);
			String editrow5earningcode=XLUtils.getCellData(path, sheetname, i, 52);
			String editrow5shiftid=XLUtils.getCellData(path, sheetname, i, 53);
			String editrow5specialpayid=XLUtils.getCellData(path, sheetname, i, 54);
			String editrow5regularhours=XLUtils.getCellData(path, sheetname, i, 55);
			String editrow5overtimehours=XLUtils.getCellData(path, sheetname, i, 56);
			String editrow5doubletimehours=XLUtils.getCellData(path, sheetname, i, 57);
			String editrow5tripletimehours=XLUtils.getCellData(path, sheetname, i, 58);
	
		//workers detail
		employees_workers_pom workerdetails=new employees_workers_pom(driver);
		//workerdetails.EmployeesTab();
		workerdetails.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		workerdetails.clickworkerstab();
		Thread.sleep(1000);
		workerdetails.WorkersScreen();
		Thread.sleep(2000);
		workerdetails.clkSearchbtn(workername);
		Thread.sleep(2000);
		workerdetails.clkEditbtn();
		Thread.sleep(2000);
		workerdetails.clkworkercurrentpositiontab();
		Thread.sleep(2000);
		//hourlyrate
		String hourlyrateamttxt=workerdetails.getHorlyrateamt();
		int hourlyrateamtlen=hourlyrateamttxt.length();
		String hourlyrateamtfinalstring=hourlyrateamttxt.substring(1,hourlyrateamtlen);
		double hourlyrateamt=Double.parseDouble(hourlyrateamtfinalstring);
		System.out.println("Hourly Amt Rate is: " +hourlyrateamt);
		//job code
		String jobcode=workerdetails.getjobcode();
		System.out.println("Jobcode is: " +jobcode);
		String positionid=workerdetails.getpositionid();
		System.out.println("Positionid is: " +positionid);
		Thread.sleep(3000);
		workerdetails.clickworkerstab();
		Thread.sleep(1000);
		workerdetails.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		if(workername.equals("Miller, Todd Li") || workername.equals("Field, John S") || workername.equals("Lovejoy, John") || workername.equals("Martinez, Tyffany") || workername.equals("Ingles, Daniel G.") || workername.equals("Johnson, Margaret"))
		{
		//newtimesheet activites
		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timesheet.TimesheetTab();
		logger.info("User Clicked Timesheet tab - Passed");
		Thread.sleep(2000);
		timesheet.TimeentryTab();
		Thread.sleep(2000);
		timesheet.AllTimesheetScreen();
		//logger.info("Navigated to AllTimeSheet Screen - Passed");
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		//logger.info("Clicked NewTimesheet button - Passed");
		Thread.sleep(3000);
		timesheet.clkWorkersText();
		Thread.sleep(3000);
		timesheet.txtworker(workername);
		//System.out.println("Worker selected is: " +workername);
		Thread.sleep(3000);
		timesheet.listselect();
		//logger.info("Worker Selected: " +workername);
		Thread.sleep(2000);
	    timesheet.clkProjectText();
	    Thread.sleep(1000);
		timesheet.txtproject(project);
		//System.out.println("Project selected is: " +project);
		Thread.sleep(3000);
		timesheet.listselect();
		//logger.info("Project selected is: " +project);
		Thread.sleep(2000);
		timesheet.clkTaskcodeText();
		Thread.sleep(2000);
		timesheet.txttaskcode(taskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(2000);
		timesheet.clkPayperiodText();
		Thread.sleep(3000);
		if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
		{
			timesheet.setPayperiod1();
		}
		/*
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
		{
			timesheet.setPayperiod33();
		}
		*/
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
		{
			timesheet.setPayperiod34();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
		{
			timesheet.setPayperiod35();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
		{
			timesheet.setPayperiod36();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
		{
			timesheet.setPayperiod37();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
		{
			timesheet.setPayperiod38();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
		{
			timesheet.setPayperiod39();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
		{
			timesheet.setPayperiod40();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
		{
			timesheet.setPayperiod41();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
		{
			timesheet.setPayperiod42();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
		{
			timesheet.setPayperiod43();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
		{
			timesheet.setPayperiod44();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
		{
			timesheet.setPayperiod45();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
		{
			timesheet.setPayperiod46();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
		{
			timesheet.setPayperiod47();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
		{
			timesheet.setPayperiod48();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("6/13/21"))
		{
			timesheet.setPayperiod49();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("6/27/21"))
		{
			timesheet.setPayperiod50();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("7/11/21"))
		{
			timesheet.setPayperiod51();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("7/25/21"))
		{
			timesheet.setPayperiod52();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("8/8/21"))
		{
			timesheet.setPayperiod53();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("8/22/21"))
		{
			timesheet.setPayperiod54();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("9/5/21"))
		{
			timesheet.setPayperiod55();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("9/19/21"))
		{
			timesheet.setPayperiod56();
		}
		//System.out.println("PayPeriod selected is: " +payperiod);
		//logger.info("Pay period date selected is: " +payperiod);
		timesheet.btnSave();
		Thread.sleep(5000);
		logger.info(workername+ ": NewTimesheet Successfully Saved - Passed");
		timesheet.setRow1();
		Thread.sleep(1000);
		timesheet.setRow1();
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.clearprojecttxt();
		Thread.sleep(1000);
		timesheet.clkprojecttxt();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(editprojectcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		timesheet.txtedittaskcodestring(edittaskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.seteditshiftid();
	    Thread.sleep(3000);
	    if(timesheet.txteditswiftstring(editshiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("First"))
		{
			timesheet.setShiftDay();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift1"))
		{
	    	timesheet.setATShift1();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift2"))
		{
			timesheet.setATShift2();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift3"))
		{
			timesheet.setATShift3();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift4"))
		{
			timesheet.setATShift4();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift5"))
		{
			timesheet.setATShift5();
		}
		else if(timesheet.txteditswiftstring(editshiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
		*/
	    Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editregularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editovertimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editdoubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(edittripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//Edit Row2
		timesheet.setRow2();
		Thread.sleep(1000);
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.clearprojecttxt();
		Thread.sleep(1000);
		timesheet.clkprojecttxt();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(editrow2projectcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		timesheet.txtedittaskcodestring(editrow2taskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.seteditshiftid();
		Thread.sleep(3000);
		if(timesheet.txteditswiftstring(editrow2shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("First"))
		{
			timesheet.setShiftDay();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift1"))
		{
	    	timesheet.setATShift1();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift2"))
		{
			timesheet.setATShift2();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift3"))
		{
			timesheet.setATShift3();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift4"))
		{
			timesheet.setATShift4();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift5"))
		{
			timesheet.setATShift5();
		}
		else if(timesheet.txteditswiftstring(editrow2shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
		*/
		Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow2regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow2overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow2doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow2tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//Edit Row3
		timesheet.setRow3();
		Thread.sleep(1000);
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.clearprojecttxt();
		Thread.sleep(1000);
		timesheet.clkprojecttxt();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(editrow3projectcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		timesheet.txtedittaskcodestring(editrow3taskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.seteditshiftid();
		Thread.sleep(3000);
		if(timesheet.txteditswiftstring(editrow3shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("First"))
		{
				timesheet.setShiftDay();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift1"))
		{
	    	timesheet.setATShift1();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift2"))
		{
			timesheet.setATShift2();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift3"))
		{
			timesheet.setATShift3();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift4"))
		{
			timesheet.setATShift4();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift5"))
		{
			timesheet.setATShift5();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
		*/
		Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow3regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow3overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow3doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow3tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//Edit Row4
		timesheet.setRow4();
		Thread.sleep(1000);
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.clearprojecttxt();
		Thread.sleep(1000);
		timesheet.clkprojecttxt();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(editrow4projectcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		timesheet.txtedittaskcodestring(editrow4taskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.seteditshiftid();
		Thread.sleep(3000);
		if(timesheet.txteditswiftstring(editrow4shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("First"))
		{
				timesheet.setShiftDay();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift1"))
		{
	    	timesheet.setATShift1();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift2"))
		{
			timesheet.setATShift2();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift3"))
		{
			timesheet.setATShift3();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift4"))
		{
			timesheet.setATShift4();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift5"))
		{
			timesheet.setATShift5();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
		*/
		Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow4regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow4overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow4doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow4tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//Edit Row5
		/*
		timesheet.setRow5();
		Thread.sleep(1000);
		timesheet.Edit();
		Thread.sleep(1000);
		timesheet.clearprojecttxt();
		Thread.sleep(1000);
		timesheet.clkprojecttxt();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(editrow5projectcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		timesheet.txtedittaskcodestring(editrow5taskcode);
		Thread.sleep(3000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.seteditshiftid();
		Thread.sleep(3000);
		if(timesheet.txteditswiftstring(editrow5shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("First"))
		{
				timesheet.setShiftDay();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift1"))
		{
	    	timesheet.setATShift1();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift2"))
		{
			timesheet.setATShift2();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift3"))
		{
			timesheet.setATShift3();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift4"))
		{
			timesheet.setATShift4();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift5"))
		{
			timesheet.setATShift5();
		}
		else if(timesheet.txteditswiftstring(editrow5shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
		Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow5regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow5overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow5doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow5tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		*/
		timesheet.Process();
		logger.info(workername+ ": Clicked on Process button - Passed");
		Thread.sleep(5000);
		timesheet.Threedots();
		Thread.sleep(5000);
		timesheet.Viewcalculation();
		Thread.sleep(5000);
		int rowcount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr")).size();
		String numofrows=String.valueOf(rowcount);
		System.out.println("number of rows: " +numofrows);
		for(int r=1;r<=rowcount;r++)
		{
			String totalhours=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
			int totalhoursfinalvalue=Integer.parseInt(totalhours);
			
			String eomployeerate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
			float employeeratefinalvalue=(float) Double.parseDouble(eomployeerate);
			//System.out.println("Employee Rate from double is: " +employeeratefinalvalue);
			DecimalFormat employeerateformat = new DecimalFormat("#.####");
			float employeeratevaluewt=Float.valueOf(employeerateformat.format(employeeratefinalvalue));
			System.out.println("Employee Rate is: " +employeeratevaluewt);
			
			String unionrate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
			float unionratefinalvalue=(float) Double.parseDouble(unionrate);
			DecimalFormat unionrateformat = new DecimalFormat("#.####");
			float unionratevaluewt=Float.valueOf(unionrateformat.format(unionratefinalvalue));
			System.out.println("Union Rate is: " +unionratevaluewt);
			
			String privailingwagerate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
			float privailingwageratefinalvalue=(float) Double.parseDouble(privailingwagerate);
			DecimalFormat privailingwagerateformat = new DecimalFormat("#.####");
			float privailingwageratevaluewt=Float.valueOf(privailingwagerateformat.format(privailingwageratefinalvalue));
			System.out.println("Privailing Rate is: " +privailingwageratevaluewt);
			
			String calculatedcost=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
			float calculatedcostfinalvalue=(float) Double.parseDouble(calculatedcost);
			DecimalFormat calculatedcostrateformat = new DecimalFormat("#.####");
			float calculatedcostratevaluewt=Float.valueOf(calculatedcostrateformat.format(calculatedcostfinalvalue));
			System.out.println("Calculated Cost Rate is: " +calculatedcostratevaluewt);
			
			driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[4]")).click();
		    String earningcodetxt=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[4]")).getText();
		    String empshiftrategrid=driver.findElement(By.xpath("//input[@name='employeeShiftRate']")).getAttribute("value");
		    float empshiftrategridvalue=(float) Double.parseDouble(empshiftrategrid);
		    System.out.println("Employee Shift rate grid is: " +empshiftrategridvalue);
		    String unionshiftrategrid=driver.findElement(By.xpath("//input[@name='unionShiftRate']")).getAttribute("value");
		    float unionshiftrategridvalue=(float) Double.parseDouble(unionshiftrategrid);
		    System.out.println("Union Shift rate grid is: " +unionshiftrategridvalue);
		    String unionspecialrategrid=driver.findElement(By.xpath("//input[@name='unionSpecialPayRate']")).getAttribute("value");
		    float unionspecialrategridvalue=(float) Double.parseDouble(unionspecialrategrid);
		    System.out.println("Union Specialpay rate grid is: " +unionspecialrategridvalue);
		    String unionextrapayrategrid=driver.findElement(By.xpath("//input[@name='extraPayRate']")).getAttribute("value");
		    float unionextrapay=(float) Double.parseDouble(unionextrapayrategrid);
		    System.out.println("Union Extrapay rate grid is: " +unionextrapayrategrid);
		    String prevailingWageRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageRate']")).getAttribute("value");
		    float prevailingWageRate=(float) Double.parseDouble(prevailingWageRategrid);
		    System.out.println("Prevailingwage rate grid is: " +prevailingWageRate);
		    String prevailingWageCashInLieugrid=driver.findElement(By.xpath("//input[@name='prevailingWageCashInLieu']")).getAttribute("value");
		    float prevailingWageCashInLieu=(float) Double.parseDouble(prevailingWageCashInLieugrid);
		    System.out.println("Prevailingwage Cashinlieu rate grid is: " +prevailingWageCashInLieu);
		    String prevailingWageShiftRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageShiftRate']")).getAttribute("value");
		    float prevailingWageShiftRate=(float) Double.parseDouble(prevailingWageShiftRategrid);
		    System.out.println("Prevailingwage Shift rate grid is: " +prevailingWageShiftRate);
		    //Employee, Union and Prevailingwage Rate calculations
		    if(earningcodetxt.equals("DOT"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*DoubletimeAmtRatevalue);
				  System.out.println("DOT Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		   //System.out.println("DOT*EmployeeRate Calculated as expected is: " +employerrate);  
	        		   Assert.assertTrue(true);
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("DOT*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		  Assert.fail();
	        	   }
				 float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*DoubletimeAmtRatevalue)+prevailingWageCashInLieu);
				 System.out.println("DOT Privailing Rate is: " +prevailingratevalue);
				 if(prevailingratevalue==privailingwageratefinalvalue)
				 {
					 //System.out.println("DOT*Privailingrate Calculated as expected is: " +prevailingratevalue);  
					 Assert.assertTrue(true);
				 }
				 else if(prevailingratevalue!=privailingwageratefinalvalue)
				 {
					 logger.info("DOT*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
					Assert.fail();
				 } 
				 
		    }
		    else if(earningcodetxt.equals("O3"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*TripletimeAmtRatevalue);
				  System.out.println("O3 Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		  // System.out.println("O3*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("O3*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		   //Assert.fail();
	        	   }
				float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*TripletimeAmtRatevalue)+prevailingWageCashInLieu);
					 System.out.println("O3 Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						// System.out.println("O3*Privailingrate Calculated as expected is: " +prevailingratevalue);  
						 Assert.assertTrue(true);
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 logger.info("O3*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
						Assert.fail();
					 } 
		    }
		    else if(earningcodetxt.equals("O"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*OvertimeAmtRatevalue);
				  System.out.println("O Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		 //  System.out.println("O*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("O*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		  Assert.fail();
	        	   }
			    float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*OvertimeAmtRatevalue)+prevailingWageCashInLieu);
					 System.out.println("O Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						// System.out.println("O*Privailingrate Calculated as expected is: " +prevailingratevalue);  
						 Assert.assertTrue(true);
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 logger.info("O*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
						Assert.fail();
					 } 
		    }
		    else if(earningcodetxt.equals("R"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*RegularAmtRatevalue);
				  System.out.println("R Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		  // System.out.println("R*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("R*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		  Assert.fail();
	        	   }
				float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*RegularAmtRatevalue)+prevailingWageCashInLieu);
					 System.out.println("R Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						// System.out.println("R*Privailingrate Calculated as expected is: " +prevailingratevalue);  
						 Assert.assertTrue(true);
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 logger.info("R*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
						Assert.fail();
					 } 
		    }
		  //Calculated Cost Rate Calculation
		    if(employeeratevaluewt>unionratevaluewt && employeeratevaluewt>privailingwageratevaluewt)
			{
				
				float Caluculatedcost =totalhoursfinalvalue * employeeratevaluewt;
				DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
				float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
				System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
				
				if(Caluculatedcostratevalue==calculatedcostratevaluewt)
				{
					Assert.assertTrue(true);
				}
				else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
				{
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
					//Assert.fail();
				}
			}
			else if(unionratevaluewt>employeeratevaluewt && unionratevaluewt>privailingwageratevaluewt)
			{
				float Caluculatedcost =(totalhoursfinalvalue * unionratevaluewt);
				DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
				float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
				System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
				
				if(Caluculatedcostratevalue==calculatedcostratevaluewt)
				{
					Assert.assertTrue(true);
				}
				else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
				{
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
					//Assert.fail();
				}
			}
			else if(privailingwageratevaluewt>employeeratevaluewt && privailingwageratevaluewt>unionratevaluewt)
			{
				float Caluculatedcost =(totalhoursfinalvalue * privailingwageratevaluewt);
				DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
				float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
				System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
				
				if(Caluculatedcostratevalue==calculatedcostratevaluewt)
				{
					Assert.assertTrue(true);
				}
				else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
				{
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
					//Assert.fail();
				}
			}
		}
		//Total hourly cost calculation
		String[][] tableVal;
	    int rowCount,columnCount;
	    double sum=0;
		List<WebElement> tablerowcount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr"));
		List<WebElement> tablecolumncount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr[1]/td"));
		rowCount = tablerowcount.size();
	    columnCount = tablecolumncount.size();
	   // System.out.println("Row :"+rowCount+" Clounm :"+columnCount);
	    tableVal = new String[rowCount][columnCount];
	    for(int w =1 ; w <= rowCount ; w++ ){
	        //for(int j =1 ; j <= columnCount ; j++ ) //{
	               tableVal[w-1][12] =driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+w+"]/td[12]")).getText();
	               float totalhour=(float) Double.parseDouble(tableVal[w-1][12]);
	               DecimalFormat totalhourformat = new DecimalFormat("#.##");
	               float totalhourformatvalue=Float.valueOf(totalhourformat.format(totalhour));
	               sum= sum+totalhourformatvalue;
	           // }
	        }
	   //System.out.println("Sum of all the Calculatedcost is: " +sum);
	  // logger.info(workername+ ": Sum of all the Calculatedcost is: " +sum);
	   DecimalFormat totalhourssum = new DecimalFormat("#.##");
	   float sumvalue=Float.valueOf(totalhourssum.format(sum));
	  // logger.info(workername+ ": Sum of all the Calculatedcost is: " +sumvalue);
	   String totalhourly= driver.findElement(By.xpath("//span[contains(text(),'Name')]//following::table[1]/tbody/tr/td[6]")).getText();
	   float totalhourlycost=(float) Double.parseDouble(totalhourly);
	 //logger.info(workername+ ": Total Hourly Cost: " +totalhourlycost);
	   DecimalFormat totalhourlycostformat = new DecimalFormat("#.##");
	   float totalhourlycostvalue=Float.valueOf(totalhourlycostformat.format(totalhourlycost));
	  // logger.info(workername+ ": Total Hourly Cost:" +totalhourlycostvalue);
	   if(totalhourlycost==sumvalue)
	   {
		  // System.out.println("Total hours Calculated as expected");
		   logger.info(workername+ ": Total hours Calculated as expected - Passed");
		   Assert.assertTrue(true);
	   }
	   else if(totalhourlycost!=sumvalue)
	   {
		   logger.info(workername+ ": Total hours Calculated(code) is: " +sumvalue);
		   logger.info(workername+ ": Total hours not Calculated(table) is: " +totalhourlycostvalue);
		   logger.info(workername+ ": Total hours not Calculated as expected");
		  Assert.fail();
	   }
	   
	    Thread.sleep(10000);
	    timesheet.clkbackbtn();
	    Thread.sleep(1000);
	    timesheet.Approve();
		Thread.sleep(1000);
		logger.info(workername+ ": Status Approved - Passed");
		timesheet.Complete();
		Thread.sleep(1000);
		logger.info(workername+ ": Status Completed - Passed");
		timesheet.CreateStatement();
		Thread.sleep(1000);
		logger.info(workername+ ": Statement Created - Passed");
		Thread.sleep(1000);
	}
	else if(workername.equals("Selbert, Tomas") || workername.equals("Coslett, Daniel A") || workername.equals("Cecchetti, Davido") || workername.equals("Martinez, Tyffany") || workername.equals("Maple, Myra") || workername.equals("French, Toni"))
	{	
		//Employee>Positions
				employees_positions_pom positions=new employees_positions_pom(driver);
				//positions.EmployeesTab();
				positions.clickpayrollmgmtadptab();
				Thread.sleep(1000);
				positions.clickworkersetuptab();
				Thread.sleep(1000);
				positions.clkpositionsscreen();
				Thread.sleep(2000);
				positions.clksearchtextbox();
				positions.txtworkersearchstring(positionid);
				Thread.sleep(2000);
				positions.clkEdit();
				Thread.sleep(2000);
				String homeunionidvalue=positions.gethomeunionidvalue();
				//logger.info("Home Union ID 1st is: " +homeunionidvalue);
				/*
				String unionetrapaystring=positions.getunionextrapayvalue();
				float unionextrapay=(float) Double.parseDouble(unionetrapaystring);
				logger.info("Union Extra pay is: " +unionextrapay);
				*/
				//String homeunionidvalue1=positions.gethomeunionidvalue();
				String homeunionid=homeunionidvalue.substring(0,10);
				System.out.print("Home Union ID is: " +homeunionid);
				Thread.sleep(2000);
				positions.clkCancel();
				Thread.sleep(3000);
				//job code rate in union
				unions_Unions_pom jobcoderate=new unions_Unions_pom(driver);
				//jobcoderate.clickUnionsTab();
				jobcoderate.clickunionmgmttab();
				Thread.sleep(1000);
				jobcoderate.clickunionsetuptab();
				Thread.sleep(1000);
				//jobcoderate.clickUnionsTab2();
				Thread.sleep(1000);
				jobcoderate.clksearchtxtbtn(homeunionid);
				Thread.sleep(2000);
				jobcoderate.clkeditbtn();
				Thread.sleep(2000);
				jobcoderate.clickUnionAgreementTab();
				Thread.sleep(4000);
				/*
				jobcoderate.clksearchtxt(jobcode);
				Thread.sleep(1000);
				jobcoderate.clksearchlensbtn();
				Thread.sleep(1000);
				*/
				String jobcoderatevalue=jobcoderate.getjobcoderate();
				//logger.info("Jobcode Rate String is: " +jobcoderatevalue);
				double jobrateamtvalue=Double.parseDouble(jobcoderatevalue);
				System.out.println("Jobcode Rate is: " +jobrateamtvalue);
				
				//newtimesheet activites
				timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
				timesheet.TimesheetTab();
				logger.info("User Clicked Timesheet tab - Passed");
				Thread.sleep(2000);
				timesheet.TimeentryTab();
				Thread.sleep(2000);
				timesheet.AllTimesheetScreen();
				//logger.info("Navigated to AllTimeSheet Screen - Passed");
				Thread.sleep(3000);
				timesheet.NewTimesheet();
				//logger.info("Clicked NewTimesheet button - Passed");
				Thread.sleep(3000);
				timesheet.clkWorkersText();
				Thread.sleep(3000);
				timesheet.txtworker(workername);
				//System.out.println("Worker selected is: " +workername);
				Thread.sleep(5000);
				timesheet.listselect();
				//logger.info("Worker Selected: " +workername);
				Thread.sleep(2000);
			    timesheet.clkProjectText();
			    Thread.sleep(1000);
				timesheet.txtproject(project);
				//System.out.println("Project selected is: " +project);
				Thread.sleep(3000);
				timesheet.listselect();
				//logger.info("Project selected is: " +project);
				Thread.sleep(2000);
				timesheet.clkTaskcodeText();
				Thread.sleep(2000);
				timesheet.txttaskcode(taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(2000);
				timesheet.clkPayperiodText();
				Thread.sleep(3000);
				if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
				{
					timesheet.setPayperiod1();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
				{
					timesheet.setPayperiod33();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
				{
					timesheet.setPayperiod34();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
				{
					timesheet.setPayperiod35();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
				{
					timesheet.setPayperiod36();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
				{
					timesheet.setPayperiod37();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
				{
					timesheet.setPayperiod38();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
				{
					timesheet.setPayperiod39();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
				{
					timesheet.setPayperiod40();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
				{
					timesheet.setPayperiod41();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
				{
					timesheet.setPayperiod42();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
				{
					timesheet.setPayperiod43();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
				{
					timesheet.setPayperiod44();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
				{
					timesheet.setPayperiod45();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
				{
					timesheet.setPayperiod46();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
				{
					timesheet.setPayperiod47();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
				{
					timesheet.setPayperiod48();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("6/13/21"))
				{
					timesheet.setPayperiod49();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("6/27/21"))
				{
					timesheet.setPayperiod50();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("7/11/21"))
				{
					timesheet.setPayperiod51();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("7/25/21"))
				{
					timesheet.setPayperiod52();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("8/8/21"))
				{
					timesheet.setPayperiod53();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("8/22/21"))
				{
					timesheet.setPayperiod54();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("9/5/21"))
				{
					timesheet.setPayperiod55();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("9/19/21"))
				{
					timesheet.setPayperiod56();
				}
				//System.out.println("PayPeriod selected is: " +payperiod);
				//logger.info("Pay period date selected is: " +payperiod);
				timesheet.btnSave();
				Thread.sleep(5000);
				logger.info(workername+ ": NewTimesheet Successfully Saved - Passed");
				timesheet.setRow1();
				Thread.sleep(1000);
				timesheet.setRow1();
				timesheet.Edit();
				Thread.sleep(1000);
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				timesheet.txtedittaskcodestring(edittaskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
			    Thread.sleep(3000);
			    if(timesheet.txteditswiftstring(editshiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("First"))
				{
					timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
			    Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editregularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editovertimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editdoubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(edittripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row2
				timesheet.setRow2();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow2taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow2shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("First"))
				{
					timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow2regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow2overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow2doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow2tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row3
				timesheet.setRow3();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow3taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow3shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow3regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow3overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow3doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow3tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row4
				timesheet.setRow4();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow4taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow4shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow4regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow4overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow4doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow4tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row5
				timesheet.setRow5();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow5projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow5taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow5shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow5regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow5overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow5doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow5tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				timesheet.Process();
				logger.info(workername+ ": Clicked on Process button - Passed");
				Thread.sleep(5000);
				timesheet.Threedots();
				Thread.sleep(5000);
				timesheet.Viewcalculation();
				Thread.sleep(5000);
				int rowcount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr")).size();
				String numofrows=String.valueOf(rowcount);
				System.out.println("number of rows: " +numofrows);
				for(int r=1;r<=rowcount;r++)
				{
					String totalhours=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
					int totalhoursfinalvalue=Integer.parseInt(totalhours);
					
					String eomployeerate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
					float employeeratefinalvalue=(float) Double.parseDouble(eomployeerate);
					//System.out.println("Employee Rate from double is: " +employeeratefinalvalue);
					DecimalFormat employeerateformat = new DecimalFormat("#.####");
					float employeeratevaluewt=Float.valueOf(employeerateformat.format(employeeratefinalvalue));
					System.out.println("Employee Rate is: " +employeeratevaluewt);
					
					String unionrate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
					float unionratefinalvalue=(float) Double.parseDouble(unionrate);
					DecimalFormat unionrateformat = new DecimalFormat("#.####");
					float unionratevaluewt=Float.valueOf(unionrateformat.format(unionratefinalvalue));
					System.out.println("Union Rate is: " +unionratevaluewt);
					
					String privailingwagerate=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
					float privailingwageratefinalvalue=(float) Double.parseDouble(privailingwagerate);
					DecimalFormat privailingwagerateformat = new DecimalFormat("#.####");
					float privailingwageratevaluewt=Float.valueOf(privailingwagerateformat.format(privailingwageratefinalvalue));
					System.out.println("Privailing Rate is: " +privailingwageratevaluewt);
					
					String calculatedcost=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
					float calculatedcostfinalvalue=(float) Double.parseDouble(calculatedcost);
					DecimalFormat calculatedcostrateformat = new DecimalFormat("#.####");
					float calculatedcostratevaluewt=Float.valueOf(calculatedcostrateformat.format(calculatedcostfinalvalue));
					System.out.println("Calculated Cost Rate is: " +calculatedcostratevaluewt);
					
					driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[4]")).click();
				    String earningcodetxt=driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+r+"]/td[4]")).getText();
				    String empshiftrategrid=driver.findElement(By.xpath("//input[@name='employeeShiftRate']")).getAttribute("value");
				    float empshiftrategridvalue=(float) Double.parseDouble(empshiftrategrid);
				    System.out.println("Employee Shift rate grid is: " +empshiftrategridvalue);
				    String unionshiftrategrid=driver.findElement(By.xpath("//input[@name='unionShiftRate']")).getAttribute("value");
				    float unionshiftrategridvalue=(float) Double.parseDouble(unionshiftrategrid);
				    System.out.println("Union Shift rate grid is: " +unionshiftrategridvalue);
				    String unionspecialrategrid=driver.findElement(By.xpath("//input[@name='unionSpecialPayRate']")).getAttribute("value");
				    float unionspecialrategridvalue=(float) Double.parseDouble(unionspecialrategrid);
				    System.out.println("Union Specialpay rate grid is: " +unionspecialrategridvalue);
				    String unionextrapayrategrid=driver.findElement(By.xpath("//input[@name='extraPayRate']")).getAttribute("value");
				    float unionextrapay=(float) Double.parseDouble(unionextrapayrategrid);
				    System.out.println("Union Extrapay rate grid is: " +unionextrapayrategrid);
				    String prevailingWageRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageRate']")).getAttribute("value");
				    float prevailingWageRate=(float) Double.parseDouble(prevailingWageRategrid);
				    System.out.println("Prevailingwage rate grid is: " +prevailingWageRate);
				    String prevailingWageCashInLieugrid=driver.findElement(By.xpath("//input[@name='prevailingWageCashInLieu']")).getAttribute("value");
				    float prevailingWageCashInLieu=(float) Double.parseDouble(prevailingWageCashInLieugrid);
				    System.out.println("Prevailingwage Cashinlieu rate grid is: " +prevailingWageCashInLieu);
				    String prevailingWageShiftRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageShiftRate']")).getAttribute("value");
				    float prevailingWageShiftRate=(float) Double.parseDouble(prevailingWageShiftRategrid);
				    System.out.println("Prevailingwage Shift rate grid is: " +prevailingWageShiftRate);
				    //Employee, Union and Prevailingwage Rate calculations
				    if(earningcodetxt.equals("DOT"))
				    {
				    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*DoubletimeAmtRatevalue);
						  System.out.println("DOT Employee Rate is: " +employerrate);
						  if(employerrate==employeeratefinalvalue)
			        	   {
			        		   //System.out.println("DOT*EmployeeRate Calculated as expected is: " +employerrate);  
			        		   Assert.assertTrue(true);
			        	   }
			        	   else if(employerrate!=employeeratefinalvalue)
			        	   {
			        		   logger.info("DOT*EmployeeRate not calculated as excpected is: "  +employerrate);
			        		  Assert.fail();
			        	   }
						 float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*DoubletimeAmtRatevalue);
						 System.out.println("DOT Union Rate is: " +unionrate);
						 if(unionratevalue==unionratefinalvalue)
						 {
							// System.out.println("DOT*Unionrate Calculated as expected is: " +unionratevalue);  
							 Assert.assertTrue(true);
						 }
						 else if(unionratevalue!=unionratefinalvalue)
						 {
							 logger.info("DOT*Unionrate not calculated as excpected is: "  +unionratevalue);
							Assert.fail();
						 }
						 float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*DoubletimeAmtRatevalue)+prevailingWageCashInLieu);
						 System.out.println("DOT Privailing Rate is: " +prevailingratevalue);
						 if(prevailingratevalue==privailingwageratefinalvalue)
						 {
							 //System.out.println("DOT*Privailingrate Calculated as expected is: " +prevailingratevalue); 
							 Assert.assertTrue(true);
						 }
						 else if(prevailingratevalue!=privailingwageratefinalvalue)
						 {
							 logger.info("DOT*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
							Assert.fail();
						 } 
						 
				    }
				    else if(earningcodetxt.equals("O3"))
				    {
				    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*TripletimeAmtRatevalue);
						  System.out.println("O3 Employee Rate is: " +employerrate);
						  if(employerrate==employeeratefinalvalue)
			        	   {
			        		  // System.out.println("O3*EmployeeRate Calculated as expected is: " +employerrate);
			        		   Assert.assertTrue(true);
			        		   
			        	   }
			        	   else if(employerrate!=employeeratefinalvalue)
			        	   {
			        		   logger.info("O3*EmployeeRate not calculated as excpected is: "  +employerrate);
			        		   //Assert.fail();
			        	   }
					    float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*TripletimeAmtRatevalue);
							 System.out.println("O3 Union Rate is: " +unionrate);
							 if(unionratevalue==unionratefinalvalue)
							 {
								// System.out.println("O3*Unionrate Calculated as expected is: " +unionratevalue);  
								 Assert.assertTrue(true);
							 }
							 else if(unionratevalue!=unionratefinalvalue)
							 {
								 logger.info("O3*Unionrate not calculated as excpected is: "  +unionratevalue);
								Assert.fail();
							 }
						float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*TripletimeAmtRatevalue)+prevailingWageCashInLieu);
							 System.out.println("O3 Privailing Rate is: " +prevailingratevalue);
							 if(prevailingratevalue==privailingwageratefinalvalue)
							 {
								// System.out.println("O3*Privailingrate Calculated as expected is: " +prevailingratevalue);  
								 Assert.assertTrue(true);
							 }
							 else if(prevailingratevalue!=privailingwageratefinalvalue)
							 {
								 logger.info("O3*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
								Assert.fail();
							 } 
				    }
				    else if(earningcodetxt.equals("O"))
				    {
				    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*OvertimeAmtRatevalue);
						  System.out.println("O Employee Rate is: " +employerrate);
						  if(employerrate==employeeratefinalvalue)
			        	   {
			        		 //  System.out.println("O*EmployeeRate Calculated as expected is: " +employerrate);
			        		   Assert.assertTrue(true);
			        		   
			        	   }
			        	   else if(employerrate!=employeeratefinalvalue)
			        	   {
			        		   logger.info("O*EmployeeRate not calculated as excpected is: "  +employerrate);
			        		  Assert.fail();
			        	   }
					    float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*OvertimeAmtRatevalue);
							 System.out.println("O Union Rate is: " +unionrate);
							 if(unionratevalue==unionratefinalvalue)
							 {
								// System.out.println("O*Unionrate Calculated as expected is: " +unionratevalue); 
								 Assert.assertTrue(true);
							 }
							 else if(unionratevalue!=unionratefinalvalue)
							 {
								 logger.info("O*Unionrate not calculated as excpected is: "  +unionratevalue);
								 //Assert.fail();
							 }
					    float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*OvertimeAmtRatevalue)+prevailingWageCashInLieu);
							 System.out.println("O Privailing Rate is: " +prevailingratevalue);
							 if(prevailingratevalue==privailingwageratefinalvalue)
							 {
								 //System.out.println("O*Privailingrate Calculated as expected is: " +prevailingratevalue);  
								 Assert.assertTrue(true);
							 }
							 else if(prevailingratevalue!=privailingwageratefinalvalue)
							 {
								 logger.info("O*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
								Assert.fail();
							 } 
				    }
				    else if(earningcodetxt.equals("R"))
				    {
				    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*RegularAmtRatevalue);
						  System.out.println("R Employee Rate is: " +employerrate);
						  if(employerrate==employeeratefinalvalue)
			        	   {
			        		  // System.out.println("R*EmployeeRate Calculated as expected is: " +employerrate);
			        		   Assert.assertTrue(true);
			        		   
			        	   }
			        	   else if(employerrate!=employeeratefinalvalue)
			        	   {
			        		   logger.info("R*EmployeeRate not calculated as excpected is: "  +employerrate);
			        		  Assert.fail();
			        	   }
						 float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*RegularAmtRatevalue);
							 System.out.println("R Union Rate is: " +unionratevalue);
							 if(unionratevalue==unionratefinalvalue)
							 {
								 //System.out.println("R*Unionrate Calculated as expected is: " +unionratevalue);
								 Assert.assertTrue(true);
							 }
							 else if(unionratevalue!=unionratefinalvalue)
							 {
								 logger.info("R*Unionrate not calculated as excpected is: "  +unionratevalue);
								Assert.fail();
							 }
						float prevailingratevalue=(float) (((prevailingWageRate+prevailingWageShiftRate)*RegularAmtRatevalue)+prevailingWageCashInLieu);
							 System.out.println("R Privailing Rate is: " +prevailingratevalue);
							 if(prevailingratevalue==privailingwageratefinalvalue)
							 {
								// System.out.println("R*Privailingrate Calculated as expected is: " +prevailingratevalue); 
								 Assert.assertTrue(true);
							 }
							 else if(prevailingratevalue!=privailingwageratefinalvalue)
							 {
								 logger.info("R*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
								Assert.fail();
							 } 
				    }
				  //Calculated Cost Rate Calculation
				    if(employeeratevaluewt>unionratevaluewt && employeeratevaluewt>privailingwageratevaluewt)
					{
						
						float Caluculatedcost =totalhoursfinalvalue * employeeratevaluewt;
						DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
						float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
						System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
						
						if(Caluculatedcostratevalue==calculatedcostratevaluewt)
						{
							Assert.assertTrue(true);
						}
						else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
						{
							logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
							//Assert.fail();
						}
					}
					else if(unionratevaluewt>employeeratevaluewt && unionratevaluewt>privailingwageratevaluewt)
					{
						float Caluculatedcost =(totalhoursfinalvalue * unionratevaluewt);
						DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
						float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
						System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
						
						if(Caluculatedcostratevalue==calculatedcostratevaluewt)
						{
							Assert.assertTrue(true);
						}
						else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
						{
							logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
							//Assert.fail();
						}
					}
					else if(privailingwageratevaluewt>employeeratevaluewt && privailingwageratevaluewt>unionratevaluewt)
					{
						float Caluculatedcost =(totalhoursfinalvalue * privailingwageratevaluewt);
						DecimalFormat Caluculatedcostformat = new DecimalFormat("#.####");
						float Caluculatedcostratevalue=Float.valueOf(Caluculatedcostformat.format(Caluculatedcost));
						System.out.println("Calculated Cost Rate is: " +Caluculatedcostratevalue);
						
						if(Caluculatedcostratevalue==calculatedcostratevaluewt)
						{
							Assert.assertTrue(true);
						}
						else if(Caluculatedcostratevalue!=calculatedcostratevaluewt)
						{
							logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
							//Assert.fail();
						}
					}
				}
				//Total hourly cost calculation
				String[][] tableVal;
			    int rowCount,columnCount;
			    double sum=0;
				List<WebElement> tablerowcount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr"));
				List<WebElement> tablecolumncount=driver.findElements(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr[1]/td"));
				rowCount = tablerowcount.size();
			    columnCount = tablecolumncount.size();
			   // System.out.println("Row :"+rowCount+" Clounm :"+columnCount);
			    tableVal = new String[rowCount][columnCount];
			    for(int w =1 ; w <= rowCount ; w++ ){
			        //for(int j =1 ; j <= columnCount ; j++ ) //{
			               tableVal[w-1][12] =driver.findElement(By.xpath("//span[contains(text(),'Date')]//following::table[1]/tbody[1]/tr["+w+"]/td[12]")).getText();
			               float totalhour=(float) Double.parseDouble(tableVal[w-1][12]);
			               DecimalFormat totalhourformat = new DecimalFormat("#.##");
			               float totalhourformatvalue=Float.valueOf(totalhourformat.format(totalhour));
			               sum= sum+totalhourformatvalue;
			           // }
			        }
			   //System.out.println("Sum of all the Calculatedcost is: " +sum);
			  // logger.info(workername+ ": Sum of all the Calculatedcost is: " +sum);
			   DecimalFormat totalhourssum = new DecimalFormat("#.##");
			   float sumvalue=Float.valueOf(totalhourssum.format(sum));
			  // logger.info(workername+ ": Sum of all the Calculatedcost is: " +sumvalue);
			   String totalhourly= driver.findElement(By.xpath("//span[contains(text(),'Name')]//following::table[1]/tbody/tr/td[6]")).getText();
			   float totalhourlycost=(float) Double.parseDouble(totalhourly);
			 //logger.info(workername+ ": Total Hourly Cost: " +totalhourlycost);
			   DecimalFormat totalhourlycostformat = new DecimalFormat("#.##");
			   float totalhourlycostvalue=Float.valueOf(totalhourlycostformat.format(totalhourlycost));
			  // logger.info(workername+ ": Total Hourly Cost:" +totalhourlycostvalue);
			   if(totalhourlycost==sumvalue)
			   {
				  // System.out.println("Total hours Calculated as expected");
				   logger.info(workername+ ": Total hours Calculated as expected - Passed");
				   Assert.assertTrue(true);
			   }
			   else if(totalhourlycost!=sumvalue)
			   {
				   logger.info(workername+ ": Total hours Calculated(code) is: " +sumvalue);
				   logger.info(workername+ ": Total hours not Calculated(table) is: " +totalhourlycostvalue);
				   logger.info(workername+ ": Total hours not Calculated as expected");
				  Assert.fail();
			   }
			   
			    Thread.sleep(10000);
			    timesheet.clkbackbtn();
			    Thread.sleep(1000);
			    timesheet.Approve();
				Thread.sleep(1000);
				logger.info(workername+ ": Status Approved - Passed");
				timesheet.Complete();
				Thread.sleep(1000);
				logger.info(workername+ ": Status Completed - Passed");
				timesheet.CreateStatement();
				Thread.sleep(1000);
				logger.info(workername+ ": Statement Created - Passed");
				Thread.sleep(1000);
	}
}
	}		

}


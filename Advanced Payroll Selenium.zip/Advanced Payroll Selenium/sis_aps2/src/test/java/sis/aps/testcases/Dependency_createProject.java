package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_Projects_pom;

public class Dependency_createProject extends baseclass {

	@Test
	public void Project_Create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Project */
		operations_Projects_pom projects = new operations_Projects_pom(driver);

		projects.clickOperationsTab();
		projects.clickProjectsTab();
		logger.info("User navigated to All projects Page");
		projects.clickNewProjectButton();
		projects.SetDProjectId();
		projects.SetDProjectName();
		projects.clickSaveButton();
		Thread.sleep(2000);

		if (projects.isProjectTaskTabDisplayed().equals("Project task")) {
			Assert.assertTrue(true);
			logger.info("Project been created");
		} else {
			Assert.fail();
		}

		projects.clickBackButton();
		Thread.sleep(2000);

	}
}

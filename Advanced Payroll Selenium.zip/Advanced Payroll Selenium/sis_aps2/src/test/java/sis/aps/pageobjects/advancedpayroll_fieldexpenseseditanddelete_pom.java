package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class advancedpayroll_fieldexpenseseditanddelete_pom {
	public WebDriver ldriver;
		
	public advancedpayroll_fieldexpenseseditanddelete_pom(WebDriver rdriver) //constructor concept
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="(//span[text()='Advance payroll'])[1]") WebElement sltAdvancePayroll;
	public void clkAdvancePayroll()
	{
		sltAdvancePayroll.click();
	}
	@FindBy(xpath="(//span[text()='Field expenses'])[1]") WebElement sltFieldExpenses;
	public void clkFieldExpenses()
	{
		sltFieldExpenses.click();
	}
	@FindBy(xpath="//a[@title='Edit expense']") WebElement btnEditFieldExpense;
	public void btnEditFieldExpense()
	{
		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", btnEditFieldExpense);
		//btnEditFieldExpense.click();
	}
	@FindBy(xpath="(//mat-icon[text()='delete'])[1]") WebElement btnDeleteFielddExpense;
	public void btnDeleteFielddExpense()
	{
		btnDeleteFielddExpense.click();
	}
	@FindBy(xpath="//input[@data-placeholder='Unit']") WebElement clkUnit;
	public void clkUnit()
	{		
		clkUnit.click();
		clkUnit.sendKeys("2");
		
	}
	@FindBy(xpath="//input[@data-placeholder='Base rate']") WebElement clkBaseRate;
	public void clkBaseRate()
	{		
		clkBaseRate.sendKeys("6");
	}
	@FindBy(xpath="//button[text()='Save']") WebElement clkSave;
	public void clkSave()
	{
		
		if(clkSave.isEnabled()) {
			System.out.println("Save is enabled");
			clkSave.click();
		    }else {
			System.out.println("Save is disabled");
		     }
			
	}
	@FindBy(xpath="//i[@class='fa fa-arrow-left']") WebElement btnBack;
	public void clkBack()
	{
		btnBack.click();
	}
	
	
}

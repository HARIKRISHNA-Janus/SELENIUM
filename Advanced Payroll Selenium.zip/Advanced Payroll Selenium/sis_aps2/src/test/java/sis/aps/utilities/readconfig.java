package sis.aps.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class readconfig {
	
	Properties prop=new Properties();
	
	public readconfig() {
		
		try {
		FileInputStream source=new FileInputStream(System.getProperty("user.dir")+"/configuration/config.properties");
		prop.load(source);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getappurl()
	{
		String url=prop.getProperty("baseurl");
		return url;
	}
	public String getbrowser()
	{
		String browserpath=prop.getProperty("chromepath");
		return browserpath;
	}
	public String getusername()
	{
		String login=prop.getProperty("username");
		return login;
	}
	public String getpassword()
	{
		String password=prop.getProperty("password");
		return password;
	}
	public String getworkername()
	{
		String workernameselect=prop.getProperty("workername");
		return workernameselect;
	}
	public String getproject()
	{
		String projectselect=prop.getProperty("project");
		return projectselect;
	}
	public String gettaskcode()
	{
		String taskcodeselect=prop.getProperty("taskcode");
		return taskcodeselect;
	}
	public String getpayperiod()
	{
		String payperiodselect=prop.getProperty("payperiod");
		return payperiodselect;
	}
	public String getrow1eidtdate()
	{
		String row1editdateselect=prop.getProperty("row1date");
		return row1editdateselect;
	}
	public String getrow1eidtpojectcode()
	{
		String row1editprojectcodeselect=prop.getProperty("row1projectcode");
		return row1editprojectcodeselect;
	}
	public String getrow1eidttaskcode()
	{
		String row1edittaskcodeselect=prop.getProperty("row1taskcode");
		return row1edittaskcodeselect;
	}
	public String getrow1eidtjobcode()
	{
		String row1editjobcodeselect=prop.getProperty("row1jobcode");
		return row1editjobcodeselect;
	}
	public String getrow1eidtshiftid()
	{
		String row1editshiftidselect=prop.getProperty("row1shiftid");
		return row1editshiftidselect;
	}
	public String getrow1eidtspecialpay()
	{
		String row1editspecialpayselect=prop.getProperty("row1specialpay");
		return row1editspecialpayselect;
	}
	public String getrow1eidtregularhours()
	{
		String row1editregularhoursselect=prop.getProperty("row1regularhours");
		return row1editregularhoursselect;
	}
	public String getrow1eidtovertimehours()
	{
		String row1editovertimehoursselect=prop.getProperty("row1overtimehours");
		return row1editovertimehoursselect;
	}
	public String getrow1eidtdoubletimehour()
	{
		String row1editdoubletimehourselect=prop.getProperty("row1doubletimehours");
		return row1editdoubletimehourselect;
	}
	public String getrow1eidttripletimehour()
	{
		String row1edittripletimehourselect=prop.getProperty("row1tripletimehours");
		return row1edittripletimehourselect;
	}

	public String getcraftId() {
		String craftId = prop.getProperty("craftId");
		return craftId;
	}

	public String getcraftName() {
		String craftName = prop.getProperty("craftName");
		return craftName;
	}

	public String getshiftId() {
		String shiftId = prop.getProperty("shiftId");
		return shiftId;
	}

	public String getshiftName() {
		String shiftName = prop.getProperty("shiftName");
		return shiftName;
	}

	public String getrate() {
		String rate = prop.getProperty("rate");
		return rate;
	}

	public String getunionId() {
		String unionId = prop.getProperty("unionId");
		return unionId;
	}

	public String getunionName() {
		String unionName = prop.getProperty("unionName");
		return unionName;
	}

	public String getfringeId() {
		String fringeId = prop.getProperty("fringeId");
		return fringeId;
	}

	public String getfringeName() {
		String fringeName = prop.getProperty("fringeName");
		return fringeName;
	}

	public String getspecialPayId() {
		String specialPayId = prop.getProperty("specialPayId");
		return specialPayId;
	}

	public String getspecialPayName() {
		String specialPayName = prop.getProperty("specialPayName");
		return specialPayName;
	}

	public String getreciprocityId() {
		String reciprocityId = prop.getProperty("reciprocityId");
		return reciprocityId;
	}

	public String getunionAgreementId() {
		String unionAgreementId = prop.getProperty("unionAgreementId");
		return unionAgreementId;
	}

	public String getunionAgreementName() {
		String unionAgreementName = prop.getProperty("unionAgreementName");
		return unionAgreementName;
	}

	public String getvendorId() {
		String vendorId = prop.getProperty("vendorId");
		return vendorId;
	}

	public String getvendorName() {
		String vendorName = prop.getProperty("vendorName");
		return vendorName;
	}

	public String getunit() {
		String unit = prop.getProperty("unit");
		return unit;
	}

	public String getbaseRate() {
		String baseRate = prop.getProperty("baseRate");
		return baseRate;
	}

	public String getprojectId() {
		String projectId = prop.getProperty("projectId");
		return projectId;
	}

	public String getprojectName() {
		String projectName = prop.getProperty("projectName");
		return projectName;
	}

	public String getprojectCategoryId() {
		String projectCategoryId = prop.getProperty("projectCategoryId");
		return projectCategoryId;
	}

	public String getprojectCategoryName() {
		String projectCategoryName = prop.getProperty("projectCategoryName");
		return projectCategoryName;
	}

	public String getprojectCostRate() {
		String projectCostRate = prop.getProperty("projectCostRate");
		return projectCostRate;
	}

	public String gettaskId() {
		String taskId = prop.getProperty("taskId");
		return taskId;
	}

	public String gettaskName() {
		String taskName = prop.getProperty("taskName");
		return taskName;
	}

	public String getcustomerId() {
		String customerId = prop.getProperty("customerId");
		return customerId;
	}

	public String getcustomerName() {
		String customerName = prop.getProperty("customerName");
		return customerName;
	}

	public String getprevailingwageId() {
		String prevailingwageId = prop.getProperty("prevailingwageId");
		return prevailingwageId;
	}

	public String getprevailingwageName() {
		String prevailingwageName = prop.getProperty("prevailingwageName");
		return prevailingwageName;
	}
	
	public String getwageRate() {
		String wageRate = prop.getProperty("wageRate");
		return wageRate;
	}
	
	public String getfringeRate() {
		String fringeRate = prop.getProperty("fringeRate");
		return fringeRate;
	}

	public String getname() {
		String name = prop.getProperty("name");
		return name;
	}

	public String getaddressL1() {
		String addressL1 = prop.getProperty("addressL1");
		return addressL1;
	}

	public String getcity() {
		String city = prop.getProperty("city");
		return city;
	}

	public String getzipCode() {
		String zipCode = prop.getProperty("zipCode");
		return zipCode;
	}

	public String getcountry() {
		String country = prop.getProperty("country");
		return country;
	}

}


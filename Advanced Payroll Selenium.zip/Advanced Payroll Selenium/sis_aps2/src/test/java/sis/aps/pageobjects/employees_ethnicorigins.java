package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class employees_ethnicorigins {
	
	public WebDriver ldriver;

	public employees_ethnicorigins(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/app-aside-dynamic[1]/div[2]/div[1]/ul[1]/li[7]/a[1]/span[2]") WebElement clkEmployeesTab;
	public void EmployeesTab()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEmployeesTab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Ethnic origins')]") WebElement clkEthnicorigins;
	public void EthnicoriginsScreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEthnicorigins);
		//clkEthnicorigins.click();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-ethnic-origin-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]") WebElement chkSyncADP;
	public boolean chkSyncWithADP()
	{
		return chkSyncADP.isEnabled();
	}
	@FindBy(xpath="//span[contains(text(),'SYNC WITH ADP')]") WebElement clkSyncADP;
	public void clkSyncWithADP()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSyncADP.click();
	}
	@FindBy(xpath="//span[@class='sync ng-star-inserted']") WebElement chkAppDate;
	public String chkAppDateDisplay()
	{
		return chkAppDate.getText();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-ethnic-origin-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]") WebElement chkSyncADPagain;
	public boolean chkSyncADPEnabledBack()
	{
		return chkSyncADPagain.isEnabled();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'check_circle')]") WebElement chkCircle;
	public boolean chkCircleEnabled()
	{
		return chkCircle.isEnabled();
	}
	@FindBy(xpath="//span[@class='react-bootstrap-table-pagin ation-total']") WebElement chkRow;
	public String chkRowDisplay()
	{		
		return chkRow.getText();
	}

}

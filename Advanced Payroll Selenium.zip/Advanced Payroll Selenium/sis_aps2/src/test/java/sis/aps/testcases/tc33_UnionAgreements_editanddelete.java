package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_UnionAgreements_pom;

public class tc33_UnionAgreements_editanddelete extends baseclass {

	@Test
	public void UnionAgreements_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		/* Create a Union then edit and delete */
		unions_UnionAgreements_pom unionAgreement = new unions_UnionAgreements_pom(driver);
		unionAgreement.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		unionAgreement.scrollIntoView();
		Thread.sleep(3000);
		unionAgreement.clickUnionAggrementsTab();
		logger.info("User clicked unionAgreement Leftsliding Sunmenu");
		unionAgreement.clickNewUnionAgreementButton();
		logger.info("User clicked new union agreement button");
		unionAgreement.SetUAgreementId(unionAgreementId);
		logger.info("User entered the union agreement Id");
		unionAgreement.SetUAgreementName(unionAgreementName);
		logger.info("User entered the union agreement Name");
		unionAgreement.ClickUnionHome();
		logger.info("User clicked union home input field");
		Thread.sleep(2000);

		unionAgreement.ClickUnionAValue();
		logger.info("User clicked Union A value");

		Thread.sleep(1000);
		unionAgreement.clickDatepickerButton();
		logger.info("User clicked datepicker icon");
		Thread.sleep(2000);
		unionAgreement.clickCurrentDate();
		logger.info("User clicked current date from calender");
		Thread.sleep(2000);
		unionAgreement.clickSActiveSlider();
		Thread.sleep(2000);
		logger.info("User clicked slider");
		unionAgreement.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (unionAgreement.is_UnionAgreementJobTabDisplayed().equals("Union agreement job")) {
			Assert.assertTrue(true);
			logger.info("User verified union agreement job Tab is dispalyed");
		} else {
			logger.info("union agreement job Tab is not dispalyed");
			System.out.println("Union Agreement Job Tab is not Displayed");
		}

		/*
		 * unionAgreement.ClickUnionAgreementJobTab();
		 * logger.info("User clicked union agreement job Tab"); Thread.sleep(2000);
		 * 
		 * if (unionAgreement.isRow1Displayed()) { Assert.assertTrue(true);
		 * logger.info("union agreement job has been added"); } else {
		 * logger.info("union agreement job has not been added");
		 * System.out.println("Union Agreement Job has not been Added"); Assert.fail();
		 * 
		 * }
		 * 
		 * unionAgreement.ClickUnionAgreementFringesTab();
		 * logger.info("User clicked union agreement fringes Tab"); Thread.sleep(2000);
		 * 
		 * if (unionAgreement.isRow1Displayed()) { Assert.assertTrue(true);
		 * logger.info("union agreement fringes has been added"); } else {
		 * logger.info("union agreement fringes has not been added");
		 * System.out.println("Union Agreement Fringes has not been Added");
		 * Assert.fail(); }
		 * 
		 * unionAgreement.ClickUnionAgreementSpecialPayTab();
		 * logger.info("User clicked union agreement special pay Tab");
		 * Thread.sleep(2000);
		 * 
		 * if (unionAgreement.isRow1Displayed()) { Assert.assertTrue(true);
		 * logger.info("union agreement special pay has been added"); } else {
		 * logger.info("union agreement special pay has not been added");
		 * System.out.println("Union Agreement Special Pay has not been Added");
		 * Assert.fail(); }
		 */

		unionAgreement.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (unionAgreement.isAllUnionAgreementHeaderDisplayed().equals("All union agreements")) {
			Assert.assertTrue(true);
			logger.info("User verified All union agreement header is dispalyed/Union Agreement has been created");
		} else {
			logger.info("All union agreement header is not dispalyed/Union Agreement has not been created");
			Assert.fail();
		}

		Thread.sleep(2000);
		unionAgreement.searchAgreement();
		logger.info("User entered the agreement Id/Name in search input field");
		unionAgreement.ClickEditIcon();
		logger.info("user clicked the edit icon");
		unionAgreement.editUAgreementId();
		logger.info("user entered agreement Id");
		unionAgreement.editUAgreementName();
		logger.info("user entered agreement Name");
		unionAgreement.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(2000);

		if (unionAgreement.IsUAgreementUpdated().contains("Union agreement updated successfully")) {
			Assert.assertTrue(true);
			logger.info("Union agreement has been updated");
			System.out.println("Updated Union Agreement Id and Name");
		} else {
			logger.info("Union agreement has not been updated");
			Assert.fail("Union Agreement Not Updated");
		}

		unionAgreement.clickBackButton();
		logger.info("User clicked back button");

		if (unionAgreement.isAllUnionAgreementHeaderDisplayed().equals("All union agreements")) {
			Assert.assertTrue(true);
			logger.info("User verified All union agreement header is dispalyed");
			System.out.println("Union Agreement has been Updated successfully !");
		} else {
			logger.info("All union agreement header is not dispalyed");
			Assert.fail("All Union Agreement Header is not disaplayed");
		}

		unionAgreement.searchAgreement();
		logger.info("User entered the agreement Id/Name in search input field");
		Thread.sleep(3000);
		unionAgreement.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		unionAgreement.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (unionAgreement.isAllUnionAgreementHeaderDisplayed().equals("All union agreements")) {
			Assert.assertTrue(true);
			logger.info("User verified All union agreement header is dispalyed/union Agreement has been deleted");
			System.out.println("Union Agreement has been Deleted successfully !");
		} else {
			logger.info("All union agreement header is not dispalyed/Union Agreement hasb not been deleted");
			Assert.fail("All Union Agreement Header is not disaplayed");
		}

	}
}

package sis.aps.testcases;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import sis.aps.utilities.readconfig;

public class baseclass{
	
	public WebDriver driver;
	public static Logger logger;
	
	
	readconfig rd=new readconfig();
	public String baseurl=rd.getappurl();
	public String browser=rd.getbrowser();
	public String username=rd.getusername();
	public String password=rd.getpassword();
	//for timesheet
	public String workername=rd.getworkername();
	public String project=rd.getproject();
	public String taskcode=rd.gettaskcode();
	public String payperiod=rd.getpayperiod();
	public String row1date=rd.getrow1eidtdate();
	public String row1projectcode=rd.getrow1eidtpojectcode();
	public String row1taskcode=rd.getrow1eidttaskcode();
	public String row1jobcode=rd.getrow1eidtjobcode();
	public String row1shiftid=rd.getrow1eidtshiftid();
	public String row1specialpay=rd.getrow1eidtspecialpay();
	public String row1regularhours=rd.getrow1eidtregularhours();
	public String row1overtimehours=rd.getrow1eidtovertimehours();
	public String row1doubletimehours=rd.getrow1eidtdoubletimehour();
	public String row1tripletimehours=rd.getrow1eidttripletimehour();
	
	// forCraft
	public String craftId = rd.getcraftId();
	public String craftName = rd.getcraftName();
	// forShift
	public String shiftId = rd.getshiftId();
	public String shiftName = rd.getshiftName();
	public String Rate = rd.getrate();
	// forUnions
	public String unionId = rd.getunionId();
	public String unionName = rd.getunionName();
	// forFringes
	public String fringeId = rd.getfringeId();
	public String fringeName = rd.getfringeName();
	// forSpecialPays
	public String specialPayId = rd.getspecialPayId();
	public String specialPayName = rd.getspecialPayName();
	// forUnionReciprocities
	public String reciprocityId = rd.getreciprocityId();
	// forUnionAgreements
	public String unionAgreementId = rd.getunionAgreementId();
	public String unionAgreementName = rd.getunionAgreementName();
	// forVendors
	public String vendorId = rd.getvendorId();
	public String vendorName = rd.getvendorName();
	// forFieldExpenses
	public String unit = rd.getunit();
	public String baseRate = rd.getbaseRate();
	// forprojects
	public String projectId = rd.getprojectId();
	public String projectName = rd.getprojectName();
	// forProjectCategory
	public String projectCategoryId = rd.getprojectCategoryId();
	public String projectCategoryName = rd.getprojectCategoryName();
	// forProjectCosts
	public String projectCostRate = rd.getprojectCostRate();
	// TaskCodes
	public String taskId = rd.gettaskId();
	public String taskName = rd.gettaskName();
	// Customers
	public String customerId = rd.getcustomerId();
	public String customerName = rd.getcustomerName();
	// PrevailingWages
	public String prevailingwageId = rd.getprevailingwageId();
	public String prevailingwageName = rd.getprevailingwageName();
	public String wageRate = rd.getwageRate();
	public String fringeRate = rd.getfringeRate();
	//ProjectAddress
	public String name = rd.getname();
	public String addressL1 = rd.getaddressL1();
	public String city = rd.getcity();
	public String zipCode = rd.getzipCode();
	public String country = rd.getcountry();
	
	@BeforeClass
	public void setup() throws InterruptedException
	{
		logger=Logger.getLogger(getClass());
		PropertyConfigurator.configure("log4j.properties");
		//logger.info("Browser Launched");
		System.setProperty("webdriver.chrome.driver", browser);
		/*
		ChromeOptions options=new ChromeOptions();
		options.setHeadless(true);
		driver=new ChromeDriver(options);
		*/
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//logger.info("Invoked Application URL");
		driver.get(baseurl);
		Thread.sleep(6000);
        //JavascriptExecutor js=(JavascriptExecutor) driver;
		//WebElement signin=driver.findElement(By.xpath("//button[@id='kt_login_signin_submit']"));
		//js.executeScript("arguments[0].click()", signin);
		driver.findElement(By.xpath("//button[@id='kt_login_signin_submit']")).click();
	//	logger.info("Login Credential Page accessed");
	}
	
	@AfterClass
	public void closebrowser()
	{
		driver.close();
		logger.info("Browser Closed");
	}
	
	@AfterMethod
	public void capturescreenshots(ITestResult result) throws IOException
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			TakesScreenshot ts=(TakesScreenshot) driver;
			File source=ts.getScreenshotAs(OutputType.FILE);
			File target=new File(System.getProperty("user.dir")+"/screenshots/"+result.getName()+".png");
			FileUtils.copyFile(source, target);
		}
	}

}

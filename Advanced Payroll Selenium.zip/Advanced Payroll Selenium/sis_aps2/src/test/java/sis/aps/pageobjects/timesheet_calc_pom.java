package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class timesheet_calc_pom {
	
	public WebDriver ldriver;

	public timesheet_calc_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//below webelements created by Sureshkumar 
	@FindBy(xpath="//span[contains(text(),'Time management')]") WebElement clkTimesheet;
	public void TimesheetTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTimesheet);
		//clkTimesheet.click();
	}
	@FindBy(xpath="//span[contains(text(),'Time entry')]") WebElement clkTimeentry;
	public void TimeentryTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTimeentry);
		//clkTimeentry.click();
	}
	@FindBy(xpath="//span[contains(text(),'All timesheet')]") WebElement clkAllTimesheet;
	public void AllTimesheetScreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAllTimesheet);
		//clkAllTimesheet.click();
	}
	@FindBy(xpath="//button[contains(text(),'New timesheet')]") WebElement btnNewTimesheet;
	public void NewTimesheet()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		btnNewTimesheet.click();
	}
	@FindBy(xpath="//input[@name='worker']") WebElement clkWorkers;
	public void clkWorkersText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkWorkers.click();
	}
	@FindBy(xpath="//input[@name='worker']") WebElement setWorkerfromconfig;
	public void txtworker(String wn)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setWorkerfromconfig.sendKeys(wn);
	}
	@FindBy(xpath="//span[@class='mat-option-text']") WebElement sltWorker;
	public void selectWorker()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltWorker.click();
	}
	@FindBy(xpath="//span[@class='mat-option-text']") WebElement listselection;
	public void listselect()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", listselection);
		//listselection.click();
	}
	//@FindBy(xpath="//input[@id='mat-input-3']") WebElement clkProject;
	@FindBy(xpath="//input[@data-placeholder='Project']") WebElement clkProject;
	public void clkProjectText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkProject.click();
	}
	@FindBy(xpath="//input[@formcontrolname='project']") WebElement setProjectfromconfig;
	public void txtproject(String proj)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setProjectfromconfig.sendKeys(proj);
	}
	@FindBy(xpath="//span[@class='mat-option-text']") WebElement sltProject;
	public void selectproject()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", sltProject);
		//sltProject.click();
	}
	@FindBy(xpath="//input[@data-placeholder='Task code']") WebElement clkTaskcode;
	public void clkTaskcodeText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkTaskcode.click();
	}
	
	@FindBy(xpath="//input[@name='taskCodeId']") WebElement setTaskfromconfig;
	public void txttaskcode(String task)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setTaskfromconfig.sendKeys(task);
	}
	// for if else condition
	@FindBy(xpath="//input[@name='taskCodeId']") WebElement setTaskfromconfigstring;
	public String txttaskcodestring(String task)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setTaskfromconfigstring.sendKeys(task);
		return task;
	}
	@FindBy(xpath="//span[@class='mat-option-text']") WebElement sltTaskcode;
	public void selecttaskcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltTaskcode.click();
	}
	@FindBy(xpath="//b[contains(text(),'T001')]") WebElement txtTaskcode1;
	public void setTaskcode1()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode1);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'T002')]") WebElement txtTaskcode2;
	public void setTaskcode2()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode2);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'T003')]") WebElement txtTaskcode3;
	public void setTaskcode3()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode3);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'Land survey')]") WebElement txtTaskcode4Land;
	public void setTaskcode4Land()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode4Land);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'Fabrication')]") WebElement txtTaskcode5Fabrication;
	public void setTaskcode5Fabrication()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode5Fabrication);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'Bar bending')]") WebElement txtTaskcode6Barbending;
	public void setTaskcode6Barbending()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode6Barbending);
		//txtWorkers.click();
	}
	//@FindBy(xpath="//div[@id='mat-select-value-1']") WebElement clkPayPeriod;
	@FindBy(xpath="//mat-select[@placeholder='Pay period date']") WebElement clkPayPeriod;
	public void clkPayperiodText()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkPayPeriod);
		//clkPayPeriod.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/01/2020 - 11/07/2020 ')]") WebElement txtPayperiod1;
	public void setPayperiod1()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod1);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/08/2020 - 11/14/2020 ')]") WebElement txtPayperiod2;
	public void setPayperiod2()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod2);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/15/2020 - 11/21/2020 ')]") WebElement txtPayperiod3;
	public void setPayperiod3()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod3);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/22/2020 - 11/28/2020 ')]") WebElement txtPayperiod4;
	public void setPayperiod4()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod4);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/29/2020 - 12/05/2020 ')]") WebElement txtPayperiod5;
	public void setPayperiod5()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod5);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/06/2020 - 12/12/2020 ')]") WebElement txtPayperiod6;
	public void setPayperiod6()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod6);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/13/2020 - 12/19/2020 ')]") WebElement txtPayperiod7;
	public void setPayperiod7()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod7);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/20/2020 - 12/26/2020 ')]") WebElement txtPayperiod8;
	public void setPayperiod8()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod8);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/27/2020 - 01/02/2021 ')]") WebElement txtPayperiod9;
	public void setPayperiod9()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod9);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/03/2021 - 01/09/2021 ')]") WebElement txtPayperiod10;
	public void setPayperiod10()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod10);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/10/2021 - 01/16/2021 ')]") WebElement txtPayperiod11;
	public void setPayperiod11()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod11);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/17/2021 - 01/23/2021 ')]") WebElement txtPayperiod12;
	public void setPayperiod12()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod12);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/24/2021 - 01/30/2021 ')]") WebElement txtPayperiod13;
	public void setPayperiod13()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod13);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/31/2021 - 02/06/2021 ')]") WebElement txtPayperiod14;
	public void setPayperiod14()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod14);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/07/2021 - 02/13/2021 ')]") WebElement txtPayperiod15;
	public void setPayperiod15()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod15);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/14/2021 - 02/20/2021 ')]") WebElement txtPayperiod16;
	public void setPayperiod16()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod16);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/21/2021 - 02/27/2021 ')]") WebElement txtPayperiod17;
	public void setPayperiod17()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod17);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/28/2021 - 03/06/2021 ')]") WebElement txtPayperiod18;
	public void setPayperiod18()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod18);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 03/07/2021 - 03/13/2021 ')]") WebElement txtPayperiod19;
	public void setPayperiod19()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod19);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 03/14/2021 - 03/20/2021 ')]") WebElement txtPayperiod20;
	public void setPayperiod20()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod20);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 03/21/2021 - 03/27/2021 ')]") WebElement txtPayperiod21;
	public void setPayperiod21()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod21);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 03/28/2021 - 04/03/2021 ')]") WebElement txtPayperiod22;
	public void setPayperiod22()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod22);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 04/04/2021 - 04/10/2021 ')]") WebElement txtPayperiod23;
	public void setPayperiod23()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod23);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 04/11/2021 - 04/17/2021 ')]") WebElement txtPayperiod24;
	public void setPayperiod24()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod24);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 04/18/2021 - 04/24/2021 ')]") WebElement txtPayperiod25;
	public void setPayperiod25()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod25);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 04/25/2021 - 05/01/2021 ')]") WebElement txtPayperiod26;
	public void setPayperiod26()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod26);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/02/2021 - 05/08/2021 ')]") WebElement txtPayperiod27;
	public void setPayperiod27()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod27);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/09/2021 - 05/15/2021 ')]") WebElement txtPayperiod28;
	public void setPayperiod28()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod1);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/16/2021 - 05/22/2021 ')]") WebElement txtPayperiod29;
	public void setPayperiod29()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod29);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/23/2021 - 05/29/2021 ')]") WebElement txtPayperiod30;
	public void setPayperiod30()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod30);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/30/2021 - 06/05/2021 ')]") WebElement txtPayperiod31;
	public void setPayperiod31()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod31);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 06/06/2021 - 06/12/2021 ')]") WebElement txtPayperiod32;
	public void setPayperiod32()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod32);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/01/2020 - 11/14/2020 ')]") WebElement txtPayperiod33;
	public void setPayperiod33()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod33);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/15/2020 - 11/28/2020 ')]") WebElement txtPayperiod34;
	public void setPayperiod34()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod34);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 11/29/2020 - 12/12/2020 ')]") WebElement txtPayperiod35;
	public void setPayperiod35()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod35);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/13/2020 - 12/26/2020 ')]") WebElement txtPayperiod36;
	public void setPayperiod36()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod36);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 12/27/2020 - 01/09/2021 ')]") WebElement txtPayperiod37;
	public void setPayperiod37()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod37);
		//txtWorkers.click();
	}
	//wantedly i make the xpath change from 2021 to 202
	@FindBy(xpath="//span[contains(text(),' 01/10/202 - 01/23/2021 ')]") WebElement txtPayperiod38;
	public void setPayperiod38()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod38);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 01/24/2021 - 02/06/2021 ')]") WebElement txtPayperiod39;
	public void setPayperiod39()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod39);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/07/2021 - 02/20/2021 ')]") WebElement txtPayperiod40;
	public void setPayperiod40()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod40);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 02/21/2021 - 03/06/2021 ')]") WebElement txtPayperiod41;
	public void setPayperiod41()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod41);
		//txtWorkers.click();
	}
	//wantedly i am changing the xpath from 2021 to 202
	@FindBy(xpath="//span[contains(text(),' 03/07/202 - 03/20/2021 ')]") WebElement txtPayperiod42;
	public void setPayperiod42()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod42);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 03/21/2021 - 04/03/2021 ')]") WebElement txtPayperiod43;
	public void setPayperiod43()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod43);
		//txtWorkers.click();
	}
	//wantedly i am changing the xpath from 2021 to 202
	@FindBy(xpath="//span[contains(text(),' 04/04/202 - 04/17/2021 ')]") WebElement txtPayperiod44;
	public void setPayperiod44()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod44);
		//txtWorkers.click();
	}
	//wantedly i am changing the xpath from 2021 to 202
	@FindBy(xpath="//span[contains(text(),' 04/18/202 - 05/01/2021 ')]") WebElement txtPayperiod45;
	public void setPayperiod45()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod45);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/02/2021 - 05/15/2021 ')]") WebElement txtPayperiod46;
	public void setPayperiod46()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod46);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/16/2021 - 05/29/2021 ')]") WebElement txtPayperiod47;
	public void setPayperiod47()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod47);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 05/30/2021 - 06/12/2021 ')]") WebElement txtPayperiod48;
	public void setPayperiod48()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod48);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 06/13/2021 - 06/26/2021 ')]") WebElement txtPayperiod49;
	public void setPayperiod49()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod49);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 06/27/2021 - 07/10/2021 ')]") WebElement txtPayperiod50;
	public void setPayperiod50()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod50);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 07/11/2021 - 07/24/2021 ')]") WebElement txtPayperiod51;
	public void setPayperiod51()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod51);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 07/25/2021 - 08/07/2021 ')]") WebElement txtPayperiod52;
	public void setPayperiod52()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod52);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 08/08/2021 - 08/21/2021 ')]") WebElement txtPayperiod53;
	public void setPayperiod53()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod53);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 08/22/2021 - 09/04/2021 ')]") WebElement txtPayperiod54;
	public void setPayperiod54()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod54);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 09/05/2021 - 09/18/2021 ')]") WebElement txtPayperiod55;
	public void setPayperiod55()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod55);
		//txtWorkers.click();
	}
	@FindBy(xpath="//span[contains(text(),' 09/19/2021 - 10/02/2021 ')]") WebElement txtPayperiod56;
	public void setPayperiod56()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod56);
		//txtWorkers.click();
	}
	public Object txtpayperiodstring(String payperiod) {
		// TODO Auto-generated method stub
		return payperiod;
	}
	@FindBy(xpath="//button[contains(text(),'Save')]") WebElement clkSave;
	public void btnSave()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSave.click();
	}
	//edit screen page
	@FindBy(xpath="//span[normalize-space()='Edit']") WebElement clkEdit;
	public void Edit()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEdit.click();
	}
	@FindBy(xpath="//span[normalize-space()='Update']") WebElement clkUpdate;
	public void Update()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkUpdate.click();
	}
	@FindBy(xpath="//a[contains(text(),' Process ')]") WebElement clkProcess;
	public void Process()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkProcess.click();
	}
	@FindBy(xpath="//a[contains(text(),' Approve ')]") WebElement clkApprove;
	public void Approve()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkApprove.click();
	}
	@FindBy(xpath="//a[normalize-space()='Details']") WebElement clkDetails;
	public void Details()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDetails.click();
	}
	@FindBy(xpath="//a[contains(text(),' Complete ')]") WebElement clkComplete;
	public void Complete()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkComplete.click();
	}
	@FindBy(xpath="//a[contains(text(),' Create Statement ')]") WebElement clkCreateStatement;
	public void CreateStatement()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkCreateStatement.click();
	}
	@FindBy(xpath="//a[@id='dropdownButton']") WebElement clkdots;
	public void Threedots()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkdots.click();
	}
	@FindBy(xpath="//span[normalize-space()='View calculation']") WebElement clkViewcalculation;
	public void Viewcalculation()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkViewcalculation.click();
	}
	@FindBy(xpath="//td[@aria-label='16 column header  Regular hours']") WebElement chkRegularhours;
	public String chkRegularhoursdisplay()
	{		
		return chkRegularhours.getText();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='0']") WebElement sltrow1;
	public void setRow1()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow1.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='1']") WebElement sltrow2;
	public void setRow2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow2.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='2']") WebElement sltrow3;
	public void setRow3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow3.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='3']") WebElement sltrow4;
	public void setRow4()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow4.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='4']") WebElement sltrow5;
	public void setRow5()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow5.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='5']") WebElement sltrow6;
	public void setRow6()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow6.click();
	}
	@FindBy(xpath="//tr[@role='row' and @aria-rowindex='6']") WebElement sltrow7;
	public void setRow7()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		sltrow7.click();
	}
	
	@FindBy(xpath="//input[@id='date']") WebElement clkeditdate;
	public void seteditdate()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditdate.click();
	}
	@FindBy(xpath="//input[@id='date']") WebElement clreditdate;
	public void cleareditdate()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clreditdate.clear();
	}
	@FindBy(xpath="//input[@id='project___code']") WebElement clkeditprojectcode;
	public void seteditprojectcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditprojectcode.click();
	}
	@FindBy(xpath="//input[@id='project___code']") WebElement clreditprojectcode;
	public void clreditprojectcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clreditprojectcode.clear();
	}
	@FindBy(xpath="//input[@id='projectTask___taskCode___code']") WebElement clkedittaskcode;
	public void setedittaskcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkedittaskcode.click();
	}
	@FindBy(xpath="//input[@id='projectTask___taskCode___code']") WebElement clredittaskcode;
	public void clredittaskcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clredittaskcode.clear();
	}
	@FindBy(xpath="//input[@id='job___code']") WebElement clkeditjobcode;
	public void seteditjobcode()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditjobcode.click();
	}
	@FindBy(xpath="//input[@formcontrolname='shift']") WebElement clkeditshiftid;
	public void seteditshiftid()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditshiftid.click();
	}
	@FindBy(xpath="//b[contains(text(),'Night')]") WebElement txtShiftNight;
	public void setShiftNight()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtShiftNight);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'Swing')]") WebElement txtShiftSwing;
	public void setShiftSwing()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtShiftSwing);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'Day')]") WebElement txtShiftDay;
	public void setShiftDay()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtShiftDay);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'AT_Shift1')]") WebElement txtATShift1;
	public void setATShift1()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtATShift1);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'AT_Shift2')]") WebElement txtATShift2;
	public void setATShift2()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtATShift2);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'AT_Shift3')]") WebElement txtATShift3;
	public void setATShift3()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtATShift3);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'AT_Shift4')]") WebElement txtATShift4;
	public void setATShift4()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtATShift4);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'AT_Shift5')]") WebElement txtATShift5;
	public void setATShift5()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtATShift5);
		//txtWorkers.click();
	}
	@FindBy(xpath="//input[@id='specialPay']") WebElement clkeditspecialpay;
	public void seteditspecialpay()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditspecialpay.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkeditregularhours;
	public void seteditregularhours()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditregularhours.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkeditovertimehours;
	public void seteditovertimehours()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditovertimehours.click();
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkeditdoubletimehours;
	public void seteditdoubletimehours()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkeditdoubletimehours.click();
	}
	@FindBy(xpath="//input[@formcontrolname='tripleTimeHours']") WebElement clkedittripletimehours;
	public void setedittripletimehours()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkedittripletimehours.click();
	}
	/*
	public Object txteditdate(String row1date) {
		return row1date;
	}
	public Object txteditprojectcode(String row1projectcode) {
		return row1projectcode;
	}
	public Object txtedittaskcode(String row1taskcode) {
		return row1taskcode;
	}
	public Object txteditjobcode(String row1jobcode) {
		return row1jobcode;
	}
	public Object txteditshiftid(String row1shiftid) {
		return row1shiftid;
	}
	public Object txteditspecialpay(String row1specialpay) {
		return row1specialpay;
	}
	public Object txteditregularhours(String row1regularhours) {
		return row1regularhours;
	}
	public Object txteditovertimehours(String row1overtimehours) {
		return row1overtimehours;
	}
	public Object txteditdoubletimehours(String row1doubletimehours) {
		return row1doubletimehours;
	}
	public Object txtedittripletimehours(String row1tripletimehours) {
		return row1tripletimehours;
	}
	*/
	@FindBy(xpath="//input[@id='date']") WebElement setrow1editdatefromconfigstring;
	public String txteditdatestring(String datetxt)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1editdatefromconfigstring.sendKeys(datetxt);
		return datetxt;
	}
	@FindBy(xpath="//input[@id='project___code']") WebElement setrow1editprojectcodefromconfigstring;
	public String txteditprojectcodestring(String projecttxt)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1editprojectcodefromconfigstring.sendKeys(projecttxt);
		return projecttxt;
	}
	@FindBy(xpath="//input[@id='projectTask___taskCode___code']") WebElement setrow1edittaskcodefromconfigstring;
	public String txtedittaskcodestring(String tasktxt)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1edittaskcodefromconfigstring.sendKeys(tasktxt);
		return tasktxt;
	}
	@FindBy(xpath="//input[@formcontrolname='shift']") WebElement setrow1shiftconfigstring;
	public String txteditswiftstring(String swifttxt)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1shiftconfigstring.sendKeys(swifttxt);
		return swifttxt;
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement setrow1regularhousfromconfigstring;
	public String txteditregularhoursstring(String regularhrs)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1regularhousfromconfigstring.sendKeys(regularhrs);
		return regularhrs;
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement setrow1overttimehoursfromconfigstring;
	public String txteditovertimehoursstring(String overtimehrs)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1overttimehoursfromconfigstring.sendKeys(overtimehrs);
		return overtimehrs;
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement setrow1doublettimehoursfromconfigstring;
	public String txteditdoubletimehoursstring(String doubleothrs)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1doublettimehoursfromconfigstring.sendKeys(doubleothrs);
		return doubleothrs;
	}
	@FindBy(xpath="//input[@formcontrolname='tripleTimeHours']") WebElement setrow1triplettimehoursfromconfigstring;
	public String txtedittripletimehoursstring(String tripleothrs)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		setrow1triplettimehoursfromconfigstring.sendKeys(tripleothrs);
		return tripleothrs;
	}
	@FindBy(xpath="//a[@type='button' and @class='btn btn-light']") WebElement clkback;
	public void clkbackbtn()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkback);
		//clkback.click();
	}
	@FindBy(xpath="//input[@name='employeeShiftRate']") WebElement getShiftrate;
	public String getShiftratevalue(String shiftrate)
	{
		return getShiftrate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='project___code']") WebElement clrtxt;
	public void clearprojecttxt()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clrtxt);
		clrtxt.clear();
	}
	@FindBy(xpath="//input[@name='project___code']") WebElement clkprojecttxt;
	public void clkprojecttxt()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clrtxt);
		clkprojecttxt.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-timesheet-calculation/div/div[2]/app-timesheet-hourly-fringe-employee/div/ul/li[2]/a") WebElement clkfringestab;
	public void clkfringestab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkfringestab);
		//clkfringestab.click();
	}
	@FindBy(xpath="//input[@name='searchText']") WebElement clksearchtxt;
	public String clicksearchtext(String workernametxt)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clksearchtxt.sendKeys(workernametxt);
		return workernametxt;
	}
	@FindBy(xpath="//th[contains(text(),'Actions')]//following::tr[1]/td[7]/a[1]") WebElement clkfirstedit;
	public void clkfirstedit()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkfirstedit);
		//clkfringestab.click();
	}
	@FindBy(xpath="//a[contains(text(),' Hours')]") WebElement clkhourstab;
	public void clickhourstab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkhourstab);
		//clkfringestab.click();
	}
	@FindBy(xpath="//a[@type='button']//i[1]") WebElement clkbackbtn;
	public void clickbackbtn()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkbackbtn);
		//clkfringestab.click();
	}
	@FindBy(xpath="//a[@type='button' and contains(text(),'Reject')]") WebElement clkreject;
	public void clickreject()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkreject);
		//clkfringestab.click();
	}
	@FindBy(xpath="//td[contains(text(),'Rejected')]//following::a[2]") WebElement clkdelete;
	public void clickdelete()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdelete);
		//clkfringestab.click();
	}
	@FindBy(xpath="//button[contains(text(),'Delete')]") WebElement clkdeletepop;
	public void clickdeletepop()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdeletepop);
		//clkfringestab.click();
	}
}


package sis.aps.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class basepage {

	WebDriver driver;

	public basepage(WebDriver driver) {

		this.driver = driver;

	}

	public void doClick(WebElement element) throws InterruptedException {

		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", element);

	}

	public void doSendKeys(WebElement element, String text) throws InterruptedException {

		Thread.sleep(2000);

		element.sendKeys(text);
	}

	public String doGetText(WebElement element) throws InterruptedException {

		Thread.sleep(2000);

		return element.getText();
	}

	public String getPageTitle() throws InterruptedException {
		Thread.sleep(2000);

		return driver.getTitle();
	}

	public void selectDropDownValueBasedOnVisibleText(List<WebElement> elements, String text) {

		for (WebElement w : elements) {

			if (w.getAttribute("innerHTML").contains(text)) {

				w.click();

				break;
			}

			else {

				System.out.println("Expected value not found in dropdown");
			}
		}
	}

	public void selectDropDownValueBasedOnVisibleText(List<WebElement> elements, String code, String name)
			throws InterruptedException {

		for (WebElement w : elements) {

			if (w.getAttribute("innerHTML").contains(code) && w.getAttribute("innerHTML").contains(name)) {

				doClick(w);
				break;
			}

			else {

				System.out.println("Expected value not found in dropdown");
			}
		}
	}

	public void selectDropDownValueBasedOnIndex(List<WebElement> elements, int index) throws InterruptedException {

		int count = 1;

		for (WebElement w : elements) {

			if (count == index) {

				doClick(w);

				break;
			}

			else {

				count++;
			}
		}
	}

	public void selectMaximumRecordsPerPage() {

		WebElement RecordsPerPage = driver.findElement(By.xpath(
				"//select[@class='form-control form-control-sm font-weight-bold mr-4 border-0 bg-light false ng-untouched ng-pristine ng-valid']"));

		Select select = new Select(RecordsPerPage);

		select.selectByVisibleText("100");
	}

}

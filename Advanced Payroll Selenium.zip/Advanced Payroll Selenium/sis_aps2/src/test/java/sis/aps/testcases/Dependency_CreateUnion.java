package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_Unions_pom;

public class Dependency_CreateUnion extends baseclass {

	@Test
	public void Dependency_CreateUnion() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(5000);
		login.clkSignin();
		Thread.sleep(13000);

		unions_Unions_pom unioncreate = new unions_Unions_pom(driver);
		unioncreate.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		unioncreate.clickUnionsTab2();
		logger.info("User clicked Union Leftsliding Sunmenu");

		/* Create Union 1 */

		unioncreate.clickNewUnionButton();
		logger.info("User clicked new union button");
		unioncreate.EnterUnionId("UnionA");
		logger.info("User entered the Union Id");
		unioncreate.EnterUnionName("UnionA");
		logger.info("User entered the Union Name");
		unioncreate.ClickUcraftId();
		logger.info("User clicked craft Id field");
		Thread.sleep(2000);
		unioncreate.ClickIndex1UcraftIdVal();
		logger.info("User clicked Index 1 value");
		unioncreate.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);
		unioncreate.clickUnionJobTab();
		logger.info("User clicked Union Job Tab");
		Thread.sleep(3000);

		if (unioncreate.verifyAddButton()) {
			Assert.assertTrue(true);
			logger.info("User verified Add button is displayed");
		} else {
			System.out.println("Button Add is not Displayed");
			logger.info("Add button is not dispalyed");
		}

		unioncreate.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (unioncreate.isUnionsHeaderDisplayed().equals("All unions")) {
			Assert.assertTrue(true);
			logger.info("User verified All Unions page Header");

		} else {
			Assert.fail("All Unions Header is not disaplayed");
			logger.info("All Unions Page Header is not dispalyed");
		}

		/* Create Union 2 */

		unioncreate.clickNewUnionButton();
		logger.info("User clicked new union button");
		unioncreate.EnterUnionId("UnionB");
		logger.info("User entered the Union Id");
		unioncreate.EnterUnionName("UnionB");
		logger.info("User entered the Union Name");
		unioncreate.ClickUcraftId();
		logger.info("User clicked craft Id field");
		Thread.sleep(2000);
		unioncreate.ClickIndex1UcraftIdVal();
		logger.info("User clicked Index 1 value");
		unioncreate.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);
		unioncreate.clickUnionJobTab();
		logger.info("User clicked Union Job Tab");
		Thread.sleep(3000);
		if (unioncreate.verifyAddButton()) {
			Assert.assertTrue(true);
			logger.info("User verified Add button is displayed");
		} else {
			System.out.println("Button Add is not Displayed");
			logger.info("Add button is not dispalyed");
		}

		unioncreate.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (unioncreate.isUnionsHeaderDisplayed().equals("All unions")) {
			Assert.assertTrue(true);
			logger.info("User verified All Unions page Header");

		} else {
			Assert.fail("All Unions Header is not disaplayed");
			logger.info("All Unions Page Header is not dispalyed");
		}

		/* Navigate to Homepage */

		Thread.sleep(3000);
		login.clkLogo();
		Thread.sleep(3000);

	}
}

package sis.aps.testcases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timesheet_calc_pom;

public class check extends baseclass {
	@Test
public void xl() throws IOException, InterruptedException {
	
	loginpage_pom login=new loginpage_pom(driver);
	Thread.sleep(3000);
	login.setUserName(username);
	login.setPasword(password);
	Thread.sleep(3000);
	login.clkSignin();
	Thread.sleep(13000);

	timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
	timesheet.TimesheetTab();
	timesheet.AllTimesheetScreen();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//tbody/tr[1]/td[7]/a[1]/mat-icon[1]")).click();
	timesheet.Threedots();
	timesheet.Viewcalculation();
	Thread.sleep(10000);
	String[][] tableVal;
    int rowCount,columnCount;
    double sum=0;
	List<WebElement> tablerowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr"));
	List<WebElement> tablecolumncount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td"));
	rowCount = tablerowcount.size();
    columnCount = tablecolumncount.size();
    System.out.println("Row :"+rowCount+" Clounm :"+columnCount);
    tableVal = new String[rowCount][columnCount];
    for(int w =1 ; w <= rowCount ; w++ ){
        //for(int j =1 ; j <= columnCount ; j++ ) //{
               tableVal[w-1][12] =driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+w+"]/td[12]")).getText();
               double totalhours=Double.parseDouble(tableVal[w-1][12]);
                System.out.println(driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+w+"]/td[12]")).getText());
                sum=sum+totalhours;
           // }
        }
    System.out.println("Sum of all the elements of an array: " +sum);
   String totalhourly= driver.findElement(By.xpath("//*[@id=\"grid_2107871731_0_content_table\"]/tbody/tr/td[6]")).getText();
   double totalhourlycost=Double.parseDouble(totalhourly);
  // System.out.println("Total Hourly Cost: " +totalhourlycost);
   logger.info("Total Hourly Cost: " +totalhourlycost);
   if(totalhourlycost==sum)
   {
	   System.out.println("Total hours Calculated as expected");
   }
   else if(totalhourlycost!=sum)
   {
	   System.out.println("Total hours not Calculated as expected");
   }
}


}

package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;

public class tc16_timesheet_Scenario3 extends baseclass {
	
	@Test
	public void multiple_projects_non_union_employee_prevailing_wage() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		
		timemgmt_alltimesheet_pom timesheet=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		timesheet.WorkersText();
		Thread.sleep(3000);
		timesheet.setWorker3();
		Thread.sleep(2000);
		timesheet.ProjectText();
		timesheet.setProject();
		timesheet.TaskcodeText();
		timesheet.setTaskcode3();
		timesheet.PayperiodText();
		timesheet.setPayperiod();
		timesheet.btnSave();
		Thread.sleep(5000);
		timesheet.Edit();
		timesheet.Regulartime3hr();
		timesheet.shifid();
		timesheet.setShiftid2();
		Thread.sleep(2000);
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.SecondRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		timesheet.Regulartimesecondrow11hr();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ThirdRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		timesheet.shifid();
		timesheet.setShiftidthirdrow();
		timesheet.RegulartimeagainS3();
		timesheet.OvertimeS3();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ForthRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		Thread.sleep(1000);
		timesheet.shifid();
		timesheet.setShiftidfourthrow();
		timesheet.RegulartimeagainS4();
		timesheet.OvertimeagainS3();
		timesheet.DoubletimeagainS3();
		timesheet.TripleTimeS3();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.FifthRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		timesheet.Regulartimefifthrow();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.Process();
		Thread.sleep(1000);
		timesheet.Approve();
		Thread.sleep(1000);
		timesheet.Complete();
		Thread.sleep(1000);
		timesheet.CreateStatement();
		Thread.sleep(2000);
		timesheet.Threedots();
		Thread.sleep(2000);
		timesheet.Viewcalculation();
		Thread.sleep(10000);
		if(timesheet.chkRegularhoursdisplayS3().equals("37"))
        {
			Assert.assertTrue(true);
			System.out.println("Regularhours calculated as expected and the value is: " +timesheet.chkRegularhoursdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTotalhourlycostdisplayS3().equals("2010.0500"))
        {
			Assert.assertTrue(true);
			System.out.println("Totalhourlycost calculated as expected and the value is: " +timesheet.chkTotalhourlycostdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		/*
		if(timesheet.chkTotalcostdisplayS3().equals("2010.0500"))
        {
        	
			Assert.assertTrue(true);
			System.out.println("Totalcost calculated as expected and the value is: " +timesheet.chkTotalcostdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		*/
		if(timesheet.chkDoubletimehoursdisplayS3().equals("2"))
        {
			Assert.assertTrue(true);
			System.out.println("Doubletimehours calculated as expected and the value is: " +timesheet.chkDoubletimehoursdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkOvertimehoursdisplayS3().equals("4"))
        {
			Assert.assertTrue(true);
			System.out.println("Overtimehours calculated as expected and the value is: " +timesheet.chkOvertimehoursdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTripleTimehoursdisplayS3().equals("2"))
        {
			Assert.assertTrue(true);
        	System.out.println("Tripletimehours calculated as expected and the value is: " +timesheet.chkTripleTimehoursdisplayS3());
        }
		else
		{
			Assert.fail();
		}
		/*
		if(timesheet.chkTotalfringecostS3().equals("0.0000"))
        {
			Assert.assertTrue(true);
        	System.out.println("Tripletimehours calculated as expected and the value is: " +timesheet.chkTotalfringecostS3());
        }
		else
		{
			Assert.fail();
		}
		*/
		Thread.sleep(2000);
		timesheet.SelectthirdRow();
		Thread.sleep(2000);
		if(timesheet.chkEmployeerateShiftrate().equals("6.3900"))
		{
			Assert.assertTrue(true);
			System.out.println("value of EmployeerateShiftrate: " +timesheet.chkEmployeerateShiftrate());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkEmployeeratedisplay().equals("12.7800"))
		{
			Assert.assertTrue(true);
			System.out.println("value of Employeerate: " +timesheet.chkEmployeeratedisplay());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkUnionbaseratedisplay().equals("22.3000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of UnionBaseRate: " +timesheet.chkUnionbaseratedisplay());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkUnionshiftratedisplay().equals("14.6500"))
		{
			Assert.assertTrue(true);
			System.out.println("value of UnionShiftRate: " +timesheet.chkUnionshiftratedisplay());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkUnionextrapayratedisplay().equals("7.0000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of UnionExtraRate: " +timesheet.chkUnionextrapayratedisplay());
			
		}
		else
		{
			Assert.fail();
		}
	}

}

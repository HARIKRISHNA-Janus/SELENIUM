package sis.aps.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.legalentities_operatingunits_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc04_syncwithadp_operatingunits extends baseclass {
	
	@Test
	public void masterdata_operatingunits_syncwithadp() throws InterruptedException
	{	
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		logger.info("User logged in Successfully");

		legalentities_operatingunits_pom ou=new legalentities_operatingunits_pom(driver);
		Thread.sleep(3000);
		ou.clkLegalEntitiesTab();
		logger.info("User clicked on LegalEntities Tab");
		ou.clkOperatingUnitsScreen();
		logger.info("User navigated to Operating Units Screen");
		//System.out.println("SYNC WITH ADP is Enabled:" +ou.chkSyncADPEnabled());
		logger.info("SYNC WITH ADP is Enabled:" +ou.chkSyncADPEnabled());
		ou.clkSyncADP();
		logger.info("User Clicked on SYNC ADP");
		Thread.sleep(50000);
		String timestamp=new SimpleDateFormat("M/dd/yy, h:mm a").format(new Date());
		String Systemtime= "System Last Sync: " +timestamp;
		System.out.println(Systemtime);
		System.out.println("App " +ou.chkAppDateDisplay());
		logger.info("SYNC WITH ADP is Enabled Back:" +ou.chkSyncADPEnabledBack());
		logger.info("Circle Stared is Enabled:" +ou.chkCircleEnabled());
		if(ou.chkRowDisplay().equals(" Showing rows 1 to 10 of 30"))
		{
			Assert.assertTrue(true);
		    logger.info("Row Count Equals");
		}
		else
		{
			Assert.fail();
			logger.info("Row Count is not Equal");
		}
	}
}

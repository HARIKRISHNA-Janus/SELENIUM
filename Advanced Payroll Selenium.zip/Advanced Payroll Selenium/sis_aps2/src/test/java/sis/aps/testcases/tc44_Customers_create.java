package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_Customers_pom;

public class tc44_Customers_create extends baseclass {

	@Test
	public void Customers_Create() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(3000);

		/* Create Customer */

		operations_Customers_pom customers = new operations_Customers_pom(driver);

		customers.clickOperationsTab();
		customers.clickCustomersTab();
		Thread.sleep(2000);
		logger.info("User navigated to All Customers Page");
		customers.clickNewCustomerButton();
		customers.SetCustomerId(customerId);
		customers.SetCustomerName(customerName);
		customers.clickSaveButton();

		if (customers.isAllCustomersHeaderDisplayed().equals("All customers")) {
			Assert.assertTrue(true);
			logger.info("Customer has been created Successfully");
		} else {
			Assert.fail();
		}

		Thread.sleep(1000);
		customers.searchCustomer();
		Thread.sleep(2000);
		customers.clickDeleteIcon();
		Thread.sleep(2000);
		customers.clickDeleteButton();
		Thread.sleep(2000);

		if (customers.isAllCustomersHeaderDisplayed().equals("All customers")) {
			Assert.assertTrue(true);
			logger.info("Customer has been Deleted");

		} else {
			Assert.fail();
		}

	}
}

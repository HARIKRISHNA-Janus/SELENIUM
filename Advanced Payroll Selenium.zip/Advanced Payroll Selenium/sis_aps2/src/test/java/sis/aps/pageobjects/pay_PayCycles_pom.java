package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pay_PayCycles_pom {

	public WebDriver ldriver;

	public pay_PayCycles_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "(//span[text()='Pay'])[1]")
	WebElement PayTab;

	public void clickPayTab() {
		PayTab.click();
	}

	@FindBy(xpath = "(//a//span[text()='Pay cycles'])[1]")
	WebElement PayCyclesTab;

	public void clickPayCyclesTab() {
		PayCyclesTab.click();
	}

	@FindBy(xpath = "//h5[contains(text(),'Pay cycles')]")
	WebElement HeaderPayCycles;

	public String IsPayCyclesHeaderDisplayed() {
		return HeaderPayCycles.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in pay cycle id or name']")
	WebElement SearchPayCycles;

	public void SearchPayCycles() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", SearchPayCycles);

		SearchPayCycles.clear();
		SearchPayCycles.click();
		SearchPayCycles.sendKeys("2");
	}

	@FindBy(xpath = "//h3[text()='All pay cycles']//following::table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement AllpayCyclesEditIcon;

	public void ClickAllPayCyclesEditIcon() {
		AllpayCyclesEditIcon.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Pay period')]")
	WebElement PayPeriodsTab;

	public void ClickPayPeriodsTab() {
		PayPeriodsTab.click();
	}

	@FindBy(xpath = "//button//span[text()='Add']")
	WebElement btnAdd;

	public void clickAddButton() {
		btnAdd.click();
	}

	@FindBy(xpath = "//input[@formcontrolname='numberOfPeriods']")
	WebElement InputNoOfPeriods;

	public void SetNoOfPeriods() {
		InputNoOfPeriods.click();
		InputNoOfPeriods.sendKeys("3");
	}

	public void EditNoOfPeriods() {
		InputNoOfPeriods.click();
		InputNoOfPeriods.sendKeys("5");
	}

	@FindBy(xpath = "(//button[@aria-label='Open calendar'])[2]")
	WebElement btnDatePicker;

	public void clickDatepickerButton() {
		btnDatePicker.click();
	}

	@FindBy(xpath = "//tbody[@class='mat-calendar-body']//div[contains(@class,'today')]")
	WebElement currentDate;

	public void clickCurrentDate() {
		currentDate.click();
	}

	@FindBy(xpath = "//mat-select[@formcontrolname='status']")
	WebElement DropDownStatusField;

	public void clickStatusField() {
		DropDownStatusField.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[2]")
	WebElement clkIndex2Value;

	public void ClickIndex2Val() {
		clkIndex2Value.click();
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

	@FindBy(xpath = "//button[@aria-label='Update']")
	WebElement BtnUpdate;

	public void clickUpdateButton() {
		BtnUpdate.click();
	}

	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement BtnDelete;

	public void clickDeleteBTN() {
		BtnDelete.click();
	}

	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickDeleteBtnPopup() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", BtnDeletePopup);
		// BtnDeletePopup.click();
	}

	@FindBy(xpath = "//span[contains(text(),'Pay period has been created')]")
	WebElement PayPeriodCreateMsg;

	public String isPayperiodCreated() {
		return PayPeriodCreateMsg.getText();
	}

	@FindBy(xpath = "//span[contains(text(),'Pay period has been updated')]")
	WebElement PayPeriodUpdatedMsg;

	public String isPayperiodUpdated() {
		return PayPeriodUpdatedMsg.getText();
	}

	@FindBy(xpath = "//span[contains(text(),'Pay period has been deleted')]")
	WebElement PayPeriodDeletedMsg;

	public String isPayperiodDeleted() {
		return PayPeriodDeletedMsg.getText();
	}

}
package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_Vendors_pom {

	public WebDriver ldriver;

	public unions_Vendors_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Unions'])[1]")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		clkUnionsTab.click();
	}

	@FindBy(xpath = "(//a//span[text()='Vendors'])[1]")
	WebElement ScrollVendorTab;

	public void scrollIntoView() {
//		Actions actions = new Actions(ldriver);
//		actions.moveToElement(UAgreementsTab);
//		actions.perform();
		((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", ScrollVendorTab);
	}

	@FindBy(xpath = "(//a//span[text()='Vendors'])[1]")
	WebElement clkVendorsTab;

	public void clickVendorsTab() {
		clkVendorsTab.click();
	}

	@FindBy(xpath = "//button[text()='New vendor']")
	WebElement clkNewVendorButton;

	public void clickNewVendorButton() {
		clkNewVendorButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Vendor id']")
	WebElement txtVendorId;

	public void SetVendorId(String VendorId) {
		txtVendorId.sendKeys(VendorId + randomInt);
	}

	public void editVendorId() {
		txtVendorId.clear();
		txtVendorId.sendKeys("AAVI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder='Vendor name']")
	WebElement txtVendorName;

	public void SetVendorName(String vendorName) {
		txtVendorName.sendKeys(vendorName + randomInt);
	}

	public void editVendorName() {
		txtVendorName.clear();
		txtVendorName.sendKeys("AAVN" + randomInt);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//app-vendor-list//h3[text()='All vendors']")
	WebElement AllVendorsHd;

	public String isVendorHeaderDisplayed() {
		return AllVendorsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in vendor name']")
	WebElement txtsearch;

	public void searchVendor() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-vendor-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class operations_ProjectCosts_pom {

	public WebDriver ldriver;

	public operations_ProjectCosts_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	WebElement clkoperationsTab;

	public void clickOperationsTab() {
		clkoperationsTab.click();
	}

	@FindBy(xpath = "//span[text()='Project costs']")
	WebElement clkProjectCostsTab;

	public void clickProjectCostsTab() {
		clkProjectCostsTab.click();
	}

	@FindBy(xpath = "//button[text()='New project cost']")
	WebElement clkNewProjectCostButton;

	public void clickNewProjectCostButton() {
		clkNewProjectCostButton.click();
	}

	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement btnDatePicker;

	public void clickDatepickerButton() {
		btnDatePicker.click();
	}

	@FindBy(xpath = "//tbody[@class='mat-calendar-body']//div[contains(@class,'today')]")
	WebElement currentDate;

	public void clickCurrentDate() {
		currentDate.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Project name']")
	WebElement ClkProjectName;

	public void ClickProjectName() {
		ClkProjectName.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option//span//b[text()='TestAutomation']")
	WebElement ValTestAutomation;

	public void ClickTestAutomationValue() {
		ValTestAutomation.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Rate']")
	WebElement InputRate;

	public void SetRate(String Rate) {
		InputRate.click();
		InputRate.sendKeys(Rate);
	}

	public void editRate() {
		InputRate.clear();
		InputRate.sendKeys("3");
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//app-project-cost-list//h3[text()='All project costs']")
	WebElement AllProjectCostsHd;

	public String isProjectCostsHeaderDisplayed() {
		return AllProjectCostsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in project name']")
	WebElement txtsearch;

	public void searchProject() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("TestAutomation");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-project-cost-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

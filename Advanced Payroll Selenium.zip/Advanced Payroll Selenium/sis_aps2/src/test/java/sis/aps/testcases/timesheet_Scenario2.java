package sis.aps.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;

public class timesheet_Scenario2 extends baseclass {
	
	@Test
	public void multiple_projects_non_union_employee_prevailing_wage() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		timemgmt_alltimesheet_pom timesheet=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		timesheet.WorkersText();
		Thread.sleep(3000);
		timesheet.setWorker2();
		Thread.sleep(2000);
		timesheet.ProjectText();
		timesheet.setProject();
		timesheet.TaskcodeText();
		timesheet.setTaskcode();
		timesheet.PayperiodText();
		timesheet.setPayperiod();
		timesheet.btnSave();
		Thread.sleep(5000);
		timesheet.Edit();
		timesheet.Regulartime();
		timesheet.DoubletimeS2();
		timesheet.shifid();
		timesheet.setShiftid();
		Thread.sleep(2000);
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.SecondRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		timesheet.ProjectID();
		Thread.sleep(1000);
		timesheet.setProjectlist1();
		Thread.sleep(1000);
		timesheet.TaskID();
		Thread.sleep(1000);
		timesheet.setTasklist2();
		Thread.sleep(1000);
		timesheet.RegulartimeagainS2();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ThirdRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		//timesheet.ProjectID();
		//timesheet.setProjectlist2();
		//timesheet.TaskID();
		//timesheet.setTasklist1();
		timesheet.OvertimeS2();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ForthRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		Thread.sleep(1000);
		timesheet.ProjectID();
		Thread.sleep(1000);
		timesheet.setProjectlist1();
		Thread.sleep(1000);
		timesheet.TaskID();
		Thread.sleep(1000);
		timesheet.setTasklist1();
		Thread.sleep(1000);
		timesheet.shifid();
		timesheet.setShiftid2();
		timesheet.OvertimeagainS2();
		timesheet.DoubletimeagainS2();
		timesheet.TripleTime();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.Process();
		Thread.sleep(1000);
		timesheet.Approve();
		Thread.sleep(1000);
		timesheet.Complete();
		Thread.sleep(1000);
		timesheet.CreateStatement();
		Thread.sleep(2000);
		timesheet.Threedots();
		Thread.sleep(2000);
		timesheet.Viewcalculation();
		Thread.sleep(10000);
		//String empshiftrate=driver.findElement(By.xpath("//input[@name='employeeShiftRate']")).getAttribute("value");
		if(timesheet.chkEmployeerateShiftrate().equals("9.3900"))
		{
			Assert.assertTrue(true);
			System.out.println("value of EmployeerateShiftrate: " +timesheet.chkEmployeerateShiftrate());
			
		}
		else
		{
			Assert.fail();
		}
		//String emprate=driver.findElement(By.xpath("//input[@name='employeeRate']")).getAttribute("value");
		if(timesheet.chkEmployeeratedisplay().equals("18.7800"))
		{
			Assert.assertTrue(true);
			System.out.println("value of Employeerate: " +timesheet.chkEmployeeratedisplay());
			
		}
		else
		{
			Assert.fail();
		}
		Thread.sleep(2000);
		timesheet.SelectRow();
		Thread.sleep(2000);
		if(timesheet.chkPrevailingWageRate().equals("38.0000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of PrevailingWageRate: " +timesheet.chkPrevailingWageRate());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkPrevailingWageFringeRate().equals("7.3000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of PrevailingWageFringeRate: " +timesheet.chkPrevailingWageFringeRate());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkPrevailingWageShiftRate().equals("1.0000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of PrevailingWageShiftRate: " +timesheet.chkPrevailingWageShiftRate());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkPrevailingWageCashInLieu().equals("7.3000"))
		{
			Assert.assertTrue(true);
			System.out.println("value of PrevailingWageCashInLieu: " +timesheet.chkPrevailingWageCashInLieu());
			
		}
		else
		{
			Assert.fail();
		}
		if(timesheet.chkRegularhoursdisplayS2().equals("13"))
        {
			Assert.assertTrue(true);
			System.out.println("Regularhours calculated as expected and the value is: " +timesheet.chkRegularhoursdisplayS2());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTotalhourlycostdisplayS2().equals("1741.0000"))
        {
			Assert.assertTrue(true);
			System.out.println("Totalhourlycost calculated as expected and the value is: " +timesheet.chkTotalhourlycostdisplayS2());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTotalcostdisplayS2().equals("1741.0000"))
        {
        	
			Assert.assertTrue(true);
			System.out.println("Totalcost calculated as expected and the value is: " +timesheet.chkTotalcostdisplayS2());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkDoubletimehoursdisplayS2().equals("7"))
        {
			Assert.assertTrue(true);
			System.out.println("Doubletimehours calculated as expected and the value is: " +timesheet.chkDoubletimehoursdisplayS2());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkOvertimehoursdisplayS2().equals("12"))
        {
			Assert.assertTrue(true);
			System.out.println("Overtimehours calculated as expected and the value is: " +timesheet.chkOvertimehoursdisplayS2());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTripleTimehoursdisplay().equals("2"))
        {
			Assert.assertTrue(true);
        	System.out.println("Tripletimehours calculated as expected and the value is: " +timesheet.chkTripleTimehoursdisplay());
        }
		else
		{
			Assert.fail();
		}
		
	}

}

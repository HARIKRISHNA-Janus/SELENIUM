package sis.aps.testcases;

import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancedlab_leftmenus_pom;
import sis.aps.pageobjects.advancepayroll_Shits_pom;
import sis.aps.pageobjects.employees_positions_pom;
import sis.aps.pageobjects.employees_workers_pom;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.pay_earningcodes_pom;
import sis.aps.pageobjects.prevailingwages_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.pageobjects.unions_Unions_pom;
import sis.aps.utilities.XLUtils;

public class timesheet_fringesrates_scenario2_prevailingwage_greater_than_union_and_employe extends baseclass {
	
	@Test
	public void fringe_prevailingwage_greater_than_union_and_employee() throws Exception {
	
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	loginpage_pom login=new loginpage_pom(driver);
	Thread.sleep(3000);
	login.setUserName(username);
	//logger.info("User entered the Username");
	login.setPasword(password);
	//logger.info("User entered the Password");
	Thread.sleep(3000);
	login.clkSignin();
	//logger.info("User Clicked on Signin button");
	Thread.sleep(10000);
	logger.info("Logged in Successfull");
	
	//earning code rates
	pay_earningcodes_pom earningcode=new pay_earningcodes_pom(driver);
	//earningcode.payTab();
	earningcode.clickpayrollmgmtadptab();
	Thread.sleep(1000);
	earningcode.clickpayrollsetuptab();
	Thread.sleep(1000);
	//logger.info("Navigated to Payroll Mgmt ADP tab");
	earningcode.earningcodesscreen();
	logger.info("Navigated to Earning codes screen");
	earningcode.searchtxtbox();
	Thread.sleep(1000);
	earningcode.searchregular();
	Thread.sleep(2000);
	earningcode.selectedit();
	Thread.sleep(2000);
	String RegularAmtRate=earningcode.selectamtratevalue();
	//logger.info("Regular Amt Rate is: " +RegularAmtRate);
	double RegularAmtRatevalue=Double.parseDouble(RegularAmtRate);
	System.out.println("Regular Amt Rate is: " +RegularAmtRatevalue);
	Thread.sleep(1000);
	earningcode.selectcancel();
	Thread.sleep(1000);
	earningcode.searchtxtbox();
	Thread.sleep(1000);
	earningcode.selectclose();
	Thread.sleep(1000);
	earningcode.searchrovertime();
	Thread.sleep(1000);
	earningcode.selectsecondedit();
	Thread.sleep(2000);
	String OvertimeAmtRate=earningcode.selectamtratevalue();
	//logger.info("Overtime Amt Rate is: " +OvertimeAmtRate);
	double OvertimeAmtRatevalue=Double.parseDouble(OvertimeAmtRate);
	System.out.println("Overtime Amt Rate is: " +OvertimeAmtRatevalue);
	Thread.sleep(1000);
	earningcode.selectcancel();
	Thread.sleep(1000);
	earningcode.searchtxtbox();
	Thread.sleep(1000);
	earningcode.selectclose();
	Thread.sleep(1000);
	earningcode.searchdot();
	Thread.sleep(1000);
	earningcode.selectedit();
	Thread.sleep(2000);
	String DoubletimeAmtRate=earningcode.selectamtratevalue();
	//logger.info("Doubleovertime Amt Rate is: " +DoubletimeAmtRate);
	double DoubletimeAmtRatevalue=Double.parseDouble(DoubletimeAmtRate);
	System.out.println("DoubleOvertime Amt Rate is: " +DoubletimeAmtRatevalue);
	Thread.sleep(1000);
	earningcode.selectcancel();
	Thread.sleep(1000);
	earningcode.searchtxtbox();
	Thread.sleep(1000);
	earningcode.selectclose();
	Thread.sleep(1000);
	earningcode.searchtripleovertime();
	Thread.sleep(1000);
	earningcode.selectedit();
	Thread.sleep(2000);
	String TripletimeAmtRate=earningcode.selectamtratevalue();
	//logger.info("Tripleovertime Amt Rate is: " +TripletimeAmtRate);
	double TripletimeAmtRatevalue=Double.parseDouble(TripletimeAmtRate);
	System.out.println("Triple Overtime Amt Rate is: " +TripletimeAmtRatevalue);
	Thread.sleep(1000);
	earningcode.selectcancel();
	Thread.sleep(1000);
	earningcode.searchtxtbox();
	Thread.sleep(1000);
	earningcode.selectclose();
	Thread.sleep(3000);
	earningcode.clickpayrollsetuptab();
	Thread.sleep(1000);
	earningcode.clickpayrollmgmtadptab();
	
	//Shift rates
	advancepayroll_Shits_pom shiftsrate=new advancepayroll_Shits_pom(driver);
	//shiftsrate.clickAdvancepayrollTab();
	shiftsrate.clickoperationsmgmttab();
	Thread.sleep(1000);
	shiftsrate.clickoperationssetuptab();
	Thread.sleep(1000);
	shiftsrate.clickShiftTab();
	Thread.sleep(2000);
	shiftsrate.clkdroplist();
	Thread.sleep(1000);
	shiftsrate.clkdroplist100();
	Thread.sleep(3000);
	//day rate
	String dayratetxt=shiftsrate.getdayrate();
	int dayratelen=dayratetxt.length();
	String dayratefinalstring=dayratetxt.substring(1,dayratelen);
	double dayratevalue=Double.parseDouble(dayratefinalstring);
	System.out.println("Day rate is: " +dayratevalue);
	//night percentage
	String nightpercenttxt=shiftsrate.getnightpercentage();
	//System.out.println("Night percent txt is: " +nightpercenttxt);
	int nightpercentratelen=(nightpercenttxt.length()-1);
	String nightpercentfinalstring=nightpercenttxt.substring(0,nightpercentratelen);
	double nightpercent=Double.parseDouble(nightpercentfinalstring);
	double nightpercentvalue=nightpercent/100;
	System.out.println("Night percentage is: " +nightpercentvalue);
	//swing rate
	String swingratetxt=shiftsrate.getswingrate();
	int swingratelen=swingratetxt.length();
	String swingratefinalstring=swingratetxt.substring(1,swingratelen);
	double swingratevalue=Double.parseDouble(swingratefinalstring);
	System.out.println("Swing rate is: " +swingratevalue);
	//AT_Shift1 rate
	String atshift1ratetxt=shiftsrate.getautomationshift1();
	int atshift1ratelen=atshift1ratetxt.length();
	String atshift1ratefinalstring=atshift1ratetxt.substring(1,atshift1ratelen);
	double atshift1ratevalue=Double.parseDouble(atshift1ratefinalstring);
	System.out.println("AT_Shift1 rate is: " +atshift1ratevalue);
	//AT_shift2 rate
	String atshift2ratetxt=shiftsrate.getautomationshift2();
	int atshift2ratelen=atshift2ratetxt.length();
	String atshift2ratefinalstring=atshift2ratetxt.substring(1,atshift2ratelen);
	double atshift2ratevalue=Double.parseDouble(atshift2ratefinalstring);
	System.out.println("AT_shift2 rate is: " +atshift2ratevalue);
	//AT_shift4 rate
	String atshift4ratetxt=shiftsrate.getautomationshift4();
	int atshift4ratelen=atshift4ratetxt.length();
	String atshift4ratefinalstring=atshift4ratetxt.substring(1,atshift4ratelen);
	double atshift4ratevalue=Double.parseDouble(atshift4ratefinalstring);
	System.out.println("AT_shift4 rate is: " +atshift4ratevalue);
	//AT_shift3 percentage
	String atshift3percenttxt=shiftsrate.getautomationshift3();
	int atshift3percentratelen=(atshift3percenttxt.length()-1);
	String atshift3percentfinalstring=atshift3percenttxt.substring(0,atshift3percentratelen);
	System.out.println("AT_shift3 len is: " +atshift3percentfinalstring);
	double atshift3percent=Double.parseDouble(atshift3percentfinalstring);
	double atshift3percentvalue=atshift3percent/100;
	System.out.println("AT_shift3 percentage is: " +atshift3percentvalue);
	//AT_shift5 percentage
	String atshift5percenttxt=shiftsrate.getautomationshift5();
	int atshift5percentratelen=(atshift3percenttxt.length()-1);
	String atshift5percentfinalstring=atshift5percenttxt.substring(0,atshift5percentratelen);
	System.out.println("AT_shift3 len is: " +atshift5percentfinalstring);
	double atshift5percent=Double.parseDouble(atshift5percentfinalstring);
	double atshift5percentvalue=atshift5percent/100;
	System.out.println("AT_shift5 percentage is: " +atshift5percentvalue);
	//union rates
	String path="./excel/Fringe calculation_Prevailing wage greater than Union and Employee rates.xlsx";
	String sheetname="Sheet1";
	XLUtils.setExcelFile(path, sheetname);
	int xlrowcount=XLUtils.getRowCount(path, sheetname);
	int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
	System.out.println("Excel Row Count: " +xlrowcount);
	System.out.println("Excel Column Count: " +xlcellcount);
			for(int i=1;i<=xlrowcount;i++)
			{

				String workername=XLUtils.getCellData(path, sheetname, i, 0);
				String project=XLUtils.getCellData(path, sheetname, i, 1);
				String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
				String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
				System.out.println("payperiod is:" +payperiod);
				
				String editdate=XLUtils.getCellData(path, sheetname, i, 4);
				String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
				String edittaskcode=XLUtils.getCellData(path, sheetname, i, 6);
				String editjobid=XLUtils.getCellData(path, sheetname, i, 7);
				String editearningcode=XLUtils.getCellData(path, sheetname, i, 8);
				String editshiftid=XLUtils.getCellData(path, sheetname, i, 9);
				String editspecialpayid=XLUtils.getCellData(path, sheetname, i, 10);
				String editregularhours=XLUtils.getCellData(path, sheetname, i, 11);
				int editrow1regularhourse=Integer.parseInt(editregularhours);
				System.out.println("Row1 Regular hours is: " +editrow1regularhourse);
				String editovertimehours=XLUtils.getCellData(path, sheetname, i, 12);
				int editrow1ovrimehourse=Integer.parseInt(editovertimehours);
				System.out.println("Row1 Overtime hours is: " +editrow1ovrimehourse);
				String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 13);
				int editrow1doubleovrimehourse=Integer.parseInt(editdoubletimehours);
				System.out.println("Row1 Double Overtime hours is: " +editrow1doubleovrimehourse);
				String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 14);
				int editrow1tripleovrimehourse=Integer.parseInt(edittripletimehours);
				System.out.println("Row1 Triple Overtime hours is: " +editrow1tripleovrimehourse);
				
				int editrow1totalhours=editrow1regularhourse+editrow1ovrimehourse+editrow1doubleovrimehourse+editrow1tripleovrimehourse;
				System.out.println("editrow1totalhours is: " +editrow1totalhours);
				
				String editrow2date=XLUtils.getCellData(path, sheetname, i, 15);
				String editrow2projectcode=XLUtils.getCellData(path, sheetname, i, 16);
				String editrow2taskcode=XLUtils.getCellData(path, sheetname, i, 17);
				String editrow2jobid=XLUtils.getCellData(path, sheetname, i, 18);
				String editrow2earningcode=XLUtils.getCellData(path, sheetname, i, 19);
				String editrow2shiftid=XLUtils.getCellData(path, sheetname, i, 20);
				String editrow2specialpayid=XLUtils.getCellData(path, sheetname, i, 21);
				String editrow2regularhours=XLUtils.getCellData(path, sheetname, i, 22);
				String editrow2overtimehours=XLUtils.getCellData(path, sheetname, i, 23);
				String editrow2doubletimehours=XLUtils.getCellData(path, sheetname, i, 24);
				String editrow2tripletimehours=XLUtils.getCellData(path, sheetname, i, 25);
				int editrow2regularhourse=Integer.parseInt(editrow2regularhours);
				System.out.println("row2 Regular hours is: " +editrow2regularhourse);
				int editrow2ovrimehourse=Integer.parseInt(editrow2overtimehours);
				System.out.println("row2 Overtime hours is: " +editrow2ovrimehourse);
				int editrow2doubleovrimehourse=Integer.parseInt(editrow2doubletimehours);
				System.out.println("row2 Double Overtime hours is: " +editrow2doubleovrimehourse);
				int editrow2tripleovrimehourse=Integer.parseInt(editrow2tripletimehours);
				System.out.println("row2 Triple Overtime hours is: " +editrow2tripleovrimehourse);

				int editrow2totalhours=editrow2regularhourse+editrow2ovrimehourse+editrow2doubleovrimehourse+editrow2tripleovrimehourse;
				System.out.println("editrow2totalhours is: " +editrow2totalhours);
				
				String editrow3date=XLUtils.getCellData(path, sheetname, i, 26);
				String editrow3projectcode=XLUtils.getCellData(path, sheetname, i, 27);
				String editrow3taskcode=XLUtils.getCellData(path, sheetname, i, 28);
				String editrow3jobid=XLUtils.getCellData(path, sheetname, i, 29);
				String editrow3earningcode=XLUtils.getCellData(path, sheetname, i, 30);
				String editrow3shiftid=XLUtils.getCellData(path, sheetname, i, 31);
				String editrow3specialpayid=XLUtils.getCellData(path, sheetname, i, 32);
				String editrow3regularhours=XLUtils.getCellData(path, sheetname, i, 33);
				String editrow3overtimehours=XLUtils.getCellData(path, sheetname, i, 34);
				String editrow3doubletimehours=XLUtils.getCellData(path, sheetname, i, 35);
				String editrow3tripletimehours=XLUtils.getCellData(path, sheetname, i, 36);
				int editrow3regularhourse=Integer.parseInt(editrow3regularhours);
				System.out.println("row3 Regular hours is: " +editrow3regularhourse);
				int editrow3ovrimehourse=Integer.parseInt(editrow3overtimehours);
				System.out.println("row3 Overtime hours is: " +editrow3ovrimehourse);
				int editrow3doubleovrimehourse=Integer.parseInt(editrow3doubletimehours);
				System.out.println("row3 Double Overtime hours is: " +editrow3doubleovrimehourse);
				int editrow3tripleovrimehourse=Integer.parseInt(editrow3tripletimehours);
				System.out.println("row3 Triple Overtime hours is: " +editrow3tripleovrimehourse);
				
				int editrow3totalhours=editrow3regularhourse+editrow3ovrimehourse+editrow3doubleovrimehourse+editrow3tripleovrimehourse;
				System.out.println("editrow3totalhours is: " +editrow3totalhours);
				
				String editrow4date=XLUtils.getCellData(path, sheetname, i, 37);
				String editrow4projectcode=XLUtils.getCellData(path, sheetname, i, 38);
				String editrow4taskcode=XLUtils.getCellData(path, sheetname, i, 39);
				String editrow4jobid=XLUtils.getCellData(path, sheetname, i, 40);
				String editrow4earningcode=XLUtils.getCellData(path, sheetname, i, 41);
				String editrow4shiftid=XLUtils.getCellData(path, sheetname, i, 42);
				String editrow4specialpayid=XLUtils.getCellData(path, sheetname, i, 43);
				String editrow4regularhours=XLUtils.getCellData(path, sheetname, i, 44);
				String editrow4overtimehours=XLUtils.getCellData(path, sheetname, i, 45);
				String editrow4doubletimehours=XLUtils.getCellData(path, sheetname, i, 46);
				String editrow4tripletimehours=XLUtils.getCellData(path, sheetname, i, 47);
				int editrow4regularhourse=Integer.parseInt(editrow4regularhours);
				System.out.println("row4 Regular hours is: " +editrow4regularhourse);
				int editrow4ovrimehourse=Integer.parseInt(editrow4overtimehours);
				System.out.println("row4 Overtime hours is: " +editrow4ovrimehourse);
				int editrow4doubleovrimehourse=Integer.parseInt(editrow4doubletimehours);
				System.out.println("row4 Double Overtime hours is: " +editrow4doubleovrimehourse);
				int editrow4tripleovrimehourse=Integer.parseInt(editrow4tripletimehours);
				System.out.println("row4 Triple Overtime hours is: " +editrow4tripleovrimehourse);
				
				int editrow4totalhours=editrow4regularhourse+editrow4ovrimehourse+editrow4doubleovrimehourse+editrow4tripleovrimehourse;
				System.out.println("editrow4totalhours is: " +editrow4totalhours);
				
				String editrow5date=XLUtils.getCellData(path, sheetname, i, 48);
				String editrow5projectcode=XLUtils.getCellData(path, sheetname, i, 49);
				String editrow5taskcode=XLUtils.getCellData(path, sheetname, i, 50);
				String editrow5jobid=XLUtils.getCellData(path, sheetname, i, 51);
				String editrow5earningcode=XLUtils.getCellData(path, sheetname, i, 52);
				String editrow5shiftid=XLUtils.getCellData(path, sheetname, i, 53);
				String editrow5specialpayid=XLUtils.getCellData(path, sheetname, i, 54);
				String editrow5regularhours=XLUtils.getCellData(path, sheetname, i, 55);
				String editrow5overtimehours=XLUtils.getCellData(path, sheetname, i, 56);
				String editrow5doubletimehours=XLUtils.getCellData(path, sheetname, i, 57);
				String editrow5tripletimehours=XLUtils.getCellData(path, sheetname, i, 58);
				int editrow5regularhourse=Integer.parseInt(editrow5regularhours);
				System.out.println("row5 Regular hours is: " +editrow5regularhourse);
				int editrow5ovrimehourse=Integer.parseInt(editrow5overtimehours);
				System.out.println("row5 Overtime hours is: " +editrow5ovrimehourse);
				int editrow5doubleovrimehourse=Integer.parseInt(editrow5doubletimehours);
				System.out.println("row5 Double Overtime hours is: " +editrow5doubleovrimehourse);
				int editrow5tripleovrimehourse=Integer.parseInt(editrow5tripletimehours);
				System.out.println("row5 Triple Overtime hours is: " +editrow5tripleovrimehourse);
				
				int editrow5totalhours=editrow5regularhourse+editrow5ovrimehourse+editrow5doubleovrimehourse+editrow5tripleovrimehourse;
				System.out.println("editrow5totalhours is: " +editrow5totalhours);
				
				//Total hours for employee in timesheet period : Here you should add all edit hours total hours and use it for Flat Employee Based calculation method.
				int totaledithours=editrow1totalhours+editrow2totalhours+editrow3totalhours+editrow4totalhours+editrow5totalhours;
				System.out.println("Total Edit Hours is: " +totaledithours);
				
				//workers detail
				employees_workers_pom workerdetails=new employees_workers_pom(driver);
				workerdetails.clickpayrollmgmtadptab();
				Thread.sleep(1000);
				workerdetails.clickworkerstab();
				Thread.sleep(1000);
				workerdetails.WorkersScreen();
				Thread.sleep(2000);
				workerdetails.clkSearchbtn(workername);
				Thread.sleep(2000);
				workerdetails.clkEditbtn();
				Thread.sleep(2000);
				workerdetails.clkworkercurrentpositiontab();
				Thread.sleep(2000);
				//hourlyrate
				String hourlyrateamttxt=workerdetails.getHorlyrateamt();
				int hourlyrateamtlen=hourlyrateamttxt.length();
				String hourlyrateamtfinalstring=hourlyrateamttxt.substring(1,hourlyrateamtlen);
				float hourlyrateamt=Float.parseFloat(hourlyrateamtfinalstring);
				//double hourlyrateamt=Double.parseDouble(hourlyrateamtfinalstring);
				System.out.println("Hourly Amt Rate is: " +hourlyrateamt);
				//job code
				String jobcode=workerdetails.getjobcode();
				System.out.println("Jobcode is: " +jobcode);
				String positionid=workerdetails.getpositionid();
				System.out.println("Positionid is: " +positionid);
				Thread.sleep(3000);
				workerdetails.clickworkerstab();
				Thread.sleep(1000);
				workerdetails.clickpayrollmgmtadptab();
				Thread.sleep(1000);
				//Employee>Positions
				employees_positions_pom positions=new employees_positions_pom(driver);
				//positions.EmployeesTab();
				positions.clickpayrollmgmtadptab();
				Thread.sleep(1000);
				positions.clickworkersetuptab();
				Thread.sleep(1000);
				positions.clkpositionsscreen();
				Thread.sleep(2000);
				positions.clksearchtextbox();
				positions.txtworkersearchstring(positionid);
				Thread.sleep(2000);
				positions.clkEdit();
				Thread.sleep(2000);
				String homeunionidvalue=positions.gethomeunionidvalue();
				//logger.info("Home Union ID 1st is: " +homeunionidvalue);
				//No Extr pay for this worker , hence i am making it as 0
				/*
				String unionetrapaystring=positions.getunionextrapayvalue();
				float unionextrapay=(float) Double.parseDouble(unionetrapaystring);
				logger.info("Union Extra pay is: " +unionextrapay);
				*/
				int unionextrapay=0;
				//String unionetrapaystring=positions.getunionextrapaytextvalue();
				//System.out.println("extra pay rate is: " +unionetrapaystring);
				//String homeunionidvalue1=positions.gethomeunionidvalue();
				String homeunionid=homeunionidvalue.substring(0,10);
				//System.out.print("Home Union ID is: " +homeunionid);
				Thread.sleep(2000);
				positions.clkCancel();
				Thread.sleep(3000);
				//job code rate in union
				unions_Unions_pom jobcoderate=new unions_Unions_pom(driver);
				//jobcoderate.clickUnionsTab();
				jobcoderate.clickunionmgmttab();
				Thread.sleep(1000);
				jobcoderate.clickunionsetuptab();
				Thread.sleep(1000);
				jobcoderate.clickUnionsTab2();
				Thread.sleep(4000);
				jobcoderate.clksearchtxtbtn(homeunionid);
				Thread.sleep(4000);
				jobcoderate.clkeditbtn();
				Thread.sleep(2000);
				jobcoderate.clickUnionFringeTab();
				Thread.sleep(2000);
				String fringecapstring=jobcoderate.getfringecapvalue();
				Thread.sleep(1000);
				float fixedcapvalue=Float.parseFloat(fringecapstring);
				System.out.println("Fringe Cap Value for fixed hourly cost is: " +fixedcapvalue);
				jobcoderate.clickUnionAgreementTab();
				Thread.sleep(4000);
				/*
				jobcoderate.clksearchtxt(jobcode);
				Thread.sleep(1000);
				jobcoderate.clksearchlensbtn();
				Thread.sleep(1000);
				*/
				String jobcoderatevalue=jobcoderate.getjobcoderate();
				//logger.info("Jobcode Rate String is: " +jobcoderatevalue);
				float jobrateamtvalue=Float.parseFloat(jobcoderatevalue);
				//double jobrateamtvalue=Double.parseDouble(jobcoderatevalue);
				logger.info("Jobcode Rate is: " +jobrateamtvalue);
				Thread.sleep(3000);
				//Fringes Rates in union
				jobcoderate.clkunionagreementfringestab();
				Thread.sleep(2000);
				String fixedhourlyratestring=jobcoderate.getfixedhourlyrate();
				float fixedhourlyratevalue=Float.parseFloat(fixedhourlyratestring);
				//double fixedhourlyratevalue=Double.parseDouble(fixedhourlyratestring);
				logger.info("Fixedhourlyrate Rate is: " +fixedhourlyratevalue);
				Thread.sleep(1000);
				String fixedpercentageratestring=jobcoderate.getfixedpercentagerate();
				float fixedpercentageratevalue=Float.parseFloat(fixedpercentageratestring);
			    //double fixedpercentageratevalue=Double.parseDouble(fixedpercentageratestring);
				logger.info("Fixedpercentagerate Rate is: " +fixedpercentageratevalue);
				Thread.sleep(1000);
				String flatemployeebasedratestring=jobcoderate.getflatemployedbaserate();
				float flatemployeebasedratevalue=Float.parseFloat(flatemployeebasedratestring);
				logger.info("flatemployeebased Rate is: " +flatemployeebasedratevalue);
				Thread.sleep(1000);
				String standardearningsstring=jobcoderate.getstdearningsrate();
				float standardearningsratevalue=Float.parseFloat(standardearningsstring);
				logger.info("standardearnings Rate is: " +standardearningsratevalue);
				Thread.sleep(1000);
				String totalearnedhoursstring=jobcoderate.getearnedhoursrate();
				float totalearnedhoursratevalue=Float.parseFloat(totalearnedhoursstring);
				logger.info("totalearnedhours Rate is: " +totalearnedhoursratevalue);
				Thread.sleep(1000);
				//to get the Prevailing Wage Rate
				advancedlab_leftmenus_pom prevailingwage=new advancedlab_leftmenus_pom(driver);
				prevailingwage.clickoperationsmgmttab();
				Thread.sleep(1000);
				prevailingwage.clickoperationssetupscreen();
				Thread.sleep(1000);
				prevailingwage.clickPrevailingwagescreen();
				Thread.sleep(1000);
				prevailingwages_pom prevailingerate=new prevailingwages_pom(driver);
				prevailingerate.searchtxtbox();
				Thread.sleep(1000);
				prevailingerate.clickedit();
				Thread.sleep(1000);
				prevailingerate.clickprevailingwagtab();
				Thread.sleep(1000);
				String wageratestring=prevailingerate.getwageratevalue();
				float wageratebeforeformat=Float.parseFloat(wageratestring);
				DecimalFormat wagerateafterformat=new DecimalFormat("#.####");
				float wagerater=Float.valueOf(wagerateafterformat.format(wageratebeforeformat));
				System.out.println("Wage rate is: " +wagerater);
				String fringeratestring=prevailingerate.getfringeratevalue();
				float fringeratebeforeformat=Float.parseFloat(fringeratestring);
				DecimalFormat fringerateafterformat=new DecimalFormat("#.####");
				//The correct cash in lieu formula has to be provide, so until i am using the fringe rate, as both are always equal.informed by functional team
				float fringerate=Float.valueOf(fringerateafterformat.format(fringeratebeforeformat));
				System.out.println("Fringe rate is: " +fringerate);
				float prevailingwageratebeforeformat=wagerater+fringerate;
				DecimalFormat prevailingwagerateafterformat=new DecimalFormat("#.####");
				float prevailingwagerate=Float.valueOf(prevailingwagerateafterformat.format(prevailingwageratebeforeformat));
				System.out.println("PrevailingWage Rate is: " +prevailingwagerate);
				
				//row1 calculation starts
				//prevailing hourly rate calc is Prevailing Wage Rate amount = (PW rate + Shift rate)*Earning code multiplier + Cash in lieu
				//for this woker there is no shift rate
				// hourlyrate for edit row1 for regular (if special pay is fixed then we should add special also) // No Extra pay for this worker hence i made it as 0 and no shift rate so removing it
				float hourlyratebeforeformatregularrow1=(float) ((wagerater)*RegularAmtRatevalue)+fringerate;
				//System.out.println("Hourly rate before format row1 is: " +hourlyratebeforeformatregularrow1);
				DecimalFormat hourlyrateforformatregularrow1= new DecimalFormat("#.####");
				float hourlyraterow1forregular=Float.valueOf(hourlyrateforformatregularrow1.format(hourlyratebeforeformatregularrow1));
				System.out.println("Hourly rate for regular is row1 is: " +hourlyraterow1forregular);
				
				// hourlyrate for edit row1 for overtime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatovertimerow1=(float) ((wagerater)*OvertimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row1 is: " +hourlyratebeforeformatovertimerow1);
				DecimalFormat hourlyrateforformatovertimerow1= new DecimalFormat("#.####");
				float hourlyraterow1forovertime=Float.valueOf(hourlyrateforformatovertimerow1.format(hourlyratebeforeformatovertimerow1));
				//System.out.println("Hourly rate for overtime is row1 is: " +hourlyraterow1forovertime);
				
				// hourlyrate for edit row1 for doubleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatdoubleovertimerow1=(float) ((wagerater)*DoubletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row1 is: " +hourlyratebeforeformatdoubleovertimerow1);
				DecimalFormat hourlyrateforformatdoubleovertimerow1= new DecimalFormat("#.####");
				float hourlyraterow1fordoubleovertime=Float.valueOf(hourlyrateforformatdoubleovertimerow1.format(hourlyratebeforeformatdoubleovertimerow1));
				//System.out.println("Hourly rate for doubleovertime is row1 is: " +hourlyraterow1fordoubleovertime);
				
				// hourlyrate for edit row1 for tripleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformattripleovertimerow1=(float) ((wagerater)*TripletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row1 is: " +hourlyratebeforeformattripleovertimerow1);
				DecimalFormat hourlyrateforformattripleovertimerow1= new DecimalFormat("#.####");
				float hourlyraterow1fortripleovertime=Float.valueOf(hourlyrateforformattripleovertimerow1.format(hourlyratebeforeformattripleovertimerow1));
				//System.out.println("Hourly rate for tripleovertime is row1 is: " +hourlyraterow1fortripleovertime);
				/*
				float hourlyraterow1format=hourlyraterow1forregular+hourlyraterow1forovertime+hourlyraterow1fordoubleovertime+hourlyraterow1fortripleovertime;
				//System.out.println("Hourly rate before format row1 is: " +hourlyraterow1format);
				DecimalFormat hourlyraterow1decimalformat= new DecimalFormat("#.####");
				float hourlyraterow1=Float.valueOf(hourlyraterow1decimalformat.format(hourlyraterow1format));
				//System.out.println("Hourly rate for row1 is: " +hourlyraterow1);
				*/
				
				//Standard Earnings Calculation method for row1
				
				float standardearningamountforregularforrow1=(float) ((hourlyraterow1forregular/RegularAmtRatevalue)*editrow1regularhourse);
				////System.out.println("Standard Earnings Calc for regular row1 is: " +standardearningamountforregularforrow1);
				float standardearningsforregularforrow1=(standardearningamountforregularforrow1*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for regular row1 is: " +standardearningsforregularforrow1);
				DecimalFormat standardearningsforregularforrow1df = new DecimalFormat("#.####");
				float standardearningsforregularforrow1format=Float.valueOf(standardearningsforregularforrow1df.format(standardearningsforregularforrow1));
				////System.out.println("Standard Earnings Fringe Amount for regular row1 format is: " +standardearningsforregularforrow1format);
				
				float standardearningamountforovertimeforrow1=(float) ((hourlyraterow1forovertime/OvertimeAmtRatevalue)*editrow1ovrimehourse);
				////System.out.println("Standard Earnings Calc for overtime row1 is: " +standardearningamountforovertimeforrow1);
				float standardearningsforovertimeforrow1=(standardearningamountforovertimeforrow1*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for overtime row1 is: " +standardearningsforovertimeforrow1);
				DecimalFormat standardearningsforovertimeforrow1df = new DecimalFormat("#.####");
				float standardearningsforovertimeforrow1format=Float.valueOf(standardearningsforovertimeforrow1df.format(standardearningsforovertimeforrow1));
				////System.out.println("Standard Earnings Fringe Amount for overtime row1 format is: " +standardearningsforovertimeforrow1format);
				
				float standardearningamountfordoubleovertimeforrow1=(float) ((hourlyraterow1fordoubleovertime/DoubletimeAmtRatevalue)*editrow1doubleovrimehourse);
				////System.out.println("Standard Earnings Calc for doubleovertime row1 is: " +standardearningamountfordoubleovertimeforrow1);
				float standardearningsfordoubleovertimeforrow1=(standardearningamountfordoubleovertimeforrow1*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row1 is: " +standardearningsfordoubleovertimeforrow1);
				DecimalFormat standardearningsfordoubleovertimeforrow1df = new DecimalFormat("#.####");
				float standardearningsfordoubleovertimeforrow1format=Float.valueOf(standardearningsfordoubleovertimeforrow1df.format(standardearningsfordoubleovertimeforrow1));
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row1 format is: " +standardearningsfordoubleovertimeforrow1format);
				
				float standardearningamountfortripleovertimeforrow1=(float) ((hourlyraterow1fortripleovertime/TripletimeAmtRatevalue)*editrow1tripleovrimehourse);
				////System.out.println("Standard Earnings Calc for tripleovertime row1 is: " +standardearningamountfortripleovertimeforrow1);
				float standardearningsfortripleovertimeforrow1=(standardearningamountfortripleovertimeforrow1*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row1 is: " +standardearningsfortripleovertimeforrow1);
				DecimalFormat standardearningsfortripleovertimeforrow1df = new DecimalFormat("#.####");
				float standardearningsfortripleovertimeforrow1format=Float.valueOf(standardearningsfortripleovertimeforrow1df.format(standardearningsfortripleovertimeforrow1));
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row1 format is: " +standardearningsfortripleovertimeforrow1format);
				
				//Sum of Standard Earnings row1
				float standardearningsrow1format=standardearningsforregularforrow1format+standardearningsforovertimeforrow1format+standardearningsfordoubleovertimeforrow1format+standardearningsfortripleovertimeforrow1format;
				////System.out.println("Standard Earnings Fringe Amount row1 is: " +standardearningsrow1format);
				DecimalFormat standardearningsrow1decimalformat = new DecimalFormat("#.####");
				float standardearningsrow1=Float.valueOf(standardearningsrow1decimalformat.format(standardearningsrow1format));
				logger.info("Standard Earnings Fringe Amount row1 is: " +standardearningsrow1);
				
				//Fixed Percentage calculation method for edit row1
				float fixedpercentageregularrow1=hourlyraterow1forregular*editrow1regularhourse;
				//System.out.println("fixedpercentageregular row1 is: " +fixedpercentageregularrow1);
				float fixedpercentageovertimerow1=hourlyraterow1forovertime*editrow1ovrimehourse;
				//System.out.println("fixedpercentageovertime row1 is: " +fixedpercentageovertimerow1);
				float fixedpercentagdoubleeovertimerow1=hourlyraterow1fordoubleovertime*editrow1doubleovrimehourse;
				//System.out.println("fixedpercentagdoubleeovertime row1 is: " +fixedpercentagdoubleeovertimerow1);
				float fixedpercentagtripleeovertimerow1=hourlyraterow1fortripleovertime*editrow1tripleovrimehourse;
				//System.out.println("fixedpercentagtripleeovertime row1 is: " +fixedpercentagtripleeovertimerow1);
				float earningamountrow1=fixedpercentageregularrow1+fixedpercentageovertimerow1+fixedpercentagdoubleeovertimerow1+fixedpercentagtripleeovertimerow1;
				//double earningamount=fixedpercentageregular+fixedpercentageovertime+fixedpercentagdoubleeovertime+fixedpercentagtripleeovertime;
				//System.out.println("Earning Amount row1 is: " +earningamountrow1);
				float fixedpercentagerow1beforeformat=(earningamountrow1*fixedpercentageratevalue)/100;
				//System.out.println("Fixed percentage row1 is: " +fixedpercentagerow1beforeformat);
				DecimalFormat fixedpercentagerow1format = new DecimalFormat("#.####");
				float fixedpercentagerow1=Float.valueOf(fixedpercentagerow1format.format(fixedpercentagerow1beforeformat));
				logger.info("Fixed percentage Fringe Amount row1 is: " +fixedpercentagerow1);
				
				//Fixed Hourly rate calculation method edit row1
				float fixedhourlyraterow1=fixedhourlyratevalue*editrow1totalhours;
				//double fixedhourlyrate=fixedhourlyratevalue*editrow1totalhours;
				logger.info("Fixed Hourly Fringe Amount row1 is: " +fixedhourlyraterow1);
				float fringevalueafterrow1=fixedcapvalue-fixedhourlyraterow1;
			//	System.out.println("Fringe Cap Value after row1 value minus is: " +fringevalueafterrow1);
				
				//Total Earned Hours calculation method edit row1
				double earnedhoursrow1=((editrow1regularhourse*RegularAmtRatevalue)+(editrow1ovrimehourse*OvertimeAmtRatevalue)+(editrow1doubleovrimehourse*DoubletimeAmtRatevalue)+(editrow1tripleovrimehourse*TripletimeAmtRatevalue));
				//System.out.println("Earned Hours row1 is: " +earnedhoursrow1);
				double totalearnedhoursrow1=totalearnedhoursratevalue*earnedhoursrow1;
				logger.info("Total Earned Fringe Amount row1 is: " +totalearnedhoursrow1);
				
				//Flat Employee Based calculation method for edit row1
				float flatemployeebasedrow1beforeformat=(editrow1totalhours*flatemployeebasedratevalue)/totaledithours;
				//logger.info("Flat Employee Based Fringe Amount row1 is: " +flatemployeebasedrow1beforeformat);
				DecimalFormat flatemployeebasedrow1afterformat= new DecimalFormat("#.####");
				float flatemployeebasedrow1=Float.valueOf(flatemployeebasedrow1afterformat.format(flatemployeebasedrow1beforeformat));
				logger.info("Flat Employee Based Fringe Amount row1 is: " +flatemployeebasedrow1);
				
				//row2 calculation starts
				// hourlyrate for edit row2 for regular (if special pay is fixed then we should add special also) and Shift not mentioned in row excel
				float hourlyratebeforeformatregularrow2=(float) ((wagerater)*RegularAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row2 is: " +hourlyratebeforeformatregularrow2);
				DecimalFormat hourlyrateforformatregularrow2= new DecimalFormat("#.####");
				float hourlyraterow2forregular=Float.valueOf(hourlyrateforformatregularrow2.format(hourlyratebeforeformatregularrow2));
				//System.out.println("Hourly rate for regular is row2 is: " +hourlyraterow2forregular);
				
				// hourlyrate for edit row2 for overtime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatovertimerow2=(float) ((wagerater)*OvertimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row2 is: " +hourlyratebeforeformatovertimerow2);
				DecimalFormat hourlyrateforformatovertimerow2= new DecimalFormat("#.####");
				float hourlyraterow2forovertime=Float.valueOf(hourlyrateforformatovertimerow2.format(hourlyratebeforeformatovertimerow2));
				//System.out.println("Hourly rate for overtime is row2 is: " +hourlyraterow2forovertime);
				
				// hourlyrate for edit row2 for doubleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatdoubleovertimerow2=(float) ((wagerater)*DoubletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row2 is: " +hourlyratebeforeformatdoubleovertimerow2);
				DecimalFormat hourlyrateforformatdoubleovertimerow2= new DecimalFormat("#.####");
				float hourlyraterow2fordoubleovertime=Float.valueOf(hourlyrateforformatdoubleovertimerow2.format(hourlyratebeforeformatdoubleovertimerow2));
				//System.out.println("Hourly rate for doubleovertime is row2 is: " +hourlyraterow2fordoubleovertime);
				
				// hourlyrate for edit row2 for tripleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformattripleovertimerow2=(float) ((wagerater)*TripletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row2 is: " +hourlyratebeforeformattripleovertimerow2);
				DecimalFormat hourlyrateforformattripleovertimerow2= new DecimalFormat("#.####");
				float hourlyraterow2fortripleovertime=Float.valueOf(hourlyrateforformattripleovertimerow2.format(hourlyratebeforeformattripleovertimerow2));
				//System.out.println("Hourly rate for tripleovertime is row2 is: " +hourlyraterow2fortripleovertime);
				
				//Standard Earnings Calculation method for row2
				
				float standardearningamountforregularforrow2=(float) ((hourlyraterow2forregular/RegularAmtRatevalue)*editrow2regularhourse);
				//System.out.println("Standard Earnings Calc for regular row2 is: " +standardearningamountforregularforrow2);
				float standardearningsforregularforrow2=(standardearningamountforregularforrow2*standardearningsratevalue)/100;
				//System.out.println("Standard Earnings Fringe Amount for regular row2 is: " +standardearningsforregularforrow2);
				DecimalFormat standardearningsforregularforrow2df = new DecimalFormat("#.####");
				float standardearningsforregularforrow2format=Float.valueOf(standardearningsforregularforrow2df.format(standardearningsforregularforrow2));
				//System.out.println("Standard Earnings Fringe Amount for regular row2 format is: " +standardearningsforregularforrow2format);
				
				float standardearningamountforovertimeforrow2=(float) ((hourlyraterow2forovertime/OvertimeAmtRatevalue)*editrow2ovrimehourse);
				//System.out.println("Standard Earnings Calc for overtime row2 is: " +standardearningamountforovertimeforrow2);
				float standardearningsforovertimeforrow2=(standardearningamountforovertimeforrow2*standardearningsratevalue)/100;
				//System.out.println("Standard Earnings Fringe Amount for overtime row2 is: " +standardearningsforovertimeforrow2);
				DecimalFormat standardearningsforovertimeforrow2df = new DecimalFormat("#.####");
				float standardearningsforovertimeforrow2format=Float.valueOf(standardearningsforovertimeforrow2df.format(standardearningsforovertimeforrow2));
				//System.out.println("Standard Earnings Fringe Amount for overtime row2 format is: " +standardearningsforovertimeforrow2format);
				
				float standardearningamountfordoubleovertimeforrow2=(float) ((hourlyraterow2fordoubleovertime/DoubletimeAmtRatevalue)*editrow2doubleovrimehourse);
				////System.out.println("Standard Earnings Calc for doubleovertime row2 is: " +standardearningamountfordoubleovertimeforrow2);
				float standardearningsfordoubleovertimeforrow2=(standardearningamountfordoubleovertimeforrow2*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row2 is: " +standardearningsfordoubleovertimeforrow2);
				DecimalFormat standardearningsfordoubleovertimeforrow2df = new DecimalFormat("#.####");
				float standardearningsfordoubleovertimeforrow2format=Float.valueOf(standardearningsfordoubleovertimeforrow2df.format(standardearningsfordoubleovertimeforrow2));
				//System.out.println("Standard Earnings Fringe Amount for doubleovertime row2 format is: " +standardearningsfordoubleovertimeforrow2format);
				
				float standardearningamountfortripleovertimeforrow2=(float) ((hourlyraterow2fortripleovertime/TripletimeAmtRatevalue)*editrow2tripleovrimehourse);
				////System.out.println("Standard Earnings Calc for tripleovertime row2 is: " +standardearningamountfortripleovertimeforrow2);
				float standardearningsfortripleovertimeforrow2=(standardearningamountfortripleovertimeforrow2*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row2 is: " +standardearningsfortripleovertimeforrow2);
				DecimalFormat standardearningsfortripleovertimeforrow2df = new DecimalFormat("#.####");
				float standardearningsfortripleovertimeforrow2format=Float.valueOf(standardearningsfortripleovertimeforrow2df.format(standardearningsfortripleovertimeforrow2));
				//System.out.println("Standard Earnings Fringe Amount for tripleovertime row2 format is: " +standardearningsfortripleovertimeforrow2format);
				
				//Sum of Standard Earnings row2
				float standardearningsrow2format=standardearningsforregularforrow2format+standardearningsforovertimeforrow2format+standardearningsfordoubleovertimeforrow2format+standardearningsfortripleovertimeforrow2format;
				//System.out.println("Standard Earnings Fringe Amount row2 is: " +standardearningsrow2format);
				DecimalFormat standardearningsrow2decimalformat = new DecimalFormat("#.####");
				float standardearningsrow2=Float.valueOf(standardearningsrow2decimalformat.format(standardearningsrow2format));
				logger.info("Standard Earnings Fringe Amount row2 is: " +standardearningsrow2);
				
				//Fixed Percentage calculation method for edit row2
				float fixedpercentageregularrow2=hourlyraterow2forregular*editrow2regularhourse;
				//System.out.println("fixedpercentageregular row2 is: " +fixedpercentageregularrow2);
				float fixedpercentageovertimerow2=hourlyraterow2forovertime*editrow2ovrimehourse;
				//System.out.println("fixedpercentageovertime row2 is: " +fixedpercentageovertimerow2);
				float fixedpercentagdoubleeovertimerow2=hourlyraterow2fordoubleovertime*editrow2doubleovrimehourse;
				//System.out.println("fixedpercentagdoubleeovertime row2 is: " +fixedpercentagdoubleeovertimerow2);
				float fixedpercentagtripleeovertimerow2=hourlyraterow2fortripleovertime*editrow2tripleovrimehourse;
				//System.out.println("fixedpercentagtripleeovertime row2 is: " +fixedpercentagtripleeovertimerow2);
				float earningamountrow2=fixedpercentageregularrow2+fixedpercentageovertimerow2+fixedpercentagdoubleeovertimerow2+fixedpercentagtripleeovertimerow2;
				//double earningamount=fixedpercentageregular+fixedpercentageovertime+fixedpercentagdoubleeovertime+fixedpercentagtripleeovertime;
				//System.out.println("Earning Amount row2 is: " +earningamountrow2);
				float fixedpercentagerow2beforeformat=(earningamountrow2*fixedpercentageratevalue)/100;
				//System.out.println("Fixed percentage row2 is: " +fixedpercentagerow2beforeformat);
				DecimalFormat fixedpercentagerow2format = new DecimalFormat("#.####");
				float fixedpercentagerow2=Float.valueOf(fixedpercentagerow2format.format(fixedpercentagerow2beforeformat));
				logger.info("Fixed percentage Fringe Amount row2 is: " +fixedpercentagerow2);
				
				//Fixed Hourly rate calculation method edit row2
				float fixedhourlyraterow2a=fixedhourlyratevalue*editrow2totalhours;
				//double fixedhourlyrate=fixedhourlyratevalue*editrow2totalhours;
				//logger.info("Fixed Hourly Fringe Amount row2 is: " +fixedhourlyraterow2a);
				float fixedhourlyraterow2 = 0;
				if(fixedhourlyraterow2a>fringevalueafterrow1)
				{
					fixedhourlyraterow2=fringevalueafterrow1;
				}
				//System.out.println("Fixed Hourly rate for row2 after fringe cap comparison is: " +fixedhourlyraterow2);
				logger.info("Fixed Hourly Fringe Amount row2 is: " +fixedhourlyraterow2);
				//Total Earned Hours calculation method edit row2
				double earnedhoursrow2=((editrow2regularhourse*RegularAmtRatevalue)+(editrow2ovrimehourse*OvertimeAmtRatevalue)+(editrow2doubleovrimehourse*DoubletimeAmtRatevalue)+(editrow2tripleovrimehourse*TripletimeAmtRatevalue));
				//System.out.println("Earned Hours row2 is: " +earnedhoursrow2);
				double totalearnedhoursrow2=totalearnedhoursratevalue*earnedhoursrow2;
				logger.info("Total Earned Fringe Amount row2 is: " +totalearnedhoursrow2);
				
				//Flat Employee Based calculation method for edit row2
				double flatemployeebasedrow2beforeformat=(editrow2totalhours*flatemployeebasedratevalue)/totaledithours;
				//logger.info("Flat Employee Based Fringe Amount row2 is: " +flatemployeebasedrow2beforeformat);
				DecimalFormat flatemployeebasedrow2afterformat= new DecimalFormat("#.####");
				float flatemployeebasedrow2=Float.valueOf(flatemployeebasedrow2afterformat.format(flatemployeebasedrow2beforeformat));
				logger.info("Flat Employee Based Fringe Amount row2 is: " +flatemployeebasedrow2);
				
				//row3 calculation starts
				// hourlyrate for edit row3 for regular (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatregularrow3=(float) ((wagerater)*RegularAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row3 is: " +hourlyratebeforeformatregularrow3);
				DecimalFormat hourlyrateforformatregularrow3= new DecimalFormat("#.####");
				float hourlyraterow3forregular=Float.valueOf(hourlyrateforformatregularrow3.format(hourlyratebeforeformatregularrow3));
				//System.out.println("Hourly rate for regular is row3 is: " +hourlyraterow3forregular);
				
				// hourlyrate for edit row3 for overtime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatovertimerow3=(float) ((wagerater)*OvertimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row3 is: " +hourlyratebeforeformatovertimerow3);
				DecimalFormat hourlyrateforformatovertimerow3= new DecimalFormat("#.####");
				float hourlyraterow3forovertime=Float.valueOf(hourlyrateforformatovertimerow3.format(hourlyratebeforeformatovertimerow3));
				//System.out.println("Hourly rate for overtime is row3 is: " +hourlyraterow3forovertime);
				
				// hourlyrate for edit row3 for doubleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatdoubleovertimerow3=(float) ((wagerater)*DoubletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row3 is: " +hourlyratebeforeformatdoubleovertimerow3);
				DecimalFormat hourlyrateforformatdoubleovertimerow3= new DecimalFormat("#.####");
				float hourlyraterow3fordoubleovertime=Float.valueOf(hourlyrateforformatdoubleovertimerow3.format(hourlyratebeforeformatdoubleovertimerow3));
				//System.out.println("Hourly rate for doubleovertime is row3 is: " +hourlyraterow3fordoubleovertime);
				
				// hourlyrate for edit row3 for tripleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformattripleovertimerow3=(float) ((wagerater)*TripletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row3 is: " +hourlyratebeforeformattripleovertimerow3);
				DecimalFormat hourlyrateforformattripleovertimerow3= new DecimalFormat("#.####");
				float hourlyraterow3fortripleovertime=Float.valueOf(hourlyrateforformattripleovertimerow3.format(hourlyratebeforeformattripleovertimerow3));
				//System.out.println("Hourly rate for tripleovertime is row3 is: " +hourlyraterow3fortripleovertime);
				
				//Standard Earnings Calculation method for row3
				
				float standardearningamountforregularforrow3=(float) ((hourlyraterow3forregular/RegularAmtRatevalue)*editrow3regularhourse);
				////System.out.println("Standard Earnings Calc for regular row3 is: " +standardearningamountforregularforrow3);
				float standardearningsforregularforrow3=(standardearningamountforregularforrow3*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for regular row3 is: " +standardearningsforregularforrow3);
				DecimalFormat standardearningsforregularforrow3df = new DecimalFormat("#.####");
				float standardearningsforregularforrow3format=Float.valueOf(standardearningsforregularforrow3df.format(standardearningsforregularforrow3));
				////System.out.println("Standard Earnings Fringe Amount for regular row3 format is: " +standardearningsforregularforrow3format);
				
				float standardearningamountforovertimeforrow3=(float) ((hourlyraterow3forovertime/OvertimeAmtRatevalue)*editrow3ovrimehourse);
				////System.out.println("Standard Earnings Calc for overtime row3 is: " +standardearningamountforovertimeforrow3);
				float standardearningsforovertimeforrow3=(standardearningamountforovertimeforrow3*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for overtime row3 is: " +standardearningsforovertimeforrow3);
				DecimalFormat standardearningsforovertimeforrow3df = new DecimalFormat("#.####");
				float standardearningsforovertimeforrow3format=Float.valueOf(standardearningsforovertimeforrow3df.format(standardearningsforovertimeforrow3));
				////System.out.println("Standard Earnings Fringe Amount for overtime row3 format is: " +standardearningsforovertimeforrow3format);
				
				float standardearningamountfordoubleovertimeforrow3=(float) ((hourlyraterow3fordoubleovertime/DoubletimeAmtRatevalue)*editrow3doubleovrimehourse);
				////System.out.println("Standard Earnings Calc for doubleovertime row3 is: " +standardearningamountfordoubleovertimeforrow3);
				float standardearningsfordoubleovertimeforrow3=(standardearningamountfordoubleovertimeforrow3*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row3 is: " +standardearningsfordoubleovertimeforrow3);
				DecimalFormat standardearningsfordoubleovertimeforrow3df = new DecimalFormat("#.####");
				float standardearningsfordoubleovertimeforrow3format=Float.valueOf(standardearningsfordoubleovertimeforrow3df.format(standardearningsfordoubleovertimeforrow3));
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row3 format is: " +standardearningsfordoubleovertimeforrow3format);
				
				float standardearningamountfortripleovertimeforrow3=(float) ((hourlyraterow3fortripleovertime/TripletimeAmtRatevalue)*editrow3tripleovrimehourse);
				////System.out.println("Standard Earnings Calc for tripleovertime row3 is: " +standardearningamountfortripleovertimeforrow3);
				float standardearningsfortripleovertimeforrow3=(standardearningamountfortripleovertimeforrow3*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row3 is: " +standardearningsfortripleovertimeforrow3);
				DecimalFormat standardearningsfortripleovertimeforrow3df = new DecimalFormat("#.####");
				float standardearningsfortripleovertimeforrow3format=Float.valueOf(standardearningsfortripleovertimeforrow3df.format(standardearningsfortripleovertimeforrow3));
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row3 format is: " +standardearningsfortripleovertimeforrow3format);
				
				//Sum of Standard Earnings row3
				float standardearningsrow3format=standardearningsforregularforrow3format+standardearningsforovertimeforrow3format+standardearningsfordoubleovertimeforrow3format+standardearningsfortripleovertimeforrow3format;
				//System.out.println("Standard Earnings Fringe Amount row3 is: " +standardearningsrow3format);
				DecimalFormat standardearningsrow3decimalformat = new DecimalFormat("#.####");
				float standardearningsrow3=Float.valueOf(standardearningsrow3decimalformat.format(standardearningsrow3format));
				logger.info("Standard Earnings Fringe Amount row3 is: " +standardearningsrow3);
				
				//Fixed Percentage calculation method for edit row3
				float fixedpercentageregularrow3=hourlyraterow3forregular*editrow3regularhourse;
				//System.out.println("fixedpercentageregular row3 is: " +fixedpercentageregularrow3);
				float fixedpercentageovertimerow3=hourlyraterow3forovertime*editrow3ovrimehourse;
				//System.out.println("fixedpercentageovertime row3 is: " +fixedpercentageovertimerow3);
				float fixedpercentagdoubleeovertimerow3=hourlyraterow3fordoubleovertime*editrow3doubleovrimehourse;
				//System.out.println("fixedpercentagdoubleeovertime row3 is: " +fixedpercentagdoubleeovertimerow3);
				float fixedpercentagtripleeovertimerow3=hourlyraterow3fortripleovertime*editrow3tripleovrimehourse;
				//System.out.println("fixedpercentagtripleeovertime row3 is: " +fixedpercentagtripleeovertimerow3);
				float earningamountrow3=fixedpercentageregularrow3+fixedpercentageovertimerow3+fixedpercentagdoubleeovertimerow3+fixedpercentagtripleeovertimerow3;
				//double earningamount=fixedpercentageregular+fixedpercentageovertime+fixedpercentagdoubleeovertime+fixedpercentagtripleeovertime;
				//System.out.println("Earning Amount row3 is: " +earningamountrow3);
				float fixedpercentagerow3beforeformat=(earningamountrow3*fixedpercentageratevalue)/100;
				//System.out.println("Fixed percentage row3 is: " +fixedpercentagerow3beforeformat);
				DecimalFormat fixedpercentagerow3format = new DecimalFormat("#.####");
				float fixedpercentagerow3=Float.valueOf(fixedpercentagerow3format.format(fixedpercentagerow3beforeformat));
				logger.info("Fixed percentage Fringe Amount row3 is: " +fixedpercentagerow3);
				
				//Fixed Hourly rate calculation method edit row3
				float fixedhourlyraterow3=fixedhourlyratevalue*editrow3totalhours;
				//double fixedhourlyrate=fixedhourlyratevalue*editrow3totalhours;
				logger.info("Fixed Hourly Fringe Amount row3 is: " +fixedhourlyraterow3);
				
				//Total Earned Hours calculation method edit row3
				double earnedhoursrow3=((editrow3regularhourse*RegularAmtRatevalue)+(editrow3ovrimehourse*OvertimeAmtRatevalue)+(editrow3doubleovrimehourse*DoubletimeAmtRatevalue)+(editrow3tripleovrimehourse*TripletimeAmtRatevalue));
				//System.out.println("Earned Hours row3 is: " +earnedhoursrow3);
				double totalearnedhoursrow3=totalearnedhoursratevalue*earnedhoursrow3;
				logger.info("Total Earned Fringe Amount row3 is: " +totalearnedhoursrow3);
				
				//Flat Employee Based calculation method for edit row3
				double flatemployeebasedrow3beforeformat=(editrow3totalhours*flatemployeebasedratevalue)/totaledithours;
				//logger.info("Flat Employee Based Fringe Amount row3 is: " +flatemployeebasedrow3beforeformat);
				DecimalFormat flatemployeebasedrow3afterformat= new DecimalFormat("#.####");
				float flatemployeebasedrow3=Float.valueOf(flatemployeebasedrow3afterformat.format(flatemployeebasedrow3beforeformat));
				logger.info("Flat Employee Based Fringe Amount row3 is: " +flatemployeebasedrow3);
				
				//row4 calculation starts
				// hourlyrate for edit row4 for regular (if special pay is fixed then we should add special also) // No Extra pay for this worker hence i made it as 0 and no shift rate so removing it
				/*
				//Shift Rate is in Percentage, So
				float jobshift=(float) ((jobrateamtvalue+unionextrapay)*atshift3percentvalue);
				//System.out.println("Jobamtrate*Shiftpercentage rate for row4 is: " +jobshift);
				DecimalFormat jobshiftformat= new DecimalFormat("#.####");
				float jobshiftrate=Float.valueOf(jobshiftformat.format(jobshift));
				//System.out.println("Jobshift rate for row3 is: " +jobshiftrate);
				*/
				float hourlyratebeforeformatregularrow4=(float) ((wagerater)*RegularAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row4 is: " +hourlyratebeforeformatregularrow4);
				DecimalFormat hourlyrateforformatregularrow4= new DecimalFormat("#.####");
				float hourlyraterow4forregular=Float.valueOf(hourlyrateforformatregularrow4.format(hourlyratebeforeformatregularrow4));
				//System.out.println("Hourly rate for regular is row4 is: " +hourlyraterow4forregular);
				
				// hourlyrate for edit row4 for overtime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatovertimerow4=(float) ((wagerater)*OvertimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row4 is: " +hourlyratebeforeformatovertimerow4);
				DecimalFormat hourlyrateforformatovertimerow4= new DecimalFormat("#.####");
				float hourlyraterow4forovertime=Float.valueOf(hourlyrateforformatovertimerow4.format(hourlyratebeforeformatovertimerow4));
				//System.out.println("Hourly rate for overtime is row4 is: " +hourlyraterow4forovertime);
				
				// hourlyrate for edit row4 for doubleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatdoubleovertimerow4=(float) ((wagerater)*DoubletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row4 is: " +hourlyratebeforeformatdoubleovertimerow4);
				DecimalFormat hourlyrateforformatdoubleovertimerow4= new DecimalFormat("#.####");
				float hourlyraterow4fordoubleovertime=Float.valueOf(hourlyrateforformatdoubleovertimerow4.format(hourlyratebeforeformatdoubleovertimerow4));
				//System.out.println("Hourly rate for doubleovertime is row4 is: " +hourlyraterow4fordoubleovertime);
				
				// hourlyrate for edit row4 for tripleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformattripleovertimerow4=(float) ((wagerater)*TripletimeAmtRatevalue)+fringerate;;
				//System.out.println("Hourly rate before format row4 is: " +hourlyratebeforeformattripleovertimerow4);
				DecimalFormat hourlyrateforformattripleovertimerow4= new DecimalFormat("#.####");
				float hourlyraterow4fortripleovertime=Float.valueOf(hourlyrateforformattripleovertimerow4.format(hourlyratebeforeformattripleovertimerow4));
				//System.out.println("Hourly rate for tripleovertime is row4 is: " +hourlyraterow4fortripleovertime);
				/*
				float hourlyraterow4format=hourlyraterow4forregular+hourlyraterow4forovertime+hourlyraterow4fordoubleovertime+hourlyraterow4fortripleovertime;
				//System.out.println("Hourly rate before format row4 is: " +hourlyraterow4format);
				DecimalFormat hourlyraterow4decimalformat= new DecimalFormat("#.####");
				float hourlyraterow4=Float.valueOf(hourlyraterow4decimalformat.format(hourlyraterow4format));
				//System.out.println("Hourly rate for row4 is: " +hourlyraterow4);
				*/
				//Standard Earnings Calculation method for row4
				
				float standardearningamountforregularforrow4=(float) ((hourlyraterow4forregular/RegularAmtRatevalue)*editrow4regularhourse);
				System.out.println("Standard Earnings Calc for regular row4 is: " +standardearningamountforregularforrow4);
				float standardearningsforregularforrow4=(standardearningamountforregularforrow4*standardearningsratevalue)/100;
				System.out.println("Standard Earnings Fringe Amount for regular row4 is: " +standardearningsforregularforrow4);
				DecimalFormat standardearningsforregularforrow4df = new DecimalFormat("#.####");
				float standardearningsforregularforrow4format=Float.valueOf(standardearningsforregularforrow4df.format(standardearningsforregularforrow4));
				System.out.println("Standard Earnings Fringe Amount for regular row4 format is: " +standardearningsforregularforrow4format);
				
				float standardearningamountforovertimeforrow4=(float) ((hourlyraterow4forovertime/OvertimeAmtRatevalue)*editrow4ovrimehourse);
				System.out.println("Standard Earnings Calc for overtime row4 is: " +standardearningamountforovertimeforrow4);
				float standardearningsforovertimeforrow4=(standardearningamountforovertimeforrow4*standardearningsratevalue)/100;
				System.out.println("Standard Earnings Fringe Amount for overtime row4 is: " +standardearningsforovertimeforrow4);
				DecimalFormat standardearningsforovertimeforrow4df = new DecimalFormat("#.####");
				float standardearningsforovertimeforrow4format=Float.valueOf(standardearningsforovertimeforrow4df.format(standardearningsforovertimeforrow4));
				System.out.println("Standard Earnings Fringe Amount for overtime row4 format is: " +standardearningsforovertimeforrow4format);
				
				float standardearningamountfordoubleovertimeforrow4=(float) ((hourlyraterow4fordoubleovertime/DoubletimeAmtRatevalue)*editrow4doubleovrimehourse);
				System.out.println("Standard Earnings Calc for doubleovertime row4 is: " +standardearningamountfordoubleovertimeforrow4);
				float standardearningsfordoubleovertimeforrow4=(standardearningamountfordoubleovertimeforrow4*standardearningsratevalue)/100;
				System.out.println("Standard Earnings Fringe Amount for doubleovertime row4 is: " +standardearningsfordoubleovertimeforrow4);
				DecimalFormat standardearningsfordoubleovertimeforrow4df = new DecimalFormat("#.####");
				float standardearningsfordoubleovertimeforrow4format=Float.valueOf(standardearningsfordoubleovertimeforrow4df.format(standardearningsfordoubleovertimeforrow4));
				System.out.println("Standard Earnings Fringe Amount for doubleovertime row4 format is: " +standardearningsfordoubleovertimeforrow4format);
				
				float standardearningamountfortripleovertimeforrow4=(float) ((hourlyraterow4fortripleovertime/TripletimeAmtRatevalue)*editrow4tripleovrimehourse);
				System.out.println("Standard Earnings Calc for tripleovertime row4 is: " +standardearningamountfortripleovertimeforrow4);
				float standardearningsfortripleovertimeforrow4=(standardearningamountfortripleovertimeforrow4*standardearningsratevalue)/100;
				System.out.println("Standard Earnings Fringe Amount for tripleovertime row4 is: " +standardearningsfortripleovertimeforrow4);
				DecimalFormat standardearningsfortripleovertimeforrow4df = new DecimalFormat("#.####");
				float standardearningsfortripleovertimeforrow4format=Float.valueOf(standardearningsfortripleovertimeforrow4df.format(standardearningsfortripleovertimeforrow4));
				System.out.println("Standard Earnings Fringe Amount for tripleovertime row4 format is: " +standardearningsfortripleovertimeforrow4format);
				
				//Sum of Standard Earnings row4
				float standardearningsrow4format=standardearningsforregularforrow4format+standardearningsforovertimeforrow4format+standardearningsfordoubleovertimeforrow4format+standardearningsfortripleovertimeforrow4format;
				System.out.println("Standard Earnings Fringe Amount row4 is: " +standardearningsrow4format);
				DecimalFormat standardearningsrow4decimalformat = new DecimalFormat("#.####");
				float standardearningsrow4=Float.valueOf(standardearningsrow4decimalformat.format(standardearningsrow4format));
				logger.info("Standard Earnings Fringe Amount row4 is: " +standardearningsrow4);
				
				//Fixed Percentage calculation method for edit row4
				float fixedpercentageregularrow4=hourlyraterow4forregular*editrow4regularhourse;
				//System.out.println("fixedpercentageregular row4 is: " +fixedpercentageregularrow4);
				float fixedpercentageovertimerow4=hourlyraterow4forovertime*editrow4ovrimehourse;
				//System.out.println("fixedpercentageovertime row4 is: " +fixedpercentageovertimerow4);
				float fixedpercentagdoubleeovertimerow4=hourlyraterow4fordoubleovertime*editrow4doubleovrimehourse;
				//System.out.println("fixedpercentagdoubleeovertime row4 is: " +fixedpercentagdoubleeovertimerow4);
				float fixedpercentagtripleeovertimerow4=hourlyraterow4fortripleovertime*editrow4tripleovrimehourse;
				//System.out.println("fixedpercentagtripleeovertime row4 is: " +fixedpercentagtripleeovertimerow4);
				float earningamountrow4=fixedpercentageregularrow4+fixedpercentageovertimerow4+fixedpercentagdoubleeovertimerow4+fixedpercentagtripleeovertimerow4;
				//double earningamount=fixedpercentageregular+fixedpercentageovertime+fixedpercentagdoubleeovertime+fixedpercentagtripleeovertime;
				//System.out.println("Earning Amount row4 is: " +earningamountrow4);
				float fixedpercentagerow4beforeformat=(earningamountrow4*fixedpercentageratevalue)/100;
				//System.out.println("Fixed percentage row4 is: " +fixedpercentagerow4beforeformat);
				DecimalFormat fixedpercentagerow4format = new DecimalFormat("#.####");
				float fixedpercentagerow4=Float.valueOf(fixedpercentagerow4format.format(fixedpercentagerow4beforeformat));
				logger.info("Fixed percentage Fringe Amount row4 is: " +fixedpercentagerow4);
				
				//Fixed Hourly rate calculation method edit row4
				float fixedhourlyraterow4=fixedhourlyratevalue*editrow4totalhours;
				//double fixedhourlyrate=fixedhourlyratevalue*editrow4totalhours;
				logger.info("Fixed Hourly Fringe Amount row4 is: " +fixedhourlyraterow4);
				
				//Total Earned Hours calculation method edit row4
				float earnedhoursrow4=(float) ((editrow4regularhourse*RegularAmtRatevalue)+(editrow4ovrimehourse*OvertimeAmtRatevalue)+(editrow4doubleovrimehourse*DoubletimeAmtRatevalue)+(editrow4tripleovrimehourse*TripletimeAmtRatevalue));
				System.out.println("Earned Hours row4 is: " +earnedhoursrow4);
				float totalearnedhoursrow4=totalearnedhoursratevalue*earnedhoursrow4;
				logger.info("Total Earned Fringe Amount row4 is: " +totalearnedhoursrow4);
				
				//Flat Employee Based calculation method for edit row4
				double flatemployeebasedrow4beforeformat=(editrow4totalhours*flatemployeebasedratevalue)/totaledithours;
				//logger.info("Flat Employee Based Fringe Amount row4 is: " +flatemployeebasedrow4beforeformat);
				DecimalFormat flatemployeebasedrow4afterformat= new DecimalFormat("#.####");
				float flatemployeebasedrow4=Float.valueOf(flatemployeebasedrow4afterformat.format(flatemployeebasedrow4beforeformat));
				logger.info("Flat Employee Based Fringe Amount row4 is: " +flatemployeebasedrow4);
				
				
				//row5 calculation starts
				// hourlyrate for edit row5 for regular (if special pay is fixed then we should add special also) // No Extra pay for this worker hence i made it as 0 and no shift rate so removing it
				float hourlyratebeforeformatregularrow5=(float) ((wagerater)*RegularAmtRatevalue)+fringerate;
				//System.out.println("Hourly rate before format row5 is: " +hourlyratebeforeformatregularrow5);
				DecimalFormat hourlyrateforformatregularrow5= new DecimalFormat("#.####");
				float hourlyraterow5forregular=Float.valueOf(hourlyrateforformatregularrow5.format(hourlyratebeforeformatregularrow5));
				//System.out.println("Hourly rate for regular is row5 is: " +hourlyraterow5forregular);
				
				// hourlyrate for edit row5 for overtime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatovertimerow5=(float) ((wagerater)*OvertimeAmtRatevalue)+fringerate;
				//System.out.println("Hourly rate before format row5 is: " +hourlyratebeforeformatovertimerow5);
				DecimalFormat hourlyrateforformatovertimerow5= new DecimalFormat("#.####");
				float hourlyraterow5forovertime=Float.valueOf(hourlyrateforformatovertimerow5.format(hourlyratebeforeformatovertimerow5));
				//System.out.println("Hourly rate for overtime is row5 is: " +hourlyraterow5forovertime);
				
				// hourlyrate for edit row5 for doubleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformatdoubleovertimerow5=(float) ((wagerater)*DoubletimeAmtRatevalue)+fringerate;
				//System.out.println("Hourly rate before format row5 is: " +hourlyratebeforeformatdoubleovertimerow5);
				DecimalFormat hourlyrateforformatdoubleovertimerow5= new DecimalFormat("#.####");
				float hourlyraterow5fordoubleovertime=Float.valueOf(hourlyrateforformatdoubleovertimerow5.format(hourlyratebeforeformatdoubleovertimerow5));
				//System.out.println("Hourly rate for doubleovertime is row5 is: " +hourlyraterow5fordoubleovertime);
				
				// hourlyrate for edit row5 for tripleovertime (if special pay is fixed then we should add special also)
				float hourlyratebeforeformattripleovertimerow5=(float) ((wagerater)*TripletimeAmtRatevalue)+fringerate;
				//System.out.println("Hourly rate before format row5 is: " +hourlyratebeforeformattripleovertimerow5);
				DecimalFormat hourlyrateforformattripleovertimerow5= new DecimalFormat("#.####");
				float hourlyraterow5fortripleovertime=Float.valueOf(hourlyrateforformattripleovertimerow5.format(hourlyratebeforeformattripleovertimerow5));
				//System.out.println("Hourly rate for tripleovertime is row5 is: " +hourlyraterow5fortripleovertime);
				
				//Standard Earnings Calculation method for row5
				
				float standardearningamountforregularforrow5=(float) ((hourlyraterow5forregular/RegularAmtRatevalue)*editrow5regularhourse);
				////System.out.println("Standard Earnings Calc for regular row5 is: " +standardearningamountforregularforrow5);
				float standardearningsforregularforrow5=(standardearningamountforregularforrow5*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for regular row5 is: " +standardearningsforregularforrow5);
				DecimalFormat standardearningsforregularforrow5df = new DecimalFormat("#.####");
				float standardearningsforregularforrow5format=Float.valueOf(standardearningsforregularforrow5df.format(standardearningsforregularforrow5));
				////System.out.println("Standard Earnings Fringe Amount for regular row5 format is: " +standardearningsforregularforrow5format);
				
				float standardearningamountforovertimeforrow5=(float) ((hourlyraterow5forovertime/OvertimeAmtRatevalue)*editrow5ovrimehourse);
				////System.out.println("Standard Earnings Calc for overtime row5 is: " +standardearningamountforovertimeforrow5);
				float standardearningsforovertimeforrow5=(standardearningamountforovertimeforrow5*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for overtime row5 is: " +standardearningsforovertimeforrow5);
				DecimalFormat standardearningsforovertimeforrow5df = new DecimalFormat("#.####");
				float standardearningsforovertimeforrow5format=Float.valueOf(standardearningsforovertimeforrow5df.format(standardearningsforovertimeforrow5));
				////System.out.println("Standard Earnings Fringe Amount for overtime row5 format is: " +standardearningsforovertimeforrow5format);
				
				float standardearningamountfordoubleovertimeforrow5=(float) ((hourlyraterow5fordoubleovertime/DoubletimeAmtRatevalue)*editrow5doubleovrimehourse);
				////System.out.println("Standard Earnings Calc for doubleovertime row5 is: " +standardearningamountfordoubleovertimeforrow5);
				float standardearningsfordoubleovertimeforrow5=(standardearningamountfordoubleovertimeforrow5*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row5 is: " +standardearningsfordoubleovertimeforrow5);
				DecimalFormat standardearningsfordoubleovertimeforrow5df = new DecimalFormat("#.####");
				float standardearningsfordoubleovertimeforrow5format=Float.valueOf(standardearningsfordoubleovertimeforrow5df.format(standardearningsfordoubleovertimeforrow5));
				////System.out.println("Standard Earnings Fringe Amount for doubleovertime row5 format is: " +standardearningsfordoubleovertimeforrow5format);
				
				float standardearningamountfortripleovertimeforrow5=(float) ((hourlyraterow5fortripleovertime/TripletimeAmtRatevalue)*editrow5tripleovrimehourse);
				////System.out.println("Standard Earnings Calc for tripleovertime row5 is: " +standardearningamountfortripleovertimeforrow5);
				float standardearningsfortripleovertimeforrow5=(standardearningamountfortripleovertimeforrow5*standardearningsratevalue)/100;
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row5 is: " +standardearningsfortripleovertimeforrow5);
				DecimalFormat standardearningsfortripleovertimeforrow5df = new DecimalFormat("#.####");
				float standardearningsfortripleovertimeforrow5format=Float.valueOf(standardearningsfortripleovertimeforrow5df.format(standardearningsfortripleovertimeforrow5));
				////System.out.println("Standard Earnings Fringe Amount for tripleovertime row5 format is: " +standardearningsfortripleovertimeforrow5format);
				
				//Sum of Standard Earnings row5
                float standardearningsrow5format=standardearningsforregularforrow5format+standardearningsforovertimeforrow5format+standardearningsfordoubleovertimeforrow5format+standardearningsfortripleovertimeforrow5format;
                //System.out.println("Standard Earnings Fringe Amount row5 is: " +standardearningsrow5format);
                DecimalFormat standardearningsrow5decimalformat = new DecimalFormat("#.####");
                float standardearningsrow5=Float.valueOf(standardearningsrow5decimalformat.format(standardearningsrow5format));
                logger.info("Standard Earnings Fringe Amount row5 is: " +standardearningsrow5);
				
				//Fixed Percentage calculation method for edit row5
				float fixedpercentageregularrow5=hourlyraterow5forregular*editrow5regularhourse;
				//System.out.println("fixedpercentageregular row5 is: " +fixedpercentageregularrow5);
				float fixedpercentageovertimerow5=hourlyraterow5forovertime*editrow5ovrimehourse;
				//System.out.println("fixedpercentageovertime row5 is: " +fixedpercentageovertimerow5);
				float fixedpercentagdoubleeovertimerow5=hourlyraterow5fordoubleovertime*editrow5doubleovrimehourse;
				//System.out.println("fixedpercentagdoubleeovertime row5 is: " +fixedpercentagdoubleeovertimerow5);
				float fixedpercentagtripleeovertimerow5=hourlyraterow5fortripleovertime*editrow5tripleovrimehourse;
				//System.out.println("fixedpercentagtripleeovertime row5 is: " +fixedpercentagtripleeovertimerow5);
				float earningamountrow5=fixedpercentageregularrow5+fixedpercentageovertimerow5+fixedpercentagdoubleeovertimerow5+fixedpercentagtripleeovertimerow5;
				//double earningamount=fixedpercentageregular+fixedpercentageovertime+fixedpercentagdoubleeovertime+fixedpercentagtripleeovertime;
				//System.out.println("Earning Amount row5 is: " +earningamountrow5);
				float fixedpercentagerow5beforeformat=(earningamountrow5*fixedpercentageratevalue)/100;
				//System.out.println("Fixed percentage row5 is: " +fixedpercentagerow5beforeformat);
				DecimalFormat fixedpercentagerow5format = new DecimalFormat("#.####");
				float fixedpercentagerow5=Float.valueOf(fixedpercentagerow5format.format(fixedpercentagerow5beforeformat));
				logger.info("Fixed percentage Fringe Amount row5 is: " +fixedpercentagerow5);
				
				//Fixed Hourly rate calculation method edit row5
				float fixedhourlyraterow5=fixedhourlyratevalue*editrow5totalhours;
				//double fixedhourlyrate=fixedhourlyratevalue*editrow5totalhours;
				logger.info("Fixed Hourly Fringe Amount row5 is: " +fixedhourlyraterow5);
				
				//Total Earned Hours calculation method edit row5
				double earnedhoursrow5=((editrow5regularhourse*RegularAmtRatevalue)+(editrow5ovrimehourse*OvertimeAmtRatevalue)+(editrow5doubleovrimehourse*DoubletimeAmtRatevalue)+(editrow5tripleovrimehourse*TripletimeAmtRatevalue));
				//System.out.println("Earned Hours row5 is: " +earnedhoursrow5);
				double totalearnedhoursrow5=totalearnedhoursratevalue*earnedhoursrow5;
				logger.info("Total Earned Fringe Amount row5 is: " +totalearnedhoursrow5);
				
				//Flat Employee Based calculation method for edit row5
				double flatemployeebasedrow5beforeformat=(editrow5totalhours*flatemployeebasedratevalue)/totaledithours;
				//logger.info("Flat Employee Based Fringe Amount row5 is: " +flatemployeebasedrow5beforeformat);
				DecimalFormat flatemployeebasedrow5afterformat= new DecimalFormat("#.####");
				float flatemployeebasedrow5=Float.valueOf(flatemployeebasedrow5afterformat.format(flatemployeebasedrow5beforeformat));
				logger.info("Flat Employee Based Fringe Amount row5 is: " +flatemployeebasedrow5);
				
				//newtimesheet activites
				timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
				timesheet.TimesheetTab();
				logger.info("User Clicked Timesheet tab - Passed");
				Thread.sleep(2000);
				timesheet.TimeentryTab();
				Thread.sleep(2000);
				timesheet.AllTimesheetScreen();
				//logger.info("Navigated to AllTimeSheet Screen - Passed");
				Thread.sleep(3000);
				timesheet.NewTimesheet();
				//logger.info("Clicked NewTimesheet button - Passed");
				Thread.sleep(3000);
				timesheet.clkWorkersText();
				Thread.sleep(3000);
				timesheet.txtworker(workername);
				//System.out.println("Worker selected is: " +workername);
				Thread.sleep(5000);
				timesheet.listselect();
				//logger.info("Worker Selected: " +workername);
				Thread.sleep(2000);
			    timesheet.clkProjectText();
			    Thread.sleep(1000);
				timesheet.txtproject(project);
				//System.out.println("Project selected is: " +project);
				Thread.sleep(3000);
				timesheet.listselect();
				//logger.info("Project selected is: " +project);
				Thread.sleep(2000);
				timesheet.clkTaskcodeText();
				Thread.sleep(2000);
				timesheet.txttaskcode(taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(2000);
				timesheet.clkPayperiodText();
				Thread.sleep(3000);
				if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
				{
					timesheet.setPayperiod1();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
				{
					timesheet.setPayperiod33();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
				{
					timesheet.setPayperiod34();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
				{
					timesheet.setPayperiod35();
				}
				//this date i have mentioned based on excel date
				else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
				{
					timesheet.setPayperiod7();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
				{
					timesheet.setPayperiod36();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
				{
					timesheet.setPayperiod37();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/3/21"))
				{
					timesheet.setPayperiod10();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
				{
					timesheet.setPayperiod11();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
				{
					timesheet.setPayperiod38();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
				{
					timesheet.setPayperiod39();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
				{
					timesheet.setPayperiod40();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
				{
					timesheet.setPayperiod41();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
				{
					timesheet.setPayperiod42();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
				{
					timesheet.setPayperiod43();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
				{
					timesheet.setPayperiod23();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
				{
					timesheet.setPayperiod44();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/11/21"))
				{
					timesheet.setPayperiod24();
				}
				/*
				else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
				{
					timesheet.setPayperiod45();
				}
				*/
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
				{
					timesheet.setPayperiod46();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
				{
					timesheet.setPayperiod47();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
				{
					timesheet.setPayperiod48();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("6/13/21"))
				{
					timesheet.setPayperiod49();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("6/27/21"))
				{
					timesheet.setPayperiod50();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("7/11/21"))
				{
					timesheet.setPayperiod51();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("7/25/21"))
				{
					timesheet.setPayperiod52();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("8/8/21"))
				{
					timesheet.setPayperiod53();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("8/22/21"))
				{
					timesheet.setPayperiod54();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("9/5/21"))
				{
					timesheet.setPayperiod55();
				}
				else if(timesheet.txtpayperiodstring(payperiod).equals("9/19/21"))
				{
					timesheet.setPayperiod56();
				}
				//System.out.println("PayPeriod selected is: " +payperiod);
				//logger.info("Pay period date selected is: " +payperiod);
				timesheet.btnSave();
				Thread.sleep(5000);
				logger.info(workername+ ": NewTimesheet Successfully Saved - Passed");
				//Edit Row1
				timesheet.setRow1();
				Thread.sleep(1000);
				timesheet.setRow1();
				timesheet.Edit();
				Thread.sleep(1000);
				/*
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				timesheet.txtedittaskcodestring(edittaskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
			    Thread.sleep(3000);
			    if(timesheet.txteditswiftstring(editshiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("First"))
				{
					timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editshiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
			    */
			    Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editregularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editovertimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editdoubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(edittripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row2
				timesheet.setRow2();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				/*
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow2taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow2shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("First"))
				{
					timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow2shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				*/
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow2regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow2overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow2doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow2tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row3
				timesheet.setRow3();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				/*
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow3taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow3shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow3shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				*/
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow3regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow3overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow3doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow3tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				//Edit Row4
				timesheet.setRow4();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				/*
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow4taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow4shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow4shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				*/
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow4regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow4overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow4doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow4tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				
				//Edit Row5
				timesheet.setRow5();
				Thread.sleep(1000);
				timesheet.Edit();
				Thread.sleep(1000);
				/*
				timesheet.clearprojecttxt();
				Thread.sleep(1000);
				timesheet.clkprojecttxt();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow5projectcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.txtedittaskcodestring(editrow5taskcode);
				Thread.sleep(3000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.seteditshiftid();
				Thread.sleep(3000);
				if(timesheet.txteditswiftstring(editrow5shiftid).equals("Swing"))
				{
			    	timesheet.setShiftSwing();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("Night"))
				{
					timesheet.setShiftNight();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("First"))
				{
						timesheet.setShiftDay();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift1"))
				{
			    	timesheet.setATShift1();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift2"))
				{
					timesheet.setATShift2();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift3"))
				{
					timesheet.setATShift3();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift4"))
				{
					timesheet.setATShift4();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals("AT_Shift5"))
				{
					timesheet.setATShift5();
				}
				else if(timesheet.txteditswiftstring(editrow5shiftid).equals(" "))
				{
					Thread.sleep(1000);
				}
				*/
				Thread.sleep(1000);
			    timesheet.txteditregularhoursstring(editrow5regularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editrow5overtimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editrow5doubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(editrow5tripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(5000);
				
				timesheet.Process();
				logger.info(workername+ ": Clicked on Process button - Passed");
				Thread.sleep(5000);
				timesheet.Threedots();
				Thread.sleep(5000);
				timesheet.Viewcalculation();
				Thread.sleep(5000);
				timesheet.clkfringestab();
				Thread.sleep(5000);
				int rowcount=driver.findElements(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr")).size();
				String numofrows=String.valueOf(rowcount);
				System.out.println("number of rows: " +numofrows);
				for(int r=1;r<=rowcount;r++)
				{
					String fringecalcmethod=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[7]")).getText();
					System.out.println("Fringe Calc Method is: " +fringecalcmethod);
					
					if(r==1 || r==2 || r==3 || r==4)
					{
					if(fringecalcmethod.equals("FlatEmployeeBased"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==flatemployeebasedrow1)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("StandardEarnings"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==standardearningsrow1)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("FixedHourlyRate"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==fixedhourlyraterow1)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
				    }
					if(fringecalcmethod.equals("TotalEarnedHours"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==totalearnedhoursrow1)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					}
					if(r==5 || r==6 || r==7 || r==8)
					{
					if(fringecalcmethod.equals("FlatEmployeeBased"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==flatemployeebasedrow2)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("StandardEarnings"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==standardearningsrow2)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("FixedHourlyRate"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==fixedhourlyraterow2)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
				    }
					if(fringecalcmethod.equals("TotalEarnedHours"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==totalearnedhoursrow2)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					}
					if(r==9 || r==10 || r==11)
					{
					if(fringecalcmethod.equals("FlatEmployeeBased"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==flatemployeebasedrow3)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("StandardEarnings"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==standardearningsrow3)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("FixedHourlyRate"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==fixedhourlyraterow3)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
				    }
					if(fringecalcmethod.equals("TotalEarnedHours"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==totalearnedhoursrow3)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					}
					if(r==12 || r==13 || r==14)
					{
					if(fringecalcmethod.equals("FlatEmployeeBased"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==flatemployeebasedrow4)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("StandardEarnings"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==standardearningsrow4)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("FixedHourlyRate"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==fixedhourlyraterow4)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
				    }
					if(fringecalcmethod.equals("TotalEarnedHours"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==totalearnedhoursrow4)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					}
					if(r==15 || r==16 || r==17)
					{
					if(fringecalcmethod.equals("FlatEmployeeBased"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==flatemployeebasedrow5)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("StandardEarnings"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==standardearningsrow5)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					if(fringecalcmethod.equals("FixedHourlyRate"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==fixedhourlyraterow5)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
				    }
					if(fringecalcmethod.equals("TotalEarnedHours"))
				    {
						String fixedamountforFixedPercentage=driver.findElement(By.xpath("//span[contains(text(),'Fringe amount')]//following::table/tbody/tr["+r+"]/td[8]")).getText();
						System.out.println("fixedamount String value is: " +fixedamountforFixedPercentage);
				    	float fixedamountvaueforFixedPercentage=Float.parseFloat(fixedamountforFixedPercentage);
				    	System.out.println("fixedamountvaue is: " +fixedamountvaueforFixedPercentage);
				    	DecimalFormat fixedamountvaueforFixedPercentagedecimalformat = new DecimalFormat("#.####");
						float fixedamountvaluewt=Float.valueOf(fixedamountvaueforFixedPercentagedecimalformat.format(fixedamountvaueforFixedPercentage));
						System.out.println("fixed amount value in webtable is: " +fixedamountvaluewt);
						if(fixedamountvaluewt==totalearnedhoursrow5)
						{
							Assert.assertTrue(true);
						}
						else
						{
							System.out.println("Web Table value not matched with if condition");
							Assert.fail();
						}
						
				    }
					}
				}
				timesheet.clickbackbtn();
				Thread.sleep(1000);
				timesheet.clickreject();
				Thread.sleep(1000);
				timesheet.clickbackbtn();
				Thread.sleep(1000);
				timesheet.clickdelete();
				Thread.sleep(1000);
				timesheet.clickdeletepop();
				Thread.sleep(1000);   
			}
	}


}

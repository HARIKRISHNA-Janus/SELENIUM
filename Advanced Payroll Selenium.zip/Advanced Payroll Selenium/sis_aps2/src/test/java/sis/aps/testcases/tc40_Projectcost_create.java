package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_ProjectCosts_pom;

public class tc40_Projectcost_create extends baseclass {

	@Test
	public void ProjectCost_Create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Project Cost */
		operations_ProjectCosts_pom projectCost = new operations_ProjectCosts_pom(driver);

		projectCost.clickOperationsTab();
		projectCost.clickProjectCostsTab();
		logger.info("User navigated to All project Costs Page");
		projectCost.clickNewProjectCostButton();
		Thread.sleep(2000);
		projectCost.clickDatepickerButton();
		Thread.sleep(2000);
		projectCost.clickCurrentDate();
		Thread.sleep(2000);
		projectCost.ClickProjectName();
		Thread.sleep(2000);
		projectCost.ClickTestAutomationValue();
		Thread.sleep(2000);
		projectCost.SetRate(projectCostRate);
		Thread.sleep(2000);
		projectCost.clickSaveButton();
		Thread.sleep(2000);

		if (projectCost.isProjectCostsHeaderDisplayed().equals("All project costs")) {
			Assert.assertTrue(true);
			logger.info("Project Cost has been created");
		} else {
			Assert.fail();
		}

		projectCost.searchProject();
		Thread.sleep(2000);
		projectCost.clickDeleteIcon();
		Thread.sleep(2000);
		projectCost.clickDeleteButton();
		Thread.sleep(2000);

		if (projectCost.isProjectCostsHeaderDisplayed().equals("All project costs")) {
			Assert.assertTrue(true);
			logger.info("Project Cost has been Deleted");
		} else {
			Assert.fail();
		}

	}
}

package sis.aps.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.legalentities_companies_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc05_syncwithadpedit_companies extends baseclass {
	
	
	@Test
	public void masterdata_companies_syncwithadpedit() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		logger.info("User logged in Successfully");
		
		legalentities_companies_pom comp=new legalentities_companies_pom(driver);
		Thread.sleep(3000);
		comp.clkLegalEntitiesTab();
		logger.info("User clicked on LegalEntities Tab");
		comp.clkCompaniesTab();
		Thread.sleep(1000);
		logger.info("User navigated to Companies Screen");
		comp.clkSyncADP();
		logger.info("User Clicked on SYNC ADP");
		Thread.sleep(55000);
		String timestamp=new SimpleDateFormat("M/dd/yy, h:mm a").format(new Date());
		String Systemtime= "System Last Sync: " +timestamp;
		System.out.println(Systemtime);
		System.out.println("App " +comp.chkAppDateDisplay());
		logger.info("SYNC WITH ADP is Enabled Back:" +comp.chkSyncADPEnabledBack());
		logger.info("Circle Stared is Enabled:" +comp.chkCircleEnabled());
		if(comp.chkRowDisplay().equals(" Showing rows 1 to 1 of 1"))
		{
			Assert.assertTrue(true);
			logger.info("Row Count Equals");
		}
		else
		{
			Assert.fail();
			logger.info("Row Count is not Equal");
		}
		logger.info("Edit is Enabled:" +comp.chkEditEnabled());
		comp.clkEdit();
		Thread.sleep(3000);
		logger.info("Cancel button is Displayed:" +comp.chkCancelDisplay());
		logger.info("Save button is Enabled:" +comp.chkSaveEnabled());
		comp.clkCancel();
		Thread.sleep(3000);
		logger.info("Circle Stared is Enabled Back:" +comp.chkCircleEnabledBack());
	}

}

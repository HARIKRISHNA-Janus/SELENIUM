package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_Vendors_pom;

public class tc31_Vendors_editanddelete extends baseclass {

	@Test
	public void Vendors_editanddelete() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		unions_Vendors_pom vendors = new unions_Vendors_pom(driver);
		vendors.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		vendors.scrollIntoView();
		Thread.sleep(3000);
		vendors.clickVendorsTab();
		logger.info("User clicked vendors Leftsliding Sunmenu");
		vendors.clickNewVendorButton();
		logger.info("User clicked new vendor button");
		vendors.SetVendorId(vendorId);
		logger.info("User entered the vendor Id");
		vendors.SetVendorName(vendorName);
		logger.info("User entered the vendor Name");
		vendors.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (vendors.isVendorHeaderDisplayed().equals("All vendors")) {
			Assert.assertTrue(true);
			logger.info("User verified vendor page header is dispalyed");
			System.out.println("vendor has been created Successfully !");
		} else {
			logger.info("Vendoe page header is not dispalyed");
			Assert.fail("All Vendor Header is not disaplayed");
		}

		vendors.searchVendor();
		logger.info("User entered the vendor Id/Name in search input field");
		vendors.ClickEditIcon();
		logger.info("user clicked the edit icon");
		vendors.editVendorId();
		logger.info("user edited vendor id");
		vendors.editVendorName();
		logger.info("user edited vendor name");
		vendors.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (vendors.isVendorHeaderDisplayed().equals("All vendors")) {
			Assert.assertTrue(true);
			logger.info("User verified vendor page header is dispalyed");
			System.out.println("vendor has been Updated !");
		} else {
			logger.info("Vendoe page header is not dispalyed");
			Assert.fail("All Vendor Header is not disaplayed");
		}

		Thread.sleep(3000);
		vendors.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		vendors.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (vendors.isVendorHeaderDisplayed().equals("All vendors")) {
			Assert.assertTrue(true);
			logger.info("User verified vendor page header is dispalyed");
			System.out.println("vendor has been Deleted !");
		} else {
			logger.info("Vendoe page header is not dispalyed");
			Assert.fail("All Vendor Header is not disaplayed");
		}

	}
}

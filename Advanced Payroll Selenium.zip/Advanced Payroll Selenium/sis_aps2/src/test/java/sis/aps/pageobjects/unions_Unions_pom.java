package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_Unions_pom {

	public WebDriver ldriver;

	public unions_Unions_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath="//a[@class='menu-link menu-toggle']//span[@class='menu-text'][normalize-space()='Unions']")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkUnionsTab);
		//clkUnionsTab.click();
	}
	@FindBy(xpath ="//a[@class='menu-link']//span[@class='menu-text'][normalize-space()='Unions']")
	WebElement clkUnionTab2;

	public void clickUnionsTab2() {
		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkUnionTab2);
		//clkUnionTab2.click();
	}

	@FindBy(xpath = "//button[text()='New union']")
	WebElement clkNewUnionButton;

	public void clickNewUnionButton() {
		clkNewUnionButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Union id']")
	WebElement txtUnionId;

	public void SetUnionId(String UnionId) {
		txtUnionId.sendKeys(UnionId + randomInt);
	}

	public void EnterUnionId(String UnionId) {
		txtUnionId.sendKeys(UnionId);
	}

	public void editUnionId() {
		txtUnionId.clear();
		txtUnionId.sendKeys("AAUI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder='Union name']")
	WebElement txtUnionName;

	public void SetUnionName(String UnionName) {
		txtUnionName.sendKeys(UnionName + randomInt);
	}

	public void EnterUnionName(String UnionName) {
		txtUnionName.sendKeys(UnionName);
	}

	public void editUnionName() {
		txtUnionName.clear();
		txtUnionName.sendKeys("AAUN" + randomInt);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Craft']")
	WebElement txtUcraftId;

	public void ClickUcraftId() {
		txtUcraftId.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][1]")
	WebElement Index1craftId;

	public void ClickIndex1UcraftIdVal() {
		Index1craftId.click();
	}

	@FindBy(xpath = "//app-union-list//h3[text()='All unions']")
	WebElement verifyAllUnionsHd;

	public String isUnionsHeaderDisplayed() {
		return verifyAllUnionsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in union id or name']")
	WebElement txtsearch;

	public void searchUnion() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	public void searchUnionA() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("UnionA");
	}
	
	public void searchUnionB() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("UnionB");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-union-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

	@FindBy(xpath = "//app-union-edit//a[contains(text(),'Union job')]")
	WebElement UnionJobTab;

	public void clickUnionJobTab() {
		UnionJobTab.click();
	}

	@FindBy(xpath = "//div[@role='toolbar']//button[@aria-label='Add']")
	WebElement btnAdd;

	public boolean verifyAddButton() {
		return btnAdd.isDisplayed();
	}

	public void clickAddButton() {
		btnAdd.click();
	}

	@FindBy(xpath = "//input[@id='job___name']")
	WebElement txtJobName;

	public void clickJobNameField() {
		txtJobName.click();
	}

	@FindBy(xpath = "//app-union-edit//a[contains(text(),'Union fringe')]")
	WebElement UnionFringeTab;

	public void clickUnionFringeTab() {
		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", UnionFringeTab);
		//UnionFringeTab.click();
	}

	@FindBy(xpath = "//app-union-edit//a[contains(text(),'Union Special pay')]")
	WebElement UnionSpecialPayTab;

	public void clickUnionSpecialPayTab() {
		UnionSpecialPayTab.click();
	}

	@FindBy(xpath = "//app-union-edit//a[contains(text(),'Union agreement')]")
	WebElement UnionAgreementTab;

	public void clickUnionAgreementTab() {
		UnionAgreementTab.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}
	// below webelements created by Sureshkumar
	@FindBy(xpath="//input[@name='searchText']")WebElement clksearhbtn;
	public String clksearchtxtbtn(String searchtxt)
	{
		clksearhbtn.sendKeys(searchtxt);
		return searchtxt;
	}
	@FindBy(xpath="//mat-icon[contains(text(),'create')]")WebElement clkedit;
	public void clkeditbtn()
	{
		clkedit.click();
	}
	@FindBy(xpath="//a[normalize-space()='Union agreement']")WebElement clkunionagreement;
	public void clkunionagreementtab()
	{
		clkunionagreement.click();
	}
	@FindBy(xpath="//div[@id='grid_2026494267_1_toolbarItems']//following::input[1]")WebElement clkseachbox;
	public String clksearchtxt(String searchtxt)
	{
		clkseachbox.sendKeys(searchtxt);
		return searchtxt;
	}
	@FindBy(xpath="//button[@aria-label='Search']")WebElement clkseachlens;
	public void clksearchlensbtn()
	{
		clkseachlens.click();
	}
	@FindBy(xpath="//span[contains(text(),'Rate *')]//following::table[1]//tbody[1]//tr[1]//td[2]") WebElement getjobcoderatevalue;
	public String getjobcoderate()
	{
		return getjobcoderatevalue.getText();
	}
	@FindBy(xpath="//div[@class='union-agreement-edit-tab']//following::div[1]//ul[1]//li[2]")WebElement clkunionagreementfringes;
	public void clkunionagreementfringestab()
	{
		clkunionagreementfringes.click();
	}
	@FindBy(xpath="//td[contains(text(),'FixedHourlyRate')]//following::td[1]") WebElement getfixedhorlyratevalue;
	public String getfixedhourlyrate()
	{
		return getfixedhorlyratevalue.getText();
	}
	@FindBy(xpath="//td[contains(text(),'FixedPercentage')]//following::td[1]") WebElement getfixedpercentageratevalue;
	public String getfixedpercentagerate()
	{
		return getfixedpercentageratevalue.getText();
	}
	@FindBy(xpath="//td[contains(text(),'FlatEmployeeBased')]//following::td[1]") WebElement getflatemployedbaseratevalue;
	public String getflatemployedbaserate()
	{
		return getflatemployedbaseratevalue.getText();
	}
	@FindBy(xpath="//td[contains(text(),'StandardEarnings')]//following::td[1]") WebElement getstdearningsratevalue;
	public String getstdearningsrate()
	{
		return getstdearningsratevalue.getText();
	}
	@FindBy(xpath="//td[contains(text(),'TotalEarnedHours')]//following::td[1]") WebElement gettotalearnedhoursratevalue;
	public String getearnedhoursrate()
	{
		return gettotalearnedhoursratevalue.getText();
	}
	@FindBy(xpath="//span[contains(text(),'Union management')]") WebElement clkunionmgmttab;
	public void clickunionmgmttab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkunionmgmttab);
		//clkunionmgmttab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Union setup')]") WebElement clkunionsetuptab;
	public void clickunionsetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkunionsetuptab);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Union setup')]") WebElement clkunionagreementfringestab;
	public void clickunionagreementfringestab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkunionagreementfringestab);
		//clkunionagreementfringestab.click();
	}
	@FindBy(xpath="//table[@class='e-table']//tr[1]//td[5]") WebElement getfringecap;
	public String getfringecapvalue()
	{
		return getfringecap.getText();
	}
	
}

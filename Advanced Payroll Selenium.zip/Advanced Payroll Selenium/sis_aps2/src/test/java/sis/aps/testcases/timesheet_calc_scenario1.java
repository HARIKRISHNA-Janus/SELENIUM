package sis.aps.testcases;



import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.utilities.XLUtils;

public class timesheet_calc_scenario1 extends baseclass {
	
	@Test
	public void timesheet_scenario1_calc() throws Exception
	{	
		String path="./excel/Timesheet_CalculatedCost.xlsx";
		XLUtils.setExcelFile(path, "Shet1");
		int xlrowcount=XLUtils.getRowCount(path, "Shet1");
		int xlcellcount=XLUtils.getCellCount(path, path, xlrowcount);
		FileInputStream file=new FileInputStream(path);
		XSSFWorkbook worbook=new XSSFWorkbook(file);
		XSSFSheet sheet=worbook.getSheet("Sheet1");
		int excelrowcount=sheet.getLastRowNum();
		int excelcellcount=sheet.getRow(0).getLastCellNum();
		for(int i=1;i<=excelrowcount;i++)
		{
			XSSFRow row=sheet.getRow(i);
			for(int c=0;c<=excelcellcount;c++)
			{
				XSSFCell cell=row.getCell(c);
				DataFormatter formatter=new DataFormatter();
				String celldata=formatter.formatCellValue(cell);
				System.out.print(celldata);
			}
			System.out.println();
		}
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timemgmt_alltimesheet_pom timesheet1=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		Thread.sleep(2000);
		timesheet.clkWorkersText();
		timesheet.txtworker(workername);
		System.out.println("Worker selected is: " +workername);
		Thread.sleep(2000);
		timesheet.selectWorker();
		Thread.sleep(2000);
		timesheet.clkProjectText();
		timesheet.txtproject(project);
		System.out.println("Project selected is: " +project);
		Thread.sleep(2000);
		timesheet.selectproject();
		Thread.sleep(2000);
		timesheet.clkTaskcodeText();
		if(timesheet.txttaskcodestring(taskcode).equals("T001"))
		{
		timesheet.setTaskcode1();
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
		{
		timesheet.setTaskcode2();
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
		{
		timesheet.setTaskcode3();
		}
		System.out.println("TaskCode selected is: " +taskcode);
		Thread.sleep(2000);
		timesheet.clkPayperiodText();
		if(timesheet.txtpayperiodstring(payperiod).equals("11/01/2020"))
		{
			timesheet.setPayperiod1();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/08/2020"))
		{
			timesheet.setPayperiod2();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/2020"))
		{
			timesheet.setPayperiod3();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/2020"))
		{
			timesheet.setPayperiod4();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/2020"))
		{
			timesheet.setPayperiod5();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/06/2020"))
		{
			timesheet.setPayperiod6();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/2020"))
		{
			timesheet.setPayperiod7();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/2020"))
		{
			timesheet.setPayperiod8();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/2020"))
		{
			timesheet.setPayperiod9();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/03/2021"))
		{
			timesheet.setPayperiod10();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/10/2021"))
		{
			timesheet.setPayperiod11();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/17/2021"))
		{
			timesheet.setPayperiod12();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/24/2021"))
		{
			timesheet.setPayperiod13();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/31/2021"))
		{
			timesheet.setPayperiod14();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/07/2021"))
		{
			timesheet.setPayperiod15();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/14/2021"))
		{
			timesheet.setPayperiod16();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/21/2021"))
		{
			timesheet.setPayperiod17();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/28/2021"))
		{
			timesheet.setPayperiod18();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/07/2021"))
		{
			timesheet.setPayperiod19();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/14/2021"))
		{
			timesheet.setPayperiod20();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/21/2021"))
		{
			timesheet.setPayperiod21();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/28/2021"))
		{
			timesheet.setPayperiod22();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/04/2021"))
		{
			timesheet.setPayperiod23();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/11/2021"))
		{
			timesheet.setPayperiod24();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/18/2021"))
		{
			timesheet.setPayperiod25();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/25/2021"))
		{
			timesheet.setPayperiod26();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/02/2021"))
		{
			timesheet.setPayperiod27();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/09/2021"))
		{
			timesheet.setPayperiod28();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/16/2021"))
		{
			timesheet.setPayperiod29();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/23/2021"))
		{
			timesheet.setPayperiod30();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/30/2021"))
		{
			timesheet.setPayperiod31();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("06/06/2021"))
		{
			timesheet.setPayperiod32();
		}
		System.out.println("PayPeriod selected is: " +payperiod);
		timesheet.btnSave();
		Thread.sleep(5000);
		timesheet.setRow1();
		Thread.sleep(1000);
		timesheet.setRow1();
		timesheet.Edit();
		Thread.sleep(1000);
		timesheet.seteditprojectcode();
		Thread.sleep(1000);
		timesheet.clreditprojectcode();
		Thread.sleep(1000);
		timesheet.seteditprojectcode();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(row1projectcode);
		Thread.sleep(1000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.setedittaskcode();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		//timesheet.txtedittaskcodestring(row1taskcode);
		timesheet.setedittaskcode();
		Thread.sleep(1000);
		if(timesheet.txtedittaskcodestring(row1taskcode).equals("T001"))
		{
		timesheet.setTaskcode1();
		}
		else if(timesheet.txtedittaskcodestring(row1taskcode).equals("T002"))
		{
		timesheet.setTaskcode2();
		}
		else if(timesheet.txtedittaskcodestring(row1taskcode).equals("T003"))
		{
		timesheet.setTaskcode3();
		}
		Thread.sleep(1000);
		timesheet.seteditregularhours();
		Thread.sleep(1000);
		timesheet.txteditregularhoursstring(row1regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(row1overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(row1doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(row1tripletimehours);
		Thread.sleep(1000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		int rowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr")).size();
		String numofrows=String.valueOf(rowcount);
		System.out.println("number of rows: " +numofrows);
		for(int r=1;r<=rowcount;r++)
		{
			String totalhours=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
			int totalhoursfinalvalue=Integer.parseInt(totalhours);
			String eomployeerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
			double employeeratefinalvalue=Double.parseDouble(eomployeerate);
			String unionrate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
			double unionratefinalvalue=Double.parseDouble(unionrate);
			String privailingwagerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
			double privailingwageratefinalvalue=Double.parseDouble(privailingwagerate);
			String calculatedcost=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
			double calculatedcostfinalvalue=Double.parseDouble(calculatedcost);
			if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			
		}
	}

}

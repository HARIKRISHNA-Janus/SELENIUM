package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class advancepayroll_crafts_pom {

	public WebDriver ldriver;

	public advancepayroll_crafts_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Advance payroll'])[1]")
	WebElement clkAdvancepayrollTab;

	public void clickAdvancepayrollTab() {
		clkAdvancepayrollTab.click();
	}

	@FindBy(xpath = "//span[text()='Crafts']")
	WebElement clkCraftsTab;

	public void clickCraftTab() {
		clkCraftsTab.click();
	}

	@FindBy(xpath = "//button[text()='New craft']")
	WebElement clkNewCraftButton;

	public void clickNewCraftButton() {
		clkNewCraftButton.click();
	}

	@FindBy(xpath = " //input[@data-placeholder=\"Craft id\"]")
	WebElement txtCraftId;

	public void SetCraftId(String CraftId) {

		txtCraftId.sendKeys(CraftId + randomInt);
	}

	public void editCraftId() {
		txtCraftId.clear();
		txtCraftId.sendKeys("AACI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Craft name\"]")
	WebElement txtCraftName;

	public void SetCraftName(String CraftName) {
		txtCraftName.sendKeys(CraftName + randomInt);
	}

	public void editCraftName() {
		txtCraftName.clear();
		txtCraftName.sendKeys("AACN" + randomInt);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//app-craft-list//h3[text()='All crafts']")
	WebElement verifyAllCraftsHd;

	public String isCraftsHeaderDisplayed() {
		return verifyAllCraftsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Search in craft id or name\"]")
	WebElement txtsearch;

	public void searchcraft() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-craft-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

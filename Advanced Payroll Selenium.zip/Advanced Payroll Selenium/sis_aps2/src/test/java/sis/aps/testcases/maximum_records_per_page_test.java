package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_Shits_pom;
import sis.aps.pageobjects.basepage;
import sis.aps.pageobjects.loginpage_pom;

public class maximum_records_per_page_test extends baseclass {

	@Test
	public void Shifts_create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		/* Create a Shift */
		advancepayroll_Shits_pom advancepayrollSFT = new advancepayroll_Shits_pom(driver);
		advancepayrollSFT.clickAdvancepayrollTab();
		logger.info("User clicked AdvancePayroll Leftsliding Menu");
		advancepayrollSFT.clickShiftTab();
		logger.info("User clicked shift Leftsliding Sunmenu");
		
		basepage basepageObj = new basepage(driver);
		basepageObj.selectMaximumRecordsPerPage();
		
		Thread.sleep(3000);

}
	
}

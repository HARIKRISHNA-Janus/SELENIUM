package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class operations_TaskCodes_pom {

	public WebDriver ldriver;

	public operations_TaskCodes_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	WebElement clkoperationsTab;

	public void clickOperationsTab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperationsTab);
		// clkoperationsTab.click();
	}

	@FindBy(xpath = "//span[text()='Task codes']")
	WebElement clkTaskCodesTab;

	public void clickTaskCodesTab() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTaskCodesTab);
		// clkTaskCodesTab.click();
	}

	@FindBy(xpath = "//button[text()='New task code']")
	WebElement clkNewTaskCodeButton;

	public void clickNewTaskCodeButton() {
		clkNewTaskCodeButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Task id']")
	WebElement InputTaskId;

	public void SetTaskId(String TaskId) {
		InputTaskId.click();
		InputTaskId.sendKeys(TaskId + randomInt);
	}

	public void editTaskId() {
		InputTaskId.clear();
		InputTaskId.sendKeys("AA_TI");
	}

	@FindBy(xpath = "//input[@data-placeholder='Task name']")
	WebElement InputTaskName;

	public void SetTasktName(String TaskName) {
		InputTaskName.click();
		InputTaskName.sendKeys(TaskName + randomInt);
	}

	public void editTaskName() {
		InputTaskName.clear();
		InputTaskName.sendKeys("AA_TN");
	}

	@FindBy(xpath = "//input[@data-placeholder='Earning code']")
	WebElement clkEarningCode;

	public void ClickEarningCode() {
		clkEarningCode.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//h3[text()='All task codes']")
	WebElement AllTaskCodesHd;

	public String isAllTaskCodesHdHeaderDisplayed() {
		return AllTaskCodesHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in task code id or name']")
	WebElement txtsearch;

	public void searchTaskcodes() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-task-code-delete-modal//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

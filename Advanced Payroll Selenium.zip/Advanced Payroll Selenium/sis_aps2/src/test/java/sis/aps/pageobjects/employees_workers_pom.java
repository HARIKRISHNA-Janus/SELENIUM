package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class employees_workers_pom {
	
	public WebDriver ldriver;

	public employees_workers_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//below webelements created by Sureshkumar 
	@FindBy(xpath="//a[@class='menu-link menu-toggle']//span[@class='menu-text'][normalize-space()='Employees']") WebElement clkEmployeesTab;
	public void EmployeesTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEmployeesTab);
		//clkEmployeesTab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Workers')]") WebElement clkWorkers;
	public void WorkersScreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkWorkers);
		//clkEthnicorigins.click();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-worker[1]/app-worker-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]/span[1]") WebElement chkSyncADP;
	public boolean chkSyncWithADP()
	{
		return chkSyncADP.isEnabled();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-worker[1]/app-worker-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]/span[1]") WebElement clkSyncADP;
	public void clkSyncWithADP()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSyncADP.click();
	}
	@FindBy(xpath="//span[@class='sync ng-star-inserted']") WebElement chkAppDate;
	public String chkAppDateDisplay()
	{
		return chkAppDate.getText();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-worker[1]/app-worker-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]/span[1]") WebElement chkSyncADPagain;
	public boolean chkSyncADPEnabledBack()
	{
		return chkSyncADPagain.isEnabled();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'check_circle')]") WebElement chkCircle;
	public boolean chkCircleEnabled()
	{
		return chkCircle.isEnabled();
	}
	@FindBy(xpath="//span[@class='react-bootstrap-table-pagin ation-total']") WebElement chkRow;
	public String chkRowDisplay()
	{		
		return chkRow.getText();
	}
	@FindBy(xpath="//tbody/tr[2]/td[7]/a[1]") WebElement chkEdit;
	public boolean chkEditEnabled()
	{
		return chkEdit.isEnabled();
	}
	@FindBy(xpath="//tbody/tr[2]/td[7]/a[1]") WebElement clkEdit;
	public void clkEdit()
	{
		clkEdit.click();
	}
	@FindBy(xpath="//a[contains(text(),'Cancel')]") WebElement chkCancel;
	public boolean chkCancelDisplay()
	{
		return chkCancel.isDisplayed();
	}
	@FindBy(xpath="//button[contains(text(),'Save')]") WebElement chkSave;
	public boolean chkSaveEnabled()
	{
		return chkSave.isEnabled();
	}
	@FindBy(xpath="//a[contains(text(),'Cancel')]") WebElement clkCancelbtn;
	public void clkCancel()
	{
		clkCancelbtn.click();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'check_circle')]") WebElement chkCircleAgain;
	public boolean chkCircleEnabledBack()
	{
		return chkCircleAgain.isEnabled();
	}
	@FindBy(xpath="//input[@name='searchText']") WebElement clksearchtxt;
	public String clkSearchbtn(String workername)
	{
		clksearchtxt.sendKeys(workername);
		return workername;
	}
	@FindBy(xpath="//input[@name='searchText']") WebElement clksearchtxtworkerpersonalnum;
	public String clksearchtxtworkerpersonalnum(String workerpersonalnum)
	{
		clksearchtxtworkerpersonalnum.sendKeys(workerpersonalnum);
		return workerpersonalnum;
	}
	@FindBy(xpath="//a[@title='Edit worker']") WebElement clkEditbtn;
	public void clkEditbtn()
	{
		clkEditbtn.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-worker-detail-list/div/div[2]/ul/li[3]/a") WebElement clkworkcurrentposition;
	public void clkworkercurrentpositiontab()
	{
		clkworkcurrentposition.click();
	}
	@FindBy(xpath="//div[normalize-space()='Hourly rate amount']//following::div[1]") WebElement gethourlyrate;
	public String getHorlyrateamt()
	{
		return gethourlyrate.getText();
	}
	@FindBy(xpath="//div[normalize-space()='Job code']//following::div[1]") WebElement getjobcodetxt;
	public String getjobcode()
	{
		return getjobcodetxt.getText();
	}
	@FindBy(xpath="//div[normalize-space()='Position id']//following::div[1]") WebElement getpositionidtxt;
	public String getpositionid()
	{
		return getpositionidtxt.getText();
	}
	@FindBy(xpath="//span[contains(text(),'Payroll management')]") WebElement clkpayrollmgmtadptab;
	public void clickpayrollmgmtadptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollmgmtadptab);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Worker setup')]") WebElement clkworkerssetuptab;
	public void clickworkerssetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkerssetuptab);
		//clkworkerssetuptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Workers')]") WebElement clkworkerstab;
	public void clickworkerstab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkerstab);
		//clkpayrollmgmtadptab.click();
	}
	//to get the full name details of worker
	@FindBy(xpath="//th[contains(text(),' Full name ')]//following::tbody/tr/td[2]") WebElement getworkerfullnamedetails;
	public String getworkerfullname()
	{
		return getworkerfullnamedetails.getText();
	}
	
}

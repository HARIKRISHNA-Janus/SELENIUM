package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_Shits_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc20_shifts_create extends baseclass {

	@Test
	public void Shifts_create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		/* Create a Shift */
		advancepayroll_Shits_pom advancepayrollSFT = new advancepayroll_Shits_pom(driver);
		advancepayrollSFT.clickAdvancepayrollTab();
		logger.info("User clicked AdvancePayroll Leftsliding Menu");
		advancepayrollSFT.clickShiftTab();
		logger.info("User clicked shift Leftsliding Sunmenu");
		advancepayrollSFT.clickNewShiftButton();
		logger.info("User clicked new shift button");
		advancepayrollSFT.SetShiftId(shiftId);
		logger.info("User entered the shift Id");
		advancepayrollSFT.SetShiftName(shiftName);
		logger.info("User entered the shift Name");
		advancepayrollSFT.ClickCalMethodDropdown();
		logger.info("User clicked calculation method drop-down field");
		advancepayrollSFT.ClickIndex1ValCalMethodDropdown();
		logger.info("User clicked index 1 value");
		advancepayrollSFT.SetRate(Rate);
		logger.info("User entered the Rate");
		advancepayrollSFT.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (advancepayrollSFT.isShiftsHeaderDisplayed().equals("All shifts")) {
			Assert.assertTrue(true);
			logger.info("User verified All shifts page Header");
			System.out.println("Shift has been created successfully !");
		} else {
			Assert.fail("All Shifts Header is not disaplayed");
			logger.info("All shifts Page Header is not dispalyed");
		}
		
		Thread.sleep(3000);
		advancepayrollSFT.searchShift();
		logger.info("User entered the shift Id/Name in search input field");
		Thread.sleep(3000);
		advancepayrollSFT.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		advancepayrollSFT.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (advancepayrollSFT.isShiftsHeaderDisplayed().equals("All shifts")) {
			Assert.assertTrue(true);
			logger.info("User verified All Shifts page Header");
			System.out.println("Shift has been created successfully !");
		} else {
			Assert.fail("All Shifts Header is not disaplayed");
			logger.info("All shifts Page Header is not dispalyed");
		}

	}
}

package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_UnionAgreements_pom {

	public WebDriver ldriver;

	public unions_UnionAgreements_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Unions'])[1]")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		clkUnionsTab.click();
	}

	@FindBy(xpath = "(//a//span[text()='Union agreements'])[1]")
	WebElement UAgreementsTab;

	public void scrollIntoView() {
//		Actions actions = new Actions(ldriver);
//		actions.moveToElement(UAgreementsTab);
//		actions.perform();
		((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", UAgreementsTab);
	}

	public void clickUnionAggrementsTab() {
		UAgreementsTab.click();
	}

	@FindBy(xpath = "//button[text()='New union agreement']")
	WebElement NewUAgreementsButton;

	public void clickNewUnionAgreementButton() {
		NewUAgreementsButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Union agreement id']")
	WebElement txtUAgreementId;

	public void SetUAgreementId(String UAgreementId) {
		txtUAgreementId.sendKeys(UAgreementId + randomInt);
	}

	public void editUAgreementId() {
		txtUAgreementId.clear();
		txtUAgreementId.sendKeys("AAAI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder='Union agreement name']")
	WebElement txtUAgreementName;

	public void SetUAgreementName(String UAgreementName) {
		txtUAgreementName.sendKeys(UAgreementName + randomInt);
	}

	public void editUAgreementName() {
		txtUAgreementName.clear();
		txtUAgreementName.sendKeys("AAAN" + randomInt);
	}

	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement btnDatePicker;

	public void clickDatepickerButton() {
		btnDatePicker.click();
	}

	@FindBy(xpath = "//tbody[@class='mat-calendar-body']//div[contains(@class,'today')]")
	WebElement currentDate;

	public void clickCurrentDate() {
		currentDate.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Union']")
	WebElement inputUnionHome;

	public void ClickUnionHome() {
		inputUnionHome.click();
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//mat-slide-toggle//div[@class='mat-slide-toggle-thumb']")
	WebElement SliderActive;

	public void clickSActiveSlider() {
		SliderActive.click();
	}

	@FindBy(xpath = "//span[text()='Union agreement updated successfully']")
	WebElement UAgreementUpdateMsg;

	public String IsUAgreementUpdated() {
		return UAgreementUpdateMsg.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][1]")
	WebElement Index1Val;

	public void ClickIndex1Val() {
		Index1Val.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option//span//b[text()='UnionA']")
	WebElement ValUnionA;

	public void ClickUnionAValue() {
		ValUnionA.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][2]")
	WebElement Index2Val;

	public void ClickIndex2Val() {
		Index2Val.click();
	}

	@FindBy(xpath = "//app-union-agreement-edit//a[contains(text(),'Union agreement job')]")
	WebElement U_AgreementJobTab;

	public String is_UnionAgreementJobTabDisplayed() {
		return U_AgreementJobTab.getText();
	}

	public void ClickUnionAgreementJobTab() {
		U_AgreementJobTab.click();
	}

	@FindBy(xpath = "//app-union-agreement-edit//a[contains(text(),'Union agreement fringes')]")
	WebElement U_AgreementFringesTab;

	public void ClickUnionAgreementFringesTab() {
		U_AgreementFringesTab.click();
	}

	@FindBy(xpath = "//app-union-agreement-edit//a[contains(text(),'Union agreement special pay')]")
	WebElement U_AgreementSpecialPayTab;

	public void ClickUnionAgreementSpecialPayTab() {
		U_AgreementSpecialPayTab.click();
	}

	@FindBy(xpath = "//table//tr//td[@tabindex='0']")
	WebElement tableRow1;

	public boolean isRow1Displayed() {
		return tableRow1.isDisplayed();
	}

	@FindBy(xpath = "//app-union-agreement-list//h3[text()='All union agreements']")
	WebElement AllUnionAgreementsHd;

	public String isAllUnionAgreementHeaderDisplayed() {
		return AllUnionAgreementsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in agreement id or name']")
	WebElement txtsearch;

	public void searchAgreement() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-union-agreement-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

	@FindBy(xpath = "//button//span[text()='Delete']")
	WebElement CheckDeleteBTN;

	public boolean IsDeleteBtnVisible() {
		return CheckDeleteBTN.isDisplayed();
	}

	@FindBy(xpath = "//button//span[text()='Add']")
	WebElement CheckAddBTN;

	public boolean IsAddBtnVisible() {
		return CheckAddBTN.isDisplayed();
	}

}

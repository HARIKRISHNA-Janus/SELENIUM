package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_UnionReciprocities_pom;

public class tc28_Unionreciprocity_create extends baseclass {

	@Test
	public void UnionReciprocity_create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(13000);

		/* Create a Union Reciprocity */
		unions_UnionReciprocities_pom unionReciprocity = new unions_UnionReciprocities_pom(driver);
		unionReciprocity.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		unionReciprocity.clickUnionReciprocitiesTab();
		logger.info("User clicked union reciprocitied Leftsliding Sunmenu");
		unionReciprocity.clickNewUnionReciprocityButton();
		logger.info("User clicked new union reciprocity button");
		unionReciprocity.SetReciprocityIdId(reciprocityId);
		logger.info("User entered the reciprocity Id");
		unionReciprocity.clickDatepickerButton();
		logger.info("User clicked datepicker icon");
		Thread.sleep(2000);
		unionReciprocity.clickCurrentDate();
		logger.info("User clicked current date from the calender");
		Thread.sleep(2000);
		unionReciprocity.ClickHomeUnion();
		logger.info("User clicked home union indput field");
		Thread.sleep(2000);
		unionReciprocity.ClickUnionAValue();
		logger.info("User clicked Union A value");
		unionReciprocity.clickWorkUnion();
		logger.info("User clicked work union indput field");
		Thread.sleep(2000);
		unionReciprocity.ClickUnionBValue();
		logger.info("User clicked UnionB value");
		unionReciprocity.clickReciprocitiesSourceDropdown();
		logger.info("User clicked reciprocities source drop-down");
		Thread.sleep(2000);
		unionReciprocity.ClickIndex1Val();
		logger.info("User clicked index 1 value");
		unionReciprocity.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (unionReciprocity.is_UnionReciprocityFringeTabDisplayed().equals("Union reciprocity fringe")) {
			Assert.assertTrue(true);
			logger.info("User verified union reciprocity Fringe Tab is dispalyed");
		} else {
			System.out.println("Union reciprocity fringe Tab is not Displayed");
			logger.info("Union reciprocity Fringe Tab is not dispalyed");
		}

		/*
		 * unionReciprocity.clickAddButton(); logger.info("User clicked add button");
		 * Thread.sleep(2000); unionReciprocity.clickUnionFringeCodeField();
		 * logger.info("User clicked union Fringe code input field");
		 * Thread.sleep(2000); unionReciprocity.ClickIndex1Val();
		 * logger.info("User clicked index 1 value");
		 * unionReciprocity.clickUnionFringeFCodeField();
		 * logger.info("User clicked union Fringe Fringe code input field");
		 * Thread.sleep(2000); unionReciprocity.ClickIndex1Val();
		 * logger.info("User clicked index 1 value"); Thread.sleep(2000);
		 * unionReciprocity.clickUpdateButton();
		 * logger.info("User clicked update button"); Thread.sleep(2000);
		 * 
		 * if (unionReciprocity.isRow1Displayed()) { Assert.assertTrue(true);
		 * logger.info("union reciprocity Fringe has been added"); } else {
		 * Assert.fail(); logger.info("union reciprocity Fringe has not been added");
		 * System.out.println("Union Reciprocity Fringe has not been Created"); }
		 */

		unionReciprocity.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (unionReciprocity.isAllUnionReciprocityHeaderDisplayed().equals("All union reciprocities")) {
			Assert.assertTrue(true);
			logger.info("User verified All union reciprocities page Header");
			System.out.println("Union Reciprocity has been created successfully !");
		} else {
			logger.info("union reciprocities page Header not displayed");
			Assert.fail("All Union Reciprocities Header is not disaplayed");
		}

		Thread.sleep(2000);
		unionReciprocity.searchReciprocity();
		logger.info("User entered the reciprocity Id/Name in search input field");
		Thread.sleep(2000);
		unionReciprocity.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		unionReciprocity.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (unionReciprocity.isAllUnionReciprocityHeaderDisplayed().equals("All union reciprocities")) {
			Assert.assertTrue(true);
			logger.info("User verified All union reciprocities page Header");
			System.out.println("Union Reciprocity has been created successfully !");
		} else {
			logger.info("union reciprocities page Header not displayed");
			Assert.fail("All Union Reciprocities Header is not disaplayed");
		}

	}
}

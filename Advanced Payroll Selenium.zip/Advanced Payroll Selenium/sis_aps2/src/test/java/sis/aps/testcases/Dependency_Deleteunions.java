package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_Unions_pom;

public class Dependency_Deleteunions extends baseclass {

	@Test
	public void Dependency_CreateUnion() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(5000);
		login.clkSignin();
		Thread.sleep(13000);

		unions_Unions_pom deleteUnion = new unions_Unions_pom(driver);
		deleteUnion.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		deleteUnion.clickUnionsTab2();
		logger.info("User clicked Union Leftsliding Sunmenu");

		/* Delete Union A */

		Thread.sleep(3000);
		deleteUnion.searchUnionA();
		Thread.sleep(3000);
		logger.info("User entered the union Id/Name in search input field");
		Thread.sleep(2000);
		deleteUnion.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		deleteUnion.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (deleteUnion.isUnionsHeaderDisplayed().equals("All unions")) {
			Assert.assertTrue(true);
			logger.info("User verified All Uions page Header");
			logger.info("Union A has been deleted");
		} else {
			Assert.fail("All Unions Header is not disaplayed");
			logger.info("All Unions Page Header is not dispalyed");
			logger.info("Union A has not been deleted");
		}

		/* Delete Union B */

		Thread.sleep(3000);
		deleteUnion.searchUnionB();
		Thread.sleep(3000);
		logger.info("User entered the union Id/Name in search input field");
		Thread.sleep(2000);
		deleteUnion.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		deleteUnion.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (deleteUnion.isUnionsHeaderDisplayed().equals("All unions")) {
			Assert.assertTrue(true);
			logger.info("User verified All Uions page Header");
			logger.info("Union B has been deleted");
		} else {
			Assert.fail("All Unions Header is not disaplayed");
			logger.info("All Unions Page Header is not dispalyed");
			logger.info("Union B has not been deleted");
		}

		/* Navigate to Homepage */

		Thread.sleep(3000);
		login.clkLogo();
		Thread.sleep(3000);

	}
}

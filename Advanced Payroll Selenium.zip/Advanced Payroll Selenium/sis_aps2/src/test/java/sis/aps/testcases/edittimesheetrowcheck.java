package sis.aps.testcases;

import org.openqa.selenium.By;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.utilities.XLUtils;

public class edittimesheetrowcheck extends baseclass {

	public void timesheet_editrow() throws Exception
	{
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(13000);

		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timesheet.TimesheetTab();
		
		String path="./excel/Timesheet_CalculatedCost.xlsx";
		String sheetname="Sheet1";
		XLUtils.setExcelFile(path, sheetname);
		int xlrowcount=XLUtils.getRowCount(path, sheetname);
		int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
		System.out.println(xlrowcount);
		System.out.println(xlcellcount);
		for(int i=1;i<=xlrowcount;i++)
		{
			String workername=XLUtils.getCellData(path, sheetname, i, 0);
			String project=XLUtils.getCellData(path, sheetname, i, 1);
			String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
			String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
			String editdate=XLUtils.getCellData(path, sheetname, i, 4);
			String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
			String edittaskcode=XLUtils.getCellData(path, sheetname, i, 6);
			String editregularhours=XLUtils.getCellData(path, sheetname, i, 7);
			String editovertimehours=XLUtils.getCellData(path, sheetname, i, 8);
			String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 9);
			String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 10);
			
			timesheet.AllTimesheetScreen();
			Thread.sleep(3000);
			timesheet.NewTimesheet();
			Thread.sleep(2000);
			timesheet.clkWorkersText();
			timesheet.txtworker(workername);
			System.out.println("Worker selected is: " +workername);
			Thread.sleep(2000);
			timesheet.selectWorker();
			Thread.sleep(2000);
		    timesheet.clkProjectText();
			timesheet.txtproject(project);
			System.out.println("Project selected is: " +project);
			Thread.sleep(2000);
			timesheet.selectproject();
			Thread.sleep(2000);
			timesheet.clkTaskcodeText();
			if(timesheet.txttaskcodestring(taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			System.out.println("TaskCode selected is: " +taskcode);
			Thread.sleep(2000);
			timesheet.clkPayperiodText();
			if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
			{
				timesheet.setPayperiod1();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/8/20"))
			{
				timesheet.setPayperiod2();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
			{
				timesheet.setPayperiod3();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/20"))
			{
				timesheet.setPayperiod4();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
			{
				timesheet.setPayperiod5();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/6/20"))
			{
				timesheet.setPayperiod6();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
			{
				timesheet.setPayperiod7();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/20"))
			{
				timesheet.setPayperiod8();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
			{
				timesheet.setPayperiod9();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/3/21"))
			{
				timesheet.setPayperiod10();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
			{
				timesheet.setPayperiod11();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/17/21"))
			{
				timesheet.setPayperiod12();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
			{
				timesheet.setPayperiod13();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/31/21"))
			{
				timesheet.setPayperiod14();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
			{
				timesheet.setPayperiod15();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/14/21"))
			{
				timesheet.setPayperiod16();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
			{
				timesheet.setPayperiod17();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/28/21"))
			{
				timesheet.setPayperiod18();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
			{
				timesheet.setPayperiod19();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/14/21"))
			{
				timesheet.setPayperiod20();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
			{
				timesheet.setPayperiod21();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/28/21"))
			{
				timesheet.setPayperiod22();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
			{
				timesheet.setPayperiod23();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/11/21"))
			{
				timesheet.setPayperiod24();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
			{
				timesheet.setPayperiod25();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/25/21"))
			{
				timesheet.setPayperiod26();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
			{
				timesheet.setPayperiod27();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/9/21"))
			{
				timesheet.setPayperiod28();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
			{
				timesheet.setPayperiod29();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/23/21"))
			{
				timesheet.setPayperiod30();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
			{
				timesheet.setPayperiod31();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("6/6/21"))
			{
				timesheet.setPayperiod32();
			}
			System.out.println("PayPeriod selected is: " +payperiod);
			timesheet.btnSave();
			Thread.sleep(5000);
			int editrowcount=driver.findElements(By.xpath("//*[@id=\"grid_822389490_0_content_table\"]/tbody/tr")).size();
			String editnumofrows=String.valueOf(editrowcount);
			System.out.println("Edit number of Rows: " +editnumofrows);
			for(int e=1;e<=editrowcount;e++)
			{
				timesheet.Edit();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id=\"grid_822389490_0_content_table\"]/tbody/tr["+e+"]/td[8]")).sendKeys(editregularhours);
				driver.findElement(By.xpath("//*[@id=\"grid_822389490_0_content_table\"]/tbody/tr["+e+"]/td[9]")).sendKeys(editovertimehours);
				driver.findElement(By.xpath("//*[@id=\"grid_822389490_0_content_table\"]/tbody/tr["+e+"]/td[10]")).sendKeys(editdoubletimehours);
				driver.findElement(By.xpath("//*[@id=\"grid_822389490_0_content_table\"]/tbody/tr["+e+"]/td[11]")).sendKeys(edittripletimehours);
				/*
				timesheet.seteditdate();
				Thread.sleep(1000);
				timesheet.cleareditdate();
				timesheet.seteditdate();
				Thread.sleep(1000);
				timesheet.txteditdatestring(editdate);
				Thread.sleep(1000);
				*/
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				//timesheet.txtedittaskcodestring(row1taskcode);
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				if(timesheet.txtedittaskcodestring(edittaskcode).equals("T001"))
				{
				timesheet.setTaskcode1();
				}
				else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T002"))
				{
				timesheet.setTaskcode2();
				}
				else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T003"))
				{
				timesheet.setTaskcode3();
				}
				Thread.sleep(1000);
				timesheet.seteditregularhours();
				Thread.sleep(1000);
				timesheet.txteditregularhoursstring(editregularhours);
				Thread.sleep(1000);
				timesheet.seteditovertimehours();
				Thread.sleep(1000);
				timesheet.txteditovertimehoursstring(editovertimehours);
				Thread.sleep(1000);
				timesheet.seteditdoubletimehours();
				Thread.sleep(1000);
				timesheet.txteditdoubletimehoursstring(editdoubletimehours);
				Thread.sleep(1000);
				timesheet.setedittripletimehours();
				Thread.sleep(1000);
				timesheet.txtedittripletimehoursstring(edittripletimehours);
				Thread.sleep(1000);
				timesheet.Update();
				Thread.sleep(7000);
			}
			
		}
	}
		
}

package sis.aps.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;

public class tc01_logincheck extends baseclass {
	
	@Test
	public void logintest() throws InterruptedException, IOException, Exception
	{
		
		//String path="./excel/StepsStatus.xlsx";
		//String sheetname="Sheet2";
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		//XLUtils.setCellData(path, sheetname, 3, 4, "Pass");
		login.setPasword(password);
		Thread.sleep(1000);
		login.clkSignin();
		Thread.sleep(5000);
		//XLUtils.setCellData(path, sheetname, 4, 4, "Pass");
		//XLUtils.setCellData(path, sheetname, 5, 4, "Pass");
		if(driver.getTitle().equals("SIS APS"))
		{
			Assert.assertTrue(true);
			logger.info("Logged in Successfully");
		}
		else
		{
			Assert.fail();
			logger.info("Login failed");
		}
		Thread.sleep(10000);
		//XLUtils.setCellData(path, sheetname, 6, 4, "Pass");
		//login.clkicon();
		//login.clkSignout();
		//logger.info("Logout Successfully");
	}
}

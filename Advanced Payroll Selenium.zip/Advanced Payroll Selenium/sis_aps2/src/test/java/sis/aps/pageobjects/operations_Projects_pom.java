package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class operations_Projects_pom {

	public WebDriver ldriver;

	public operations_Projects_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	WebElement clkoperationsTab;

	public void clickOperationsTab() {
		clkoperationsTab.click();
	}

	@FindBy(xpath = "//span[text()='Projects']")
	WebElement clkProjectsTab;

	public void clickProjectsTab() {
		clkProjectsTab.click();
	}

	@FindBy(xpath = "//button[text()='New project']")
	WebElement clkNewProjectButton;

	public void clickNewProjectButton() {
		clkNewProjectButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Project id']")
	WebElement InputProjectId;

	public void SetProjectId(String ProjectId) {
		InputProjectId.click();
		InputProjectId.sendKeys(ProjectId + randomInt);
	}

	public void SetDProjectId() {
		InputProjectId.click();
		InputProjectId.sendKeys("TestAutomation");
	}

	public void editProjectId() {
		InputProjectId.clear();
		InputProjectId.sendKeys("AA_PI");
	}

	@FindBy(xpath = "//input[@data-placeholder='Project name']")
	WebElement InputProjectName;

	public void SetProjectName(String ProjectName) {
		InputProjectName.click();
		InputProjectName.sendKeys(ProjectName + randomInt);
	}

	public void SetDProjectName() {
		InputProjectName.click();
		InputProjectName.sendKeys("TestAutomation");
	}

	public void editProjectName() {
		InputProjectName.clear();
		InputProjectName.sendKeys("AA_PN");
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//span[text()='Project has been updated']")
	WebElement ProjectUpdateMsg;

	public String IsProjectUpdated() {
		return ProjectUpdateMsg.getText();
	}

	@FindBy(xpath = "//app-project-details//a[contains(text(),'Project task')]")
	WebElement ProjectTaskTab;

	public String isProjectTaskTabDisplayed() {
		return ProjectTaskTab.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", btnBack);
		// btnBack.click();
	}

	@FindBy(xpath = "//app-project-list//h3[text()='All projects']")
	WebElement AllProjectsHd;

	public String isProjectsHeaderDisplayed() {
		return AllProjectsHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in project id or name']")
	WebElement txtsearch;

	public void searchProjects() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	public void searchDProject() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("TestAutomation");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-delete-project-modal//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

	public void clickProjectTaskTab() {
		ProjectTaskTab.click();
	}

	@FindBy(xpath = "//app-project-details//a[contains(text(),'Project address')]")
	WebElement ProjectAddressTab;

	public void clickProjectAddressTab() {
		ProjectAddressTab.click();
	}

	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement BtnAdd;

	public void clickAddButton() {
		BtnAdd.click();
	}

	@FindBy(xpath = "//app-project-task-craft//button[@aria-label='Add']")
	WebElement BtnAddPTC;

	public void clickAddButtonPTC() {
		BtnAddPTC.click();
	}

	public void scrollIntoView() {
		((JavascriptExecutor) ldriver).executeScript("arguments[0].scrollIntoView(true);", BtnAddPTC);
	}

	@FindBy(xpath = "//input[@id='name']")
	WebElement InputName;

	public void SetName(String Name) {
		InputName.click();
		InputName.sendKeys(Name);
	}

	public void EditName() {
		InputName.click();
		InputName.clear();
		InputName.sendKeys("AA_UPAN");
	}

	@FindBy(xpath = "//input[@id='addressLine1']")
	WebElement InputAddressL1;

	public void SetAddressL1(String AddressL1) {
		InputAddressL1.click();
		InputAddressL1.sendKeys(AddressL1);
	}

	@FindBy(xpath = "//input[@id='city']")
	WebElement InputCity;

	public void SetCity(String City) {
		InputCity.click();
		InputCity.sendKeys(City);
	}

	@FindBy(xpath = "//input[@name='state']")
	WebElement ClickStateField;

	public void ClickStateField() {
		ClickStateField.click();
	}

	@FindBy(xpath = "//input[@id='zipCode']")
	WebElement InputZipcode;

	public void SetZipCode(String ZipCode) {
		InputZipcode.click();
		InputZipcode.sendKeys(ZipCode);
	}

	@FindBy(xpath = "//input[@id='countryRegion']")
	WebElement InputCountry;

	public void SetCountry(String Country) {
		InputCountry.click();
		InputCountry.sendKeys(Country);
	}

	@FindBy(xpath = "//input[@id='taskCode___name']")
	WebElement InputPTaskCode;

	public void clickprojectTaskCodeField() {
		InputPTaskCode.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[2]")
	WebElement clkIndex2Value;

	public void ClickIndex2Val() {
		clkIndex2Value.click();
	}

	@FindBy(xpath = "//label//span[contains(@class,'e-frame')]")
	WebElement checkActive;

	public void ClickActiveCheckbox() {
		checkActive.click();
	}

	@FindBy(xpath = "//input[@id='craft___name']")
	WebElement InputCraftName;

	public void clickprojectTaskCraftField() {
		InputCraftName.click();
	}

	@FindBy(xpath = "//input[@id='union___name']")
	WebElement InputUnionName;

	public void clickprojectTaskUnionField() {
		InputUnionName.click();
	}

	@FindBy(xpath = "//input[@id='taxRegion___name']")
	WebElement InputtaxregionName;

	public void clickprojectTaskTaxRegionNameField() {
		InputtaxregionName.click();
	}

	@FindBy(xpath = "//button[@aria-label='Update']")
	WebElement BtnUpdate;

	public void clickUpdateButton() {
		BtnUpdate.click();
	}

	@FindBy(xpath = "//app-project-task-craft//button[@aria-label='Update']")
	WebElement BtnUpdatePTC;

	public void clickUpdateButtonPTC() {
		BtnUpdatePTC.click();
	}

	@FindBy(xpath = "//span[text()='Project task has been created']")
	WebElement ProjectTaskCreateMsg;

	public String IsprojectTaskCreated() {
		return ProjectTaskCreateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project task craft created successfully']")
	WebElement ProjectTaskCraftCreateMsg;

	public String IsprojectTaskCraftCreated() {
		return ProjectTaskCraftCreateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project address has been created']")
	WebElement ProjectAddressCreateMsg;

	public String IsprojectAddressCreated() {
		return ProjectAddressCreateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project task craft updated successfully']")
	WebElement ProjectTaskCraftUpdateMsg;

	public String IsprojectTaskCraftUpdated() {
		return ProjectTaskCraftUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project task has been updated']")
	WebElement ProjectTaskUpdateMsg;

	public String IsprojectTaskUpdated() {
		return ProjectTaskUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project address has been updated']")
	WebElement ProjectAddressUpdateMsg;

	public String IsprojectAddressUpdated() {
		return ProjectAddressUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project task craft has been deleted']")
	WebElement ProjectTaskCraftDeleteMsg;

	public String IsprojectTaskCraftdeleted() {
		return ProjectTaskCraftDeleteMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project task has been deleted']")
	WebElement ProjectTaskDeleteMsg;

	public String IsprojectTaskDeleted() {
		return ProjectTaskDeleteMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Project address has been deleted']")
	WebElement ProjectAddressDeleteMsg;

	public String IsprojectAddressDeleted() {
		return ProjectAddressDeleteMsg.getText();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

	@FindBy(xpath = "//app-project-task-craft//button[@aria-label='Edit']")
	WebElement BtnEditPTC;

	public void clickEditButtonPTC() {
		BtnEditPTC.click();
	}

	@FindBy(xpath = "//app-project-task//button[@aria-label='Delete']")
	WebElement BtnDeletePT;

	public void clickDeleteBTN() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", BtnDeletePT);
		// BtnDeletePT.click();
	}

	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement BtnDeleteToolBar;

	public void clickDeleteBTNToolBar() {
		// JavascriptExecutor js = (JavascriptExecutor) ldriver;
		// js.executeScript("arguments[0].click()", BtnDeletePT);
		BtnDeleteToolBar.click();
	}

	@FindBy(xpath = "//app-project-task-craft//button[@aria-label='Delete']")
	WebElement BtnDeletePTC;

	public void clickDeleteBTN_PTC() {
		BtnDeletePTC.click();
	}

	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickDeleteBtnPopup() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", BtnDeletePopup);
		// BtnDeletePopup.click();
	}

}

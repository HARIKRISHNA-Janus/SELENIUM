package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_ProjectCategories_pom;

public class tc39_Projectcategories_editanddelete extends baseclass {

	@Test
	public void ProjectCategory_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Project Category Create then edit and delete */
		operations_ProjectCategories_pom projectCategory = new operations_ProjectCategories_pom(driver);

		projectCategory.clickOperationsTab();
		projectCategory.clickProjectCategoriesTab();
		logger.info("User navigated to All project Categories Page");
		projectCategory.clickNewProjectCategoryButton();
		projectCategory.SetProjectCategoryId(projectCategoryId);
		projectCategory.SetProjectCategoryName(projectCategoryName);
		projectCategory.ClickTransctionTypeDropdown();
		Thread.sleep(2000);
		projectCategory.ClickIndex1Val();
		Thread.sleep(2000);
		projectCategory.clickSaveButton();
		Thread.sleep(2000);

		if (projectCategory.isProjectCategoryHeaderDisplayed().equals("All project categories")) {
			Assert.assertTrue(true);
			logger.info("Project Category has been created");
		} else {
			Assert.fail();
		}

		projectCategory.searchProjectCategory();
		Thread.sleep(3000);
		projectCategory.ClickEditIcon();
		Thread.sleep(2000);
		projectCategory.editProjectCategoryId();
		projectCategory.editProjectCategoryName();
		projectCategory.clickSaveButton();
		Thread.sleep(2000);

		if (projectCategory.isProjectCategoryHeaderDisplayed().equals("All project categories")) {
			Assert.assertTrue(true);
			logger.info("Project Category has been Updated");
		} else {
			Assert.fail();
		}

		projectCategory.searchProjectCategory();
		Thread.sleep(2000);
		projectCategory.clickDeleteIcon();
		Thread.sleep(2000);
		projectCategory.clickDeleteButton();
		Thread.sleep(2000);

		if (projectCategory.isProjectCategoryHeaderDisplayed().equals("All project categories")) {
			Assert.assertTrue(true);
			logger.info("Project Category has been Deleted");
		} else {
			Assert.fail();
		}

	}
}

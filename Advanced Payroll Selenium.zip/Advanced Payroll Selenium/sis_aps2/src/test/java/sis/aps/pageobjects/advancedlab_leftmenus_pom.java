package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class advancedlab_leftmenus_pom {
	
	public WebDriver ldriver;

	public advancedlab_leftmenus_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//Dashboard
	@FindBy(xpath="//span[contains(text(),'Dashboard')]") WebElement clkdashboardtab;
	public void clickdashboardtab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkdashboardtab);
		//clkdashboardtab.click();
	}
	//Time Management > Time Entry > All Timesheets / Excel Import
	@FindBy(xpath="//span[contains(text(),'Time management')]") WebElement clkTimesheet;
	public void TimesheetTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTimesheet);
		//clkTimesheet.click();
	}
	@FindBy(xpath="//span[contains(text(),'Time entry')]") WebElement clkTimeentry;
	public void TimeentryTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTimeentry);
		//clkTimeentry.click();
	}
	@FindBy(xpath="//span[contains(text(),'All timesheet')]") WebElement clkAllTimesheet;
	public void AllTimesheetScreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAllTimesheet);
		//clkAllTimesheet.click();
	}
	//Export import Tab
	@FindBy(xpath="//span[contains(text(),'Excel import')]") WebElement clkecelimport;
	public void clickexcelimport()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkecelimport);
		//clkecelimport.click();
	}
	//Time Management > Common Data > Workers / Projects / Unions
	@FindBy(xpath="//span[contains(text(),'Common data')]") WebElement clkcommondata;
	public void clickcommondatatab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkcommondata);
		//clkcommondata.click();
	}
	@FindBy(xpath="//span[contains(text(),'Workers')]") WebElement clktimesheettabworkers;
	public void clicktimesheetworkers()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheettabworkers);
		//clktimesheettabworkers.click();
	}
	@FindBy(xpath="//span[contains(text(),'Projects')]") WebElement clktimesheetprojects;
	public void clicktimesheetprojects()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheetprojects);
		//clktimesheetprojects.click();
	}
	@FindBy(xpath="//span[contains(text(),'Unions')]") WebElement clktimesheetunion;
	public void clicktimesheetunion()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheetunion);
		//clktimesheetunion.click();
	}
	//Time Management > Inquiries and reports > 
	@FindBy(xpath="//span[contains(text(),'Inquiries and reports')]") WebElement clkinquiriesandreports;
	public void clickinquiriesandreportstab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkinquiriesandreports);
		//clkinquiriesandreports.click();
	}
	@FindBy(xpath="//span[contains(text(),'Timesheet inquiries')]") WebElement clktimesheetinquiries;
	public void clicktimesheetinquiries()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheetinquiries);
		//clktimesheetinquiries.click();
	}
	@FindBy(xpath="//span[contains(text(),'Timesheet audit report')]") WebElement clktimesheetauditreport;
	public void clicktimesheetauditreport()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clktimesheetauditreport);
		//clktimesheetauditreport.click();
	}
	@FindBy(xpath="//span[contains(text(),'Certified payroll report')]") WebElement clkcertifiedpayrollreport;
	public void clickcertifiedpayrollreport()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkcertifiedpayrollreport);
		//clkcertifiedpayrollreport.click();
	}
	//Processing Management
	@FindBy(xpath="//span[contains(text(),'Processing management')]") WebElement clkprocessingmanagementtab;
	public void clickprocessingmanagementtab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprocessingmanagementtab);
		//clkpayrollmgmtadptab.click();
	}
	//Payroll Management
	@FindBy(xpath="//span[contains(text(),'Payroll management')]") WebElement clkpayrollmgmtadptab;
	public void clickpayrollmgmtadptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollmgmtadptab);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Worker setup')]") WebElement clkworkerssetuptab;
	public void clickworkerssetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkerssetuptab);
		//clkworkerssetuptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Workers')]") WebElement clkworkerstab;
	public void clickworkerstab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkerstab);
		//clkworkerstab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Positions')]") WebElement clkpositions;
	public void clickpositions()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpositions);
		//clkpositions.click();
	}
	@FindBy(xpath="//span[contains(text(),'Jobs')]") WebElement clkjobs;
	public void clickjobs()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkjobs);
		//clkjobs.click();
	}
	@FindBy(xpath="//span[contains(text(),'Worker categories list')]") WebElement clkworkercatlist;
	public void clickworkercategorieslist()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkercatlist);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Marital statuses list')]") WebElement clkmartialstatuseslist;
	public void clickmartialstatuseslist()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkmartialstatuseslist);
		//clkmartialstatuseslist.click();
	}
	@FindBy(xpath="//span[contains(text(),'Ethnic origins list')]") WebElement clkethnicoriginlist;
	public void clickthnicoriginlist()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkethnicoriginlist);
		//clkpayrollmgmtadptab.click();
	}
	//Payroll Management > Payroll Setup > Earning Codes / Memo Codes / Deduction Codes / Tax Codes / Pay Cycles&Pay Periods
	@FindBy(xpath="//span[contains(text(),'Payroll setup')]") WebElement clkpayrollsetup;
	public void clickpayrollsetup()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollsetup);
	}
	
	@FindBy(xpath="//span[contains(text(),'Memo codes')]") WebElement clkmemocode;
	public void clickmemocode()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkmemocode);
	}
	//System Management
	@FindBy(xpath="//span[contains(text(),'System management')]") WebElement clksystemmgmt;
	public void clicksystemmgmttab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clksystemmgmt);
		//clksystemmgmt.click();
	}
	@FindBy(xpath="//span[contains(text(),'Legal entities')]") WebElement clklegalentities;
	public void clicklegalentitiestab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clklegalentities);
		//clklegalentities.click();
	}
	@FindBy(xpath="//span[contains(text(),'Operating units')]") WebElement clkoperatingnits;
	public void clickoperatingunits()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperatingnits);
		//clkoperatingnits.click();
	}
	@FindBy(xpath="//span[contains(text(),'Companies')]") WebElement clkcompanies;
	public void clickcompanies()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkcompanies);
		//clkcompanies.click();
	}
	@FindBy(xpath="//span[contains(text(),'Operations management')]") WebElement clkoperationsmgmt;
	public void clickoperationsmgmttab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperationsmgmt);
		//clkcompanies.click();
	}
	@FindBy(xpath="//span[contains(text(),'Operations setup')]") WebElement clkoperationssetup;
	public void clickoperationssetupscreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperationssetup);
		//clkcompanies.click();
	}
	@FindBy(xpath="//span[contains(text(),'Prevailing wages')]") WebElement clkPrevailingwages;
	public void clickPrevailingwagescreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkPrevailingwages);
		//clkcompanies.click();
	}
}

package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_Fringes_pom {

	public WebDriver ldriver;

	public unions_Fringes_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Unions'])[1]")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		clkUnionsTab.click();
	}

	@FindBy(xpath = "//div[@class='e-toolbar-item']//button[@aria-label='Delete']")
	WebElement BtnDeleteFringeEarningCode;

	public void clickGridDeleteButton() {
		BtnDeleteFringeEarningCode.click();
	}

	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickPopupDeleteButton() {
		BtnDeletePopup.click();
	}

	@FindBy(xpath = "(//a//span[text()='Fringes'])[1]")
	WebElement FringesTab;

	public void clickFringesTab() {
		FringesTab.click();
	}

	@FindBy(xpath = "//button[text()='New fringe']")
	WebElement NewFringeButton;

	public void clickNewFringeButton() {
		NewFringeButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Fringe id']")
	WebElement txtFringeId;

	public void SetFringeId(String FringeId) {
		txtFringeId.sendKeys(FringeId + randomInt);
	}

	public void editFringeId() {
		txtFringeId.clear();
		txtFringeId.sendKeys("AAFI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder='Fringe name']")
	WebElement txtFringeName;

	public void SetFringeName(String FringeName) {
		txtFringeName.sendKeys(FringeName + randomInt);
	}

	public void editFringeName() {
		txtFringeName.clear();
		txtFringeName.sendKeys("AAFN" + randomInt);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//mat-select[@placeholder='Calculation method']")
	WebElement dropdownCalMethod;

	public void ClickCalcMethodDropdown() {
		dropdownCalMethod.click();
	}

	@FindBy(xpath = "//mat-select[@placeholder='Classification']")
	WebElement dropdownClassification;

	public void ClickClassificationDropdown() {
		dropdownClassification.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Deduction code']")
	WebElement dropdownDeductionCode;

	public void ClickDeductionCodeDropdown() {
		dropdownDeductionCode.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][1]")
	WebElement Index1Val;

	public void ClickIndex1Val() {
		Index1Val.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][5]")
	WebElement Index2Val;

	public void ClickIndex2Val() {
		Index2Val.click();
	}

	@FindBy(xpath = "//app-fringe-edit//a[contains(text(),'Fringe earning code')]")
	WebElement FearningCodeTab;

	public String isFringesEarningCodeDisplayed() {
		return FearningCodeTab.getText();
	}

	@FindBy(xpath = "//button//span[text()='Update']")
	WebElement btnUpdate;

	public void clickUpdateButton() {
		btnUpdate.click();
	}

	@FindBy(xpath = "//span[text()='Fringe earning code has been  created successfully']")
	WebElement FringesEarningCodeCreatedMsg;

	public String IsFringeEarningCodeCreated() {
		return FringesEarningCodeCreatedMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Fringe earning code has been  updated successfully']")
	WebElement FringesEarningCodeUpdatedMsg;

	public String IsFringeEarningCodeUpdated() {
		return FringesEarningCodeUpdatedMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Fringe earning code has been deleted']")
	WebElement FringesEarningCodeDeletedMsg;

	public String IsFringeEarningCodeDeleted() {
		return FringesEarningCodeDeletedMsg.getText();
	}

	@FindBy(xpath = "//button//span[text()='Add']")
	WebElement btnAdd;

	public void clickAddButton() {
		btnAdd.click();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

	@FindBy(xpath = "//input[@id='earningCode___name']")
	WebElement InputEarningCodeName;

	public void clickEarningCodeNAme() {
		InputEarningCodeName.click();
	}

	@FindBy(xpath = "//app-fringe-list//h3[text()='All fringes']")
	WebElement AllFringesHd;

	public String isAllFringesHeaderDisplayed() {
		return AllFringesHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in fringe id or name']")
	WebElement txtsearch;

	public void searchFringe() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-fringe-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_crafts_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc18_crafts_create extends baseclass {

	@Test
	public void Crafts_Create() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		advancepayroll_crafts_pom advancepayrollCFT = new advancepayroll_crafts_pom(driver);
		advancepayrollCFT.clickAdvancepayrollTab();
		logger.info("User clicked AdvancePayroll Leftsliding Menu");
		advancepayrollCFT.clickCraftTab();
		logger.info("User clicked craft Leftsliding Sunmenu");
		advancepayrollCFT.clickNewCraftButton();
		logger.info("User clicked new craft button");
		advancepayrollCFT.SetCraftId(craftId);
		logger.info("User entered the craft Id");
		advancepayrollCFT.SetCraftName(craftName);
		logger.info("User entered the craft Name");
		advancepayrollCFT.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (advancepayrollCFT.isCraftsHeaderDisplayed().equals("All crafts")) {
			Assert.assertTrue(true);
			logger.info("User verified All Crafts page Header");
			System.out.println("Craft has been created Successfully !");
		} else {
			Assert.fail("All Crafts Header is not disaplayed");
			logger.info("All craft Page Header is not dispalyed");
		}

		Thread.sleep(3000);
		advancepayrollCFT.searchcraft();
		logger.info("User entered the craft Id/Name in search input field");
		Thread.sleep(3000);
		advancepayrollCFT.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		advancepayrollCFT.clickDeleteButton();
		logger.info("user clicked the delete button");

		if (advancepayrollCFT.isCraftsHeaderDisplayed().equals("All crafts")) {
			Assert.assertTrue(true);
			logger.info("User verified All Crafts page Header");
			System.out.println("Craft has been created Successfully !");
		} else {
			Assert.fail("All Crafts Header is not disaplayed");
			logger.info("All crafts Page Header is not dispalyed");
		}

	}
}

package sis.aps.testcases;


import org.testng.Assert;
import org.testng.annotations.Test;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.pay_PayCycles_pom;

public class Create_PayPeriods_APS extends baseclass {

	@Test
	public void Create_PayPeriods() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);

		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(3000);

		pay_PayCycles_pom payPeriods = new pay_PayCycles_pom(driver);

		payPeriods.clickPayTab();
		Thread.sleep(2000);
		payPeriods.clickPayCyclesTab();
		Thread.sleep(2000);
		payPeriods.SearchPayCycles();
		Thread.sleep(3000);
		payPeriods.ClickAllPayCyclesEditIcon();
		Thread.sleep(2000);

		/* Create Pay Periods */

		payPeriods.ClickPayPeriodsTab();
		Thread.sleep(2000);
		payPeriods.clickAddButton();
		Thread.sleep(2000);
		payPeriods.SetNoOfPeriods();
		Thread.sleep(2000);
		payPeriods.clickDatepickerButton();
		Thread.sleep(2000);
		payPeriods.clickCurrentDate();
		Thread.sleep(2000);
		payPeriods.clickStatusField();
		Thread.sleep(2000);
		payPeriods.ClickIndex1Val();
		Thread.sleep(2000);
		payPeriods.clickSaveButton();
		Thread.sleep(2000);

		if (payPeriods.isPayperiodCreated().equals("Pay period has been created")) {
			Assert.assertTrue(true);
			logger.info("Pay period has been created");
		} else {
			logger.info("Pay period has not been created");
			Assert.fail();
		}

	}
}
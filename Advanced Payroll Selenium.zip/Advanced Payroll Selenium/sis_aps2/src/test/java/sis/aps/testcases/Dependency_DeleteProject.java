package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_Projects_pom;

public class Dependency_DeleteProject extends baseclass {

	@Test
	public void Dependency_Delete_Project() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(5000);
		login.clkSignin();
		Thread.sleep(6000);

		/* Delete Project */
		operations_Projects_pom projects = new operations_Projects_pom(driver);

		projects.clickOperationsTab();
		projects.clickProjectsTab();
		logger.info("User navigated to All projects Page");

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		projects.searchDProject();
		Thread.sleep(2000);
		projects.clickDeleteIcon();
		Thread.sleep(2000);
		projects.clickDeleteButton();
		Thread.sleep(2000);

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
			logger.info("Project has been deleted");
		} else {
			Assert.fail();
		}

	}
}

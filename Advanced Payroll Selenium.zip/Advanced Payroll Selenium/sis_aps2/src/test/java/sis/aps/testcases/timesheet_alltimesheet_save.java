package sis.aps.testcases;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;

public class timesheet_alltimesheet_save extends baseclass {
	
	@Test
	public void non_union_employee_non_union_employee_non_prevailing_wage() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		timemgmt_alltimesheet_pom timesheet=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		timesheet.WorkersText();
		Thread.sleep(3000);
		timesheet.setWorker();
		//timesheet.PayperiodText();
		Thread.sleep(2000);
		//timesheet.setPayperiod();
		timesheet.ProjectText();
		timesheet.setProject();
		timesheet.TaskcodeText();
		timesheet.setTaskcode();
		timesheet.PayperiodText();
		timesheet.setPayperiod();
		timesheet.btnSave();
		Thread.sleep(5000);
		//timesheet.FirstRowSelect();
		timesheet.Edit();
		timesheet.Regulartime();
		timesheet.Doubletime();
		Thread.sleep(2000);
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.SecondRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		Thread.sleep(2000);
		timesheet.Regulartimeagain();
		Thread.sleep(2000);
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ThirdRowSelect();
		timesheet.Edit();
		Thread.sleep(2000);
		timesheet.Overtime();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.ForthRowSelect();
		Thread.sleep(2000);
		timesheet.Edit();
		Thread.sleep(2000);
		timesheet.Overtimeagain();
		timesheet.Doubletimeagain();
		timesheet.Update();
		Thread.sleep(7000);
		timesheet.Process();
		Thread.sleep(1000);
		timesheet.Approve();
		Thread.sleep(1000);
		timesheet.Complete();
		Thread.sleep(1000);
		timesheet.CreateStatement();
		Thread.sleep(2000);
		timesheet.Threedots();
		Thread.sleep(2000);
		timesheet.Viewcalculation();
		Thread.sleep(10000);
		if(timesheet.chkRegularhoursdisplay().equals("16"))
        {
			Assert.assertTrue(true);
			System.out.println("Regularhour calculated as expected and the value is: " +timesheet.chkRegularhoursdisplay());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTotalhourlycostdisplay().equals("816.0000"))
        {
			Assert.assertTrue(true);
			System.out.println("Totalhourlycost calculated as expected and the value is: " +timesheet.chkTotalhourlycostdisplay());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkTotalcostdisplay().equals("816.0000"))
        {
        	
			Assert.assertTrue(true);
			System.out.println("Totalcost calculated as expected and the value is: " +timesheet.chkTotalcostdisplay());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkEmployeeratedisplay().equals("24.0000"))
        {
			Assert.assertTrue(true);
			System.out.println("Employeerate calculated as expected and the value is: " +timesheet.chkEmployeeratedisplay());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkDoubletimehoursdisplay().equals("6"))
        {
			Assert.assertTrue(true);
			System.out.println("Doubletimehours calculated as expected and the value is: " +timesheet.chkDoubletimehoursdisplay());
        }
		else
		{
			Assert.fail();
		}
		if(timesheet.chkOvertimehoursdisplay().equals("4"))
        {
			Assert.assertTrue(true);
			System.out.println("Overtimehours calculated as expected and the value is: " +timesheet.chkOvertimehoursdisplay());
        }
		else
		{
			Assert.fail();
		}
		
	}

}

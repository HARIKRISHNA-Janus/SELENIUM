package sis.aps.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.employees_martialstatuses_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc06_syncwithadp_martialstatuses extends baseclass {
	
	@Test
	public void masterdata_martialstatuses_syncwithadp() throws InterruptedException
	{	
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		logger.info("User logged in Successfully");
		
		employees_martialstatuses_pom sync=new employees_martialstatuses_pom(driver);
		Thread.sleep(3000);
		sync.EmployeesTab();
		logger.info("User clicked on Employees Tab");
		sync.MartialStatusesScreen();
		logger.info("User clicked on MartialStatuses Screen");
		logger.info("SYNC WITH ADP is Enabled:" +sync.chkSyncWithADP());
		sync.SyncWithADP();
		Thread.sleep(55000);
		String timestamp=new SimpleDateFormat("M/dd/yy, h:mm a").format(new Date());
		String Systemtime= "System Last Sync: " +timestamp;
		System.out.println(Systemtime);
		System.out.println("App " +sync.chkAppDateDisplay());
		logger.info("SYNC WITH ADP is Enabled Back:" +sync.chkSyncADPEnabledBack());
		logger.info("Circle Stared is Enabled:" +sync.chkCircleEnabled());
		if(sync.chkRowDisplay().equals(" Showing rows 1 to 8 of 8"))
		{
			Assert.assertTrue(true);
			logger.info("Row Count Equals");
		}
		else
		{
			Assert.fail();
			logger.info("Row Count Not Equal");
		}
	}

}

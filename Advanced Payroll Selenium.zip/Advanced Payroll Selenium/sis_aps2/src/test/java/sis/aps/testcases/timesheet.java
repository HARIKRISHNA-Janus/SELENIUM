package sis.aps.testcases;

import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.utilities.XLUtils;

public class timesheet extends baseclass {
	
	@Test
	public void timesheet() throws Exception
	{
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(13000);

		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timesheet.TimesheetTab();
		
		String path="./excel/NewTimesheet - 10-02-21.xlsx";
		String writepath="./excel/NewTimesheetC - 10-02-21.xlsx";
		String sheetname="Sheet1";
		String sheetwrite="Sheet1";
		XLUtils.setExcelFile(path, sheetname);
		int xlrowcount=XLUtils.getRowCount(path, sheetname);
		int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
		System.out.println("Excel Row Count: " +xlrowcount);
		System.out.println("Excel Column Count: " +xlcellcount);
		for(int i=1;i<=xlrowcount;i++)
		{
			String workername=XLUtils.getCellData(path, sheetname, i, 0);
			String project=XLUtils.getCellData(path, sheetname, i, 1);
			String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
			String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
			String editdate=XLUtils.getCellData(path, sheetname, i, 4);
			String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
			String edittaskcode=XLUtils.getCellData(path, sheetname, i, 6);
			String editjobid=XLUtils.getCellData(path, sheetname, i, 7);
			String editearningcode=XLUtils.getCellData(path, sheetname, i, 8);
			String editshiftid=XLUtils.getCellData(path, sheetname, i, 9);
			String editspecialpayid=XLUtils.getCellData(path, sheetname, i, 10);
			String editregularhours=XLUtils.getCellData(path, sheetname, i, 11);
			String editovertimehours=XLUtils.getCellData(path, sheetname, i, 12);
			String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 13);
			String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 14);
			
			String editrow2date=XLUtils.getCellData(path, sheetname, i, 15);
			String editrow2projectcode=XLUtils.getCellData(path, sheetname, i, 16);
			String editrow2taskcode=XLUtils.getCellData(path, sheetname, i, 17);
			String editrow2jobid=XLUtils.getCellData(path, sheetname, i, 18);
			String editrow2earningcode=XLUtils.getCellData(path, sheetname, i, 19);
			String editrow2shiftid=XLUtils.getCellData(path, sheetname, i, 20);
			String editrow2specialpayid=XLUtils.getCellData(path, sheetname, i, 21);
			String editrow2regularhours=XLUtils.getCellData(path, sheetname, i, 22);
			String editrow2overtimehours=XLUtils.getCellData(path, sheetname, i, 23);
			String editrow2doubletimehours=XLUtils.getCellData(path, sheetname, i, 24);
			String editrow2tripletimehours=XLUtils.getCellData(path, sheetname, i, 25);
			
			String editrow3date=XLUtils.getCellData(path, sheetname, i, 26);
			String editrow3projectcode=XLUtils.getCellData(path, sheetname, i, 27);
			String editrow3taskcode=XLUtils.getCellData(path, sheetname, i, 28);
			String editrow3jobid=XLUtils.getCellData(path, sheetname, i, 29);
			String editrow3earningcode=XLUtils.getCellData(path, sheetname, i, 30);
			String editrow3shiftid=XLUtils.getCellData(path, sheetname, i, 31);
			String editrow3specialpayid=XLUtils.getCellData(path, sheetname, i, 32);
			String editrow3regularhours=XLUtils.getCellData(path, sheetname, i, 33);
			String editrow3overtimehours=XLUtils.getCellData(path, sheetname, i, 34);
			String editrow3doubletimehours=XLUtils.getCellData(path, sheetname, i, 35);
			String editrow3tripletimehours=XLUtils.getCellData(path, sheetname, i, 36);
			
			String editrow4date=XLUtils.getCellData(path, sheetname, i, 37);
			String editrow4projectcode=XLUtils.getCellData(path, sheetname, i, 38);
			String editrow4taskcode=XLUtils.getCellData(path, sheetname, i, 39);
			String editrow4jobid=XLUtils.getCellData(path, sheetname, i, 40);
			String editrow4earningcode=XLUtils.getCellData(path, sheetname, i, 41);
			String editrow4shiftid=XLUtils.getCellData(path, sheetname, i, 42);
			String editrow4specialpayid=XLUtils.getCellData(path, sheetname, i, 43);
			String editrow4regularhours=XLUtils.getCellData(path, sheetname, i, 44);
			String editrow4overtimehours=XLUtils.getCellData(path, sheetname, i, 45);
			String editrow4doubletimehours=XLUtils.getCellData(path, sheetname, i, 46);
			String editrow4tripletimehours=XLUtils.getCellData(path, sheetname, i, 47);
			
			String editrow5date=XLUtils.getCellData(path, sheetname, i, 48);
			String editrow5projectcode=XLUtils.getCellData(path, sheetname, i, 49);
			String editrow5taskcode=XLUtils.getCellData(path, sheetname, i, 50);
			String editrow5jobid=XLUtils.getCellData(path, sheetname, i, 51);
			String editrow5earningcode=XLUtils.getCellData(path, sheetname, i, 52);
			String editrow5shiftid=XLUtils.getCellData(path, sheetname, i, 53);
			String editrow5specialpayid=XLUtils.getCellData(path, sheetname, i, 54);
			String editrow5regularhours=XLUtils.getCellData(path, sheetname, i, 55);
			String editrow5overtimehours=XLUtils.getCellData(path, sheetname, i, 56);
			String editrow5doubletimehours=XLUtils.getCellData(path, sheetname, i, 57);
			String editrow5tripletimehours=XLUtils.getCellData(path, sheetname, i, 58);
			
			String editrow6date=XLUtils.getCellData(path, sheetname, i, 59);
			String editrow6projectcode=XLUtils.getCellData(path, sheetname, i, 60);
			String editrow6taskcode=XLUtils.getCellData(path, sheetname, i, 61);
			String editrow6jobid=XLUtils.getCellData(path, sheetname, i, 62);
			String editrow6earningcode=XLUtils.getCellData(path, sheetname, i, 63);
			String editrow6shiftid=XLUtils.getCellData(path, sheetname, i, 64);
			String editrow6specialpayid=XLUtils.getCellData(path, sheetname, i, 65);
			String editrow6regularhours=XLUtils.getCellData(path, sheetname, i, 66);
			String editrow6overtimehours=XLUtils.getCellData(path, sheetname, i, 67);
			String editrow6doubletimehours=XLUtils.getCellData(path, sheetname, i, 68);
			String editrow6tripletimehours=XLUtils.getCellData(path, sheetname, i, 69);
			
			String editrow7date=XLUtils.getCellData(path, sheetname, i, 70);
			String editrow7projectcode=XLUtils.getCellData(path, sheetname, i, 71);
			String editrow7taskcode=XLUtils.getCellData(path, sheetname, i, 72);
			String editrow7jobid=XLUtils.getCellData(path, sheetname, i, 73);
			String editrow7earningcode=XLUtils.getCellData(path, sheetname, i, 74);
			String editrow7shiftid=XLUtils.getCellData(path, sheetname, i, 75);
			String editrow7specialpayid=XLUtils.getCellData(path, sheetname, i, 76);
			String editrow7regularhours=XLUtils.getCellData(path, sheetname, i, 77);
			String editrow7overtimehours=XLUtils.getCellData(path, sheetname, i, 78);
			String editrow7doubletimehours=XLUtils.getCellData(path, sheetname, i, 79);
			String editrow7tripletimehours=XLUtils.getCellData(path, sheetname, i, 80);
			
			timesheet.AllTimesheetScreen();
			Thread.sleep(3000);
			timesheet.NewTimesheet();
			Thread.sleep(2000);
			timesheet.clkWorkersText();
			timesheet.txtworker(workername);
			System.out.println("Worker selected is: " +workername);
			Thread.sleep(2000);
			timesheet.selectWorker();
			Thread.sleep(2000);
		    timesheet.clkProjectText();
			timesheet.txtproject(project);
			System.out.println("Project selected is: " +project);
			Thread.sleep(2000);
			timesheet.selectproject();
			Thread.sleep(2000);
			timesheet.clkTaskcodeText();
			if(timesheet.txttaskcodestring(taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			System.out.println("TaskCode selected is: " +taskcode);
			Thread.sleep(2000);
			timesheet.clkPayperiodText();
			if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
			{
				timesheet.setPayperiod1();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/8/20"))
			{
				timesheet.setPayperiod2();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
			{
				timesheet.setPayperiod3();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/20"))
			{
				timesheet.setPayperiod4();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
			{
				timesheet.setPayperiod5();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/6/20"))
			{
				timesheet.setPayperiod6();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
			{
				timesheet.setPayperiod7();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/20"))
			{
				timesheet.setPayperiod8();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
			{
				timesheet.setPayperiod9();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/3/21"))
			{
				timesheet.setPayperiod10();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
			{
				timesheet.setPayperiod11();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/17/21"))
			{
				timesheet.setPayperiod12();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
			{
				timesheet.setPayperiod13();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("1/31/21"))
			{
				timesheet.setPayperiod14();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
			{
				timesheet.setPayperiod15();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/14/21"))
			{
				timesheet.setPayperiod16();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
			{
				timesheet.setPayperiod17();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("2/28/21"))
			{
				timesheet.setPayperiod18();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
			{
				timesheet.setPayperiod19();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/14/21"))
			{
				timesheet.setPayperiod20();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
			{
				timesheet.setPayperiod21();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("3/28/21"))
			{
				timesheet.setPayperiod22();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
			{
				timesheet.setPayperiod23();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/11/21"))
			{
				timesheet.setPayperiod24();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
			{
				timesheet.setPayperiod25();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("4/25/21"))
			{
				timesheet.setPayperiod26();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
			{
				timesheet.setPayperiod27();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/9/21"))
			{
				timesheet.setPayperiod28();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
			{
				timesheet.setPayperiod29();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/23/21"))
			{
				timesheet.setPayperiod30();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
			{
				timesheet.setPayperiod31();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("6/6/21"))
			{
				timesheet.setPayperiod32();
			}
			System.out.println("PayPeriod selected is: " +payperiod);
			timesheet.btnSave();
			Thread.sleep(5000);
			//Edit Row1
			timesheet.setRow1();
			Thread.sleep(1000);
			timesheet.setRow1();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditdate();
			Thread.sleep(1000);
			timesheet.cleareditdate();
			timesheet.seteditdate();
			Thread.sleep(1000);
			timesheet.txteditdatestring(editdate);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editprojectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			//timesheet.txtedittaskcodestring(row1taskcode);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(edittaskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editshiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editregularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editovertimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editdoubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(edittripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(7000);
			//Edit Row2
			timesheet.setRow2();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow2date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow2projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			//timesheet.txteditrow2taskcodestring(row1taskcode);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow2shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow2regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow2overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow2doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow2tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			//Edit Row3
			timesheet.setRow3();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow3date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow3projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow3shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow3regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow3overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow3doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow3tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			//Edit Row4
			timesheet.setRow4();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow2date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow4projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow4shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow4regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow4overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow4doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow4tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			//Edit Row5
			timesheet.setRow5();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow2date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow5projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow5taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow5taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow5taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow5shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow5regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow5overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow5doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow5tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			//Edit Row6
			timesheet.setRow6();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow2date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow6projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow6taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow6taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow6taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow6shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow6regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow6overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow6doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow6tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			//Edit Row7
			timesheet.setRow7();
			timesheet.Edit();
			Thread.sleep(1000);
			/*
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.cleareditrow2date();
			timesheet.seteditrow2date();
			Thread.sleep(1000);
			timesheet.txteditrow2datestring(editrow2date);
			Thread.sleep(1000);
			*/
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.clreditprojectcode();
			Thread.sleep(1000);
			timesheet.seteditprojectcode();
			Thread.sleep(1000);
			timesheet.txteditprojectcodestring(editrow7projectcode);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			if(timesheet.txtedittaskcodestring(editrow7taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(editrow7taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(editrow7taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			Thread.sleep(1000);
			timesheet.seteditshiftid();
			Thread.sleep(1000);
			timesheet.txteditswiftstring(editrow7shiftid);
			Thread.sleep(1000);
			timesheet.listselect();
			Thread.sleep(1000);
			timesheet.seteditregularhours();
			Thread.sleep(1000);
			timesheet.txteditregularhoursstring(editrow7regularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editrow7overtimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editrow7doubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(editrow7tripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(10000);
			
			timesheet.Process();
			Thread.sleep(2000);
			timesheet.Threedots();
			Thread.sleep(2000);
			timesheet.Viewcalculation();
			Thread.sleep(10000);
			int rowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr")).size();
			String numofrows=String.valueOf(rowcount);
			System.out.println("number of rows: " +numofrows);
			for(int r=1;r<=rowcount;r++)
			{
				String totalhours=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
				int totalhoursfinalvalue=Integer.parseInt(totalhours);
				BigDecimal totalhoursdisplay= new BigDecimal(totalhoursfinalvalue).setScale(0, RoundingMode.HALF_EVEN);
				System.out.println("Employee Rate is: " +totalhoursdisplay);
				String eomployeerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
				double employeeratefinalvalue=Double.parseDouble(eomployeerate);
				BigDecimal employeeratedisplay= new BigDecimal(employeeratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
				System.out.println("Employee Rate is: " +employeeratedisplay);
				String unionrate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
				//double unionratefinalvalue=Double.parseDouble(unionrate);
				float unionratefinalvalue=(float) Double.parseDouble(unionrate);
				System.out.println("unionratefinalvalue is: " +unionratefinalvalue);
				BigDecimal unionratedisplay= new BigDecimal(unionratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
				System.out.println("Union Rate is: " +unionratedisplay);
				String privailingwagerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
				double privailingwageratefinalvalue=Double.parseDouble(privailingwagerate);
				BigDecimal privailingwageratedisplay= new BigDecimal(privailingwageratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
				System.out.println("Priviling Wage Rate is: " +privailingwageratedisplay);
				String calculatedcost=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
				//double calculatedcostfinalvalue=Double.parseDouble(calculatedcost);
				float calculatedcostfinalvalue=(float) Double.parseDouble(calculatedcost);
				System.out.println("calculatedcostfinalvalue is: " +calculatedcostfinalvalue);
				BigDecimal calcostdisplay= new BigDecimal(calculatedcostfinalvalue).setScale(4, RoundingMode.HALF_EVEN);
				//System.out.println("Calculated cost display  is: " +calcostdisplay);
				String calcostfinalvaluefromapp=calcostdisplay.toString();
				//System.out.println("Calculated cost display from app  is: " +calcostfinalvaluefromapp);
				if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
				{
					
					double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
					System.out.println("Calculated cost is: " +Caluculatedcost);
					if(Caluculatedcost==calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost calculated as expected");
						BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
						String writexlClculatedcost=Calculatedcoststring.toString();
						FileOutputStream file=new FileOutputStream("./excel/NewTimesheetB - 10-02-21.xlsx");
						XSSFWorkbook workbook=new XSSFWorkbook();
						XSSFSheet sheet=workbook.createSheet("Calculatedcost");
						XSSFRow row=sheet.createRow(0);
						for(int j=0;j<29;j++)
						{
							row.createCell(j).setCellValue(writexlClculatedcost);
						}
						//XLUtils.setCellData(path, sheetwrite, r, 0, writexlClculatedcost);
					}
					else if(Caluculatedcost!=calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost not calculated as expected");
					}
					/*
					double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
					BigDecimal calcostrate= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
					//System.out.println("Calculated cost is: " +calcostrate);
					String calcostfinalvalue=calcostrate.toString();
					System.out.println("Calculated cost is: " +calcostfinalvalue);
					if(calcostfinalvalue==calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost calculated as expected");
					}
					else if(calcostfinalvalue!=calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost not calculated as expected");
					}
					*/
				}
				else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
				{
					double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
					System.out.println("Calculated cost is: " +Caluculatedcost);
					if(Caluculatedcost==calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost calculated as expected");
						BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
						String writexlClculatedcost=Calculatedcoststring.toString();
						FileOutputStream file=new FileOutputStream("./excel/NewTimesheetB - 10-02-21.xlsx");
						XSSFWorkbook workbook=new XSSFWorkbook();
						XSSFSheet sheet=workbook.createSheet("Calculatedcost");
						XSSFRow row=sheet.createRow(0);
						for(int j=0;j<29;j++)
						{
							row.createCell(j).setCellValue(writexlClculatedcost);
						}
					}
					else if(Caluculatedcost!=calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost not calculated as expected");
						
					}
					/*
					double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
					BigDecimal calcostrate= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
					//System.out.println("Calculated cost is: " +calcostrate);
					String calcostfinalvalue=calcostrate.toString();
					System.out.println("Calculated cost is: " +calcostfinalvalue);
					if(calcostfinalvalue==calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost calculated as expected");
					}
					else if(calcostfinalvalue!=calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost not calculated as expected");
					}
					*/
				}
				else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
				{
					double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
					System.out.println("Calculated cost is: " +Caluculatedcost);
					if(Caluculatedcost==calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost calculated as expected");
						BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
						String writexlClculatedcost=Calculatedcoststring.toString();
						FileOutputStream file=new FileOutputStream("./excel/NewTimesheetB - 10-02-21.xlsx");
						XSSFWorkbook workbook=new XSSFWorkbook();
						XSSFSheet sheet=workbook.createSheet("Calculatedcost");
						XSSFRow row=sheet.createRow(0);
						for(int j=0;j<29;j++)
						{
							row.createCell(j).setCellValue(writexlClculatedcost);
						}
					}
					else if(Caluculatedcost!=calculatedcostfinalvalue)
					{
						System.out.println("Calculated cost not calculated as expected");
					}
					/*
					double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
					BigDecimal calcostrate= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
					//System.out.println("Calculated cost is: " +calcostrate);
					String calcostfinalvalue=calcostrate.toString();
					System.out.println("Calculated cost is: " +calcostfinalvalue);
					if(calcostfinalvalue==calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost calculated as expected");
					}
					else if(calcostfinalvalue!=calcostfinalvaluefromapp)
					{
						System.out.println("Calculated cost not calculated as expected");
					}
					*/
				}
				/*
				//int Calccostcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[\"+r+\"]/td[12]")).size();
				int[][] calcostcount={{r,12}};
				int sum=0;
				for(int c=0;c<calcostcount.length;c++)
				{
					sum=sum+calcostcount[c];
				}
				System.out.println("Sum value of Calculatedcost is: " +sum);
				*/
			}
			int tablerowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr")).size();
			int tablecolumncount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td")).size();
			for(int c=1;c<=tablerowcount;c++)
			{
				for(int d=1;d<tablecolumncount;d++)
				{
					List<WebElement> Calccostcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[\"+r+\"]/td[12]"));
					String calcoststring=Calccostcount.toString();
					XLUtils.setCellData(writepath, sheetwrite, c, d, calcoststring);
				}
			}
			Thread.sleep(5000);
		}
	}
}

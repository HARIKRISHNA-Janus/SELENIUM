package sis.aps.testcases;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_Shits_pom;
import sis.aps.pageobjects.employees_positions_pom;
import sis.aps.pageobjects.employees_workers_pom;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.pay_earningcodes_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.pageobjects.unions_Unions_pom;
import sis.aps.utilities.XLUtils;

public class timesheet_emp_union_prev_rate_calc extends baseclass {
	
	@Test
	public void timesheet_rates() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		//logger.info("User entered the Username");
		login.setPasword(password);
		//logger.info("User entered the Password");
		Thread.sleep(3000);
		login.clkSignin();
		//logger.info("User Clicked on Signin button");
		Thread.sleep(10000);
		logger.info("Logged in Successfull");
		
		//earning code rates
		pay_earningcodes_pom earningcode=new pay_earningcodes_pom(driver);
		//earningcode.payTab();
		earningcode.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		earningcode.clickpayrollsetuptab();
		Thread.sleep(1000);
		//logger.info("Navigated to Payroll Mgmt ADP tab");
		earningcode.earningcodesscreen();
		logger.info("Navigated to Earning codes screen");
		earningcode.searchtxtbox();
		earningcode.searchregular();
		Thread.sleep(2000);
		earningcode.selectedit();
		String RegularAmtRate=earningcode.selectamtratevalue();
		//logger.info("Regular Amt Rate is: " +RegularAmtRate);
		double RegularAmtRatevalue=Double.parseDouble(RegularAmtRate);
		logger.info("Regular Amt Rate is: " +RegularAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchrovertime();
		Thread.sleep(1000);
		earningcode.selectsecondedit();
		String OvertimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Overtime Amt Rate is: " +OvertimeAmtRate);
		double OvertimeAmtRatevalue=Double.parseDouble(OvertimeAmtRate);
		logger.info("Overtime Amt Rate is: " +OvertimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchdot();
		Thread.sleep(1000);
		earningcode.selectedit();
		String DoubletimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Doubleovertime Amt Rate is: " +DoubletimeAmtRate);
		double DoubletimeAmtRatevalue=Double.parseDouble(DoubletimeAmtRate);
		logger.info("DoubleOvertime Amt Rate is: " +DoubletimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchtripleovertime();
		Thread.sleep(1000);
		earningcode.selectedit();
		String TripletimeAmtRate=earningcode.selectamtratevalue();
		//logger.info("Tripleovertime Amt Rate is: " +TripletimeAmtRate);
		double TripletimeAmtRatevalue=Double.parseDouble(TripletimeAmtRate);
		logger.info("Triple Overtime Amt Rate is: " +TripletimeAmtRatevalue);
		Thread.sleep(1000);
		earningcode.selectcancel();
		Thread.sleep(1000);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		Thread.sleep(3000);
		earningcode.clickpayrollsetuptab();
		Thread.sleep(1000);
		earningcode.clickpayrollmgmtadptab();
		//Shift rates
		advancepayroll_Shits_pom shiftsrate=new advancepayroll_Shits_pom(driver);
		//shiftsrate.clickAdvancepayrollTab();
		shiftsrate.clickoperationsmgmttab();
		Thread.sleep(1000);
		shiftsrate.clickoperationssetuptab();
		Thread.sleep(1000);
		shiftsrate.clickShiftTab();
		Thread.sleep(2000);
		shiftsrate.clkdroplist();
		Thread.sleep(1000);
		shiftsrate.clkdroplist100();
		Thread.sleep(1000);
		//day rate
		String dayratetxt=shiftsrate.getdayrate();
		int dayratelen=dayratetxt.length();
		String dayratefinalstring=dayratetxt.substring(1,dayratelen);
		double dayratevalue=Double.parseDouble(dayratefinalstring);
		logger.info("Day rate is: " +dayratevalue);
		/*
		//fixed rate
		String fixedratetxt=shiftsrate.getfixedrate();
		int fixedratelen=fixedratetxt.length();
		String fixedratefinalstring=fixedratetxt.substring(1,fixedratelen);
		double fixedratevalue=Double.parseDouble(fixedratefinalstring);
		logger.info("Fixed rate is: " +fixedratevalue);
		//mid rate
		String midratetxt=shiftsrate.getmidrate();
		int midratelen=midratetxt.length();
		String midratefinalstring=midratetxt.substring(1,midratelen);
		double midratevalue=Double.parseDouble(midratefinalstring);
		logger.info("Mid rate is: " +midratevalue);
		*/
		//night percentage
		String nightpercenttxt=shiftsrate.getnightpercentage();
		//System.out.println("Night percent txt is: " +nightpercenttxt);
		String nightpercentfinalstring=nightpercenttxt.substring(0,7);
		double nightpercent=Double.parseDouble(nightpercentfinalstring);
		double nightpercentvalue=nightpercent/100;
		logger.info("Night percentage is: " +nightpercentvalue);
		/*
		//split percentage
		String splitpercenttxt=shiftsrate.getsplitpercentage();
		//System.out.println("split percent txt is: " +splitpercenttxt);
		String splitpercentfinalstring=splitpercenttxt.substring(0,7);
		double splitpercent=Double.parseDouble(splitpercentfinalstring);
		double splitpercentvalue=splitpercent/100;
		logger.info("Split percentage is: " +splitpercentvalue);
		*/
		//swing rate
		String swingratetxt=shiftsrate.getswingrate();
		int swingratelen=swingratetxt.length();
		String swingratefinalstring=swingratetxt.substring(1,swingratelen);
		double swingratevalue=Double.parseDouble(swingratefinalstring);
		logger.info("Swing rate is: " +swingratevalue);
		
		//union rates
		String path="./excel/NewTimesheet.xlsx";
		String sheetname="Sheet1";
		XLUtils.setExcelFile(path, sheetname);
		int xlrowcount=XLUtils.getRowCount(path, sheetname);
		int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
		System.out.println("Excel Row Count: " +xlrowcount);
		System.out.println("Excel Column Count: " +xlcellcount);
		for(int i=1;i<=xlrowcount;i++)
		{

			String workername=XLUtils.getCellData(path, sheetname, i, 0);
			String project=XLUtils.getCellData(path, sheetname, i, 1);
			String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
			String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
			
			String editdate=XLUtils.getCellData(path, sheetname, i, 4);
			String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
			String edittaskcode=XLUtils.getCellData(path, sheetname, i, 6);
			String editjobid=XLUtils.getCellData(path, sheetname, i, 7);
			String editearningcode=XLUtils.getCellData(path, sheetname, i, 8);
			String editshiftid=XLUtils.getCellData(path, sheetname, i, 9);
			String editspecialpayid=XLUtils.getCellData(path, sheetname, i, 10);
			String editregularhours=XLUtils.getCellData(path, sheetname, i, 11);
			String editovertimehours=XLUtils.getCellData(path, sheetname, i, 12);
			String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 13);
			String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 14);

			String editrow2date=XLUtils.getCellData(path, sheetname, i, 15);
			String editrow2projectcode=XLUtils.getCellData(path, sheetname, i, 16);
			String editrow2taskcode=XLUtils.getCellData(path, sheetname, i, 17);
			String editrow2jobid=XLUtils.getCellData(path, sheetname, i, 18);
			String editrow2earningcode=XLUtils.getCellData(path, sheetname, i, 19);
			String editrow2shiftid=XLUtils.getCellData(path, sheetname, i, 20);
			String editrow2specialpayid=XLUtils.getCellData(path, sheetname, i, 21);
			String editrow2regularhours=XLUtils.getCellData(path, sheetname, i, 22);
			String editrow2overtimehours=XLUtils.getCellData(path, sheetname, i, 23);
			String editrow2doubletimehours=XLUtils.getCellData(path, sheetname, i, 24);
			String editrow2tripletimehours=XLUtils.getCellData(path, sheetname, i, 25);
			
			String editrow3date=XLUtils.getCellData(path, sheetname, i, 26);
			String editrow3projectcode=XLUtils.getCellData(path, sheetname, i, 27);
			String editrow3taskcode=XLUtils.getCellData(path, sheetname, i, 28);
			String editrow3jobid=XLUtils.getCellData(path, sheetname, i, 29);
			String editrow3earningcode=XLUtils.getCellData(path, sheetname, i, 30);
			String editrow3shiftid=XLUtils.getCellData(path, sheetname, i, 31);
			String editrow3specialpayid=XLUtils.getCellData(path, sheetname, i, 32);
			String editrow3regularhours=XLUtils.getCellData(path, sheetname, i, 33);
			String editrow3overtimehours=XLUtils.getCellData(path, sheetname, i, 34);
			String editrow3doubletimehours=XLUtils.getCellData(path, sheetname, i, 35);
			String editrow3tripletimehours=XLUtils.getCellData(path, sheetname, i, 36);
			
			String editrow4date=XLUtils.getCellData(path, sheetname, i, 37);
			String editrow4projectcode=XLUtils.getCellData(path, sheetname, i, 38);
			String editrow4taskcode=XLUtils.getCellData(path, sheetname, i, 39);
			String editrow4jobid=XLUtils.getCellData(path, sheetname, i, 40);
			String editrow4earningcode=XLUtils.getCellData(path, sheetname, i, 41);
			String editrow4shiftid=XLUtils.getCellData(path, sheetname, i, 42);
			String editrow4specialpayid=XLUtils.getCellData(path, sheetname, i, 43);
			String editrow4regularhours=XLUtils.getCellData(path, sheetname, i, 44);
			String editrow4overtimehours=XLUtils.getCellData(path, sheetname, i, 45);
			String editrow4doubletimehours=XLUtils.getCellData(path, sheetname, i, 46);
			String editrow4tripletimehours=XLUtils.getCellData(path, sheetname, i, 47);
			
		//workers detail
		employees_workers_pom workerdetails=new employees_workers_pom(driver);
		//workerdetails.EmployeesTab();
		workerdetails.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		workerdetails.clickworkerstab();
		Thread.sleep(1000);
		workerdetails.WorkersScreen();
		Thread.sleep(2000);
		workerdetails.clkSearchbtn(workername);
		Thread.sleep(2000);
		workerdetails.clkEditbtn();
		workerdetails.clkworkercurrentpositiontab();
		Thread.sleep(2000);
		//hourlyrate
		String hourlyrateamttxt=workerdetails.getHorlyrateamt();
		int hourlyrateamtlen=hourlyrateamttxt.length();
		String hourlyrateamtfinalstring=hourlyrateamttxt.substring(1,hourlyrateamtlen);
		double hourlyrateamt=Double.parseDouble(hourlyrateamtfinalstring);
		logger.info("Hourly Amt Rate is: " +hourlyrateamt);
		//job code
		String jobcode=workerdetails.getjobcode();
		logger.info("Jobcode is: " +jobcode);
		String positionid=workerdetails.getpositionid();
		logger.info("Positionid is: " +positionid);
		Thread.sleep(3000);
		workerdetails.clickworkerstab();
		Thread.sleep(1000);
		workerdetails.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		//Employee>Positions
		employees_positions_pom positions=new employees_positions_pom(driver);
		//positions.EmployeesTab();
		positions.clickpayrollmgmtadptab();
		Thread.sleep(1000);
		positions.clickworkersetuptab();
		Thread.sleep(1000);
		positions.clkpositionsscreen();
		Thread.sleep(2000);
		positions.clksearchtextbox();
		positions.txtworkersearchstring(positionid);
		Thread.sleep(2000);
		positions.clkEdit();
		Thread.sleep(2000);
		String homeunionidvalue=positions.gethomeunionidvalue();
		//logger.info("Home Union ID 1st is: " +homeunionidvalue);
		/*
		String unionetrapaystring=positions.getunionextrapayvalue();
		float unionextrapay=(float) Double.parseDouble(unionetrapaystring);
		logger.info("Union Extra pay is: " +unionextrapay);
		*/
		if(homeunionidvalue.equals(""))
		{
			logger.info("No Union available for: " +workername);
			positions.clkCancel();
		}
		else if(homeunionidvalue.equals("Union 01 (United Steelworkers)") || homeunionidvalue.equals("Union 02 (UNITE HERE)") || homeunionidvalue.equals("Union 03 (Teamsters)") || homeunionidvalue.equals("Union 04 (United Auto Workers)") || homeunionidvalue.equals("Automation_Union01 (AutomationUnion01)"))
		{
			String homeunionidvalue1=positions.gethomeunionidvalue();
			String homeunionid=homeunionidvalue1.substring(0,8);
			logger.info("Home Union ID is: " +homeunionid);
			Thread.sleep(2000);
			positions.clkCancel();
			Thread.sleep(5000);
			//job code rate in union
			unions_Unions_pom jobcoderate=new unions_Unions_pom(driver);
			//jobcoderate.clickUnionsTab();
			jobcoderate.clickunionmgmttab();
			Thread.sleep(1000);
			jobcoderate.clickunionsetuptab();
			Thread.sleep(1000);
			//jobcoderate.clickUnionsTab2();
			Thread.sleep(1000);
			jobcoderate.clksearchtxtbtn(homeunionid);
			Thread.sleep(2000);
			jobcoderate.clkeditbtn();
			Thread.sleep(2000);
			jobcoderate.clickUnionAgreementTab();
			Thread.sleep(4000);
			/*
			jobcoderate.clksearchtxt(jobcode);
			Thread.sleep(1000);
			jobcoderate.clksearchlensbtn();
			Thread.sleep(1000);
			*/
			String jobcoderatevalue=jobcoderate.getjobcoderate();
			//logger.info("Jobcode Rate String is: " +jobcoderatevalue);
			double jobrateamtvalue=Double.parseDouble(jobcoderatevalue);
			//logger.info("Jobcode Rate is: " +jobrateamtvalue);
		}
		unions_Unions_pom jobcoderate=new unions_Unions_pom(driver);
		String jobcoderatevalue=jobcoderate.getjobcoderate();
		//logger.info("Jobcode Rate String is: " +jobcoderatevalue);
		double jobrateamtvalue=Double.parseDouble(jobcoderatevalue);
		logger.info("Jobcode Rate is: " +jobrateamtvalue);
		//newtimesheet activites
		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timesheet.TimesheetTab();
		logger.info("User Clicked Timesheet tab - Passed");
		Thread.sleep(2000);
		timesheet.TimeentryTab();
		Thread.sleep(2000);
		timesheet.AllTimesheetScreen();
		//logger.info("Navigated to AllTimeSheet Screen - Passed");
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		//logger.info("Clicked NewTimesheet button - Passed");
		Thread.sleep(3000);
		timesheet.clkWorkersText();
		Thread.sleep(3000);
		timesheet.txtworker(workername);
		//System.out.println("Worker selected is: " +workername);
		Thread.sleep(3000);
		timesheet.selectWorker();
		//logger.info("Worker Selected: " +workername);
		Thread.sleep(1000);
	    timesheet.clkProjectText();
		timesheet.txtproject(project);
		//System.out.println("Project selected is: " +project);
		Thread.sleep(1000);
		timesheet.selectproject();
		//logger.info("Project selected is: " +project);
		Thread.sleep(1000);
		timesheet.clkTaskcodeText();
		Thread.sleep(1000);
		timesheet.txttaskcode(taskcode);
		Thread.sleep(1000);
		timesheet.selecttaskcode();
		Thread.sleep(1000);
		/*
		if(timesheet.txttaskcodestring(taskcode).equals("T001"))
		{
		timesheet.setTaskcode1();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
		{
		timesheet.setTaskcode2();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
		{
		timesheet.setTaskcode3();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("Land survey"))
		{
		timesheet.setTaskcode4Land();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("Fabrication"))
		{
		timesheet.setTaskcode5Fabrication();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("Bar bending"))
		{
		timesheet.setTaskcode6Barbending();
		//logger.info("Taskcode selected is: " +taskcode);
		}
		//System.out.println("TaskCode selected is: " +taskcode);
		Thread.sleep(1000);
		*/
		timesheet.clkPayperiodText();
		/*// it is for weekly time period
		if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
		{
			timesheet.setPayperiod1();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/8/20"))
		{
			timesheet.setPayperiod2();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
		{
			timesheet.setPayperiod3();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/20"))
		{
			timesheet.setPayperiod4();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
		{
			timesheet.setPayperiod5();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/6/20"))
		{
			timesheet.setPayperiod6();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
		{
			timesheet.setPayperiod7();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/20"))
		{
			timesheet.setPayperiod8();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
		{
			timesheet.setPayperiod9();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/3/21"))
		{
			timesheet.setPayperiod10();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
		{
			timesheet.setPayperiod11();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/17/21"))
		{
			timesheet.setPayperiod12();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
		{
			timesheet.setPayperiod13();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/31/21"))
		{
			timesheet.setPayperiod14();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
		{
			timesheet.setPayperiod15();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/14/21"))
		{
			timesheet.setPayperiod16();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
		{
			timesheet.setPayperiod17();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/28/21"))
		{
			timesheet.setPayperiod18();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
		{
			timesheet.setPayperiod19();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/14/21"))
		{
			timesheet.setPayperiod20();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
		{
			timesheet.setPayperiod21();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/28/21"))
		{
			timesheet.setPayperiod22();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
		{
			timesheet.setPayperiod23();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/11/21"))
		{
			timesheet.setPayperiod24();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
		{
			timesheet.setPayperiod25();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/25/21"))
		{
			timesheet.setPayperiod26();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
		{
			timesheet.setPayperiod27();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/9/21"))
		{
			timesheet.setPayperiod28();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
		{
			timesheet.setPayperiod29();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/23/21"))
		{
			timesheet.setPayperiod30();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
		{
			timesheet.setPayperiod31();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("6/6/21"))
		{
			timesheet.setPayperiod32();
		}
		*/
		if(timesheet.txtpayperiodstring(payperiod).equals("11/1/20"))
		{
			timesheet.setPayperiod33();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/20"))
		{
			timesheet.setPayperiod34();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/20"))
		{
			timesheet.setPayperiod35();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/20"))
		{
			timesheet.setPayperiod36();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/20"))
		{
			timesheet.setPayperiod37();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/10/21"))
		{
			timesheet.setPayperiod38();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("1/24/21"))
		{
			timesheet.setPayperiod39();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/7/21"))
		{
			timesheet.setPayperiod40();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("2/21/21"))
		{
			timesheet.setPayperiod41();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/7/21"))
		{
			timesheet.setPayperiod42();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("3/21/21"))
		{
			timesheet.setPayperiod43();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/4/21"))
		{
			timesheet.setPayperiod44();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("4/18/21"))
		{
			timesheet.setPayperiod45();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/2/21"))
		{
			timesheet.setPayperiod46();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/16/21"))
		{
			timesheet.setPayperiod47();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("5/30/21"))
		{
			timesheet.setPayperiod48();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("6/13/21"))
		{
			timesheet.setPayperiod49();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("6/27/21"))
		{
			timesheet.setPayperiod50();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("7/11/21"))
		{
			timesheet.setPayperiod51();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("7/25/21"))
		{
			timesheet.setPayperiod52();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("8/8/21"))
		{
			timesheet.setPayperiod53();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("8/22/21"))
		{
			timesheet.setPayperiod54();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("9/5/21"))
		{
			timesheet.setPayperiod55();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("9/19/21"))
		{
			timesheet.setPayperiod56();
		}
		//System.out.println("PayPeriod selected is: " +payperiod);
		//logger.info("Pay period date selected is: " +payperiod);
		timesheet.btnSave();
		Thread.sleep(5000);
		logger.info(workername+ ": NewTimesheet Successfully Saved - Passed");
		//Edit Row1
		timesheet.setRow1();
		Thread.sleep(1000);
		timesheet.setRow1();
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.seteditdate();
		Thread.sleep(1000);
		timesheet.cleareditdate();
		timesheet.seteditdate();
		Thread.sleep(1000);
		timesheet.txteditdatestring(editdate);
		Thread.sleep(1000);
		*/
		/*
		if(project==editprojectcode)
		{
			Thread.sleep(1000);
		}
		else if(project!=editprojectcode)
		{
		*/
		/* on 19th feb 2021
			if(timesheet.txteditprojectcodestring(editprojectcode).equals("P000001"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(1000);
				timesheet.listselect();
			    Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editprojectcode).equals("P000002"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editprojectcode).equals("P000003"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editprojectcode).equals("P000004"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editprojectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editprojectcode).equals(" "))
			{
				Thread.sleep(1000);
			}
			if(timesheet.txtedittaskcodestring(edittaskcode).equals("T001"))
			{
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.setTaskcode1();
			}
			else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T002"))
			{
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.setTaskcode2();
			}
			else if(timesheet.txtedittaskcodestring(edittaskcode).equals("T003"))
			{
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.clredittaskcode();
				Thread.sleep(1000);
				timesheet.setedittaskcode();
				Thread.sleep(1000);
				timesheet.setTaskcode3();
			}
			else if(timesheet.txtedittaskcodestring(edittaskcode).equals(" "))
			{
				Thread.sleep(1000);
			}
			*/
		    timesheet.seteditshiftid();
		    Thread.sleep(1000);
		    if(timesheet.txteditswiftstring(editshiftid).equals("Swing"))
			{
		    	timesheet.setShiftSwing();
			}
			else if(timesheet.txteditswiftstring(editshiftid).equals("Night"))
			{
				timesheet.setShiftNight();
			}
			else if(timesheet.txteditswiftstring(editshiftid).equals("Day"))
			{
				timesheet.setShiftDay();
			}
			else if(timesheet.txteditswiftstring(editshiftid).equals(" "))
			{
				Thread.sleep(1000);
			}
		    Thread.sleep(1000);
		    timesheet.txteditregularhoursstring(editregularhours);
			Thread.sleep(1000);
			timesheet.seteditovertimehours();
			Thread.sleep(1000);
			timesheet.txteditovertimehoursstring(editovertimehours);
			Thread.sleep(1000);
			timesheet.seteditdoubletimehours();
			Thread.sleep(1000);
			timesheet.txteditdoubletimehoursstring(editdoubletimehours);
			Thread.sleep(1000);
			timesheet.setedittripletimehours();
			Thread.sleep(1000);
			timesheet.txtedittripletimehoursstring(edittripletimehours);
			Thread.sleep(1000);
			timesheet.Update();
			Thread.sleep(5000);
			//logger.info("Row 1 Successfully Updated");
		//Edit Row2
		timesheet.setRow2();
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.cleareditrow2date();
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.txteditrow2datestring(editrow2date);
		Thread.sleep(1000);
		*/
		/* on 19th feb 2021
		if(project==editrow2projectcode)
		{
			Thread.sleep(1000);
		}
		else if(project!=editrow2projectcode)
		{
			if(timesheet.txteditprojectcodestring(editrow2projectcode).equals("P000001"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow2projectcode).equals("P000002"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow2projectcode).equals("P000003"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow2projectcode).equals("P000004"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow2projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow2projectcode).equals(" "))
			{
				Thread.sleep(1000);
			}
		}
		if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T001"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode1();
		}
		else if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T002"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode2();
		}
		else if(timesheet.txtedittaskcodestring(editrow2taskcode).equals("T003"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode3();
		}
		else if(timesheet.txtedittaskcodestring(editrow2taskcode).equals(" "))
		{
			Thread.sleep(1000);
		}
		 Thread.sleep(1000);
		 */
		 timesheet.seteditshiftid();
		    Thread.sleep(1000);
		    if(timesheet.txteditswiftstring(editrow2shiftid).equals("Swing"))
			{
		    	timesheet.setShiftSwing();
			}
			else if(timesheet.txteditswiftstring(editrow2shiftid).equals("Night"))
			{
				timesheet.setShiftNight();
			}
			else if(timesheet.txteditswiftstring(editrow2shiftid).equals("Day"))
			{
				timesheet.setShiftDay();
			}
			else if(timesheet.txteditswiftstring(editrow2shiftid).equals(" "))
			{
				Thread.sleep(1000);
			}
		Thread.sleep(1000);
		timesheet.txteditregularhoursstring(editrow2regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow2overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow2doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow2tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//logger.info("Row 2 Successfully Updated");
		//Edit Row3
		timesheet.setRow3();
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.cleareditrow2date();
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.txteditrow2datestring(editrow3date);
		Thread.sleep(1000);
		*/
		/* on 19th feb 2021
		if(project==editrow3projectcode)
		{
			Thread.sleep(1000);
		}
		else if(project!=editrow3projectcode)
		{
			if(timesheet.txteditprojectcodestring(editrow3projectcode).equals("P000001"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow3projectcode).equals("P000002"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow3projectcode).equals("P000003"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow3projectcode).equals("P000004"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow3projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow3projectcode).equals(" "))
			{
				Thread.sleep(1000);
			}
		}
		if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T001"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode1();
		}
		else if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T002"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode2();
		}
		else if(timesheet.txtedittaskcodestring(editrow3taskcode).equals("T003"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode3();
		}
		else if(timesheet.txtedittaskcodestring(editrow3taskcode).equals(" "))
		{
			Thread.sleep(1000);
		}
		 Thread.sleep(1000);
		 */
		timesheet.seteditshiftid();
	    Thread.sleep(1000);
	    if(timesheet.txteditswiftstring(editrow3shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals("Day"))
			{
				timesheet.setShiftDay();
			}
		else if(timesheet.txteditswiftstring(editrow3shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
	    Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow3regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow3overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow3doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow3tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//logger.info("Row 3 Successfully Updated");
		//Edit Row4
		timesheet.setRow4();
		timesheet.Edit();
		Thread.sleep(1000);
		/*
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.cleareditrow2date();
		timesheet.seteditrow2date();
		Thread.sleep(1000);
		timesheet.txteditrow2datestring(editrow2date);
		Thread.sleep(1000);
		*/
		/* on 19th feb 2021
		if(project==editrow4projectcode)
		{
			Thread.sleep(1000);
		}
		else if(project!=editrow4projectcode)
		{
			if(timesheet.txteditprojectcodestring(editrow4projectcode).equals("P000001"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow4projectcode).equals("P000002"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow4projectcode).equals("P000003"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow4projectcode).equals("P000004"))
			{
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.clreditprojectcode();
				Thread.sleep(1000);
				timesheet.seteditprojectcode();
				Thread.sleep(1000);
				timesheet.txteditprojectcodestring(editrow4projectcode);
				Thread.sleep(1000);
				timesheet.listselect();
				Thread.sleep(1000);
			}
			else if(timesheet.txteditprojectcodestring(editrow4projectcode).equals(" "))
			{
				Thread.sleep(1000);
			}
		}
		if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T001"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode1();
		}
		else if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T002"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode2();
		}
		else if(timesheet.txtedittaskcodestring(editrow4taskcode).equals("T003"))
		{
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.clredittaskcode();
			Thread.sleep(1000);
			timesheet.setedittaskcode();
			Thread.sleep(1000);
			timesheet.setTaskcode3();
		}
		else if(timesheet.txtedittaskcodestring(editrow4taskcode).equals(" "))
		{
			Thread.sleep(1000);
		}
		 Thread.sleep(1000);
		 */
		timesheet.seteditshiftid();
	    Thread.sleep(1000);
	    if(timesheet.txteditswiftstring(editrow4shiftid).equals("Swing"))
		{
	    	timesheet.setShiftSwing();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("Night"))
		{
			timesheet.setShiftNight();
		}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals("Day"))
			{
				timesheet.setShiftDay();
			}
		else if(timesheet.txteditswiftstring(editrow4shiftid).equals(" "))
		{
			Thread.sleep(1000);
		}
	    Thread.sleep(1000);
	    timesheet.txteditregularhoursstring(editrow4regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(editrow4overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(editrow4doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(editrow4tripletimehours);
		Thread.sleep(1000);
		timesheet.Update();
		Thread.sleep(5000);
		//logger.info("Row 4 Successfully Updated");
		timesheet.Process();
		logger.info(workername+ ": Clicked on Process button - Passed");
		Thread.sleep(5000);
		timesheet.Threedots();
		Thread.sleep(5000);
		timesheet.Viewcalculation();
		Thread.sleep(5000);
		int rowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr")).size();
		String numofrows=String.valueOf(rowcount);
		System.out.println("number of rows: " +numofrows);
		for(int r=1;r<=rowcount;r++)
		{
			String totalhours=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
			int totalhoursfinalvalue=Integer.parseInt(totalhours);
			BigDecimal totalhoursdisplay= new BigDecimal(totalhoursfinalvalue).setScale(0, RoundingMode.HALF_EVEN);
			System.out.println("Total Hours is: " +totalhoursdisplay);
			//logger.info("TotalHours is: " +totalhoursdisplay);
			String eomployeerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
			float employeeratefinalvalue=(float) Double.parseDouble(eomployeerate);
			System.out.println("Employee Rate from double is: " +employeeratefinalvalue);
			BigDecimal employeeratedisplay= new BigDecimal(employeeratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
			String employeeratedisplaystring=employeeratedisplay.toString();
			System.out.println("Employee Rate is: " +employeeratedisplaystring);
			//logger.info("Employee Rate is: " +employeeratefinalvalue);
			String unionrate=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
			//double unionratefinalvalue=Double.parseDouble(unionrate);
			float unionratefinalvalue=(float) Double.parseDouble(unionrate);
			System.out.println("unionratefinalvalue is: " +unionratefinalvalue);
			BigDecimal unionratedisplay= new BigDecimal(unionratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
			System.out.println("Union Rate is: " +unionratedisplay);
			//logger.info("Union Rate is: " +unionratedisplay);
			String privailingwagerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
			float privailingwageratefinalvalue=(float) Double.parseDouble(privailingwagerate);
			BigDecimal privailingwageratedisplay= new BigDecimal(privailingwageratefinalvalue).setScale(4, RoundingMode.HALF_EVEN);
			System.out.println("Priviling Wage Rate is: " +privailingwageratedisplay);
			//logger.info("Priviling Wage Rate is: " +privailingwageratedisplay);
			String calculatedcost=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
			//double calculatedcostfinalvalue=Double.parseDouble(calculatedcost);
			float calculatedcostfinalvalue=(float) Double.parseDouble(calculatedcost);
			System.out.println("Calculated cost display from app - double  is: " +calculatedcostfinalvalue);
			BigDecimal calcostdisplay= new BigDecimal(calculatedcostfinalvalue).setScale(4, RoundingMode.HALF_EVEN);
			//System.out.println("Calculated cost display  is: " +calcostdisplay);
			String calcostfinalvaluefromapp=calcostdisplay.toString();
			System.out.println("Calculated cost display from app  is: " +calcostfinalvaluefromapp);
			//logger.info("Calculated cost display from app  is: " +calcostfinalvaluefromapp);
			//logger.info("Calculated cost display from app  is: " +calculatedcostfinalvalue);
			driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[4]")).click();
		    String earningcodetxt=driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[4]")).getText();
		    String empshiftrategrid=driver.findElement(By.xpath("//input[@name='employeeShiftRate']")).getAttribute("value");
		    float empshiftrategridvalue=(float) Double.parseDouble(empshiftrategrid);
		    System.out.println("Employee Shift rate grid is: " +empshiftrategridvalue);
		    String unionshiftrategrid=driver.findElement(By.xpath("//input[@name='unionShiftRate']")).getAttribute("value");
		    float unionshiftrategridvalue=(float) Double.parseDouble(unionshiftrategrid);
		    System.out.println("Union Shift rate grid is: " +unionshiftrategridvalue);
		    String unionspecialrategrid=driver.findElement(By.xpath("//input[@name='unionSpecialPayRate']")).getAttribute("value");
		    float unionspecialrategridvalue=(float) Double.parseDouble(unionspecialrategrid);
		    System.out.println("Union Specialpay rate grid is: " +unionspecialrategridvalue);
		    String unionextrapayrategrid=driver.findElement(By.xpath("//input[@name='extraPayRate']")).getAttribute("value");
		    float unionextrapay=(float) Double.parseDouble(unionextrapayrategrid);
		    System.out.println("Union Extrapay rate grid is: " +unionextrapayrategrid);
		    String prevailingWageRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageRate']")).getAttribute("value");
		    float prevailingWageRate=(float) Double.parseDouble(prevailingWageRategrid);
		    System.out.println("Prevailingwage rate grid is: " +prevailingWageRate);
		    String prevailingWageCashInLieugrid=driver.findElement(By.xpath("//input[@name='prevailingWageCashInLieu']")).getAttribute("value");
		    float prevailingWageCashInLieu=(float) Double.parseDouble(prevailingWageCashInLieugrid);
		    System.out.println("Prevailingwage Cashinlieu rate grid is: " +prevailingWageCashInLieu);
		    String prevailingWageShiftRategrid=driver.findElement(By.xpath("//input[@name='prevailingWageShiftRate']")).getAttribute("value");
		    float prevailingWageShiftRate=(float) Double.parseDouble(prevailingWageShiftRategrid);
		    System.out.println("Prevailingwage Shift rate grid is: " +prevailingWageShiftRate);
		    //Employee, Union and Prevailingwage Rate calculations
		    if(earningcodetxt.equals("DOT"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*DoubletimeAmtRatevalue);
				  System.out.println("DOT Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		   //System.out.println("DOT*EmployeeRate Calculated as expected is: " +employerrate);  
	        		   Assert.assertTrue(true);
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("DOT*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		   Assert.fail();
	        	   }
				 float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*DoubletimeAmtRatevalue);
				 System.out.println("DOT Union Rate is: " +unionrate);
				 if(unionratevalue==unionratefinalvalue)
				 {
					// System.out.println("DOT*Unionrate Calculated as expected is: " +unionratevalue);  
					 Assert.assertTrue(true);
				 }
				 else if(unionratevalue!=unionratefinalvalue)
				 {
					 logger.info("DOT*Unionrate not calculated as excpected is: "  +unionratevalue);
					 Assert.fail();
				 }
				 float prevailingratevalue=(float) ((prevailingWageRate+prevailingWageCashInLieu+prevailingWageShiftRate)*DoubletimeAmtRatevalue);
				 System.out.println("DOT Privailing Rate is: " +prevailingratevalue);
				 if(prevailingratevalue==privailingwageratefinalvalue)
				 {
					 System.out.println("DOT*Privailingrate Calculated as expected is: " +prevailingratevalue);  
				 }
				 else if(prevailingratevalue!=privailingwageratefinalvalue)
				 {
					 System.out.println("DOT*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
				 } 
				 
		    }
		    else if(earningcodetxt.equals("O3"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*TripletimeAmtRatevalue);
				  System.out.println("O3 Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		  // System.out.println("O3*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("O3*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		   Assert.fail();
	        	   }
			    float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*TripletimeAmtRatevalue);
					 System.out.println("O3 Union Rate is: " +unionrate);
					 if(unionratevalue==unionratefinalvalue)
					 {
						// System.out.println("O3*Unionrate Calculated as expected is: " +unionratevalue);  
						 Assert.assertTrue(true);
					 }
					 else if(unionratevalue!=unionratefinalvalue)
					 {
						 logger.info("O3*Unionrate not calculated as excpected is: "  +unionratevalue);
						 Assert.fail();
					 }
				float prevailingratevalue=(float) ((prevailingWageRate+prevailingWageCashInLieu+prevailingWageShiftRate)*TripletimeAmtRatevalue);
					 System.out.println("O3 Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						 System.out.println("O3*Privailingrate Calculated as expected is: " +prevailingratevalue);  
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 System.out.println("O3*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
					 } 
		    }
		    else if(earningcodetxt.equals("O"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*OvertimeAmtRatevalue);
				  System.out.println("O Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		 //  System.out.println("O*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("O*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		   Assert.fail();
	        	   }
			    float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*OvertimeAmtRatevalue);
					 System.out.println("O Union Rate is: " +unionrate);
					 if(unionratevalue==unionratefinalvalue)
					 {
						// System.out.println("O*Unionrate Calculated as expected is: " +unionratevalue); 
						 Assert.assertTrue(true);
					 }
					 else if(unionratevalue!=unionratefinalvalue)
					 {
						 logger.info("O*Unionrate not calculated as excpected is: "  +unionratevalue);
						 Assert.fail();
					 }
			    float prevailingratevalue=(float) ((prevailingWageRate+prevailingWageCashInLieu+prevailingWageShiftRate)*OvertimeAmtRatevalue);
					 System.out.println("O Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						 System.out.println("O*Privailingrate Calculated as expected is: " +prevailingratevalue);  
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 System.out.println("O*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
					 } 
		    }
		    else if(earningcodetxt.equals("R"))
		    {
		    	float employerrate=(float) ((hourlyrateamt+empshiftrategridvalue)*RegularAmtRatevalue);
				  System.out.println("R Employee Rate is: " +employerrate);
				  if(employerrate==employeeratefinalvalue)
	        	   {
	        		  // System.out.println("R*EmployeeRate Calculated as expected is: " +employerrate);
	        		   Assert.assertTrue(true);
	        		   
	        	   }
	        	   else if(employerrate!=employeeratefinalvalue)
	        	   {
	        		   logger.info("R*EmployeeRate not calculated as excpected is: "  +employerrate);
	        		   Assert.fail();
	        	   }
				 float unionratevalue=(float) ((jobrateamtvalue+unionshiftrategridvalue+unionextrapay+unionspecialrategridvalue)*RegularAmtRatevalue);
					 System.out.println("R Union Rate is: " +unionratevalue);
					 if(unionratevalue==unionratefinalvalue)
					 {
						 //System.out.println("R*Unionrate Calculated as expected is: " +unionratevalue);
						 Assert.assertTrue(true);
					 }
					 else if(unionratevalue!=unionratefinalvalue)
					 {
						 logger.info("R*Unionrate not calculated as excpected is: "  +unionratevalue);
						 Assert.fail();
					 }
				float prevailingratevalue=(float) ((prevailingWageRate+prevailingWageCashInLieu+prevailingWageShiftRate)*RegularAmtRatevalue);
					 System.out.println("R Privailing Rate is: " +prevailingratevalue);
					 if(prevailingratevalue==privailingwageratefinalvalue)
					 {
						 System.out.println("R*Privailingrate Calculated as expected is: " +prevailingratevalue);  
					 }
					 else if(prevailingratevalue!=privailingwageratefinalvalue)
					 {
						 System.out.println("R*Privailingrate not calculated as excpected is: "  +prevailingratevalue);
					 } 
		    }
		    //Calculated Cost Rate Calculation
		    if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
			{
				
				float Caluculatedcost =totalhoursfinalvalue * employeeratefinalvalue;
				//System.out.println("Calculated cost is: " +Caluculatedcost);
				//logger.info("Calculated cost from double is: " +Caluculatedcost);
				BigDecimal Caluculatedcostvaluestring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
				String Caluculatedcostvalue =Caluculatedcostvaluestring.toString();
				System.out.println("Caluculatedcostvalue is: " +Caluculatedcostvalue);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					Assert.assertTrue(true);
					//System.out.println("Calculated cost calculated as expected");
					//logger.info("Calculated cost calculated as expected");
					//BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
				}
				else if(Caluculatedcost!=calculatedcostfinalvalue)
				{
					
					Assert.fail();
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
					//Assert.fail();
					//System.out.println("Calculated cost not calculated as expected");
				}
			}
			else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
			{
				float Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
				//System.out.println("Calculated cost is: " +Caluculatedcost);
				//logger.info("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					Assert.assertTrue(true);
					//System.out.println("Calculated cost calculated as expected");
					//logger.info("Calculated cost calculated as expected");
					//BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
					//String writexlClculatedcost=Calculatedcoststring.toString();
				}
				else if(Caluculatedcost!=calculatedcostfinalvalue)
				{
					Assert.fail();
					//System.out.println("Calculated cost not calculated as expected");
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
				}
			}
			else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
			{
				float Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
				//System.out.println("Calculated cost is: " +Caluculatedcost);
				//logger.info("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					Assert.assertTrue(true);
					//System.out.println("Calculated cost calculated as expected");
					//logger.info("Calculated cost calculated as expected");
					//BigDecimal Calculatedcoststring= new BigDecimal(Caluculatedcost).setScale(4, RoundingMode.HALF_EVEN);
					//String writexlClculatedcost=Calculatedcoststring.toString();
				}
				else if(Caluculatedcost!=calculatedcostfinalvalue)
				{
					Assert.fail();
					//System.out.println("Calculated cost not calculated as expected");
					logger.info(workername+ ": Calculated cost not calculated as expected - Failed");
				}
			}
		
		}
		//Total hourly cost calculation
		String[][] tableVal;
	    int rowCount,columnCount;
	    float sum=0;
		List<WebElement> tablerowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr"));
		List<WebElement> tablecolumncount=driver.findElements(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td"));
		rowCount = tablerowcount.size();
	    columnCount = tablecolumncount.size();
	   // System.out.println("Row :"+rowCount+" Clounm :"+columnCount);
	    tableVal = new String[rowCount][columnCount];
	    for(int w =1 ; w <= rowCount ; w++ ){
	        //for(int j =1 ; j <= columnCount ; j++ ) //{
	               tableVal[w-1][12] =driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+w+"]/td[12]")).getText();
	               float totalhour=(float) Double.parseDouble(tableVal[w-1][12]);
	                //System.out.println(driver.findElement(By.xpath("//ejs-grid[@id='grid_262291362_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+w+"]/td[12]")).getText());
	                sum=sum+totalhour;
	           // }
	        }
	   //System.out.println("Sum of all the Calculatedcost is: " +sum);
	   logger.info(workername+ ": Sum of all the Calculatedcost is: " +sum);
	   String totalhourly= driver.findElement(By.xpath("//*[@id=\"grid_262291362_0_content_table\"]/tbody/tr/td[6]")).getText();
	   float totalhourlycost=(float) Double.parseDouble(totalhourly);
	   //System.out.println("Total Hourly Cost: " +totalhourlycost);
	   logger.info(workername+ ": Total Hourly Cost: " +totalhourlycost);
	   if(totalhourlycost==sum)
	   {
		  // System.out.println("Total hours Calculated as expected");
		   logger.info(workername+ ": Total hours Calculated as expected - Passed");
	   }
	   else if(totalhourlycost!=sum)
	   {
		   //System.out.println("Total hours not Calculated as expected for the worker: " +workername);
		   logger.info(workername+ ": Total hours not Calculated as expected - Failed");
	   }
	   
	    Thread.sleep(10000);
	    timesheet.clkbackbtn();
	    Thread.sleep(1000);
	    timesheet.Approve();
		Thread.sleep(1000);
		logger.info(workername+ ": Status Approved - Passed");
		timesheet.Complete();
		Thread.sleep(1000);
		logger.info(workername+ ": Status Completed - Passed");
		timesheet.CreateStatement();
		Thread.sleep(1000);
		logger.info(workername+ ": Statement Created - Passed");
		Thread.sleep(1000);
		/*
		timesheet.AllTimesheetScreen();
		Thread.sleep(5000);
		timesheet.NewTimesheet();
		Thread.sleep(2000);
		*/
	}
	
  }

}

package sis.aps.testcases;

import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;
import sis.aps.pageobjects.timesheet_calc_pom;
import sis.aps.utilities.XLUtils;

public class datadriven extends baseclass {

	@Test
	public void timesheet()  throws Exception
	{
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);

		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timemgmt_alltimesheet_pom timesheet1=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		Thread.sleep(2000);
		
		String path="./excel/Timesheet_CalculatedCost.xlsx";
		String sheetname="Sheet1";
		XLUtils.setExcelFile(path, sheetname);
		int xlrowcount=XLUtils.getRowCount(path, sheetname);
		int xlcellcount=XLUtils.getCellCount(path, sheetname, xlrowcount);
		System.out.println(xlrowcount);
		System.out.println(xlcellcount);
		for(int i=0;i<=xlrowcount;i++)
		{
			String workername=XLUtils.getCellData(path, sheetname, i, 0);
			String project=XLUtils.getCellData(path, sheetname, i, 1);
			String taskcode=XLUtils.getCellData(path, sheetname, i, 2);
			String payperiod=XLUtils.getCellData(path, sheetname, i, 3);
			String editdate=XLUtils.getCellData(path, sheetname, i, 4);
			String edittaskcode=XLUtils.getCellData(path, sheetname, i, 5);
			String editprojectcode=XLUtils.getCellData(path, sheetname, i, 5);
			String editregularhours=XLUtils.getCellData(path, sheetname, i, 6);
			String editovertimehours=XLUtils.getCellData(path, sheetname, i, 7);
			String editdoubletimehours=XLUtils.getCellData(path, sheetname, i, 8);
			String edittripletimehours=XLUtils.getCellData(path, sheetname, i, 9);
			
			timesheet.clkWorkersText();
			timesheet.txtworker(workername);
			System.out.println("Worker selected is: " +workername);
			Thread.sleep(2000);
			timesheet.selectWorker();
			Thread.sleep(2000);
			timesheet.clkProjectText();
			timesheet.txtproject(project);
			System.out.println("Project selected is: " +project);
			Thread.sleep(2000);
			timesheet.selectproject();
			Thread.sleep(2000);
			timesheet.clkTaskcodeText();
			if(timesheet.txttaskcodestring(taskcode).equals("T001"))
			{
			timesheet.setTaskcode1();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
			{
			timesheet.setTaskcode2();
			}
			else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
			{
			timesheet.setTaskcode3();
			}
			System.out.println("TaskCode selected is: " +taskcode);
			Thread.sleep(2000);
			timesheet.clkPayperiodText();
			if(timesheet.txtpayperiodstring(payperiod).equals("11/01/2020"))
			{
				timesheet.setPayperiod1();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/08/2020"))
			{
				timesheet.setPayperiod2();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/2020"))
			{
				timesheet.setPayperiod3();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/2020"))
			{
				timesheet.setPayperiod4();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/2020"))
			{
				timesheet.setPayperiod5();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/06/2020"))
			{
				timesheet.setPayperiod6();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/2020"))
			{
				timesheet.setPayperiod7();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/2020"))
			{
				timesheet.setPayperiod8();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/2020"))
			{
				timesheet.setPayperiod9();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("01/03/2021"))
			{
				timesheet.setPayperiod10();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("01/10/2021"))
			{
				timesheet.setPayperiod11();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("01/17/2021"))
			{
				timesheet.setPayperiod12();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("01/24/2021"))
			{
				timesheet.setPayperiod13();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("01/31/2021"))
			{
				timesheet.setPayperiod14();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("02/07/2021"))
			{
				timesheet.setPayperiod15();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("02/14/2021"))
			{
				timesheet.setPayperiod16();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("02/21/2021"))
			{
				timesheet.setPayperiod17();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("02/28/2021"))
			{
				timesheet.setPayperiod18();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("03/07/2021"))
			{
				timesheet.setPayperiod19();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("03/14/2021"))
			{
				timesheet.setPayperiod20();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("03/21/2021"))
			{
				timesheet.setPayperiod21();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("03/28/2021"))
			{
				timesheet.setPayperiod22();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("04/04/2021"))
			{
				timesheet.setPayperiod23();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("04/11/2021"))
			{
				timesheet.setPayperiod24();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("04/18/2021"))
			{
				timesheet.setPayperiod25();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("04/25/2021"))
			{
				timesheet.setPayperiod26();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("05/02/2021"))
			{
				timesheet.setPayperiod27();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("05/09/2021"))
			{
				timesheet.setPayperiod28();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("05/16/2021"))
			{
				timesheet.setPayperiod29();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("05/23/2021"))
			{
				timesheet.setPayperiod30();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("05/30/2021"))
			{
				timesheet.setPayperiod31();
			}
			else if(timesheet.txtpayperiodstring(payperiod).equals("06/06/2021"))
			{
				timesheet.setPayperiod32();
			}
			System.out.println("PayPeriod selected is: " +payperiod);
			timesheet.btnSave();
			Thread.sleep(5000);
		}
		
		
		/*
		FileInputStream file=new FileInputStream("./excel/Timesheet_CalculatedCost.xlsx");
		XSSFWorkbook worbook=new XSSFWorkbook(file);
		XSSFSheet sheet=worbook.getSheet("Sheet1");
		int excelrowcount=sheet.getLastRowNum();
		System.out.println(excelrowcount);
		int excelcellcount=sheet.getRow(0).getLastCellNum();
		System.out.println(excelcellcount);
		for(int i=1;i<=excelrowcount;i++)
		{
			XSSFRow row=sheet.getRow(i);
			for(int c=0;c<=excelcellcount;c++)
			{
				XSSFCell cell=row.getCell(c);
				DataFormatter formatter=new DataFormatter();
				String celldata=formatter.formatCellValue(cell);
				System.out.print(celldata);
			}
			System.out.println();
		}
		*/
	}
}

package sis.aps.testcases;

import org.openqa.selenium.By;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.timemgmt_alltimesheet_pom;
import sis.aps.pageobjects.timesheet_calc_pom;

public class dontdelete extends baseclass {

	public void timesheet_scenario1_calc() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		timesheet_calc_pom timesheet=new timesheet_calc_pom(driver);
		timemgmt_alltimesheet_pom timesheet1=new timemgmt_alltimesheet_pom(driver);
		Thread.sleep(10000);
		timesheet.TimesheetTab();
		timesheet.AllTimesheetScreen();
		Thread.sleep(3000);
		timesheet.NewTimesheet();
		Thread.sleep(2000);
		timesheet.clkWorkersText();
		timesheet.txtworker(workername);
		System.out.println("Worker selected is: " +workername);
		Thread.sleep(2000);
		timesheet.selectWorker();
		Thread.sleep(2000);
		timesheet.clkProjectText();
		timesheet.txtproject(project);
		System.out.println("Project selected is: " +project);
		Thread.sleep(2000);
		timesheet.selectproject();
		Thread.sleep(2000);
		timesheet.clkTaskcodeText();
		if(timesheet.txttaskcodestring(taskcode).equals("T001"))
		{
		timesheet.setTaskcode1();
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T002"))
		{
		timesheet.setTaskcode2();
		}
		else if(timesheet.txttaskcodestring(taskcode).equals("T003"))
		{
		timesheet.setTaskcode3();
		}
		System.out.println("TaskCode selected is: " +taskcode);
		Thread.sleep(2000);
		/*
		WebElement drop=driver.findElement(By.xpath("//div[starts-with(@class, 'mat-select-arrow ng-tns-c')]"));
		Select dropdown=new Select(drop);
		System.out.println("No of Options is dropdown list is: " +dropdown.getOptions().size());
		List<WebElement> options=dropdown.getOptions();
		for(WebElement s:options)
		{
			System.out.println(s.getText());
		}
		dropdown.selectByVisibleText(payperiod);
		*/
		timesheet.clkPayperiodText();
		if(timesheet.txtpayperiodstring(payperiod).equals("11/01/2020"))
		{
			timesheet.setPayperiod1();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/08/2020"))
		{
			timesheet.setPayperiod2();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/15/2020"))
		{
			timesheet.setPayperiod3();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/22/2020"))
		{
			timesheet.setPayperiod4();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("11/29/2020"))
		{
			timesheet.setPayperiod5();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/06/2020"))
		{
			timesheet.setPayperiod6();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/13/2020"))
		{
			timesheet.setPayperiod7();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/20/2020"))
		{
			timesheet.setPayperiod8();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("12/27/2020"))
		{
			timesheet.setPayperiod9();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/03/2021"))
		{
			timesheet.setPayperiod10();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/10/2021"))
		{
			timesheet.setPayperiod11();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/17/2021"))
		{
			timesheet.setPayperiod12();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/24/2021"))
		{
			timesheet.setPayperiod13();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("01/31/2021"))
		{
			timesheet.setPayperiod14();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/07/2021"))
		{
			timesheet.setPayperiod15();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/14/2021"))
		{
			timesheet.setPayperiod16();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/21/2021"))
		{
			timesheet.setPayperiod17();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("02/28/2021"))
		{
			timesheet.setPayperiod18();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/07/2021"))
		{
			timesheet.setPayperiod19();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/14/2021"))
		{
			timesheet.setPayperiod20();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/21/2021"))
		{
			timesheet.setPayperiod21();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("03/28/2021"))
		{
			timesheet.setPayperiod22();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/04/2021"))
		{
			timesheet.setPayperiod23();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/11/2021"))
		{
			timesheet.setPayperiod24();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/18/2021"))
		{
			timesheet.setPayperiod25();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("04/25/2021"))
		{
			timesheet.setPayperiod26();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/02/2021"))
		{
			timesheet.setPayperiod27();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/09/2021"))
		{
			timesheet.setPayperiod28();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/16/2021"))
		{
			timesheet.setPayperiod29();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/23/2021"))
		{
			timesheet.setPayperiod30();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("05/30/2021"))
		{
			timesheet.setPayperiod31();
		}
		else if(timesheet.txtpayperiodstring(payperiod).equals("06/06/2021"))
		{
			timesheet.setPayperiod32();
		}
		System.out.println("PayPeriod selected is: " +payperiod);
		timesheet.btnSave();
		Thread.sleep(5000);
		/*
		//Scenario: 1
		//timesheet.FirstRowSelect();
		timesheet1.Edit();
		timesheet1.Regulartime();
		timesheet1.Doubletime();
		Thread.sleep(2000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.SecondRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		Thread.sleep(2000);
		timesheet1.Regulartimeagain();
		Thread.sleep(2000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ThirdRowSelect();
		timesheet1.Edit();
		Thread.sleep(2000);
		timesheet1.Overtime();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ForthRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		Thread.sleep(2000);
		timesheet1.Overtimeagain();
		timesheet1.Doubletimeagain();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		*/
		/*
		//Scenario 2:
		timesheet1.Edit();
		timesheet1.Regulartime();
		timesheet1.DoubletimeS2();
		timesheet1.shifid();
		timesheet1.setShiftid();
		Thread.sleep(2000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.SecondRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		timesheet1.ProjectID();
		Thread.sleep(1000);
		timesheet1.setProjectlist1();
		Thread.sleep(1000);
		timesheet1.TaskID();
		Thread.sleep(1000);
		timesheet1.setTasklist2();
		Thread.sleep(1000);
		timesheet1.RegulartimeagainS2();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ThirdRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		//timesheet1.ProjectID();
		//timesheet1.setProjectlist2();
		//timesheet1.TaskID();
		//timesheet1.setTasklist1();
		timesheet1.OvertimeS2();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ForthRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		Thread.sleep(1000);
		timesheet1.ProjectID();
		Thread.sleep(1000);
		timesheet1.setProjectlist1();
		Thread.sleep(1000);
		timesheet1.TaskID();
		Thread.sleep(1000);
		timesheet1.setTasklist1();
		Thread.sleep(1000);
		timesheet1.shifid();
		timesheet1.setShiftid2();
		timesheet1.OvertimeagainS2();
		timesheet1.DoubletimeagainS2();
		timesheet1.TripleTime();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		*/
		/*
		//Scenario 3:
		timesheet1.Edit();
		timesheet1.Regulartime3hr();
		timesheet1.shifid();
		timesheet1.setShiftid2();
		Thread.sleep(2000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.SecondRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		timesheet1.Regulartimesecondrow11hr();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ThirdRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		timesheet1.shifid();
		timesheet1.setShiftidthirdrow();
		timesheet1.RegulartimeagainS3();
		timesheet1.OvertimeS3();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.ForthRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		Thread.sleep(1000);
		timesheet1.shifid();
		timesheet1.setShiftidfourthrow();
		timesheet1.RegulartimeagainS4();
		timesheet1.OvertimeagainS3();
		timesheet1.DoubletimeagainS3();
		timesheet1.TripleTimeS3();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.FifthRowSelect();
		Thread.sleep(2000);
		timesheet1.Edit();
		timesheet1.Regulartimefifthrow();
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		*/
		/*
		timesheet1.Edit();
		driver.findElement(By.xpath("//input[@formcontrolname='regularHours']")).sendKeys("8");
		Thread.sleep(2000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		*/
		timesheet.setRow1();
		Thread.sleep(1000);
		timesheet.setRow1();
		timesheet.Edit();
		/*
		timesheet.seteditdate();
		Thread.sleep(1000);
		timesheet.cleareditdate();
		Thread.sleep(1000);
		timesheet.txteditdatestring(row1date);
		*/
		Thread.sleep(1000);
		timesheet.seteditprojectcode();
		Thread.sleep(1000);
		timesheet.clreditprojectcode();
		Thread.sleep(1000);
		timesheet.seteditprojectcode();
		Thread.sleep(1000);
		timesheet.txteditprojectcodestring(row1projectcode);
		Thread.sleep(1000);
		timesheet.listselect();
		Thread.sleep(1000);
		timesheet.setedittaskcode();
		Thread.sleep(1000);
		timesheet.clredittaskcode();
		Thread.sleep(1000);
		//timesheet.txtedittaskcodestring(row1taskcode);
		timesheet.setedittaskcode();
		Thread.sleep(1000);
		if(timesheet.txtedittaskcodestring(row1taskcode).equals("T001"))
		{
		timesheet.setTaskcode1();
		}
		else if(timesheet.txtedittaskcodestring(row1taskcode).equals("T002"))
		{
		timesheet.setTaskcode2();
		}
		else if(timesheet.txtedittaskcodestring(row1taskcode).equals("T003"))
		{
		timesheet.setTaskcode3();
		}
		Thread.sleep(1000);
		timesheet.seteditregularhours();
		Thread.sleep(1000);
		timesheet.txteditregularhoursstring(row1regularhours);
		Thread.sleep(1000);
		timesheet.seteditovertimehours();
		Thread.sleep(1000);
		timesheet.txteditovertimehoursstring(row1overtimehours);
		Thread.sleep(1000);
		timesheet.seteditdoubletimehours();
		Thread.sleep(1000);
		timesheet.txteditdoubletimehoursstring(row1doubletimehours);
		Thread.sleep(1000);
		timesheet.setedittripletimehours();
		Thread.sleep(1000);
		timesheet.txtedittripletimehoursstring(row1tripletimehours);
		Thread.sleep(1000);
		timesheet1.Update();
		Thread.sleep(7000);
		timesheet1.Process();
		Thread.sleep(2000);
		timesheet1.Threedots();
		Thread.sleep(2000);
		timesheet1.Viewcalculation();
		Thread.sleep(10000);
		
		int rowcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr")).size();
		//System.out.println("number of rows: " +rowcount);
		
		String numofrows=String.valueOf(rowcount);
		System.out.println("number of rows: " +numofrows);
		
		int cellcount=driver.findElements(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td")).size();
		System.out.println("number of rows: " +cellcount);
		
		//System.out.println("Date"+"   "+"Project ID"+"  ");
		/*
		for(int r=1;r<=rowcount;r++)
		{
			for(int c=1;c<=cellcount;c++)
			{
				String value=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td[6]")).getText();
				System.out.println(value+"      ");
			}
		}
		*/
		//System.out.println("TotalHours"+"           "+"Employeerate"+"            "+"UnionRate"+"           "+"PrivailingWageRate");
		for(int r=1;r<=rowcount;r++)
		{
			String totalhours=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[6]")).getText();
			//System.out.println(totalhours+"      ");
			int totalhoursfinalvalue=Integer.parseInt(totalhours);
			String eomployeerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[7]")).getText();
			//System.out.println(eomployeerate+"      ");
			double employeeratefinalvalue=Double.parseDouble(eomployeerate);
			String unionrate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[8]")).getText();
			//System.out.println(unionrate+"      ");
			double unionratefinalvalue=Double.parseDouble(unionrate);
			String privailingwagerate=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[9]")).getText();
			//System.out.println(privailingwagerate+"      ");
			double privailingwageratefinalvalue=Double.parseDouble(privailingwagerate);
			String calculatedcost=driver.findElement(By.xpath("//ejs-grid[@id='grid_2107871731_1']/div[3]/div[1]/table[1]/tbody[1]/tr["+r+"]/td[12]")).getText();
			//System.out.println(privailingwagerate+"      ");
			double calculatedcostfinalvalue=Double.parseDouble(calculatedcost);
			if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			
		}
		/*
		if(numofrows.equals("1"))
		{
		
			WebElement totalhours = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='5' and @aria-selected='true']"));
			String totalhoursfinal= totalhours.getText();
			int totalhoursfinalvalue=Integer.parseInt(totalhoursfinal);
			System.out.println("totalhoursfinal is: " +totalhoursfinalvalue);
			WebElement employeerate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='6' and @aria-selected='true']"));
			String employeeratefinal= employeerate.getText();
			double employeeratefinalvalue=Double.parseDouble(employeeratefinal);
			System.out.println("employeeratefinal is: " +employeeratefinalvalue);
			WebElement unionrate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='7' and @aria-selected='true']"));
			String unionratefinal= unionrate.getText();
			double unionratefinalvalue=Double.parseDouble(unionratefinal);
			System.out.println("unionratefinal is: " +unionratefinalvalue);
			WebElement privailingwagerate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='8' and @aria-selected='true']"));
			String privailingwageratefinal= privailingwagerate.getText();
			double privailingwageratefinalvalue=Double.parseDouble(privailingwageratefinal);
			System.out.println("privailingwageratefinal is: " +privailingwageratefinalvalue);
			WebElement calculatedcost = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='11' and @aria-selected='true']"));
			String calculatedcostfinal= calculatedcost.getText();
			double calculatedcostfinalvalue=Double.parseDouble(calculatedcostfinal);
			System.out.println("calculatedcostfinal is: " +calculatedcostfinalvalue);
			if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
		}
		if(numofrows.equals("4"))
		{
			WebElement totalhours = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='5' and @aria-selected='true']"));
			String totalhoursfinal= totalhours.getText();
			int totalhoursfinalvalue=Integer.parseInt(totalhoursfinal);
			System.out.println("totalhoursfinal is: " +totalhoursfinalvalue);
			WebElement employeerate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='6' and @aria-selected='true']"));
			String employeeratefinal= employeerate.getText();
			double employeeratefinalvalue=Double.parseDouble(employeeratefinal);
			System.out.println("employeeratefinal is: " +employeeratefinalvalue);
			WebElement unionrate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='7' and @aria-selected='true']"));
			String unionratefinal= unionrate.getText();
			double unionratefinalvalue=Double.parseDouble(unionratefinal);
			System.out.println("unionratefinal is: " +unionratefinalvalue);
			WebElement privailingwagerate = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='8' and @aria-selected='true']"));
			String privailingwageratefinal= privailingwagerate.getText();
			double privailingwageratefinalvalue=Double.parseDouble(privailingwageratefinal);
			System.out.println("privailingwageratefinal is: " +privailingwageratefinalvalue);
			WebElement calculatedcost = driver.findElement(By.xpath("//td[@role='gridcell' and @index='0' and @aria-colindex='11' and @aria-selected='true']"));
			String calculatedcostfinal= calculatedcost.getText();
			double calculatedcostfinalvalue=Double.parseDouble(calculatedcostfinal);
			System.out.println("calculatedcostfinal is: " +calculatedcostfinalvalue);
			if(employeeratefinalvalue>unionratefinalvalue && employeeratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * employeeratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(unionratefinalvalue>employeeratefinalvalue && unionratefinalvalue>privailingwageratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * unionratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(privailingwageratefinalvalue>employeeratefinalvalue && privailingwageratefinalvalue>unionratefinalvalue)
			{
				double Caluculatedcost =(totalhoursfinalvalue * privailingwageratefinalvalue);
				System.out.println("Calculated cost is: " +Caluculatedcost);
				if(Caluculatedcost==calculatedcostfinalvalue)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
		
			WebElement totalhours1 = driver.findElement(By.xpath("//td[@role='gridcell' and @index='1' and @aria-colindex='5']"));
			String totalhoursfinal1= totalhours1.getText();
			int totalhoursfinalvalue1=Integer.parseInt(totalhoursfinal1);
			System.out.println("totalhoursfinal is: " +totalhoursfinalvalue1);
			WebElement employeerate1 = driver.findElement(By.xpath("//td[@role='gridcell' and @index='1' and @aria-colindex='6']"));
			String employeeratefinal1= employeerate1.getText();
			double employeeratefinalvalue1=Double.parseDouble(employeeratefinal1);
			System.out.println("employeeratefinal is: " +employeeratefinalvalue1);
			WebElement unionrate1 = driver.findElement(By.xpath("//td[@role='gridcell' and @index='1' and @aria-colindex='7']"));
			String unionratefinal1= unionrate1.getText();
			double unionratefinalvalue1=Double.parseDouble(unionratefinal1);
			System.out.println("unionratefinal is: " +unionratefinalvalue1);
			WebElement privailingwagerate1 = driver.findElement(By.xpath("//td[@role='gridcell' and @index='1' and @aria-colindex='8']"));
			String privailingwageratefinal1= privailingwagerate1.getText();
			double privailingwageratefinalvalue1=Double.parseDouble(privailingwageratefinal1);
			System.out.println("privailingwageratefinal is: " +privailingwageratefinalvalue1);
			WebElement calculatedcost1 = driver.findElement(By.xpath("//td[@role='gridcell' and @index='1' and @aria-colindex='11']"));
			String calculatedcostfinal1= calculatedcost1.getText();
			double calculatedcostfinalvalue1=Double.parseDouble(calculatedcostfinal1);
			System.out.println("calculatedcostfinal is: " +calculatedcostfinalvalue1);
			if(employeeratefinalvalue1>unionratefinalvalue1 && employeeratefinalvalue1>privailingwageratefinalvalue1)
			{
				float Caluculatedcost1 =(float) (totalhoursfinalvalue1 * employeeratefinalvalue1);
				System.out.println("Calculated cost is: " +Caluculatedcost1);
				if(Caluculatedcost1==calculatedcostfinalvalue1)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(unionratefinalvalue1>employeeratefinalvalue1 && unionratefinalvalue1>privailingwageratefinalvalue1)
			{
				float Caluculatedcost1 =(float) (totalhoursfinalvalue1 * unionratefinalvalue1);
				System.out.println("Calculated cost is: " +Caluculatedcost1);
				if(Caluculatedcost1==calculatedcostfinalvalue1)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
			else if(privailingwageratefinalvalue1>employeeratefinalvalue1 && privailingwageratefinalvalue1>unionratefinalvalue1)
			{
				float Caluculatedcost1 =(float) (totalhoursfinalvalue1 * privailingwageratefinalvalue1);
				System.out.println("Calculated cost is: " +Caluculatedcost1);
				if(Caluculatedcost1==calculatedcostfinalvalue1)
				{
					System.out.println("Calculated cost calculated as expected");
				}
			}
		}
		*/
	}

}

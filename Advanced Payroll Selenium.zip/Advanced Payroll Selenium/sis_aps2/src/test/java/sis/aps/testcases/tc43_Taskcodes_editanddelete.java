package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_TaskCodes_pom;

public class tc43_Taskcodes_editanddelete extends baseclass {

	@Test
	public void TaskCodes_Create() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Task code then edit and delete */
		operations_TaskCodes_pom taskCodes = new operations_TaskCodes_pom(driver);

		taskCodes.clickOperationsTab();
		Thread.sleep(2000);
		taskCodes.clickTaskCodesTab();
		logger.info("User navigated to All Task Codes Page");
		Thread.sleep(2000);
		taskCodes.clickNewTaskCodeButton();
		taskCodes.SetTaskId(taskId);
		taskCodes.SetTasktName(taskName);
		taskCodes.ClickEarningCode();
		Thread.sleep(2000);
		taskCodes.ClickIndex1Val();
		taskCodes.clickSaveButton();
		Thread.sleep(2000);

		if (taskCodes.isAllTaskCodesHdHeaderDisplayed().equals("All task codes")) {
			Assert.assertTrue(true);
			logger.info("Task Code has been created");
		} else {
			Assert.fail();
		}

		taskCodes.searchTaskcodes();
		Thread.sleep(2000);
		taskCodes.ClickEditIcon();
		Thread.sleep(2000);
		taskCodes.editTaskId();
		taskCodes.editTaskName();
		taskCodes.clickSaveButton();
		Thread.sleep(2000);

		if (taskCodes.isAllTaskCodesHdHeaderDisplayed().equals("All task codes")) {
			Assert.assertTrue(true);
			logger.info("Task Code has been Updated");
		} else {
			Assert.fail();
		}

		taskCodes.searchTaskcodes();
		Thread.sleep(2000);
		taskCodes.clickDeleteIcon();
		Thread.sleep(2000);
		taskCodes.clickDeleteButton();
		Thread.sleep(2000);

		if (taskCodes.isAllTaskCodesHdHeaderDisplayed().equals("All task codes")) {
			Assert.assertTrue(true);
			logger.info("Task Code has been Deleted");
		} else {
			Assert.fail();
		}

	}
}

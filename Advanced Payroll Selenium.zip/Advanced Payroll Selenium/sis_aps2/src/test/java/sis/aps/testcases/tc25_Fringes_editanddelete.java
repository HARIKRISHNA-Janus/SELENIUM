package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_Fringes_pom;

public class tc25_Fringes_editanddelete extends baseclass {

	@Test
	public void Fringes_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(3000);

		/* Create a Fringe then edit and delete */
		unions_Fringes_pom fringes = new unions_Fringes_pom(driver);
		fringes.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		fringes.clickFringesTab();
		logger.info("User clicked Fringes Leftsliding Sunmenu");
		fringes.clickNewFringeButton();
		logger.info("User clicked new Fringe button");
		fringes.SetFringeId(fringeId);
		logger.info("User entered the fringe Id");
		fringes.SetFringeName(fringeName);
		logger.info("User entered the fringe Name");
		fringes.ClickCalcMethodDropdown();
		logger.info("User clicked calculation method drop-down field");
		Thread.sleep(2000);
		fringes.ClickIndex1Val();
		logger.info("User clicked index 1 value");
		fringes.ClickClassificationDropdown();
		logger.info("User clicked classification drop-down field");
		Thread.sleep(2000);
		fringes.ClickIndex1Val();
		logger.info("User clicked index 1 value");
		Thread.sleep(2000);
		fringes.ClickDeductionCodeDropdown();
		logger.info("User clicked deduction code drop-down field");
		fringes.ClickIndex1Val();
		logger.info("User clicked index 1 value");
		Thread.sleep(3000);
		fringes.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (fringes.isFringesEarningCodeDisplayed().equals("Fringe earning code")) {
			Assert.assertTrue(true);
			logger.info("User verified Fringe earning code Tab is dispalyed");
		} else {
			System.out.println("Fringe earning code Tab is not Displayed");
			logger.info("Fringe earning code Tab is not dispalyed");
		}

		/* Delete Fringe Earning Code */

		fringes.clickGridDeleteButton();
		Thread.sleep(2000);
		fringes.clickPopupDeleteButton();
		Thread.sleep(2000);

		/* Create Fringe Earning Code */

		Thread.sleep(2000);
		fringes.clickAddButton();
		Thread.sleep(2000);
		fringes.clickEarningCodeNAme();
		Thread.sleep(2000);
		fringes.ClickIndex1Val();
		Thread.sleep(2000);
		fringes.clickUpdateButton();
		Thread.sleep(2000);

		if (fringes.IsFringeEarningCodeCreated().equals("Fringe earning code has been created successfully")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been added");
		} else {
			logger.info("Earning code has not been added");
			Assert.fail();
		}

		/* Update Fringe Earning code */

		Thread.sleep(2000);
		fringes.clickEditButton();
		Thread.sleep(2000);
		fringes.clickEarningCodeNAme();
		Thread.sleep(2000);
		fringes.ClickIndex2Val();
		Thread.sleep(2000);
		fringes.clickUpdateButton();
		Thread.sleep(2000);

		if (fringes.IsFringeEarningCodeUpdated().equals("Fringe earning code has been updated successfully")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been updated");
		} else {
			logger.info("Earning code has not been updated");
			Assert.fail();
		}

		/* Delete Fringe Earning Code */

		fringes.clickGridDeleteButton();
		Thread.sleep(2000);
		fringes.clickPopupDeleteButton();
		Thread.sleep(2000);
		fringes.clickGridDeleteButton();
		Thread.sleep(2000);
		fringes.clickPopupDeleteButton();
		Thread.sleep(2000);
		fringes.clickGridDeleteButton();
		Thread.sleep(2000);
		fringes.clickPopupDeleteButton();
		Thread.sleep(2000);
		fringes.clickGridDeleteButton();
		Thread.sleep(2000);
		fringes.clickPopupDeleteButton();
		Thread.sleep(2000);

		if (fringes.IsFringeEarningCodeDeleted().equals("Fringe earning code has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been deleted");
		} else {
			logger.info("Earning code has not been deleted");
			Assert.fail();
		}

		fringes.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (fringes.isAllFringesHeaderDisplayed().equals("All fringes")) {
			Assert.assertTrue(true);
			logger.info("User verified All fringes page Header");
			System.out.println("Fringes has been created successfully !");
		} else {
			Assert.fail("Fringes Header is not disaplayed");
			logger.info("All fringes Page Header is not dispalyed");
		}

		fringes.searchFringe();
		logger.info("User entered the fringe Id/Name in search input field");
		fringes.ClickEditIcon();
		logger.info("user clicked the edit icon");
		fringes.editFringeId();
		logger.info("user edited fringe Id");
		fringes.editFringeName();
		logger.info("user edited fringe Name");
		fringes.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(2000);
		fringes.clickBackButton();
		logger.info("User clicked back button");

		if (fringes.isAllFringesHeaderDisplayed().equals("All fringes")) {
			Assert.assertTrue(true);
			logger.info("User verified All fringes page Header");
			System.out.println("Fringes has been Updated successfully !");
		} else {
			Assert.fail("All Fringes Header is not disaplayed");
			logger.info("All fringes Page Header is not dispalyed");
		}

		Thread.sleep(3000);
		fringes.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		fringes.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (fringes.isAllFringesHeaderDisplayed().equals("All fringes")) {
			Assert.assertTrue(true);
			logger.info("User verified All fringes page Header");
			System.out.println("Fringes has been Deleted successfully !");
		} else {
			Assert.fail("All Fringes Header is not disaplayed");
			logger.info("All fringes Page Header is not dispalyed");
		}

	}
}

package sis.aps.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.employees_jobs_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc10_syncwithadpedit_jobs extends baseclass {
	
	@Test
	public void masterdata_jobs_syncwithadpedit() throws InterruptedException
	{	
		
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		logger.info("User logged in Successfully");
		
		employees_jobs_pom sync=new employees_jobs_pom(driver);
		Thread.sleep(3000);
		sync.EmployeesTab();
		logger.info("User clicked on Employees Tab");
		sync.JobsScreen();
		logger.info("User navigated to Workers Screen");
		logger.info("SYNC WITH ADP is Enabled:" +sync.chkSyncWithADP());
		sync.clkSyncWithADP();
		Thread.sleep(55000);
		String timestamp=new SimpleDateFormat("M/dd/yy, h:mm a").format(new Date());
		String Systemtime= "System Last Sync: " +timestamp;
		System.out.println(Systemtime);
		System.out.println("App " +sync.chkAppDateDisplay());
		logger.info("SYNC WITH ADP is Enabled Back:" +sync.chkSyncADPEnabledBack());
		logger.info("Circle Stared is Enabled:" +sync.chkCircleEnabled());
		if(sync.chkRowDisplay().equals(" Showing rows 1 to 10 of 50"))
		{
			Assert.assertTrue(true);
			logger.info("Row Count Equals");
		}
		else
		{
			Assert.fail();
			logger.info("Row Count is not Equal");
		}
		logger.info("Edit is Enabled:" +sync.chkEditEnabled());
		sync.clkEdit();
		Thread.sleep(3000);
		logger.info("Cancel button is Displayed:" +sync.chkCancelDisplay());
		logger.info("Save button is Enabled:" +sync.chkSaveEnabled());
		sync.clkCancel();
		Thread.sleep(3000);
		logger.info("Circle Stared is Enabled Back:" +sync.chkCircleEnabledBack());
	}
}

package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class certifiedPayroll_PrevallingWages_pom {

	public WebDriver ldriver;

	public certifiedPayroll_PrevallingWages_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Certified payroll'])[1]")
	WebElement clkCertifiedPayrollTab;

	public void clickCertifiedPayrollTab() {
		clkCertifiedPayrollTab.click();
	}

	@FindBy(xpath = "//span[text()='Prevailing wages']")
	WebElement clkPrevailingWagesTab;

	public void clickPrevailingWagesTab() {
		clkPrevailingWagesTab.click();
	}

	@FindBy(xpath = "//button[text()='New prevailing wage']")
	WebElement clkNewprevailingwageButton;

	public void clickNewprevailingwageButton() {
		clkNewprevailingwageButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Prevailing wage id']")
	WebElement InputPrevailingwageId;

	public void SetPrevailingwageId(String PrevailingwageId) {
		InputPrevailingwageId.click();
		InputPrevailingwageId.sendKeys(PrevailingwageId + randomInt);
	}

	public void editPrevailingwageId() {
		InputPrevailingwageId.clear();
		InputPrevailingwageId.sendKeys("AA_PWID");
	}

	@FindBy(xpath = "//input[@data-placeholder='Prevailing wage name']")
	WebElement InputPrevailingwageName;

	public void SetPrevailingwageName(String PrevailingwageName) {
		InputPrevailingwageName.click();
		InputPrevailingwageName.sendKeys(PrevailingwageName + randomInt);
	}

	public void editPrevailingwageName() {
		InputPrevailingwageName.clear();
		InputPrevailingwageName.sendKeys("AA_CN");
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//span[text()='Prevailing wage has been updated']")
	WebElement PrevailingWagestUpdateMsg;

	public String IsPrevailingWagesUpdated() {
		return PrevailingWagestUpdateMsg.getText();
	}

	@FindBy(xpath = "//h3[text()='All prevailing wages']")
	WebElement AllprevailingwagesHd;

	public String isAllprevailingwagesHeaderDisplayed() {
		return AllprevailingwagesHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in prevailing wage id or name']")
	WebElement txtsearch;

	public void search() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-prevailing-wage-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}
	
	@FindBy(xpath = "//a[contains(text(),'Prevailing wage job')]")
	WebElement PrevailingWageJobTab;

	public String isPrevailingWageJobTabDisplayed() {
		return PrevailingWageJobTab.getText();
	}

	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement BtnAdd;

	public void clickAddButton() {
		BtnAdd.click();
	}

	@FindBy(xpath = "//input[@id='job___name']")
	WebElement clickJobNameField;

	public void clickJobNameField() {
		clickJobNameField.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[2]")
	WebElement clkIndex2Value;

	public void ClickIndex2Val() {
		clkIndex2Value.click();
	}

	@FindBy(xpath = "//button[@aria-label='Open calendar']")
	WebElement btnDatePicker;

	public void clickDatepickerButton() {
		btnDatePicker.click();
	}

	@FindBy(xpath = "//tbody[@class='mat-calendar-body']//div[contains(@class,'today')]")
	WebElement currentDate;

	public void clickCurrentDate() {
		currentDate.click();
	}

	@FindBy(xpath = "//input[@id='wageRate']")
	WebElement InputWageRate;

	public void SetWageRate(String WageRate) {
		InputWageRate.click();
		InputWageRate.sendKeys(WageRate);
	}

	@FindBy(xpath = "//input[@id='fringeRate']")
	WebElement InputFringeRate;

	public void SetFringeRate(String FringeRate) {
		InputFringeRate.click();
		InputFringeRate.sendKeys(FringeRate);
	}

	@FindBy(xpath = "//button[@aria-label='Update']")
	WebElement BtnUpdate;

	public void clickUpdateButton() {
		BtnUpdate.click();
	}

	@FindBy(xpath = "//span[contains(text(),'Prevailing wage job has been  created successfully')]")
	WebElement PrevailingWageJobCreateMsg;

	public String isPrevailingWageJobCreated() {
		return PrevailingWageJobCreateMsg.getText();
	}

	@FindBy(xpath = "//span[contains(text(),'Prevailing wage job has been  updated successfully')]")
	WebElement PrevailingWageJobUpdateMsg;

	public String isPrevailingWageJobUpdated() {
		return PrevailingWageJobUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[contains(text(),'Prevailing wage job has been deleted')]")
	WebElement PrevailingWageJobDeleteMsg;

	public String isPrevailingWageJobDeleted() {
		return PrevailingWageJobDeleteMsg.getText();
	}

	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement BtnDeletePWJ;

	public void clickDeleteBTN_PWJ() {
		BtnDeletePWJ.click();
	}

	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickDeleteBtnPopup() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", BtnDeletePopup);
		// BtnDeletePopup.click();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

}

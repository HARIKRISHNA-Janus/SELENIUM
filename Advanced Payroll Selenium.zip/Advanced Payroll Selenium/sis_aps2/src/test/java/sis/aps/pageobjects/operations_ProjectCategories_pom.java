package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class operations_ProjectCategories_pom {

	public WebDriver ldriver;

	public operations_ProjectCategories_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	WebElement clkoperationsTab;

	public void clickOperationsTab() {
		clkoperationsTab.click();
	}

	@FindBy(xpath = "//span[text()='Project categories']")
	WebElement clkProjectCategoriesTab;

	public void clickProjectCategoriesTab() {
		clkProjectCategoriesTab.click();
	}

	@FindBy(xpath = "//button[text()='New project category']")
	WebElement clkNewProjectCategoryButton;

	public void clickNewProjectCategoryButton() {
		clkNewProjectCategoryButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Project category id']")
	WebElement InputProjectCategoryId;

	public void SetProjectCategoryId(String ProjectCategoryId) {
		InputProjectCategoryId.click();
		InputProjectCategoryId.sendKeys(ProjectCategoryId + randomInt);
	}

	public void editProjectCategoryId() {
		InputProjectCategoryId.clear();
		InputProjectCategoryId.sendKeys("AA_PCI");
	}

	@FindBy(xpath = "//input[@data-placeholder='Project category name']")
	WebElement InputProjectCategoryName;

	public void SetProjectCategoryName(String ProjectCategoryName) {
		InputProjectCategoryName.click();
		InputProjectCategoryName.sendKeys(ProjectCategoryName + randomInt);
	}

	public void editProjectCategoryName() {
		InputProjectCategoryName.clear();
		InputProjectCategoryName.sendKeys("AA_PCN");
	}

	@FindBy(xpath = "//mat-select[@placeholder='Transaction type']")
	WebElement DropdownTranscationType;

	public void ClickTransctionTypeDropdown() {
		DropdownTranscationType.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//span[text()='Project category has been updated']")
	WebElement ProjectCategoryUpdateMsg;

	public String IsProjectCategoryUpdated() {
		return ProjectCategoryUpdateMsg.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//app-project-category-list//h3[text()='All project categories']")
	WebElement AllProjectcategoriesHd;

	public String isProjectCategoryHeaderDisplayed() {
		return AllProjectcategoriesHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in project category id or name']")
	WebElement txtsearch;

	public void searchProjectCategory() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-project-category-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

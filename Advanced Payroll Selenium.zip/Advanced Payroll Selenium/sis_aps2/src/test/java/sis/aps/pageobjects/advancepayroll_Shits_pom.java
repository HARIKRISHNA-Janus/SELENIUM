package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class advancepayroll_Shits_pom {

	public WebDriver ldriver;

	public advancepayroll_Shits_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Advance payroll'])")
	WebElement clkAdvancepayrollTab;

	public void clickAdvancepayrollTab() {
		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkAdvancepayrollTab);
	}
	@FindBy(xpath = "//span[text()='Shifts']")
	WebElement clkShiftsTab;

	public void clickShiftTab() {
		clkShiftsTab.click();
	}
	@FindBy(xpath="//td[2][contains(text(),'First shift')]//following::td[2]") WebElement sltdayrate;
	public String getdayrate()
	{
		return sltdayrate.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Fixed shift')]//following::td[2]") WebElement sltfixedrate;
	public String getfixedrate()
	{
		return sltfixedrate.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Mid-Day')]//following::td[2]") WebElement sltmidrate;
	public String getmidrate()
	{
		return sltmidrate.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Night')]//following::td[2]") WebElement sltnightpercent;
	public String getnightpercentage()
	{
		return sltnightpercent.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Split')]//following::td[2]") WebElement sltsplitpercente;
	public String getsplitpercentage()
	{
		return sltsplitpercente.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Swing')]//following::td[2]") WebElement sltswingrate;
	public String getswingrate()
	{
		return sltswingrate.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Automation Shift 1')]//following::td[2]") WebElement sltAutomationShift1;
	public String getautomationshift1()
	{
		return sltAutomationShift1.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Automation Shift 2')]//following::td[2]") WebElement sltAutomationShift2;
	public String getautomationshift2()
	{
		return sltAutomationShift2.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Automation Shift 3')]//following::td[2]") WebElement sltAutomationShift3;
	public String getautomationshift3()
	{
		return sltAutomationShift3.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Automation Shift 4')]//following::td[2]") WebElement sltAutomationShift4;
	public String getautomationshift4()
	{
		return sltAutomationShift4.getText();
	}
	@FindBy(xpath="//td[2][contains(text(),'Automation Shift 5')]//following::td[2]") WebElement sltAutomationShift5;
	public String getautomationshift5()
	{
		return sltAutomationShift5.getText();
	}
	@FindBy(xpath="//span[@class='react-bootstrap-table-pagin ation-total']//preceding::select[1]") WebElement sltdroplist;
	public void clkdroplist()
	{
		sltdroplist.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-shift-list/div/div[2]/app-paginator/div[2]/select/option[6]") WebElement sltdroplist100;
	public void clkdroplist100()
	{
		sltdroplist100.click();
	}
	@FindBy(xpath = "//button[text()='New shift']")
	WebElement clkNewShiftButton;

	public void clickNewShiftButton() {
		clkNewShiftButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Shift id\"]")
	WebElement txtShiftId;

	public void SetShiftId(String shiftId) {
		txtShiftId.sendKeys(shiftId + randomInt);
	}

	public void editShiftId() {
		txtShiftId.clear();
		txtShiftId.sendKeys("AASI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Shift name\"]")
	WebElement txtShiftName;

	public void SetShiftName(String shiftName) {
		txtShiftName.sendKeys(shiftName + randomInt);
	}

	public void editShiftName() {
		txtShiftName.clear();
		txtShiftName.sendKeys("AASN" + randomInt);
	}

	@FindBy(xpath = "(//mat-select[@formcontrolname=\"shiftCalcMethod\"]//div[contains(@class,'select-arrow')])[1]")
	WebElement clkCalMethodDropdownArrow;

	public void ClickCalMethodDropdown() {
		clkCalMethodDropdownArrow.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1ValCalMethodDropdown() {
		clkIndex1Value.click();
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Rate\"]")
	WebElement txtRate;

	public void SetRate(String Rate) {
		txtRate.sendKeys(Rate);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder=\"Search in shift id or name\"]")
	WebElement txtsearch;

	public void searchShift() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-shift-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

	@FindBy(xpath = "//app-shift-list//h3[text()='All shifts']")
	WebElement verifyAllShiftsHd;

	public String isShiftsHeaderDisplayed() {
		return verifyAllShiftsHd.getText();
	}
	
	//below webelements created by Sureshkumar
	@FindBy(xpath="//span[contains(text(),'Operations management')]") WebElement clkoperationsmgmttab;
	public void clickoperationsmgmttab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperationsmgmttab);
		//clkoperationsmgmttab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Operations setup')]") WebElement clkoperationssetuptab;
	public void clickoperationssetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkoperationssetuptab);
		//clkoperationssetuptab.click();
	}
	
}

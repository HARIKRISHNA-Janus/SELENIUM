package sis.aps.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import sis.aps.pageobjects.employees_positions_pom;
import sis.aps.pageobjects.loginpage_pom;

public class dashboard extends baseclass {
	
	@Test
	public void dashboard1() throws Exception
	{
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the Password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User Clicked on Signin button");
		Thread.sleep(10000);
		logger.info("Logged in Successfull");
		/*
		pay_earningcodes_pom earningcode=new pay_earningcodes_pom(driver);
		earningcode.payTab();
		logger.info("Navigated to Pay tab");
		earningcode.earningcodesscreen();
		logger.info("Navigated to Earning codes screen");
		earningcode.searchtxtbox();
		earningcode.searchregular();
		Thread.sleep(1000);
		earningcode.selectedit();
		String RegularAmtRate=earningcode.selectamtratevalue();
		logger.info("Regular Amt Rate is: " +RegularAmtRate);
		Thread.sleep(300);
		earningcode.selectcancel();
		Thread.sleep(500);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchrovertime();
		Thread.sleep(1000);
		earningcode.selectsecondedit();
		String OvertimeAmtRate=earningcode.selectamtratevalue();
		logger.info("Overtime Amt Rate is: " +OvertimeAmtRate);
		Thread.sleep(300);
		earningcode.selectcancel();
		Thread.sleep(500);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchdot();
		Thread.sleep(1000);
		earningcode.selectedit();
		String DoubletimeAmtRate=earningcode.selectamtratevalue();
		logger.info("Doubleovertime Amt Rate is: " +DoubletimeAmtRate);
		Thread.sleep(300);
		earningcode.selectcancel();
		Thread.sleep(500);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		earningcode.searchtripleovertime();
		Thread.sleep(1000);
		earningcode.selectedit();
		String TripletimeAmtRate=earningcode.selectamtratevalue();
		logger.info("Tripleovertime Amt Rate is: " +TripletimeAmtRate);
		Thread.sleep(300);
		earningcode.selectcancel();
		Thread.sleep(500);
		earningcode.searchtxtbox();
		earningcode.selectclose();
		*/
		//Employee>Positions
		employees_positions_pom positions=new employees_positions_pom(driver);
		positions.EmployeesTab();
		positions.clkpositionsscreen();
		positions.clksearchtextbox();
		positions.txtworkersearchstring("miller");
		Thread.sleep(3000);
		int positionscount=driver.findElements(By.xpath("//*[@id=\"kt_content\"]/div/div/app-position/app-position-list/div/div[2]/div/table/tbody/tr")).size();
		logger.info("Positions Count is: " +positionscount);
		driver.findElement(By.xpath("//*[@id=\"kt_content\"]/div/div/app-position/app-position-list/div/div[2]/div/table/tbody/tr["+positionscount+"]/td[7]")).click();
        /*
		positions.clkEdit();
		*/
		String hourlyrateamttxt=positions.getHorlyrateamt();
		int hourlyrateamtlen=hourlyrateamttxt.length();
		String hourlyrateamtfinalstring=hourlyrateamttxt.substring(1,hourlyrateamtlen);
		double hourlyrateamt=Double.parseDouble(hourlyrateamtfinalstring);
		logger.info("Hourly Amt Rate is: " +hourlyrateamt);
		Thread.sleep(500);
		positions.clkCancel();
}
}
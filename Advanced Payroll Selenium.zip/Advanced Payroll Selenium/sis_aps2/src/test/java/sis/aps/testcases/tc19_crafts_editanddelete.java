package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_crafts_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc19_crafts_editanddelete extends baseclass {

	@Test
	public void Crafts_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(10000);

		/* Create a Craft,Edit and Delete */
		advancepayroll_crafts_pom advancepayrollCFT = new advancepayroll_crafts_pom(driver);
		advancepayrollCFT.clickAdvancepayrollTab();
		logger.info("User clicked AdvancePayroll Leftsliding Menu");
		advancepayrollCFT.clickCraftTab();
		logger.info("User clicked craft Leftsliding Sunmenu");
		advancepayrollCFT.clickNewCraftButton();
		logger.info("User clicked new craft button");
		advancepayrollCFT.SetCraftId(craftId);
		logger.info("User entered the craft Id");
		advancepayrollCFT.SetCraftName(craftName);
		logger.info("User entered the craft Name");
		advancepayrollCFT.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);
		
		if (advancepayrollCFT.isCraftsHeaderDisplayed().equals("All crafts")) {
			Assert.assertTrue(true);
			logger.info("User verified All Crafts page Header");
		} else {
			Assert.fail("All Crafts Header is not disaplayed");
			logger.info("All craft Page Header is not dispalyed");
		}

		advancepayrollCFT.searchcraft();
		logger.info("User entered the craft Id/Name in search input field");
		advancepayrollCFT.ClickEditIcon();
		logger.info("User clicked edit icon");
		advancepayrollCFT.editCraftId();
		logger.info("User edited craft Id");
		advancepayrollCFT.editCraftName();
		logger.info("User edited craft Name");
		advancepayrollCFT.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);
		
		if (advancepayrollCFT.isCraftsHeaderDisplayed().equals("All crafts")) {
			Assert.assertTrue(true);
			System.out.println("Craft has been Updated !");
		} else {
			Assert.fail("All Crafts Header is not disaplayed");
		}

		Thread.sleep(3000);
		advancepayrollCFT.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		advancepayrollCFT.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);
		
		if (advancepayrollCFT.isCraftsHeaderDisplayed().equals("All crafts")) {
			Assert.assertTrue(true);
			logger.info("User verified All Crafts page Header");
			System.out.println("Craft has been created Deleted !");
		} else {
			Assert.fail("All Crafts Header is not disaplayed");
			logger.info("All crafts Page Header is not dispalyed");
		}
		
	}
}

package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginpage_pom {
	
	public WebDriver ldriver;
	//JavascriptExecutor js=(JavascriptExecutor) ldriver;
	
	public loginpage_pom(WebDriver rdriver) //constructor concept
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//@FindBy(xpath="//input[@id='logonIdentifier']") WebElement txtUserName;
	@FindBy(xpath="//input[@id='email']") WebElement txtUserName;
	public void setUserName(String uname)
	{
		txtUserName.sendKeys(uname);
	}
	@FindBy(xpath="//input[@id='password']") WebElement txtPassword;
	public void setPasword(String pwd)
	{
		txtPassword.sendKeys(pwd);
	}
	@FindBy(xpath="//button[@id='next']") WebElement clkSubmit;
	public void clkSignin()
	{
		//js.executeScript("arguments[0].click()",clkSubmit);
		clkSubmit.click();
	}
	@FindBy(xpath="//span[@class='symbol symbol-lg-35 symbol-25 symbol-light-success']") WebElement clkLogouticon;
	public void clkicon()
	{		
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkLogouticon);
		//clkLogouticon.click();
	}
	@FindBy(xpath="//a[@class='btn btn-sm btn-light-primary font-weight-bolder py-2 px-5 cursor-pointer']") WebElement clkSignout;
	public void clkSignout()
	{
		//js.executeScript("arguments[0].click()", clkSignout);
		clkSignout.click();
	}
	/* DashBoard */

	@FindBy(xpath = "//a[@class='brand-logo']")
	WebElement Logo;

	public void clkLogo() {
		Logo.click();
	}
}

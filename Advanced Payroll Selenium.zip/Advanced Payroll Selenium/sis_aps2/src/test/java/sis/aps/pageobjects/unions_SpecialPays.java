package sis.aps.pageobjects;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class unions_SpecialPays {

	public WebDriver ldriver;

	public unions_SpecialPays(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Unions'])[1]")
	WebElement clkUnionsTab;

	public void clickUnionsTab() {
		clkUnionsTab.click();
	}

	@FindBy(xpath = "(//a//span[text()='Special pays'])[1]")
	WebElement SpecialPaysTab;

	public void clickSpecialPaysTab() {
		SpecialPaysTab.click();
	}

	@FindBy(xpath = "//button[text()='New special pay']")
	WebElement NewSpecialPayButton;

	public void clickNewSpecialPayButton() {
		NewSpecialPayButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Special pay id']")
	WebElement txtSpecialPayId;

	public void SetSpecialPayId(String SpecialPayId) {
		txtSpecialPayId.sendKeys(SpecialPayId + randomInt);
	}

	public void editSpecialPayIdId() {
		txtSpecialPayId.clear();
		txtSpecialPayId.sendKeys("AASPI" + randomInt);
	}

	@FindBy(xpath = "//input[@data-placeholder='Special pay name']")
	WebElement txtSpecialPayName;

	public void SetSpecialPayName(String SpecialPayName) {
		txtSpecialPayName.sendKeys(SpecialPayName + randomInt);
	}

	public void editSpecialPayName() {
		txtSpecialPayName.clear();
		txtSpecialPayName.sendKeys("AASPN" + randomInt);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//span[text()='Special pay has been updated']")
	WebElement SpayUpdateMsg;

	public String IsSpayUpdated() {
		return SpayUpdateMsg.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//mat-select[@placeholder='Calculation method']")
	WebElement dropdownCalMethod;

	public void ClickCalcMethodDropdown() {
		dropdownCalMethod.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][1]")
	WebElement Index1Val;

	public void ClickIndex1Val() {
		Index1Val.click();
	}

	@FindBy(xpath = "//div[@role='listbox']//mat-option[@tabindex='0'][2]")
	WebElement Index2Val;

	public void ClickIndex2Val() {
		Index2Val.click();
	}

	@FindBy(xpath = "//app-special-pay-edit//a[contains(text(),'Special pay earning code')]")
	WebElement S_EarningCodeTab;

	public String isSpecialPayEarningCodeDisplayed() {
		return S_EarningCodeTab.getText();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

	@FindBy(xpath = "//button//span[text()='Add']")
	WebElement btnAdd;

	public void clickAddButton() {
		btnAdd.click();
	}

	@FindBy(xpath = "//input[@name='earningCode___name']")
	WebElement ecNameField;

	public void clickEarningCodeField() {
		ecNameField.click();
	}

	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement BtnDeleteUJ;

	public void clickDeleteBTN_UJ() {
		BtnDeleteUJ.click();
	}

	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickDeleteBtnPopup() {
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", BtnDeletePopup);
		// BtnDeletePopup.click();
	}

	@FindBy(xpath = "//table//tr//td[@tabindex='0']")
	WebElement tableRow1;

	public boolean isRow1Displayed() {
		return tableRow1.isDisplayed();
	}

	@FindBy(xpath = "//span[text()='Special pay earning code has been created successfully']")
	WebElement UnionSpecialPayEarningCodeCreatedMsg;

	public String IsUnionSpecialPayEarningCodeCreated() {
		return UnionSpecialPayEarningCodeCreatedMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Special pay earning code has been updated successfully']")
	WebElement UnionSpecialPayEarningCodeUpdateMsg;

	public String IsUnionSpecialPayEarningCodeUpdated() {
		return UnionSpecialPayEarningCodeUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Special pay earning code has been deleted']")
	WebElement UnionSpecialPayEarningCodeDeleteMsg;

	public String IsUnionSpecialPayEarningCodeDeleted() {
		return UnionSpecialPayEarningCodeDeleteMsg.getText();
	}

	@FindBy(xpath = "//button//span[text()='Update']")
	WebElement btnUpdate;

	public void clickUpdateButton() {
		btnUpdate.click();
	}

	@FindBy(xpath = "//app-special-pay-list//h3[text()='All special pays']")
	WebElement AllSpecialPaysHd;

	public String isAllSpecialPaysHeaderDisplayed() {
		return AllSpecialPaysHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in special pay id or name']")
	WebElement txtsearch;

	public void searchSpecialPay() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-special-pay-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class pay_earningcodes_pom {
	
	public WebDriver ldriver;

	public pay_earningcodes_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//below webelements created by sureshkumar 
	@FindBy(xpath="//a[@class='menu-link menu-toggle']//span[@class='menu-text'][normalize-space()='Pay']") WebElement clkPaytab;
	public void payTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkPaytab);
		//clkTimesheet.click();
	}
	@FindBy(xpath="//span[normalize-space()='Earning codes']") WebElement clkEarningcodes;
	public void earningcodesscreen()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEarningcodes);
		//clkTimesheet.click();
	}
	@FindBy(xpath="//input[@data-placeholder='Search in earning code id or name']") WebElement txtSearchbox;
	public void searchtxtbox()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtSearchbox);
		//txtSearchbox.click();
	}
	@FindBy(xpath="//input[@data-placeholder='Search in earning code id or name']") WebElement txtSearchforregular;
	public void searchregular()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtSearchforregular);
		//txtSearchforregular.click();
		txtSearchforregular.sendKeys("Regular");
	}
	@FindBy(xpath="//input[@data-placeholder='Search in earning code id or name']") WebElement txtSearchforovertime;
	public void searchrovertime()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtSearchforovertime);
		//txtSearchforovertime.click();
		txtSearchforovertime.sendKeys("Overtime");
	}
	@FindBy(xpath="//input[@data-placeholder='Search in earning code id or name']") WebElement txtSearchfordot;
	public void searchdot()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtSearchfordot);
		//txtSearchfordot.click();
		txtSearchfordot.sendKeys("Double Overtime");
	}
	@FindBy(xpath="//input[@data-placeholder='Search in earning code id or name']") WebElement txtSearchfortripleot;
	public void searchtripleovertime()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtSearchfortripleot);
		//txtSearchfortripleot.click();
		txtSearchfortripleot.sendKeys("O3");
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-earning-code/app-earning-code-list/div/div[2]/div/table/tbody/tr/td[7]/a/mat-icon") WebElement clkEdit;
	public void selectedit()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkEdit);
		//clkEdit.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-earning-code/app-earning-code-list/div/div[2]/div/table/tbody/tr[2]/td[7]/a/mat-icon") WebElement clksecondEdit;
	public void selectsecondedit()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clksecondEdit);
		//clksecondEdit.click();
	}
	@FindBy(xpath="//input[@formcontrolname='amtRateMultiplier']") WebElement sltamtratemultiplier;
	public String selectamtratevalue()
	{
		return sltamtratemultiplier.getAttribute("value");
	}
	@FindBy(xpath="//button[normalize-space()='Cancel']") WebElement clkCancel;
	public void selectcancel()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCancel);
		//clkCancel.click();
	}
	@FindBy(xpath="//mat-icon[normalize-space()='close']") WebElement clkClose;
	public void selectclose()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkClose);
		//clkClose.click();
	}
	//below webelements created by sureshkumar 
	@FindBy(xpath="//span[contains(text(),'Payroll management')]") WebElement clkpayrollmgmtadptab;
	public void clickpayrollmgmtadptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollmgmtadptab);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Payroll setup')]") WebElement clkpayrollsetuptab;
	public void clickpayrollsetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollsetuptab);
		//clkpayrollsetuptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Earning codes')]") WebElement clkearningcodes;
	public void clickearningcodes()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkearningcodes);
		//clkearningcodes.click();
	}
}

package sis.aps.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class legalentities_companies_pom {
	
	public WebDriver ldriver;

	public legalentities_companies_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/app-aside-dynamic[1]/div[2]/div[1]/ul[1]/li[5]/a[1]/span[2]") WebElement clkLegalEntities;
	public void clkLegalEntitiesTab()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkLegalEntities.click();
	}
	@FindBy(xpath="//span[contains(text(),'Companies')]") WebElement clkCompanies;
	public void clkCompaniesTab()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkCompanies.click();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-company-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]") WebElement chkSyncADP;
	public boolean chkSyncADPEnabled()
	{
		return chkSyncADP.isEnabled();
	}
	@FindBy(xpath="//span[contains(text(),'SYNC WITH ADP')]") WebElement clkSyncADP;
	public void clkSyncADP()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSyncADP.click();
	}
	@FindBy(xpath="//span[@class='sync ng-star-inserted']") WebElement chkAppDate;
	public String chkAppDateDisplay()
	{
		return chkAppDate.getText();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-company-list[1]/div[1]/div[1]/div[2]/app-synchronization[1]/div[1]/div[2]/button[1]/span[2]") WebElement chkSyncADPagain;
	public boolean chkSyncADPEnabledBack()
	{
		return chkSyncADPagain.isEnabled();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'check_circle')]") WebElement chkCircle;
	public boolean chkCircleEnabled()
	{
		return chkCircle.isEnabled();
	}
	@FindBy(xpath="//span[@class='react-bootstrap-table-pagin ation-total']") WebElement chkRow;
	public String chkRowDisplay()
	{
		return chkRow.getText();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'create')]") WebElement chkEdit;
	public boolean chkEditEnabled()
	{
		return chkEdit.isEnabled();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'create')]") WebElement clkEdit;
	public void clkEdit()
	{
		clkEdit.click();
	}
	@FindBy(xpath="//button[@class='btn btn-light btn-elevate mr-2']") WebElement chkCancel;
	public boolean chkCancelDisplay()
	{
		return chkCancel.isDisplayed();
	}
	@FindBy(xpath="//button[@class='btn btn-primary btn-elevate']") WebElement chkSave;
	public boolean chkSaveEnabled()
	{
		return chkSave.isEnabled();
	}
	@FindBy(xpath="//button[@class='btn btn-light btn-elevate mr-2']") WebElement clkCancelbtn;
	public void clkCancel()
	{
		clkCancelbtn.click();
	}
	@FindBy(xpath="//mat-icon[contains(text(),'check_circle')]") WebElement chkCircleAgain;
	public boolean chkCircleEnabledBack()
	{
		return chkCircleAgain.isEnabled();
	}
	
	

}

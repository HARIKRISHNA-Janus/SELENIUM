package sis.aps.testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.employees_workercategories;
import sis.aps.pageobjects.loginpage_pom;

public class tc07_syncwithadp_workingcategories extends baseclass{
	
	@Test
	public void masterdata_workingcategories_syncwithadp() throws InterruptedException
	{	
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		logger.info("User logged in Successfully");

		employees_workercategories sync=new employees_workercategories(driver);
		Thread.sleep(3000);
		sync.EmployeesTab();
		logger.info("User clicked on Employees Tab");
		sync.WorkerCategoriesScreen();
		logger.info("User navigated to WorkerCategories Screen");
		logger.info("SYNC WITH ADP is Enabled:" +sync.chkSyncWithADP());
		sync.clkSyncWithADP();
		Thread.sleep(55000);
		String timestamp=new SimpleDateFormat("M/dd/yy, h:mm a").format(new Date());
		String Systemtime= "System Last Sync: " +timestamp;
		System.out.println(Systemtime);
		System.out.println("App " +sync.chkAppDateDisplay());
		logger.info("SYNC WITH ADP is Enabled Back:" +sync.chkSyncADPEnabledBack());
		logger.info("Circle Stared is Enabled:" +sync.chkCircleEnabled());
		if(sync.chkRowDisplay().equals(" Showing rows 1 to 10 of 28"))
		{
			Assert.assertTrue(true);
			logger.info("Row Count Equals");
		}
		else
		{
			Assert.fail();
			logger.info("Row Count Not Equal");
		}
	}


}

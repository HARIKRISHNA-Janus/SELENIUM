package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class prevailingwages_pom {
	
	public WebDriver ldriver;

	public prevailingwages_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//below webelements created by sureshkumar 
	@FindBy(xpath="//input[@name='searchText']") WebElement clkprevailingwageseachtxt;
	public void searchtxtbox()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprevailingwageseachtxt);
		clkprevailingwageseachtxt.sendKeys("AT_PW7");
	}
	@FindBy(xpath="//a[@title='Edit prevailing wage']") WebElement clkedit;
	public void clickedit()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkedit );
	}
	@FindBy(xpath="//a[@role='button']") WebElement clkprevailingwagejob;
	public void clickprevailingwagtab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkprevailingwagejob);
	}
	@FindBy(xpath="//tr[@class='e-row']//td[5]") WebElement getwagerate;
	public String getwageratevalue()
	{
		return getwagerate.getText();
	}
	@FindBy(xpath="//tr[@class='e-row']//td[6]") WebElement getfringerate;
	public String getfringeratevalue()
	{
		return getfringerate.getText();
	}
}

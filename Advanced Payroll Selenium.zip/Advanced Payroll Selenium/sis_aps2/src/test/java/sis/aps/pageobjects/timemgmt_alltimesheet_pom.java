package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class timemgmt_alltimesheet_pom {
	
	public WebDriver ldriver;

	public timemgmt_alltimesheet_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//span[contains(text(),'Time management')]") WebElement clkTimesheet;
	public void TimesheetTab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkTimesheet);
		//clkTimesheet.click();
	}
	@FindBy(xpath="//span[contains(text(),'All timesheet')]") WebElement clkAllTimesheet;
	public void AllTimesheetScreen()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkAllTimesheet.click();
	}
	@FindBy(xpath="//button[contains(text(),'New timesheet')]") WebElement btnNewTimesheet;
	public void NewTimesheet()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		btnNewTimesheet.click();
	}
	@FindBy(xpath="//input[@name='worker']") WebElement clkWorkers;
	public void WorkersText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkWorkers.click();
	}
	//for Worker: Todd Miller
	@FindBy(xpath="//b[contains(text(),'0000000023')]") WebElement txtWorkers;
	public void setWorker()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtWorkers);
		//txtWorkers.click();
	}
	//for worker: Daniel G. Ingles
	@FindBy(xpath="//b[contains(text(),'0000000008')]") WebElement txtWorkers2;
	public void setWorker2()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtWorkers2);
		//txtWorkers.click();
	}
	//for worker: Maple Myra
	@FindBy(xpath="//b[contains(text(),'0000000003')]") WebElement txtWorkers3;
	public void setWorker3()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtWorkers3);
		//txtWorkers.click();
	}
	@FindBy(xpath="//div[@id='mat-select-value-1']") WebElement clkPayPeriod;
	public void PayperiodText()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkPayPeriod);
		//clkPayPeriod.click();
	}
	@FindBy(xpath="//span[contains(text(),' 04/04/2021 - 04/10/2021 ')]") WebElement txtPayperiod;
	public void setPayperiod()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtPayperiod);
		//txtWorkers.click();
	}
	@FindBy(xpath="//input[@id='mat-input-3']") WebElement clkProject;
	public void ProjectText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkProject.click();
	}
	@FindBy(xpath="//b[contains(text(),'P000002')]") WebElement txtProject;
	public void setProject()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtProject);
		//txtWorkers.click();
	}
	@FindBy(xpath="//input[@id='mat-input-4']") WebElement clkTaskcode;
	public void TaskcodeText()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkTaskcode.click();
	}
	@FindBy(xpath="//b[contains(text(),'T001')]") WebElement txtTaskcode;
	public void setTaskcode()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode);
		//txtWorkers.click();
	}
	@FindBy(xpath="//b[contains(text(),'T003')]") WebElement txtTaskcode3;
	public void setTaskcode3()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", txtTaskcode3);
		//txtWorkers.click();
	}
	@FindBy(xpath="//button[contains(text(),'Save')]") WebElement clkSave;
	public void btnSave()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSave.click();
	}
	//hours screen
	@FindBy(xpath="//tr[@data-uid='grid-row12']") WebElement clkFirstRow;
	public void FirstRowSelect()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkFirstRow);
		//clkFirstRow.click();
	}
	@FindBy(xpath="//span[normalize-space()='Edit']") WebElement clkEdit;
	public void Edit()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEdit.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartime;
	public void Regulartime()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkRegulartime.click();
		clkRegulartime.sendKeys("8");
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartime3hr;
	public void Regulartime3hr()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkRegulartime.click();
		clkRegulartime3hr.sendKeys("3");
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkDoubletime;
	public void Doubletime()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDoubletime.sendKeys("3");
		clkDoubletime.click();
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkDoubletimeS2;
	public void DoubletimeS2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDoubletimeS2.sendKeys("5");
		clkDoubletimeS2.click();
	}
	@FindBy(xpath="//input[@name='shift']") WebElement clkShiftid;
	public void shifid()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkShiftid.click();
	}
	@FindBy(xpath="//b[contains(text(),'Night')]") WebElement clkNight;
	public void setShiftid()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkNight.click();
	}
	@FindBy(xpath="//b[contains(text(),'Swing')]") WebElement clkSwing;
	public void setShiftid2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkSwing.click();
	}
	@FindBy(xpath="//input[@id='project___code']") WebElement clkProjectid;
	public void ProjectID()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkProjectid.click();
	}
	@FindBy(xpath="//b[contains(text(),'P000001')]") WebElement clkP000001;
	public void setProjectlist1()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkP000001.click();
	}
	@FindBy(xpath="//b[contains(text(),'P000002')]") WebElement clkP000002;
	public void setProjectlist2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkP000002.click();
	}
	@FindBy(xpath="//input[@id='projectTask___taskCode___code']") WebElement clkTaskid;
	public void TaskID()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkTaskid.click();
	}
	@FindBy(xpath="//b[contains(text(),'T001')]") WebElement clkT001;
	public void setTasklist1()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkT001.click();
	}
	@FindBy(xpath="//b[contains(text(),'T002')]") WebElement clkT002;
	public void setTasklist2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkT002.click();
	}
	@FindBy(xpath="//td[@aria-label='04/05/2021 column header Date *']") WebElement clkSecondRow;
	public void SecondRowSelect()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSecondRow.click();
	}
	@FindBy(xpath="//span[normalize-space()='Edit']") WebElement clkEditgain;
	public void Editagain()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEditgain.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimeagain;
	public void Regulartimeagain()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimeagain.sendKeys("8");
		clkRegulartimeagain.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimesecondrow11hr;
	public void Regulartimesecondrow11hr()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimesecondrow11hr.sendKeys("11");
		clkRegulartimesecondrow11hr.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimeagainS2;
	public void RegulartimeagainS2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimeagainS2.sendKeys("5");
		clkRegulartimeagainS2.click();
	}
	@FindBy(xpath="//span[normalize-space()='Update']") WebElement clkUpdate;
	public void Update()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkUpdate.click();
	}
	@FindBy(xpath="//td[@aria-label='04/06/2021 column header Date *']") WebElement clkThirdRow;
	public void ThirdRowSelect()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkThirdRow.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimeagainS3;
	public void RegulartimeagainS3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimeagainS3.sendKeys("7");
		clkRegulartimeagainS3.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertime;
	public void Overtime()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertime.sendKeys("2");
		clkOvertime.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertimeS2;
	public void OvertimeS2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertimeS2.sendKeys("7");
		clkOvertimeS2.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertimeS3;
	public void OvertimeS3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertimeS3.sendKeys("2");
		clkOvertimeS3.click();
	}
	@FindBy(xpath="//b[contains(text(),'Night')]") WebElement clkNightthirdrow;
	public void setShiftidthirdrow()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkNightthirdrow.click();
	}
	@FindBy(xpath="//td[@aria-label='04/07/2021 column header Date *']") WebElement clkForthRow;
	public void ForthRowSelect()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkForthRow.click();
	}
	@FindBy(xpath="//b[contains(text(),'Night')]") WebElement clkNightfourthrow;
	public void setShiftidfourthrow()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkNightfourthrow.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimeagainS4;
	public void RegulartimeagainS4()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimeagainS4.sendKeys("8");
		clkRegulartimeagainS4.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertimeagain;
	public void Overtimeagain()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertimeagain.sendKeys("2");
		clkOvertimeagain.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertimeagainS2;
	public void OvertimeagainS2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertimeagainS2.sendKeys("5");
		clkOvertimeagainS2.click();
	}
	@FindBy(xpath="//input[@formcontrolname='overTimeHours']") WebElement clkOvertimeagainS3;
	public void OvertimeagainS3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkOvertimeagainS3.sendKeys("2");
		clkOvertimeagainS3.click();
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkDoubletimeagain;
	public void Doubletimeagain()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDoubletimeagain.sendKeys("3");
		clkDoubletimeagain.click();
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkDoubletimeagainS2;
	public void DoubletimeagainS2()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDoubletimeagainS2.sendKeys("2");
		clkDoubletimeagainS2.click();
	}
	@FindBy(xpath="//input[@formcontrolname='doubleTimeHours']") WebElement clkDoubletimeagainS3;
	public void DoubletimeagainS3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDoubletimeagainS3.sendKeys("2");
		clkDoubletimeagainS3.click();
	}
	@FindBy(xpath="//input[@formcontrolname='tripleTimeHours']") WebElement clkTripleTime;
	public void TripleTime()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkTripleTime.sendKeys("2");
		clkTripleTime.click();
	}
	@FindBy(xpath="//input[@formcontrolname='tripleTimeHours']") WebElement clkTripleTimeS3;
	public void TripleTimeS3()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkTripleTimeS3.sendKeys("2");
		clkTripleTimeS3.click();
	}
	@FindBy(xpath="//td[@aria-label='04/08/2021 column header Date *']") WebElement clkFifthRow;
	public void FifthRowSelect()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkFifthRow.click();
	}
	@FindBy(xpath="//input[@formcontrolname='regularHours']") WebElement clkRegulartimeFifthrow;
	public void Regulartimefifthrow()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkRegulartimeFifthrow.sendKeys("8");
		clkRegulartimeFifthrow.click();
	}
	@FindBy(xpath="//a[contains(text(),' Process ')]") WebElement clkProcess;
	public void Process()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkProcess.click();
	}
	@FindBy(xpath="//a[contains(text(),' Approve ')]") WebElement clkApprove;
	public void Approve()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkApprove.click();
	}
	@FindBy(xpath="//a[normalize-space()='Details']") WebElement clkDetails;
	public void Details()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkDetails.click();
	}
	@FindBy(xpath="//a[contains(text(),' Complete ')]") WebElement clkComplete;
	public void Complete()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkComplete.click();
	}
	@FindBy(xpath="//a[contains(text(),' Create Statement ')]") WebElement clkCreateStatement;
	public void CreateStatement()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkCreateStatement.click();
	}
	@FindBy(xpath="//a[@id='dropdownButton']") WebElement clkdots;
	public void Threedots()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkdots.click();
	}
	@FindBy(xpath="//span[normalize-space()='View calculation']") WebElement clkViewcalculation;
	public void Viewcalculation()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkViewcalculation.click();
	}
	@FindBy(xpath="//td[@aria-label='16 column header  Regular hours']") WebElement chkRegularhours;
	public String chkRegularhoursdisplay()
	{		
		return chkRegularhours.getText();
	}
	@FindBy(xpath="//td[@aria-label='13 column header  Regular hours']") WebElement chkRegularhoursS2;
	public String chkRegularhoursdisplayS2()
	{		
		return chkRegularhoursS2.getText();
	}
	@FindBy(xpath="//td[@aria-label='37 column header  Regular hours']") WebElement chkRegularhoursS3;
	public String chkRegularhoursdisplayS3()
	{		
		return chkRegularhoursS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='4 column header  Overtime hours']") WebElement chkOvertimehours;
	public String chkOvertimehoursdisplay()
	{		
		return chkOvertimehours.getText();
	}
	@FindBy(xpath="//td[@aria-label='12 column header  Overtime hours']") WebElement chkOvertimehoursS2;
	public String chkOvertimehoursdisplayS2()
	{		
		return chkOvertimehoursS2.getText();
	}
	@FindBy(xpath="//td[@aria-label='4 column header  Overtime hours']") WebElement chkOvertimehoursS3;
	public String chkOvertimehoursdisplayS3()
	{		
		return chkOvertimehoursS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='6 column header Double time hours']") WebElement chkDoubletimehors;
	public String chkDoubletimehoursdisplay()
	{		
		return chkDoubletimehors.getText();
	}
	@FindBy(xpath="//td[@aria-label='7 column header Double time hours']") WebElement chkDoubletimehorsS2;
	public String chkDoubletimehoursdisplayS2()
	{		
		return chkDoubletimehorsS2.getText();
	}
	@FindBy(xpath="//td[@aria-label='2 column header Double time hours']") WebElement chkDoubletimehorsS3;
	public String chkDoubletimehoursdisplayS3()
	{		
		return chkDoubletimehorsS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='816.0000 column header Total hourly cost']") WebElement chkTotalhourlycost;
	public String chkTotalhourlycostdisplay()
	{		
		return chkTotalhourlycost.getText();
	}
	@FindBy(xpath="//td[@aria-label='1741.0000 column header Total hourly cost']") WebElement chkTotalhourlycostS2;
	public String chkTotalhourlycostdisplayS2()
	{		
		return chkTotalhourlycostS2.getText();
	}
	@FindBy(xpath="//td[@aria-label='2010.0500 column header Total hourly cost']") WebElement chkTotalhourlycostS3;
	public String chkTotalhourlycostdisplayS3()
	{		
		return chkTotalhourlycostS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='816.0000 column header Total cost']") WebElement chkTotalcost;
	public String chkTotalcostdisplay()
	{		
		return chkTotalcost.getText();
	}
	@FindBy(xpath="//td[@aria-label='1741.0000 column header Total cost']") WebElement chkTotalcostS2;
	public String chkTotalcostdisplayS2()
	{		
		return chkTotalcostS2.getText();
	}
	@FindBy(xpath="//td[@aria-label='2010.0500 column header Total cost']") WebElement chkTotalcostS3;
	public String chkTotalcostdisplayS3()
	{		
		return chkTotalcostS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='2 column header Triple time hours']") WebElement chkTripletimehours;
	public String chkTripleTimehoursdisplay()
	{		
		return chkTripletimehours.getText();
	}
	@FindBy(xpath="//td[@aria-label='2 column header Triple time hours']") WebElement chkTripletimehoursS3;
	public String chkTripleTimehoursdisplayS3()
	{		
		return chkTripletimehoursS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='0.0000 column header  Total fringe cost']") WebElement chkTotalfringecostS3;
	public String chkTotalfringecostS3()
	{		
		return chkTotalfringecostS3.getText();
	}
	@FindBy(xpath="//td[@aria-label='29.6700 column header Employee rate']") WebElement clkRow;
	public void SelectRow()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkRow.click();
	}
	@FindBy(xpath="//td[@aria-label='19.1700 column header Employee rate']") WebElement clkthirdRow;
	public void SelectthirdRow()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		//clkDoubletime.click();
		clkthirdRow.click();
	}
	@FindBy(xpath="//input[@name='unionBaseRate']") WebElement chkUnionbaserate;
	public String chkUnionbaseratedisplay()
	{		
		return chkUnionbaserate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='unionShiftRate']") WebElement chkUnionshiftrate;
	public String chkUnionshiftratedisplay()
	{		
		return chkUnionshiftrate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='extraPayRate']") WebElement chkUnionextrapayrate;
	public String chkUnionextrapayratedisplay()
	{		
		return chkUnionextrapayrate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='employeeRate']") WebElement chkEmpolyeerate;
	public String chkEmployeeratedisplay()
	{		
		return chkEmpolyeerate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='employeeShiftRate']") WebElement chkEmpolyeeshiftrate;
	public String chkEmployeerateShiftrate()
	{		
		return chkEmpolyeeshiftrate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='prevailingWageRate']") WebElement chkprevailingWageRate;
	public String chkPrevailingWageRate()
	{		
		return chkprevailingWageRate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='prevailingWageFringeRate']") WebElement chkprevailingWageFringeRate;
	public String chkPrevailingWageFringeRate()
	{		
		return chkprevailingWageFringeRate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='prevailingWageShiftRate']") WebElement chkprevailingWageShiftRate;
	public String chkPrevailingWageShiftRate()
	{		
		return chkprevailingWageShiftRate.getAttribute("value");
	}
	@FindBy(xpath="//input[@name='prevailingWageCashInLieu']") WebElement chkprevailingWageCashInLieu;
	public String chkPrevailingWageCashInLieu()
	{		
		return chkprevailingWageCashInLieu.getAttribute("value");
	}
	
	
}

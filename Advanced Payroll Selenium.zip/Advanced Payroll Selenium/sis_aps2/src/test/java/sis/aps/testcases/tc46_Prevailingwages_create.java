package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.certifiedPayroll_PrevallingWages_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc46_Prevailingwages_create extends baseclass {

	@Test
	public void Prevailingwages_create() throws InterruptedException {

		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(3000);

		/* Prevailing Wages create */

		certifiedPayroll_PrevallingWages_pom prevailingWages = new certifiedPayroll_PrevallingWages_pom(driver);

		prevailingWages.clickCertifiedPayrollTab();
		prevailingWages.clickPrevailingWagesTab();
		Thread.sleep(2000);
		logger.info("User navigated to All Prevailing Wages Page");
		prevailingWages.clickNewprevailingwageButton();
		prevailingWages.SetPrevailingwageId(prevailingwageId);
		prevailingWages.SetPrevailingwageName(prevailingwageName);
		prevailingWages.clickSaveButton();
		Thread.sleep(2000);

		if (prevailingWages.isPrevailingWageJobTabDisplayed().equals("Prevailing wage job")) {
			Assert.assertTrue(true);
			logger.info("Prevailing Wages has been created Successfully");
		} else {
			Assert.fail();
			logger.info("Prevailing Wages has not been created");
		}

		/* Create Prevailing Wage Job */
		prevailingWages.clickAddButton();
		Thread.sleep(2000);
		prevailingWages.clickJobNameField();
		Thread.sleep(2000);
		prevailingWages.ClickIndex1Val();
		Thread.sleep(2000);
		prevailingWages.clickDatepickerButton();
		Thread.sleep(2000);
		prevailingWages.clickCurrentDate();
		Thread.sleep(2000);
		prevailingWages.SetWageRate(wageRate);
		prevailingWages.SetFringeRate(fringeRate);
		Thread.sleep(2000);
		prevailingWages.clickUpdateButton();
		Thread.sleep(2000);

		if (prevailingWages.isPrevailingWageJobCreated().equals("Prevailing wage job has been created successfully")) {
			Assert.assertTrue(true);
			logger.info("Prevailing Wages Job has been created Successfully");
		} else {
			Assert.fail();
			logger.info("Prevailing Wages Job has not been created");
		}

		/* Delete Prevailing Wage Job */

		Thread.sleep(2000);
		prevailingWages.clickDeleteBTN_PWJ();
		Thread.sleep(2000);
		prevailingWages.clickDeleteBtnPopup();
		Thread.sleep(2000);

		if (prevailingWages.isPrevailingWageJobDeleted().equals("Prevailing wage job has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Prevailing Wages Job has been deleted");
		} else {
			Assert.fail();
			logger.info("Prevailing Wages Job has not been deleted");
		}

		prevailingWages.clickBackButton();
		Thread.sleep(2000);

		if (prevailingWages.isAllprevailingwagesHeaderDisplayed().equals("All prevailing wages")) {
			Assert.assertTrue(true);
			logger.info("Prevailing Wages has been created Successfully");
		} else {
			Assert.fail();
		}

		Thread.sleep(1000);
		prevailingWages.search();
		Thread.sleep(2000);
		prevailingWages.clickDeleteIcon();
		Thread.sleep(2000);
		prevailingWages.clickDeleteButton();
		Thread.sleep(2000);

		if (prevailingWages.isAllprevailingwagesHeaderDisplayed().equals("All prevailing wages")) {
			Assert.assertTrue(true);
			logger.info("Prevailing Wages has been Deleted");
		} else {
			Assert.fail();
		}

	}
}

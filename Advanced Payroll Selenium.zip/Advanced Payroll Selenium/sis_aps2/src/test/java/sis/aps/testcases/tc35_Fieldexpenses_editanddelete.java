package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.advancepayroll_FieldExpenses_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc35_Fieldexpenses_editanddelete extends baseclass {

	@Test
	public void FieldExpenses_EditandDelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Field Expense Create then edit and Delete */
		advancepayroll_FieldExpenses_pom fieldExpense = new advancepayroll_FieldExpenses_pom(driver);

		fieldExpense.clickAdvancepayrollTab();
		Thread.sleep(2000);
		fieldExpense.clickFieldExpensesTab();
		logger.info("User navigated to All Field Expenses Page");
		Thread.sleep(2000);
		fieldExpense.clickNewFieldExpenseButton();
		Thread.sleep(2000);
		fieldExpense.clickProjectCategory();
		Thread.sleep(2000);
		fieldExpense.ClickIndex3Val();
		Thread.sleep(2000);
		fieldExpense.SetUnit(unit);
		Thread.sleep(2000);
		fieldExpense.clickDeductionCode();
		Thread.sleep(2000);
		fieldExpense.ClickIndex1Val();
		Thread.sleep(2000);
		fieldExpense.SetBaseRate(baseRate);
		Thread.sleep(2000);
		fieldExpense.clickSaveButton();
		Thread.sleep(2000);

		if (fieldExpense.isExpenseRateOverridesTabDisplayed().equals("Expense rate overrides")) {
			Assert.assertTrue(true);
			logger.info("Field Expenses has been created");
		} else {
			Assert.fail();
		}

		if (fieldExpense.isExpenseRateOverridesTabDisplayed().equals("Expense rate overrides")) {
			Assert.assertTrue(true);
			logger.info("Field Expenses has been created");
		} else {
			Assert.fail();
		}

		/* Create Expense Rate Overrides */
		Thread.sleep(2000);
		fieldExpense.clickExpenseRateOverridesTabD();
		Thread.sleep(1000);
		fieldExpense.clickAddButton();
		Thread.sleep(2000);
		fieldExpense.clickDatePicker();
		Thread.sleep(1000);
		fieldExpense.clickCurrentDate();
		Thread.sleep(2000);
		fieldExpense.clickprojectField();
		fieldExpense.ClickIndex1Val();
		Thread.sleep(2000);
		fieldExpense.clickWorkerField();
		fieldExpense.ClickIndex1Val();
		Thread.sleep(2000);
		fieldExpense.clickJobField();
		fieldExpense.ClickIndex1Val();
		Thread.sleep(2000);
		fieldExpense.SetRateEro(baseRate);
		Thread.sleep(2000);
		fieldExpense.ClickActiveCheckbox();
		Thread.sleep(2000);
		fieldExpense.clickUpdateButton();
		Thread.sleep(2000);

		if (fieldExpense.IsExpenseRateOvrCreated().equals("Expense rate overrides has been created")) {
			Assert.assertTrue(true);
			logger.info("Expense Rate Overrides has been created");
		} else {
			Assert.fail();
			logger.info("Expense Rate Overrides has Not been created");
		}

		/* Update Expense Rate Overrides */
		
		Thread.sleep(2000);
		fieldExpense.clickEditButton();
		Thread.sleep(2000);
		fieldExpense.clickprojectField();
		fieldExpense.ClickIndex2Val();
		Thread.sleep(2000);
		fieldExpense.clickWorkerField();
		fieldExpense.ClickIndex2Val();
		Thread.sleep(2000);
		fieldExpense.clickJobField();
		fieldExpense.ClickIndex2Val();
		Thread.sleep(2000);
		fieldExpense.EditRateEro();
		Thread.sleep(2000);
		fieldExpense.clickUpdateButton();
		Thread.sleep(2000);

		if (fieldExpense.IsExpenseRateOvrUpdated().equals("Expense rate overrides has been updated")) {
			Assert.assertTrue(true);
			logger.info("Expense Rate Overrides has been updated");
		} else {
			Assert.fail();
			logger.info("Expense Rate Overrides has Not been updated");
		}
		
		/* Delete Expense Rate Overrides */
		
		Thread.sleep(2000);
		fieldExpense.clickDeleteBTN();
		Thread.sleep(2000);
		fieldExpense.clickDeleteBtnPopup();
		Thread.sleep(2000);
		
		if (fieldExpense.IsExpenseRateOvrDeleted().equals("Expense rate overrides has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Expense Rate Overrides has been deleted");
		} else {
			Assert.fail();
			logger.info("Expense Rate Overrides has Not been deleted");
		}
		
		Thread.sleep(2000);
		fieldExpense.clickBackButton();
		Thread.sleep(2000);

		if (fieldExpense.isFieldExpensesHeaderDisplayed().equals("All field expenses")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		fieldExpense.searchFieldExpenses();
		Thread.sleep(2000);
		fieldExpense.ClickEditIcon();
		Thread.sleep(2000);
		fieldExpense.editUnit();
		Thread.sleep(1000);
		fieldExpense.clickSaveButton();
		Thread.sleep(2000);

		if (fieldExpense.IsFieldExpenseUpdated().contains("Field expense has been updated")) {
			Assert.assertTrue(true);
			logger.info("Field Expense has been updated");
		} else {
			Assert.fail();
		}

		Thread.sleep(2000);
		fieldExpense.clickBackButton();
		Thread.sleep(2000);

		if (fieldExpense.isFieldExpensesHeaderDisplayed().equals("All field expenses")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		fieldExpense.searchFieldExpenses();
		Thread.sleep(2000);
		fieldExpense.clickDeleteIcon();
		Thread.sleep(2000);
		fieldExpense.clickDeleteButton();
		Thread.sleep(2000);

		if (fieldExpense.isFieldExpensesHeaderDisplayed().equals("All field expenses")) {
			Assert.assertTrue(true);
			logger.info("Field Expenses has been deleted");
		} else {
			Assert.fail();
		}

	}
}

package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class employees_positions_pom {
	
	public WebDriver ldriver;

	public employees_positions_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	//below webelements created by Sureshkumar 
	@FindBy(xpath="//a[@class='menu-link menu-toggle']//span[@class='menu-text'][normalize-space()='Employees']") WebElement clkEmployeesTab;
	public void EmployeesTab()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEmployeesTab.click();
	}
	@FindBy(xpath="//span[normalize-space()='Positions']") WebElement clkpositions;
	public void clkpositionsscreen()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkpositions.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-position/app-position-list/div/div[1]/div/div/div/mat-form-field/div/div[1]/div/input") WebElement clkSearchtxt;
	public void clksearchtextbox()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkSearchtxt.click();
	}
	@FindBy(xpath="//*[@id=\"kt_content\"]/div/div/app-position/app-position-list/div/div[1]/div/div/div/mat-form-field/div/div[1]/div/input") WebElement searchworkertxt;
	public String txtworkersearchstring(String worker)
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		searchworkertxt.sendKeys(worker);
		return worker;
	}
	@FindBy(xpath="//a[@title='Edit position']//mat-icon[@role='img'][normalize-space()='create']") WebElement clkEditbtn;
	public void clkEdit()
	{
		//JavascriptExecutor js=(JavascriptExecutor) ldriver;
		//js.executeScript("arguments[0].click()", clkLegalEntities);
		clkEditbtn.click();
	}
	@FindBy(xpath="//div[normalize-space()='Hourly rate amount']//following::div[1]") WebElement gethourlyrate;
	public String getHorlyrateamt()
	{
		return gethourlyrate.getText();
	}
	@FindBy(xpath="//button[normalize-space()='Cancel']") WebElement clkCancelbtn;
	public void clkCancel()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkCancelbtn);
		//clkCancelbtn.click();
	}
	@FindBy(xpath="//input[@name='homeUnionId']") WebElement gethomeunion;
	public String gethomeunionid()
	{
		return gethomeunion.getText();
	}
	@FindBy(xpath="//input[@name='homeUnionId']") WebElement gethomeunionvalue;
	public String gethomeunionidvalue()
	{
		return gethomeunionvalue.getAttribute("value");
	}
	@FindBy(xpath="//input[@formcontrolname='extraPay']") WebElement getunionextrapay;
	public String getunionextrapayvalue()
	{
		return getunionextrapay.getAttribute("value");
	}
	@FindBy(xpath="//input[@formcontrolname='extraPay']") WebElement getunionextrapaytext;
	public String getunionextrapaytextvalue()
	{
		return getunionextrapaytext.getText();
	}
	//below webelements created by Sureshkumar 
	@FindBy(xpath="//span[contains(text(),'Payroll management')]") WebElement clkpayrollmgmtadptab;
	public void clickpayrollmgmtadptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkpayrollmgmtadptab);
		//clkpayrollmgmtadptab.click();
	}
	@FindBy(xpath="//span[contains(text(),'Worker setup')]") WebElement clkworkersetuptab;
	public void clickworkersetuptab()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkworkersetuptab);
		//clkworkersetuptab.click();
	}
}

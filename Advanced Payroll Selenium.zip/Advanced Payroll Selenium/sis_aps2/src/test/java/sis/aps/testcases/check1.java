package sis.aps.testcases;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import org.testng.annotations.Test;

public class check1 {
	

	@Test
public void xl() throws IOException, InterruptedException {
	
		String eomployeerate="15.589746982";
		String eomployeeratesum="15.53434";
	
	//float employeeratefinalvalue=(float) Double.parseDouble(eomployeerate);
	BigDecimal employeeratedisplay= new BigDecimal(eomployeerate).setScale(4, RoundingMode.HALF_EVEN);
	String employeeratedisplaystring=employeeratedisplay.toString();
	System.out.println("Employee Rate is: " +employeeratedisplaystring);
	BigDecimal employeeratedisplaysum= new BigDecimal(eomployeeratesum).setScale(4, RoundingMode.HALF_EVEN);
	String employeeratedisplaystringsum=employeeratedisplaysum.toString();
	System.out.println("Employee Rate Sum is: " +employeeratedisplaystringsum);
	if(employeeratedisplaystring==employeeratedisplaystringsum)
	{
		System.out.println("Passed");
	}
	else
	{
		System.out.println("failed");
	}
}
}
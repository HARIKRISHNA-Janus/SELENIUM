package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.unions_SpecialPays;

public class tc27_SpecialPay_editanddelete extends baseclass {

	@Test
	public void SpecialPay_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		logger.info("User entered the Username");
		login.setPasword(password);
		logger.info("User entered the password");
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User clicked SignIn button");
		Thread.sleep(3000);

		/* Create a SpecialPay then edit and delete */
		unions_SpecialPays specialPays = new unions_SpecialPays(driver);
		specialPays.clickUnionsTab();
		logger.info("User clicked Unions Leftsliding Menu");
		specialPays.clickSpecialPaysTab();
		logger.info("User clicked special pay Leftsliding Sunmenu");
		specialPays.clickNewSpecialPayButton();
		logger.info("User clicked new special pay button");
		specialPays.SetSpecialPayId(specialPayId);
		logger.info("User entered the specialpay Id");
		specialPays.SetSpecialPayName(specialPayName);
		logger.info("User entered the specialpay Name");
		specialPays.ClickCalcMethodDropdown();
		logger.info("User clicked calculation method drop-down field");
		Thread.sleep(2000);
		specialPays.ClickIndex1Val();
		logger.info("User clicked index 1 value");
		specialPays.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(3000);

		if (specialPays.isSpecialPayEarningCodeDisplayed().equals("Special pay earning code")) {
			Assert.assertTrue(true);
			logger.info("User verified specialpay earning code Tab is dispalyed");
		} else {
			System.out.println("Special pay earning code Tab is not Displayed");
			logger.info("Specialpay earning code Tab is not dispalyed");
		}

		/* Create Special Pay Earning Code */

		specialPays.clickAddButton();
		Thread.sleep(2000);
		specialPays.clickEarningCodeField();
		Thread.sleep(2000);
		specialPays.ClickIndex1Val();
		specialPays.clickUpdateButton();
		Thread.sleep(2000);

		if (specialPays.IsUnionSpecialPayEarningCodeCreated()
				.equals("Special pay earning code has been created successfully")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been added");
		} else {
			logger.info("Earning code has not been added");
			Assert.fail();
		}

		Thread.sleep(2000);

		if (specialPays.isRow1Displayed()) {
			Assert.assertTrue(true);
			logger.info("Earning code has been added");
		} else {
			Assert.fail();
			logger.info("Earning code has not been added");

		}

		/* Update Special Pay Earning Code */

		Thread.sleep(2000);
		specialPays.clickEditButton();
		Thread.sleep(2000);
		specialPays.clickEarningCodeField();
		Thread.sleep(2000);
		specialPays.ClickIndex2Val();
		specialPays.clickUpdateButton();
		Thread.sleep(2000);

		if (specialPays.IsUnionSpecialPayEarningCodeUpdated()
				.equals("Special pay earning code has been updated successfully")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been updated");
		} else {
			logger.info("Earning code has not been updated");
			Assert.fail();
		}

		/* Delete Special Pay Earning Code */

		Thread.sleep(2000);
		specialPays.clickDeleteBTN_UJ();
		Thread.sleep(2000);
		specialPays.clickDeleteBtnPopup();
		Thread.sleep(2000);

		if (specialPays.IsUnionSpecialPayEarningCodeDeleted().equals("Special pay earning code has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Earning code has been deletd");
		} else {
			logger.info("Earning code has not been deleted");
			Assert.fail();
		}

		specialPays.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(3000);

		if (specialPays.isAllSpecialPaysHeaderDisplayed().equals("All special pays")) {
			Assert.assertTrue(true);
			logger.info("User verified All special pay page Header");
			System.out.println("Special pays has been created successfully !");
		} else {
			logger.info("All fringes Page Header is not dispalyed");
			Assert.fail("All special pays Header is not disaplayed");
		}

		Thread.sleep(2000);
		specialPays.searchSpecialPay();
		logger.info("User entered the specialpay Id/Name in search input field");
		Thread.sleep(2000);
		specialPays.ClickEditIcon();
		logger.info("user clicked the edit icon");
		Thread.sleep(2000);
		specialPays.editSpecialPayIdId();
		logger.info("user edited special pay Id");
		specialPays.editSpecialPayName();
		logger.info("user edited special pay Name");
		Thread.sleep(2000);
		specialPays.clickSaveButton();
		logger.info("User clicked save button");
		Thread.sleep(1000);

		if (specialPays.IsSpayUpdated().contains("Special pay has been updated")) {
			Assert.assertTrue(true);
			logger.info("User verified special pay has been updated");
		} else {
			Assert.fail("Special Pay has not been Updated");
			logger.info("Special pay has not been updated");
		}

		specialPays.clickBackButton();
		logger.info("User clicked back button");
		Thread.sleep(2000);
		
		if (specialPays.isAllSpecialPaysHeaderDisplayed().equals("All special pays")) {
			Assert.assertTrue(true);
			logger.info("User verified All special pay page Header");
			System.out.println("Special Pay has been Updated successfully !");
		} else {
			logger.info("All fringes Page Header is not dispalyed");
			Assert.fail("All Special Pay Header is not disaplayed");
		}

		Thread.sleep(2000);
		specialPays.clickDeleteIcon();
		logger.info("user clicked the delete icon");
		specialPays.clickDeleteButton();
		logger.info("user clicked the delete button");
		Thread.sleep(3000);

		if (specialPays.isAllSpecialPaysHeaderDisplayed().equals("All special pays")) {
			Assert.assertTrue(true);
			logger.info("User verified All special pay page Header");
			System.out.println("Special has been Deleted successfully !");
		} else {
			logger.info("All fringes Page Header is not dispalyed");
			Assert.fail("All Special Pay Header is not disaplayed");
		}

	}
}

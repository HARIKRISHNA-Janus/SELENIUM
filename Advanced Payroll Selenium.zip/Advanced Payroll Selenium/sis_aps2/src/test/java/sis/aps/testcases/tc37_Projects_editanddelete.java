package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.pageobjects.operations_Projects_pom;

public class tc37_Projects_editanddelete extends baseclass {

	@Test
	public void Projects_editanddelete() throws InterruptedException {

		/* Login to the AAPS Application */
		loginpage_pom login = new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		logger.info("User logged in successfully !");
		Thread.sleep(3000);

		/* Create a Project then edit and delete */
		operations_Projects_pom projects = new operations_Projects_pom(driver);

		projects.clickOperationsTab();
		projects.clickProjectsTab();
		logger.info("User navigated to All projects Page");
		projects.clickNewProjectButton();
		projects.SetProjectId(projectId);
		projects.SetProjectName(projectName);
		projects.clickSaveButton();
		Thread.sleep(2000);

		if (projects.isProjectTaskTabDisplayed().equals("Project task")) {
			Assert.assertTrue(true);
			logger.info("Project has been created");
		} else {
			Assert.fail();
		}

		/* Create a Project Task */

		Thread.sleep(2000);
		projects.clickProjectTaskTab();
		Thread.sleep(2000);
		projects.clickAddButton();
		Thread.sleep(2000);
		projects.clickprojectTaskCodeField();
		Thread.sleep(2000);
		projects.ClickIndex1Val();
		Thread.sleep(2000);
		projects.ClickActiveCheckbox();
		Thread.sleep(2000);
		projects.clickUpdateButton();
		Thread.sleep(2000);

		if (projects.IsprojectTaskCreated().equals("Project task has been created")) {
			Assert.assertTrue(true);
			logger.info("Project task has been deleted");
		} else {
			Assert.fail();
			logger.info("Project task has not been deleted");
		}

		/* Update Project Task */

		Thread.sleep(2000);
		projects.clickEditButton();
		Thread.sleep(2000);
		projects.clickprojectTaskCodeField();
		Thread.sleep(2000);
		projects.ClickIndex2Val();
		Thread.sleep(2000);
		projects.clickUpdateButton();
		Thread.sleep(2000);

		if (projects.IsprojectTaskUpdated().equals("Project task has been updated")) {
			Assert.assertTrue(true);
			logger.info("Project task has been updated");
		} else {
			Assert.fail();
			logger.info("Project task has not been updated");
		}

		/* Create Project Task Crafts */
		Thread.sleep(2000);
		projects.scrollIntoView();
		Thread.sleep(3000);
		projects.clickAddButtonPTC();
		Thread.sleep(2000);
		projects.clickprojectTaskCraftField();
		Thread.sleep(2000);
		projects.ClickIndex1Val();
		Thread.sleep(2000);
		projects.clickprojectTaskUnionField();
		Thread.sleep(2000);
		projects.ClickIndex1Val();
		Thread.sleep(2000);
		projects.clickprojectTaskTaxRegionNameField();
		Thread.sleep(2000);
		projects.ClickIndex1Val();
		Thread.sleep(2000);
		projects.clickUpdateButtonPTC();
		Thread.sleep(2000);

		if (projects.IsprojectTaskCraftCreated().equals("Project task craft created successfully")) {
			Assert.assertTrue(true);
			logger.info("Project task craft has been created");
		} else {
			Assert.fail();
			logger.info("Project task craft has not been created");
		}

		/* Update Project Task Crafts */
		Thread.sleep(2000);
		projects.clickEditButtonPTC();
		Thread.sleep(2000);
		projects.clickprojectTaskCraftField();
		Thread.sleep(2000);
		projects.ClickIndex2Val();
		Thread.sleep(2000);
		projects.clickprojectTaskUnionField();
		Thread.sleep(2000);
		projects.ClickIndex1Val();
		Thread.sleep(2000);
		projects.clickprojectTaskTaxRegionNameField();
		Thread.sleep(2000);
		projects.ClickIndex2Val();
		Thread.sleep(2000);
		projects.clickUpdateButtonPTC();
		Thread.sleep(2000);

		if (projects.IsprojectTaskCraftUpdated().equals("Project task craft updated successfully")) {
			Assert.assertTrue(true);
			logger.info("Project task craft has been updated");
		} else {
			Assert.fail();
			logger.info("Project task craft has not been updated");
		}

		/* Delete Project Task Craft */
		Thread.sleep(2000);
		projects.clickDeleteBTN_PTC();
		Thread.sleep(2000);
		projects.clickDeleteBtnPopup();
		Thread.sleep(2000);

		if (projects.IsprojectTaskCraftdeleted().equals("Project task craft has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Project task craft has been deleted");
		} else {
			Assert.fail();
			logger.info("Project task craft has not been deleted");
		}

		/* Delete project Task */
		Thread.sleep(2000);
		projects.clickDeleteBTN();
		Thread.sleep(2000);
		projects.clickDeleteBtnPopup();
		Thread.sleep(2000);

		if (projects.IsprojectTaskDeleted().equals("Project task has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Project task has been deleted");
		} else {
			Assert.fail();
			logger.info("Project task has not been deleted");
		}
		

		/* Create Project Address */

		Thread.sleep(2000);
		projects.clickProjectAddressTab();
		Thread.sleep(2000);
		projects.clickAddButton();
		Thread.sleep(2000);
		projects.SetName(name);
		Thread.sleep(1000);
		projects.SetAddressL1(addressL1);
		Thread.sleep(1000);
		projects.SetCity(city);
		Thread.sleep(1000);
		projects.ClickStateField();
		Thread.sleep(1000);
		projects.ClickIndex1Val();
		Thread.sleep(1000);
		projects.SetZipCode(zipCode);
		Thread.sleep(1000);
		projects.SetCountry(country);
		Thread.sleep(2000);
		projects.clickUpdateButton();
		Thread.sleep(2000);

		if (projects.IsprojectAddressCreated().equals("Project address has been created")) {
			Assert.assertTrue(true);
			logger.info("Project Address has been Created");
		} else {
			Assert.fail();
			logger.info("Project Address has not been Created");
		}

		/* Update Project Address */
		
		Thread.sleep(2000);
		projects.clickEditButton();
		Thread.sleep(2000);
		projects.EditName();
		Thread.sleep(2000);
		projects.clickUpdateButton();
		Thread.sleep(2000);
		
		if (projects.IsprojectAddressUpdated().equals("Project address has been updated")) {
			Assert.assertTrue(true);
			logger.info("Project Address has been Updated");
		} else {
			Assert.fail();
			logger.info("Project Address has not been Updated");
		}
		
		/* Delete Project Address */
		
		Thread.sleep(2000);
		projects.clickDeleteBTNToolBar();
		Thread.sleep(2000);
		projects.clickDeleteBtnPopup();
		Thread.sleep(2000);
		
		if (projects.IsprojectAddressDeleted().equals("Project address has been deleted")) {
			Assert.assertTrue(true);
			logger.info("Project Address has been Deleted");
		} else {
			Assert.fail();
			logger.info("Project Address has not been Deleted");
		}
		
		Thread.sleep(2000);
		projects.clickBackButton();
		Thread.sleep(2000);

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		projects.searchProjects();
		Thread.sleep(2000);
		projects.ClickEditIcon();
		Thread.sleep(2000);
		projects.editProjectId();
		projects.editProjectName();
		projects.clickSaveButton();
		Thread.sleep(2000);

		if (projects.IsProjectUpdated().contains("Project has been updated")) {
			Assert.assertTrue(true);
			logger.info("Project has been updated");
		} else {
			Assert.fail();
		}

		projects.clickBackButton();
		Thread.sleep(2000);

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
		} else {
			Assert.fail();
		}

		projects.searchProjects();
		Thread.sleep(2000);
		projects.clickDeleteIcon();
		Thread.sleep(2000);
		projects.clickDeleteButton();
		Thread.sleep(2000);

		if (projects.isProjectsHeaderDisplayed().equals("All projects")) {
			Assert.assertTrue(true);
			logger.info("Project has been deleted");
		} else {
			Assert.fail();
		}

	}
}

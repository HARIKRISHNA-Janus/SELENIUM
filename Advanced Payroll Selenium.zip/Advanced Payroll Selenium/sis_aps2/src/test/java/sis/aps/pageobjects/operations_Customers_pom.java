package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class operations_Customers_pom {

	public WebDriver ldriver;

	public operations_Customers_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

	@FindBy(xpath = "(//span[text()='Operations'])[1]")
	WebElement clkoperationsTab;

	public void clickOperationsTab() {
		clkoperationsTab.click();
	}

	@FindBy(xpath = "//span[text()='Customers']")
	WebElement clkCustomersTab;

	public void clickCustomersTab() {
		clkCustomersTab.click();
	}

	@FindBy(xpath = "//button[text()='New customer']")
	WebElement clkNewCustomerButton;

	public void clickNewCustomerButton() {
		clkNewCustomerButton.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Customer id']")
	WebElement InputCustomerId;

	public void SetCustomerId(String CustomerId) {
		InputCustomerId.click();
		InputCustomerId.sendKeys(CustomerId + randomInt);
	}

	public void editCustomerId() {
		InputCustomerId.clear();
		InputCustomerId.sendKeys("AA_CID");
	}

	@FindBy(xpath = "//input[@data-placeholder='Customer name']")
	WebElement InputCustomerName;

	public void SetCustomerName(String CustomerName) {
		InputCustomerName.click();
		InputCustomerName.sendKeys(CustomerName + randomInt);
	}

	public void editCustomerName() {
		InputCustomerName.clear();
		InputCustomerName.sendKeys("AA_CN");
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//h3[text()='All customers']")
	WebElement AllCustomersHd;

	public String isAllCustomersHeaderDisplayed() {
		return AllCustomersHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in customer id or name']")
	WebElement txtsearch;

	public void searchCustomer() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-customer-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}

}

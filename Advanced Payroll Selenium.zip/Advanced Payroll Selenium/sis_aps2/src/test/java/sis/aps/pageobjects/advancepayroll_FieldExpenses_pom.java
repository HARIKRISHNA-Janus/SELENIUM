package sis.aps.pageobjects;

import java.util.Random;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class advancepayroll_FieldExpenses_pom {

	public WebDriver ldriver;

	public advancepayroll_FieldExpenses_pom(WebDriver rdriver) {

		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	Random randomGenerator = new Random();
	int randomInt = randomGenerator.nextInt(100000);

		@FindBy(xpath = "(//span[text()='Advance payroll'])[1]")
	WebElement clkAdvancepayrollTab;

	public void clickAdvancepayrollTab() {
		clkAdvancepayrollTab.click();
	}

	@FindBy(xpath = "//span[text()='Field expenses']")
	WebElement clkFieldExpensesTab;

	public void clickFieldExpensesTab() {
		clkFieldExpensesTab.click();
	}

	@FindBy(xpath = "//button[text()='New field expense']")
	WebElement clkNewFieldExpenseButton;

	public void clickNewFieldExpenseButton() {
		//clkNewFieldExpenseButton.click();
		JavascriptExecutor js = (JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkNewFieldExpenseButton);
	}

	@FindBy(xpath = "//input[@data-placeholder='Project category']")
	WebElement InputFieldProjectCategory;

	public void clickProjectCategory() {
		InputFieldProjectCategory.click();
	}

	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[1]")
	WebElement clkIndex1Value;

	public void ClickIndex1Val() {
		clkIndex1Value.click();
	}
	
	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[3]")
	WebElement clkIndex3Value;

	public void ClickIndex3Val() {
		clkIndex3Value.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Unit']")
	WebElement InputFieldUnit;

	public void SetUnit(String Unit) {
		InputFieldUnit.click();
		InputFieldUnit.sendKeys(Unit);
	}

	public void editUnit() {
		InputFieldUnit.clear();
		InputFieldUnit.sendKeys("AA_UU");
	}

	@FindBy(xpath = "//input[@data-placeholder='Deduction code']")
	WebElement InputFieldDeductionCode;

	public void clickDeductionCode() {
		InputFieldDeductionCode.click();
	}

	@FindBy(xpath = "//input[@data-placeholder='Base rate']")
	WebElement InputBaseRate;

	public void SetBaseRate(String BaseRate) {
		InputBaseRate.click();
		InputBaseRate.sendKeys(BaseRate);
	}

	@FindBy(xpath = "//button[text()='Save']")
	WebElement clkSaveButton;

	public void clickSaveButton() {
		clkSaveButton.click();
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='create'][1]")
	WebElement clkEditIcon;

	public void ClickEditIcon() {
		clkEditIcon.click();
	}

	@FindBy(xpath = "//span[text()='Field expense has been updated']")
	WebElement FieldExpenseUpdateMsg;

	public String IsFieldExpenseUpdated() {
		return FieldExpenseUpdateMsg.getText();
	}

	@FindBy(xpath = "//app-field-expense-edit//a[contains(text(),'Expense rate overrides')]")
	WebElement ExpenseRateOVRTab;

	public String isExpenseRateOverridesTabDisplayed() {
		return ExpenseRateOVRTab.getText();
	}

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement btnBack;

	public void clickBackButton() {
		btnBack.click();
	}

	@FindBy(xpath = "//app-field-expense-list//h3[text()='All field expenses']")
	WebElement verifyAllFieldExpensesHd;

	public String isFieldExpensesHeaderDisplayed() {
		return verifyAllFieldExpensesHd.getText();
	}

	@FindBy(xpath = "//input[@data-placeholder='Search in project category, unit or base rate']")
	WebElement txtsearch;

	public void searchFieldExpenses() {
		txtsearch.clear();
		txtsearch.click();
		txtsearch.sendKeys("AA");
	}

	@FindBy(xpath = "//table//tr[1]//a//mat-icon[text()='delete'][1]")
	WebElement clkDeleteIcon;

	public void clickDeleteIcon() {
		clkDeleteIcon.click();
	}

	@FindBy(xpath = "//app-field-expense-delete//button[normalize-space(text())='Delete']")
	WebElement clkDeleteButton;

	public void clickDeleteButton() {
		clkDeleteButton.click();
	}
	
	@FindBy(xpath = "//button[normalize-space(text())='Delete']")
	WebElement BtnDeletePopup;

	public void clickDeleteBtnPopup() {
		BtnDeletePopup.click();
	}
	
	public void clickExpenseRateOverridesTabD() {
		ExpenseRateOVRTab.click();
	}

	@FindBy(xpath = "//button[@aria-label='Add']")
	WebElement BtnAdd;

	public void clickAddButton() {
		BtnAdd.click();
	}

	@FindBy(xpath = "//mat-datepicker-toggle[contains(@data-mat-calendar,'mat-datepicker')]")
	WebElement BtnDatePicker;

	public void clickDatePicker() {
		BtnDatePicker.click();
	}

	@FindBy(xpath = "//div[contains(@class,'today')]")
	WebElement CurrentDate;

	public void clickCurrentDate() {
		CurrentDate.click();
	}

	@FindBy(xpath = "//input[@id='project___name']")
	WebElement InputProjectERO;

	public void clickprojectField() {
		InputProjectERO.click();
	}

	@FindBy(xpath = "//input[@id='worker___fullName']")
	WebElement InputWorkerERO;

	public void clickWorkerField() {
		InputWorkerERO.click();
	}

	@FindBy(xpath = "//input[@id='job___name']")
	WebElement InputJobERO;

	public void clickJobField() {
		InputJobERO.click();
	}

	@FindBy(xpath = "//input[@id='rate']")
	WebElement InputrateERO;

	public void SetRateEro(String RateERO) {
		InputrateERO.click();
		InputrateERO.sendKeys(RateERO);
	}

	public void EditRateEro() {
		InputrateERO.click();
		InputrateERO.clear();
		InputrateERO.sendKeys("54");
	}

	@FindBy(xpath = "//label//span[contains(@class,'e-frame')]")
	WebElement checkActive;

	public void ClickActiveCheckbox() {
		checkActive.click();
	}

	@FindBy(xpath = "//button[@aria-label='Edit']")
	WebElement BtnEdit;

	public void clickEditButton() {
		BtnEdit.click();
	}

	@FindBy(xpath = "//span[text()='Expense rate overrides has been created']")
	WebElement ExpenseRateOvrCreateMsg;

	public String IsExpenseRateOvrCreated() {
		return ExpenseRateOvrCreateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Expense rate overrides has been updated']")
	WebElement ExpenseRateOvrUpdateMsg;

	public String IsExpenseRateOvrUpdated() {
		return ExpenseRateOvrUpdateMsg.getText();
	}

	@FindBy(xpath = "//span[text()='Expense rate overrides has been deleted']")
	WebElement ExpenseRateOvrDeleteMsg;

	public String IsExpenseRateOvrDeleted() {
		return ExpenseRateOvrDeleteMsg.getText();
	}

	@FindBy(xpath = "//button[@aria-label='Update']")
	WebElement BtnUpdate;

	public void clickUpdateButton() {
		BtnUpdate.click();
	}

	@FindBy(xpath = "//button[@aria-label='Delete']")
	WebElement BtnDelete;

	public void clickDeleteBTN() {
		BtnDelete.click();
	}
	
	@FindBy(xpath = "(//mat-option[@tabindex=\"0\"])[2]")
	WebElement clkIndex2Value;

	public void ClickIndex2Val() {
		clkIndex2Value.click();
	}

}
